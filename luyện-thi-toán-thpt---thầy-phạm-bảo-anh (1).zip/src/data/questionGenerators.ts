import { Grade, QuestionGenerated, TrueFalseStatement } from '../types/math';
import { normalizeQuestionContent, normalizeMathContent } from '../utils/mathNormalize';

function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randNonZero(min: number, max: number): number {
  let val = 0;
  while (val === 0) {
    val = randInt(min, max);
  }
  return val;
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function shuffle<T>(arr: T[]): T[] {
  const result = [...arr];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

// -------------------------------------------------------------
// QUESTION GENERATORS BY TOPIC
// -------------------------------------------------------------

export interface GeneratorDef {
  id: string;
  topicTitle: string;
  grade: Grade;
  generate: () => QuestionGenerated;
}

export const TOPIC_GENERATORS: Record<string, GeneratorDef> = {
  // 10-1: Mệnh đề phủ định
  '10-1': {
    id: '10-1',
    topicTitle: 'Phủ định mệnh đề chứa $\\forall, \\exists$',
    grade: 10,
    generate: () => {
      const a = randNonZero(-5, 5);
      const isForall = Math.random() > 0.5;
      const op = pick(['>', '<', '\\ge', '\\le']);
      const signStr = a > 0 ? `+ ${a}` : `- ${Math.abs(a)}`;

      const negOpMap: Record<string, string> = {
        '>': '\\le',
        '<': '\\ge',
        '\\ge': '<',
        '\\le': '>'
      };
      const negOp = negOpMap[op];

      const quant = isForall ? '\\forall' : '\\exists';
      const negQuant = isForall ? '\\exists' : '\\forall';

      const originalProp = `${quant} x \\in \\mathbb{R}, \\ x^2 ${signStr} ${op} 0`;
      const correctNeg = `${negQuant} x \\in \\mathbb{R}, \\ x^2 ${signStr} ${negOp} 0`;

      const w1 = `${quant} x \\in \\mathbb{R}, \\ x^2 ${signStr} ${negOp} 0`;
      const w2 = `${negQuant} x \\in \\mathbb{R}, \\ x^2 ${signStr} ${op} 0`;
      const w3 = `${negQuant} x \\in \\mathbb{R}, \\ x^2 ${signStr} = 0`;

      const tf: TrueFalseStatement[] = [
        {
          text: `Mệnh đề phủ định của $P$ chứa lượng từ "${negQuant === '\\exists' ? '\\exists' : '\\forall'}".`,
          isTrue: true,
          explanation: `Phủ định của lượng từ $\\${quant}$ là lượng từ $\\${negQuant}$.`
        },
        {
          text: `Mệnh đề phủ định của $P$ là $${quant} x \\in \\mathbb{R}, x^2 ${signStr} ${negOp} 0$.`,
          isTrue: false,
          explanation: `Sai vì chưa phủ định lượng từ $\\${quant}$ thành $\\${negQuant}$.`
        },
        {
          text: `Với $x = 0$, biểu thức $x^2 ${signStr}$ nhận giá trị bằng $${a}$.`,
          isTrue: true,
          explanation: `Thay $x = 0$ ta được $0^2 ${signStr} = ${a}$.`
        },
        {
          text: `Nếu $P$ là mệnh đề đúng thì phủ định $\\overline{P}$ cũng luôn là mệnh đề đúng.`,
          isTrue: false,
          explanation: `Theo định nghĩa, hai mệnh đề $P$ và $\\overline{P}$ có giá trị chân lí trái ngược nhau.`
        }
      ];

      return {
        id: `gen-10-1-${Date.now()}-${Math.random()}`,
        topicTitle: 'Phủ định mệnh đề chứa $\\forall, \\exists$',
        grade: 10,
        context: `Cho mệnh đề $P: "${originalProp}"$.`,
        ask: 'Tìm mệnh đề phủ định $\\overline{P}$ của mệnh đề $P$.',
        correctOption: `$${correctNeg}$`,
        distractors: [`$${w1}$`, `$${w2}$`, `$${w3}$`],
        tfStatements: tf,
        shortAnswer: `${a}`,
        shortAnswerPrompt: `Tính giá trị của biểu thức $x^2 ${signStr}$ tại $x = 0$.`,
        solution: `Phủ định của lượng từ $\\${quant}$ là $\\${negQuant}$; phủ định của quan hệ so sánh $${op}$ là $${negOp}$. Do đó mệnh đề phủ định là $\\overline{P}: "${correctNeg}"$.`
      };
    }
  },

  // 10-2: Tập hợp & Phép toán khoảng đoạn
  '10-2': {
    id: '10-2',
    topicTitle: 'Giao, hợp và hiệu các khoảng, đoạn',
    grade: 10,
    generate: () => {
      // Guarantee a < c < b < d strictly:
      const a = randInt(-6, -3);
      const c = randInt(-2, 1);
      const b = randInt(2, 5);
      const d = randInt(6, 9);

      // A = [a, b], B = (c, d)
      // Since a < c < b < d, intersection is strictly (c, b]
      const intersection = `(${c}; ${b}]`;
      const union = `[${a}; ${d})`;
      const diff = `[${a}; ${c}]`;

      const tf: TrueFalseStatement[] = [
        {
          text: `Tập hợp $A \\cap B = (${c}; ${b}]$.`,
          isTrue: true,
          explanation: `Vì $x \\in A \\cap B \\Leftrightarrow a \\le x \\le b$ và $c < x < d$, suy ra $c < x \\le b$.`
        },
        {
          text: `Số phần tử nguyên thuộc $A \\cap B$ là hữu hạn.`,
          isTrue: true,
          explanation: `Trong nửa khoảng $(c; b]$, số phần tử nguyên luôn là hữu hạn.`
        },
        {
          text: `Số $${d}$ thuộc tập hợp $B$.`,
          isTrue: false,
          explanation: `Khoảng $B = (${c}; ${d})$ là khoảng mở tại đầu mút $${d}$, nên $${d} \\notin B$.`
        },
        {
          text: `Tập hợp $A \\cup B = [${a}; ${d})$.`,
          isTrue: true,
          explanation: `Hợp của hai tập hợp là phần từ nhỏ nhất $${a}$ đến lớn nhất $${d}$.`
        }
      ];

      return normalizeQuestionContent({
        id: `gen-10-2-${Date.now()}`,
        topicTitle: 'Giao và hợp của khoảng, đoạn',
        grade: 10,
        context: `Cho hai tập hợp $A = [${a}; ${b}]$ và $B = (${c}; ${d})$.`,
        ask: 'Tìm tập hợp $A \\cap B$.',
        correctOption: `$(${c}; ${b}]$`,
        distractors: [`$[${a}; ${d})$`, `$[${a}; ${c}]$`, `$(${c}; ${d})$`],
        tfStatements: tf,
        shortAnswer: `${b - c}`,
        shortAnswerPrompt: `Tính độ dài khoảng giao $A \\cap B$ (lấy đầu mút phải trừ đầu mút trái: $b - c$):`,
        solution: `Biểu diễn trên trục số:\n- $A = [${a}; ${b}]$\n- $B = (${c}; ${d})$\nPhần chung của cả hai tập hợp là khoảng giao: $A \\cap B = (${c}; ${b}]$.`,
        diagram: { type: 'numberLine' }
      });
    }
  },

  // 10-5: Hệ thức lượng trong tam giác
  '10-5': {
    id: '10-5',
    topicTitle: 'Định lí côsin và diện tích tam giác',
    grade: 10,
    generate: () => {
      const b = randInt(4, 8);
      const c = randInt(5, 9);
      const angle = 60; // cos 60 = 0.5
      // a^2 = b^2 + c^2 - 2bc * cos 60 = b^2 + c^2 - bc
      const a2 = b * b + c * c - b * c;
      const S = (0.5 * b * c * Math.sqrt(3)) / 2;

      return {
        id: `gen-10-5-${Date.now()}`,
        topicTitle: 'Định lí côsin trong tam giác',
        grade: 10,
        context: `Tam giác $ABC$ có cạnh $b = AC = ${b}$, cạnh $c = AB = ${c}$ và góc $\\widehat{A} = 60^\\circ$.`,
        ask: 'Tính bình phương độ dài cạnh $a = BC$ ($a^2$).',
        correctOption: `$${a2}$`,
        distractors: [`$${a2 + 2 * b * c}$`, `$${b * b + c * c}$`, `$${a2 - 12}$`],
        tfStatements: [
          {
            text: `Theo định lí côsin, $a^2 = b^2 + c^2 - 2bc\\cos A$.`,
            isTrue: true,
            explanation: `Đây là công thức định lí côsin chuẩn trong tam giác.`
          },
          {
            text: `Giá trị $\\cos 60^\\circ = \\frac{\\sqrt{3}}{2}$.`,
            isTrue: false,
            explanation: `Sai, vì $\\cos 60^\\circ = \\frac{1}{2}$.`
          },
          {
            text: `Bình phương cạnh $BC$ là $a^2 = ${a2}$.`,
            isTrue: true,
            explanation: `Thay số: $a^2 = ${b}^2 + ${c}^2 - 2 \\cdot ${b} \\cdot ${c} \\cdot \\frac{1}{2} = ${a2}$.`
          },
          {
            text: `Diện tích tam giác $ABC$ tính theo công thức $S = \\frac{1}{2}bc\\sin A$.`,
            isTrue: true,
            explanation: `Đúng, $S = \\frac{1}{2} \\cdot ${b} \\cdot ${c} \\cdot \\sin 60^\\circ$.`
          }
        ],
        shortAnswer: `${a2}`,
        shortAnswerPrompt: `Nhập giá trị $BC^2$:`,
        solution: `Áp dụng định lí côsin:\n$$BC^2 = AB^2 + AC^2 - 2 \\cdot AB \\cdot AC \\cdot \\cos A$$\n$$BC^2 = ${c}^2 + ${b}^2 - 2 \\cdot ${c} \\cdot ${b} \\cdot \\cos 60^\\circ = ${c * c} + ${b * b} - ${b * c} = ${a2}.$$`
      };
    }
  },

  // 10-3: Bất phương trình bậc nhất hai ẩn
  '10-3': {
    id: '10-3',
    topicTitle: 'Điểm thuộc miền nghiệm bất phương trình',
    grade: 10,
    generate: () => {
      const a = randInt(1, 4);
      const b = randInt(1, 4);
      const c = randInt(5, 12);
      const x0 = randInt(1, 3);
      const y0 = randInt(1, 3);
      const val = a * x0 + b * y0;
      const isLe = val <= c;

      return normalizeQuestionContent({
        id: `gen-10-3-${Date.now()}`,
        topicTitle: 'Bất phương trình bậc nhất hai ẩn',
        grade: 10,
        context: `Cho bất phương trình $${a}x + ${b}y \\le ${c}$ và điểm $M(${x0}; ${y0})$.`,
        ask: `Khẳng định nào sau đây là đúng về điểm $M(${x0}; ${y0})$?`,
        correctOption: isLe ? `Điểm $M(${x0}; ${y0})$ thuộc miền nghiệm của bất phương trình.` : `Điểm $M(${x0}; ${y0})$ không thuộc miền nghiệm của bất phương trình.`,
        distractors: [
          isLe ? `Điểm $M(${x0}; ${y0})$ không thuộc miền nghiệm của bất phương trình.` : `Điểm $M(${x0}; ${y0})$ thuộc miền nghiệm của bất phương trình.`,
          `Điểm $M(${x0}; ${y0})$ luôn nằm trên đường thẳng biên $${a}x + ${b}y = ${c}$.`,
          `Bất phương trình đã cho vô nghiệm.`
        ],
        tfStatements: [
          {
            text: `Thay toạ độ $M(${x0}; ${y0})$ vào biểu thức $${a}x + ${b}y$ ta được giá trị bằng $${val}$.`,
            isTrue: true,
            explanation: `Tính $${a} \\cdot ${x0} + ${b} \\cdot ${y0} = ${val}$.`
          },
          {
            text: `Gốc toạ độ $O(0; 0)$ thuộc miền nghiệm của bất phương trình $${a}x + ${b}y \\le ${c}$.`,
            isTrue: 0 <= c,
            explanation: `Thay toạ độ $O(0; 0)$ được $0 \\le ${c}$ (đúng vì ${c} > 0$).`
          },
          {
            text: `Đường thẳng biên của miền nghiệm có phương trình là $${a}x + ${b}y = ${c}$.`,
            isTrue: true,
            explanation: `Đường thẳng biên tương ứng là $${a}x + ${b}y = ${c}$.`
          },
          {
            text: `Miền nghiệm của bất phương trình chứa vô số điểm.`,
            isTrue: true,
            explanation: `Miền nghiệm là nửa mặt phẳng chứa vô số điểm.`
          }
        ],
        shortAnswer: `${val}`,
        shortAnswerPrompt: `Tính giá trị của biểu thức $${a}x + ${b}y$ tại điểm $M(${x0}; ${y0})$:`,
        solution: `Thay toạ độ điểm $M(${x0}; ${y0})$ vào vế trái bất phương trình:\n$$${a} \\cdot (${x0}) + ${b} \\cdot (${y0}) = ${val}.$$\nSo sánh với $c = ${c}$: Vì $${val} ${isLe ? '\\le' : '>'} ${c}$ nên điểm $M$ ${isLe ? 'thuộc' : 'không thuộc'} miền nghiệm.`,
        diagram: { type: 'quadratic' }
      });
    }
  },

  // 10-6: Hệ thức lượng và Diện tích tam giác
  '10-6': {
    id: '10-6',
    topicTitle: 'Diện tích tam giác và Bán kính ngoại tiếp',
    grade: 10,
    generate: () => {
      const a = randInt(5, 8);
      const b = randInt(6, 9);
      // S = 1/2 * a * b * sin 30 = a*b/4
      const S = (a * b) / 4;
      return normalizeQuestionContent({
        id: `gen-10-6-${Date.now()}`,
        topicTitle: 'Diện tích tam giác',
        grade: 10,
        context: `Tam giác $ABC$ có cạnh $a = BC = ${a}$, $b = AC = ${b}$ và góc xen giữa $\\widehat{C} = 30^\\circ$.`,
        ask: 'Tính diện tích tam giác $ABC$.',
        correctOption: `$${S}$`,
        distractors: [`$${S * 2}$`, `$${(a * b) / 2}$`, `$${S + 3}$`],
        tfStatements: [
          {
            text: `Công thức diện tích tam giác là $S = \\frac{1}{2}ab\\sin C$.`,
            isTrue: true,
            explanation: `Đây là công thức diện tích tam giác biết 2 cạnh và góc kẹp giữa.`
          },
          {
            text: `Giá trị $\\sin 30^\\circ = \\frac{1}{2}$.`,
            isTrue: true,
            explanation: `Đúng, $\\sin 30^\\circ = 0.5$.`
          },
          {
            text: `Diện tích tam giác $ABC$ bằng $${S}$.`,
            isTrue: true,
            explanation: `Thay số: $S = \\frac{1}{2} \\cdot ${a} \\cdot ${b} \\cdot \\frac{1}{2} = ${S}$.`
          },
          {
            text: `Độ dài cạnh $c = AB$ tính theo định lí sin.`,
            isTrue: false,
            explanation: `Biết 2 cạnh và góc xen giữa tính cạnh thứ ba bằng định lí Côsin.`
          }
        ],
        shortAnswer: `${S}`,
        shortAnswerPrompt: `Nhập diện tích tam giác $S$:`,
        solution: `Áp dụng công thức tính diện tích tam giác:\n$$S = \\frac{1}{2} a b \\sin C = \\frac{1}{2} \\cdot ${a} \\cdot ${b} \\cdot \\sin 30^\\circ = \\frac{1}{2} \\cdot ${a} \\cdot ${b} \\cdot \\frac{1}{2} = ${S}.$$`
      });
    }
  },

  // 10-10: Vectơ trong mặt phẳng toạ độ
  '10-10': {
    id: '10-10',
    topicTitle: 'Toạ độ vectơ và Độ dài đoạn thẳng',
    grade: 10,
    generate: () => {
      const xA = randInt(-3, 2);
      const yA = randInt(-2, 3);
      const dx = randInt(3, 6);
      const dy = randInt(2, 5);
      const xB = xA + dx;
      const yB = yA + dy;
      const lenSq = dx * dx + dy * dy;

      return normalizeQuestionContent({
        id: `gen-10-10-${Date.now()}`,
        topicTitle: 'Toạ độ vectơ và độ dài',
        grade: 10,
        context: `Trong mặt phẳng toạ độ $Oxy$, cho hai điểm $A(${xA}; ${yA})$ và $B(${xB}; ${yB})$.`,
        ask: 'Tìm toạ độ của vectơ $\\vec{AB}$.',
        correctOption: `$\\vec{AB} = (${dx}; ${dy})$`,
        distractors: [
          `$\\vec{AB} = (${-dx}; ${-dy})$`,
          `$\\vec{AB} = (${xA + xB}; ${yA + yB})$`,
          `$\\vec{AB} = (${dy}; ${dx})$`
        ],
        tfStatements: [
          {
            text: `Toạ độ vectơ $\\vec{AB}$ là $(x_B - x_A; y_B - y_A) = (${dx}; ${dy})$.`,
            isTrue: true,
            explanation: `Lấy toạ độ điểm ngọn $B$ trừ toạ độ điểm gốc $A$.`
          },
          {
            text: `Bình phương độ dài đoạn thẳng $AB^2 = ${lenSq}$.`,
            isTrue: true,
            explanation: `$AB^2 = (${dx})^2 + (${dy})^2 = ${lenSq}$.`
          },
          {
            text: `Trung điểm của đoạn $AB$ có hoành độ là $x_I = ${((xA + xB) / 2).toFixed(1)}$.`,
            isTrue: true,
            explanation: `$x_I = \\frac{${xA} + ${xB}}{2} = ${((xA + xB) / 2).toFixed(1)}$.`
          },
          {
            text: `Vectơ đối của $\\vec{AB}$ là $\\vec{BA} = (${dx}; ${dy})$.`,
            isTrue: false,
            explanation: `Vectơ đối $\\vec{BA} = -\\vec{AB} = (${-dx}; ${-dy})$.`
          }
        ],
        shortAnswer: `${lenSq}`,
        shortAnswerPrompt: `Nhập giá trị $AB^2$:`,
        solution: `Toạ độ vectơ $\\vec{AB}$:\n$$\\vec{AB} = (x_B - x_A; y_B - y_A) = (${xB} - (${xA}); ${yB} - (${yA})) = (${dx}; ${dy}).$$\nĐộ dài: $AB = \\sqrt{(${dx})^2 + (${dy})^2} = \\sqrt{${lenSq}}$.`
      });
    }
  },

  // 10-11: Tích vô hướng của hai vectơ
  '10-11': {
    id: '10-11',
    topicTitle: 'Tích vô hướng và góc giữa hai vectơ',
    grade: 10,
    generate: () => {
      const u1 = randInt(-3, 4);
      const u2 = randInt(1, 4);
      const v1 = randInt(-2, 3);
      const v2 = randInt(-3, 3);
      const dot = u1 * v1 + u2 * v2;

      return normalizeQuestionContent({
        id: `gen-10-11-${Date.now()}`,
        topicTitle: 'Tích vô hướng của hai vectơ',
        grade: 10,
        context: `Cho hai vectơ $\\vec{u} = (${u1}; ${u2})$ và $\\vec{v} = (${v1}; ${v2})$.`,
        ask: 'Tính tích vô hướng $\\vec{u} \\cdot \\vec{v}$.',
        correctOption: `$${dot}$`,
        distractors: [`$${dot + 4}$`, `$${dot - 5}$`, `$${-dot}$`],
        tfStatements: [
          {
            text: `Công thức tích vô hướng toạ độ là $\\vec{u} \\cdot \\vec{v} = u_1 v_1 + u_2 v_2$.`,
            isTrue: true,
            explanation: `Đúng theo định lý biểu thức toạ độ của tích vô hướng.`
          },
          {
            text: `Giá trị tích vô hướng $\\vec{u} \\cdot \\vec{v} = ${dot}$.`,
            isTrue: true,
            explanation: `Tính $(${u1}) \\cdot (${v1}) + (${u2}) \\cdot (${v2}) = ${dot}$.`
          },
          {
            text: `Hai vectơ $\\vec{u}$ và $\\vec{v}$ vuông góc khi và chỉ khi $\\vec{u} \\cdot \\vec{v} = 0$.`,
            isTrue: true,
            explanation: `Đúng, điều kiện vuông góc là tích vô hướng bằng 0.`
          },
          {
            text: `Tích vô hướng của hai vectơ là một vectơ.`,
            isTrue: false,
            explanation: `Sai, tích vô hướng là một SỐ THỰC.`
          }
        ],
        shortAnswer: `${dot}`,
        shortAnswerPrompt: `Nhập giá trị $\\vec{u} \\cdot \\vec{v}$:`,
        solution: `Biểu thức toạ độ tích vô hướng:\n$$\\vec{u} \\cdot \\vec{v} = u_1 v_1 + u_2 v_2 = (${u1}) \\cdot (${v1}) + (${u2}) \\cdot (${v2}) = ${u1 * v1} + ${u2 * v2} = ${dot}.$$`
      });
    }
  },

  // 10-16: Hàm số bậc hai
  '10-16': {
    id: '10-16',
    topicTitle: 'Toạ độ đỉnh của Parabol y = ax² + bx + c',
    grade: 10,
    generate: () => {
      const a = pick([1, -1, 2]);
      const xv = randInt(-3, 3);
      const yv = randInt(-4, 5);
      // y = a(x - xv)^2 + yv = a(x^2 - 2*xv*x + xv^2) + yv = ax^2 - 2*a*xv*x + (a*xv^2 + yv)
      const b = -2 * a * xv;
      const c = a * xv * xv + yv;
      const bSign = b >= 0 ? `+ ${b}x` : `- ${Math.abs(b)}x`;
      const cSign = c >= 0 ? `+ ${c}` : `- ${Math.abs(c)}`;
      const formula = `${a === 1 ? '' : a === -1 ? '-' : a}x^2 ${bSign} ${cSign}`;

      return normalizeQuestionContent({
        id: `gen-10-16-${Date.now()}`,
        topicTitle: 'Đỉnh Parabol bậc hai',
        grade: 10,
        context: `Cho hàm số bậc hai $y = ${formula}$.`,
        ask: 'Tìm toạ độ đỉnh $I$ của đồ thị hàm số.',
        correctOption: `$I(${xv}; ${yv})$`,
        distractors: [
          `$I(${-xv}; ${yv})$`,
          `$I(${xv}; ${-yv})$`,
          `$I(${yv}; ${xv})$`
        ],
        tfStatements: [
          {
            text: `Trục đối xứng của parabol là đường thẳng $x = ${xv}$.`,
            isTrue: true,
            explanation: `Trục đối xứng $x = -\\frac{b}{2a} = ${xv}$.`
          },
          {
            text: `Tung độ đỉnh của parabol là $y_I = ${yv}$.`,
            isTrue: true,
            explanation: `Thay $x = ${xv}$ vào hàm số ta được $y = ${yv}$.`
          },
          {
            text: `Bề lõm của đồ thị quay lên trên nếu $a > 0$.`,
            isTrue: true,
            explanation: `Hệ số $a = ${a}$ quyết định hướng bề lõm parabol.`
          },
          {
            text: `Đồ thị hàm số cắt trục tung tại điểm có tung độ bằng $0$.`,
            isTrue: c === 0,
            explanation: `Giao với trục tung tại $x = 0 \\implies y = c = ${c}$.`
          }
        ],
        shortAnswer: `${xv}`,
        shortAnswerPrompt: `Nhập hoành độ đỉnh $x_I$:`,
        solution: `Hoành độ đỉnh:\n$$x_I = -\\frac{b}{2a} = -\\frac{${b}}{2 \\cdot (${a})} = ${xv}.$$\nThay $x_I = ${xv}$ vào hàm số:\n$$y_I = ${a} \\cdot (${xv})^2 + (${b}) \\cdot (${xv}) + (${c}) = ${yv}.$$\nVậy toạ độ đỉnh là $I(${xv}; ${yv})$.`,
        diagram: { type: 'quadratic', params: { a, b, c } }
      });
    }
  },

  // 10-17: Dấu của tam thức bậc hai
  '10-17': {
    id: '10-17',
    topicTitle: 'Tập nghiệm bất phương trình bậc hai',
    grade: 10,
    generate: () => {
      const x1 = randInt(-4, 0);
      const x2 = randInt(1, 5);
      // (x - x1)(x - x2) = x^2 - (x1+x2)x + x1*x2 < 0
      const b = -(x1 + x2);
      const c = x1 * x2;
      const bStr = b >= 0 ? `+ ${b}x` : `- ${Math.abs(b)}x`;
      const cStr = c >= 0 ? `+ ${c}` : `- ${Math.abs(c)}`;

      return normalizeQuestionContent({
        id: `gen-10-17-${Date.now()}`,
        topicTitle: 'Dấu tam thức bậc hai',
        grade: 10,
        context: `Cho bất phương trình $x^2 ${bStr} ${cStr} < 0$.`,
        ask: 'Tìm tập nghiệm $S$ của bất phương trình đã cho.',
        correctOption: `$S = (${x1}; ${x2})$`,
        distractors: [
          `$S = (-\\infty; ${x1}) \\cup (${x2}; +\\infty)$`,
          `$S = [${x1}; ${x2}]$`,
          `$S = (${-x2}; ${-x1})$`
        ],
        tfStatements: [
          {
            text: `Phương trình $x^2 ${bStr} ${cStr} = 0$ có hai nghiệm phân biệt là $x_1 = ${x1}$ và $x_2 = ${x2}$.`,
            isTrue: true,
            explanation: `Biệt thức $\\Delta = (${b})^2 - 4(${c}) > 0$, nghiệm là $${x1}$ và $${x2}$.`
          },
          {
            text: `Hệ số $a = 1 > 0$, theo quy tắc "trong trái ngoài cùng", tam thức mang dấu âm ở khoảng trong hai nghiệm.`,
            isTrue: true,
            explanation: `Trong khoảng hai nghiệm $(${x1}; ${x2})$, $f(x)$ trái dấu với $a=1 > 0$.`
          },
          {
            text: `Tập nghiệm của bất phương trình là khoảng mở $(${x1}; ${x2})$.`,
            isTrue: true,
            explanation: `Vì bất phương trình mang dấu $<$ nên không lấy hai đầu mút nghiệm.`
          },
          {
            text: `Bất phương trình đã cho vô nghiệm.`,
            isTrue: false,
            explanation: `Bất phương trình có tập nghiệm rõ ràng $(${x1}; ${x2})$.`
          }
        ],
        shortAnswer: `${x2 - x1}`,
        shortAnswerPrompt: `Nhập độ dài khoảng nghiệm $x_2 - x_1$:`,
        solution: `Tam thức $f(x) = x^2 ${bStr} ${cStr}$ có hai nghiệm phân biệt $x_1 = ${x1}, x_2 = ${x2}$ và hệ số $a = 1 > 0$.\nTheo quy tắc xét dấu "trong trái, ngoài cùng":\n$$f(x) < 0 \\iff ${x1} < x < ${x2}.$$\nVậy tập nghiệm $S = (${x1}; ${x2})$.`,
        diagram: { type: 'quadratic', params: { a: 1, b, c } }
      });
    }
  },

  // 10-21: Đường tròn trong mặt phẳng toạ độ
  '10-21': {
    id: '10-21',
    topicTitle: 'Tâm và bán kính đường tròn',
    grade: 10,
    generate: () => {
      const a = randInt(-3, 3);
      const b = randInt(-3, 3);
      const R = randInt(2, 6);
      const R2 = R * R;
      // x^2 + y^2 - 2ax - 2by + (a^2+b^2-R^2) = 0
      const c = a * a + b * b - R2;
      const termA = -2 * a >= 0 ? `+ ${-2 * a}x` : `- ${Math.abs(-2 * a)}x`;
      const termB = -2 * b >= 0 ? `+ ${-2 * b}y` : `- ${Math.abs(-2 * b)}y`;
      const termC = c >= 0 ? `+ ${c}` : `- ${Math.abs(c)}`;

      return normalizeQuestionContent({
        id: `gen-10-21-${Date.now()}`,
        topicTitle: 'Đường tròn Oxy',
        grade: 10,
        context: `Cho đường tròn $(C)$ có phương trình: $x^2 + y^2 ${termA} ${termB} ${termC} = 0$.`,
        ask: 'Tìm toạ độ tâm $I$ và bán kính $R$ của đường tròn $(C)$.',
        correctOption: `$I(${a}; ${b}), \\ R = ${R}$`,
        distractors: [
          `$I(${-a}; ${-b}), \\ R = ${R}$`,
          `$I(${a}; ${b}), \\ R = ${R2}$`,
          `$I(${-a}; ${-b}), \\ R = ${R2}$`
        ],
        tfStatements: [
          {
            text: `Tâm đường tròn là $I(${a}; ${b})$.`,
            isTrue: true,
            explanation: `Hoành độ $a = \\frac{-2a}{-2} = ${a}$, tung độ $b = \\frac{-2b}{-2} = ${b}$.`
          },
          {
            text: `Bán kính đường tròn là $R = ${R}$.`,
            isTrue: true,
            explanation: `$R = \\sqrt{a^2 + b^2 - c} = \\sqrt{${a * a} + ${b * b} - (${c})} = ${R}$.`
          },
          {
            text: `Điểm $I(${a}; ${b})$ nằm trên đường tròn $(C)$.`,
            isTrue: false,
            explanation: `Tâm đường tròn không thuộc đường tròn.`
          },
          {
            text: `Phương trình chính tắc là $(x ${a >= 0 ? `- ${a}` : `+ ${-a}`})^2 + (y ${b >= 0 ? `- ${b}` : `+ ${-b}`})^2 = ${R2}$.`,
            isTrue: true,
            explanation: `Dạng chính tắc: $(x - a)^2 + (y - b)^2 = R^2$.`
          }
        ],
        shortAnswer: `${R}`,
        shortAnswerPrompt: `Nhập bán kính $R$:`,
        solution: `Phương trình tổng quát $x^2 + y^2 - 2ax - 2by + c = 0$ có:\n- $a = ${a}, b = ${b}, c = ${c}$.\n- Tâm $I(${a}; ${b})$.\n- Bán kính $R = \\sqrt{a^2 + b^2 - c} = \\sqrt{${a * a} + ${b * b} - (${c})} = ${R}$.`,
        diagram: { type: 'circle' }
      });
    }
  },

  // 10-24: Hoán vị, chỉnh hợp và tổ hợp
  '10-24': {
    id: '10-24',
    topicTitle: 'Chọn nhóm không thứ tự (Tổ hợp)',
    grade: 10,
    generate: () => {
      const n = randInt(7, 12);
      const k = 3;
      // C_n^3 = n*(n-1)*(n-2)/6
      const C = (n * (n - 1) * (n - 2)) / 6;

      return normalizeQuestionContent({
        id: `gen-10-24-${Date.now()}`,
        topicTitle: 'Tổ hợp chập k của n',
        grade: 10,
        context: `Một lớp học có $${n}$ học sinh giỏi. Giáo viên cần chọn ra $3$ học sinh để thành lập đội tuyển thi học sinh giỏi (không phân biệt nhiệm vụ).`,
        ask: `Có bao nhiêu cách chọn ra $3$ học sinh từ $${n}$ học sinh giỏi?`,
        correctOption: `$${C}$ cách`,
        distractors: [
          `$${C * 6}$ cách`,
          `$${C + 10}$ cách`,
          `$${C - 5}$ cách`
        ],
        tfStatements: [
          {
            text: `Vì việc chọn học sinh không phân biệt thứ tự nhiệm vụ nên đây là bài toán tổ hợp.`,
            isTrue: true,
            explanation: `Chọn nhóm không thứ tự dùng tổ hợp $C_n^k$.`
          },
          {
            text: `Số cách chọn là $C_{${n}}^3 = \\frac{${n}!}{3!(${n}-3)!} = ${C}$.`,
            isTrue: true,
            explanation: `Tính $C_{${n}}^3 = \\frac{${n} \\cdot ${n - 1} \\cdot ${n - 2}}{6} = ${C}$.`
          },
          {
            text: `Nếu phân công rõ ràng 3 vị trí Trưởng đoàn, Phó đoàn và Thư ký thì số cách chọn là $A_{${n}}^3 = ${C * 6}$.`,
            isTrue: true,
            explanation: `Có thứ tự phân công dùng chỉnh hợp $A_{${n}}^3 = 3! \\cdot C_{${n}}^3 = ${C * 6}$.`
          },
          {
            text: `Số cách chọn luôn nhỏ hơn $10$.`,
            isTrue: false,
            explanation: `Sai, số cách chọn là $${C}$.`
          }
        ],
        shortAnswer: `${C}`,
        shortAnswerPrompt: `Nhập số cách chọn:`,
        solution: `Chọn $3$ học sinh từ $${n}$ học sinh không phân biệt thứ tự là tổ hợp chập $3$ của $${n}$ phần tử:\n$$C_{${n}}^3 = \\frac{${n}!}{3!(${n}-3)!} = \\frac{${n} \\cdot ${n - 1} \\cdot ${n - 2}}{3 \\cdot 2 \\cdot 1} = ${C} \\text{ cách}.$$`
      });
    }
  },

  // 10-26: Xác suất theo định nghĩa cổ điển
  '10-26': {
    id: '10-26',
    topicTitle: 'Xác suất lấy bi từ hộp',
    grade: 10,
    generate: () => {
      const red = randInt(4, 6);
      const blue = randInt(3, 5);
      const total = red + blue;
      // Pick 2 balls both red: C_red^2 / C_total^2
      const numRed = (red * (red - 1)) / 2;
      const numTotal = (total * (total - 1)) / 2;

      return normalizeQuestionContent({
        id: `gen-10-26-${Date.now()}`,
        topicTitle: 'Xác suất cổ điển',
        grade: 10,
        context: `Một hộp đựng $${red}$ quả cầu đỏ và $${blue}$ quả cầu xanh có cùng kích thước. Lấy ngẫu nhiên đồng thời $2$ quả cầu.`,
        ask: 'Tính xác suất để cả 2 quả cầu lấy ra đều có màu đỏ.',
        correctOption: `$P = \\frac{${numRed}}{${numTotal}}$`,
        distractors: [
          `$P = \\frac{${red}}{${total}}$`,
          `$P = \\frac{${numRed + 1}}{${numTotal}}$`,
          `$P = \\frac{${numRed}}{${numTotal + 5}}$`
        ],
        tfStatements: [
          {
            text: `Số phần tử của không gian mẫu là $n(\\Omega) = C_{${total}}^2 = ${numTotal}$.`,
            isTrue: true,
            explanation: `Lấy ngẫu nhiên $2$ quả cầu từ tổng số $${total}$ quả cầu là $C_{${total}}^2 = ${numTotal}$.`
          },
          {
            text: `Số cách chọn được 2 quả cầu đỏ là $n(A) = C_{${red}}^2 = ${numRed}$.`,
            isTrue: true,
            explanation: `Chọn 2 quả đỏ từ $${red}$ quả đỏ là $C_{${red}}^2 = ${numRed}$.`
          },
          {
            text: `Xác suất của biến cố là $P(A) = \\frac{n(A)}{n(\\Omega)} = \\frac{${numRed}}{${numTotal}}$.`,
            isTrue: true,
            explanation: `Định nghĩa cổ điển: $P(A) = \\frac{n(A)}{n(\\Omega)}$.`
          },
          {
            text: `Xác suất để có ít nhất một quả cầu xanh bằng $1 - P(A)$.`,
            isTrue: true,
            explanation: `Biến cố đối của "cả 2 quả đỏ" là "có ít nhất một quả xanh".`
          }
        ],
        shortAnswer: `${numRed}`,
        shortAnswerPrompt: `Nhập số cách chọn được 2 quả cầu đỏ ($n(A)$):`,
        solution: `- Không gian mẫu: $n(\\Omega) = C_{${total}}^2 = \\frac{${total} \\cdot ${total - 1}}{2} = ${numTotal}$.\n- Số kết quả thuận lợi cho biến cố $A$ ("cả 2 quả cầu màu đỏ"): $n(A) = C_{${red}}^2 = \\frac{${red} \\cdot ${red - 1}}{2} = ${numRed}$.\n- Xác suất: $P(A) = \\frac{n(A)}{n(\\Omega)} = \\frac{${numRed}}{${numTotal}}$.`
      });
    }
  },

  // 11-1: Giá trị lượng giác
  '11-1': {
    id: '11-1',
    topicTitle: 'Giá trị lượng giác của góc và công thức cộng',
    grade: 11,
    generate: () => {
      // sin x = 3/5 with x in (0, pi/2)
      const isFirstQuadrant = true;
      const sinVal = '3/5';
      const cosVal = '4/5';
      const sin2Val = '24/25';
      const cos2Val = '7/25';

      return {
        id: `gen-11-1-${Date.now()}`,
        topicTitle: 'Công thức góc nhân đôi lượng giác',
        grade: 11,
        context: `Cho góc $\\alpha$ thỏa mãn $\\sin \\alpha = \\frac{3}{5}$ với $0 < \\alpha < \\frac{\\pi}{2}$.`,
        ask: 'Tính giá trị của biểu thức $\\sin 2\\alpha$.',
        correctOption: `$\\frac{24}{25}$`,
        distractors: [`$\\frac{6}{5}$`, `$\\frac{7}{25}$`, `$\\frac{12}{25}$`],
        tfStatements: [
          {
            text: `Vì $0 < \\alpha < \\frac{\\pi}{2}$ nên $\\cos \\alpha > 0$.`,
            isTrue: true,
            explanation: `Góc phần tư thứ nhất có $\\cos > 0$ và $\\sin > 0$.`
          },
          {
            text: `Giá trị của $\\cos \\alpha = \\frac{4}{5}$.`,
            isTrue: true,
            explanation: `$\\cos \\alpha = \\sqrt{1 - \\sin^2 \\alpha} = \\sqrt{1 - (3/5)^2} = 4/5$.`
          },
          {
            text: `Công thức nhân đôi là $\\sin 2\\alpha = 2\\sin\\alpha\\cos\\alpha$.`,
            isTrue: true,
            explanation: `Đúng, công thức nhân đôi của sin.`
          },
          {
            text: `Giá trị của $\\cos 2\\alpha = -\\frac{7}{25}$.`,
            isTrue: false,
            explanation: `Sai vì $\\cos 2\\alpha = 1 - 2\\sin^2\\alpha = 1 - 2(9/25) = 7/25 > 0$.`
          }
        ],
        shortAnswer: '0.96',
        shortAnswerPrompt: `Nhập giá trị $\\sin 2\\alpha$ dưới dạng số thập phân:`,
        solution: `Vì $0 < \\alpha < \\frac{\\pi}{2}$ nên $\\cos \\alpha = \\sqrt{1 - \\sin^2 \\alpha} = \\sqrt{1 - \\frac{9}{25}} = \\frac{4}{5}$.\nTa có $\\sin 2\\alpha = 2\\sin\\alpha\\cos\\alpha = 2 \\cdot \\frac{3}{5} \\cdot \\frac{4}{5} = \\frac{24}{25} = 0{,}96$.`,
        diagram: { type: 'trig' }
      };
    }
  },

  // 11-6: Cấp số cộng
  '11-6': {
    id: '11-6',
    topicTitle: 'Cấp số cộng và tổng n số hạng đầu',
    grade: 11,
    generate: () => {
      const u1 = randInt(1, 5);
      const d = randInt(2, 5);
      const n = randInt(8, 12);
      const un = u1 + (n - 1) * d;
      const Sn = (n * (2 * u1 + (n - 1) * d)) / 2;

      return {
        id: `gen-11-6-${Date.now()}`,
        topicTitle: 'Cấp số cộng',
        grade: 11,
        context: `Cho cấp số cộng $(u_n)$ có số hạng đầu $u_1 = ${u1}$ và công sai $d = ${d}$.`,
        ask: `Tính số hạng thứ $${n}$ ($u_{${n}}$) của cấp số cộng.`,
        correctOption: `$${un}$`,
        distractors: [`$${un + d}$`, `$${un - 2 * d}$`, `$${u1 * n * d}$`],
        tfStatements: [
          {
            text: `Công sai của cấp số cộng là $d = ${d}$.`,
            isTrue: true,
            explanation: `Theo đề bài, $d = ${d}$.`
          },
          {
            text: `Số hạng tổng quát là $u_n = u_1 + nd$.`,
            isTrue: false,
            explanation: `Sai, công thức đúng là $u_n = u_1 + (n - 1)d$.`
          },
          {
            text: `Số hạng thứ ba là $u_3 = ${u1 + 2 * d}$.`,
            isTrue: true,
            explanation: `$u_3 = ${u1} + 2 \\cdot ${d} = ${u1 + 2 * d}$.`
          },
          {
            text: `Tổng của $${n}$ số hạng đầu là $S_{${n}} = ${Sn}$.`,
            isTrue: true,
            explanation: `$S_{${n}} = \\frac{${n}(${u1} + ${un})}{2} = ${Sn}$.`
          }
        ],
        shortAnswer: `${un}`,
        shortAnswerPrompt: `Nhập giá trị của $u_{${n}}$:`,
        solution: `Áp dụng công thức số hạng tổng quát của cấp số cộng:\n$$u_n = u_1 + (n - 1)d$$\nVới $n = ${n}$, ta có:\n$$u_{${n}} = ${u1} + (${n} - 1) \\cdot ${d} = ${u1} + ${n - 1} \\cdot ${d} = ${un}.$$`
      };
    }
  },

  // 11-2: Công thức lượng giác
  '11-2': {
    id: '11-2',
    topicTitle: 'Công thức hạ bậc và nhân đôi lượng giác',
    grade: 11,
    generate: () => {
      const cosVal = pick(['1/2', '1/3', '1/4']);
      const cosNum = cosVal === '1/2' ? 1 : cosVal === '1/3' ? 1 : 1;
      const cosDen = cosVal === '1/2' ? 2 : cosVal === '1/3' ? 3 : 4;
      // cos 2a = 2 cos^2 a - 1 = 2*(cosNum^2)/(cosDen^2) - 1
      const num2 = 2 * cosNum * cosNum - cosDen * cosDen;
      const den2 = cosDen * cosDen;
      const resStr = `${num2}/${den2}`;

      return normalizeQuestionContent({
        id: `gen-11-2-${Date.now()}`,
        topicTitle: 'Công thức nhân đôi',
        grade: 11,
        context: `Cho góc $\\alpha$ thoả mãn $\\cos \\alpha = \\frac{${cosNum}}{${cosDen}}$.`,
        ask: 'Tính giá trị của biểu thức $\\cos 2\\alpha$.',
        correctOption: `$\\frac{${num2}}{${den2}}$`,
        distractors: [
          `$\\frac{${num2 + 2}}{${den2}}$`,
          `$\\frac{${-num2}}{${den2}}$`,
          `$\\frac{${cosNum * 2}}{${cosDen}}$`
        ],
        tfStatements: [
          {
            text: `Công thức nhân đôi của hàm côsin là $\\cos 2\\alpha = 2\\cos^2\\alpha - 1$.`,
            isTrue: true,
            explanation: `Đúng, công thức nhân đôi: $\\cos 2\\alpha = 2\\cos^2\\alpha - 1 = 1 - 2\\sin^2\\alpha$.`
          },
          {
            text: `Giá trị của $\\cos^2\\alpha$ bằng $\\frac{${cosNum * cosNum}}{${den2}}$.`,
            isTrue: true,
            explanation: `$(\\frac{${cosNum}}{${cosDen}})^2 = \\frac{${cosNum * cosNum}}{${den2}}$.`
          },
          {
            text: `Giá trị $\\cos 2\\alpha$ luôn dương với mọi góc $\\alpha$.`,
            isTrue: false,
            explanation: `Sai, ví dụ $\\alpha = 60^\\circ$ thì $\\cos 120^\\circ = -0.5 < 0$.`
          },
          {
            text: `Biểu thức $\\sin^2\\alpha = 1 - \\cos^2\\alpha = \\frac{${den2 - cosNum * cosNum}}{${den2}}$.`,
            isTrue: true,
            explanation: `Hệ thức lượng giác cơ bản: $\\sin^2\\alpha + \\cos^2\\alpha = 1$.`
          }
        ],
        shortAnswer: `${num2}/${den2}`,
        shortAnswerPrompt: `Nhập phân số tối giản $\\cos 2\\alpha$:`,
        solution: `Áp dụng công thức nhân đôi:\n$$\\cos 2\\alpha = 2\\cos^2\\alpha - 1 = 2 \\cdot \\left(\\frac{${cosNum}}{${cosDen}}\\right)^2 - 1 = 2 \\cdot \\frac{${cosNum * cosNum}}{${den2}} - 1 = \\frac{${num2}}{${den2}}.$$`,
        diagram: { type: 'trig' }
      });
    }
  },

  // 11-4: Phương trình lượng giác cơ bản
  '11-4': {
    id: '11-4',
    topicTitle: 'Số nghiệm phương trình lượng giác',
    grade: 11,
    generate: () => {
      return normalizeQuestionContent({
        id: `gen-11-4-${Date.now()}`,
        topicTitle: 'Phương trình lượng giác cơ bản',
        grade: 11,
        context: `Cho phương trình $\\sin x = \\frac{1}{2}$ trên đoạn $[0; 2\\pi]$.`,
        ask: 'Phương trình đã cho có bao nhiêu nghiệm trên đoạn $[0; 2\\pi]$?',
        correctOption: '2 nghiệm',
        distractors: ['1 nghiệm', '3 nghiệm', '4 nghiệm'],
        tfStatements: [
          {
            text: `Nghiệm cơ bản của phương trình là $x = \\frac{\\pi}{6}$ và $x = \\frac{5\\pi}{6}$.`,
            isTrue: true,
            explanation: `$\\sin x = \\sin(\\pi/6) \\iff x = \\pi/6 + k2\\pi$ hoặc $x = 5\\pi/6 + k2\\pi$.`
          },
          {
            text: `Tập giá trị của hàm số $y = \\sin x$ là $[-1; 1]$.`,
            isTrue: true,
            explanation: `Vì $|\\sin x| \\le 1$ nên phương trình $\\sin x = 1/2$ có nghiệm.`
          },
          {
            text: `Tổng các nghiệm của phương trình trên $[0; 2\\pi]$ bằng $\\pi$.`,
            isTrue: true,
            explanation: `$\\pi/6 + 5\\pi/6 = \\pi$.`
          },
          {
            text: `Phương trình có vô số nghiệm trên khoảng $(0; \\pi)$.`,
            isTrue: false,
            explanation: `Chỉ có đúng 2 nghiệm trên $(0; \\pi)$.`
          }
        ],
        shortAnswer: '2',
        shortAnswerPrompt: 'Nhập số nghiệm của phương trình:',
        solution: `Ta có $\\sin x = \\frac{1}{2} = \\sin\\frac{\\pi}{6} \\iff \\begin{cases} x = \\frac{\\pi}{6} + k2\\pi \\\\ x = \\frac{5\\pi}{6} + k2\\pi \\end{cases} \\, (k \\in \\mathbb{Z})$.\nVì $x \\in [0; 2\\pi]$ nên ta có 2 nghiệm thoả mãn: $x_1 = \\frac{\\pi}{6}$ (với $k=0$) và $x_2 = \\frac{5\\pi}{6}$ (với $k=0$).`,
        diagram: { type: 'trig' }
      });
    }
  },

  // 11-7: Cấp số nhân
  '11-7': {
    id: '11-7',
    topicTitle: 'Cấp số nhân và số hạng tổng quát',
    grade: 11,
    generate: () => {
      const u1 = randInt(2, 4);
      const q = randInt(2, 3);
      const n = randInt(4, 5);
      const un = u1 * Math.pow(q, n - 1);
      const Sn = (u1 * (Math.pow(q, n) - 1)) / (q - 1);

      return normalizeQuestionContent({
        id: `gen-11-7-${Date.now()}`,
        topicTitle: 'Cấp số nhân',
        grade: 11,
        context: `Cho cấp số nhân $(u_n)$ có số hạng đầu $u_1 = ${u1}$ và công bội $q = ${q}$.`,
        ask: `Tìm số hạng thứ $${n}$ ($u_{${n}}$) của cấp số nhân.`,
        correctOption: `$${un}$`,
        distractors: [`$${un * q}$`, `$${u1 + (n - 1) * q}$`, `$${un - u1}$`],
        tfStatements: [
          {
            text: `Công thức số hạng tổng quát của cấp số nhân là $u_n = u_1 \\cdot q^{n-1}$.`,
            isTrue: true,
            explanation: `Đúng, $u_n = u_1 \\cdot q^{n-1}$.`
          },
          {
            text: `Số hạng thứ hai là $u_2 = ${u1 * q}$.`,
            isTrue: true,
            explanation: `$u_2 = u_1 \\cdot q = ${u1} \\cdot ${q} = ${u1 * q}$.`
          },
          {
            text: `Tổng của $${n}$ số hạng đầu tiên là $S_{${n}} = ${Sn}$.`,
            isTrue: true,
            explanation: `$S_{${n}} = ${u1} \\cdot \\frac{${q}^{${n}} - 1}{${q} - 1} = ${Sn}$.`
          },
          {
            text: `Ba số $u_1, u_2, u_3$ lập thành một cấp số cộng.`,
            isTrue: false,
            explanation: `Chúng lập thành cấp số nhân chứ không phải cấp số cộng.`
          }
        ],
        shortAnswer: `${un}`,
        shortAnswerPrompt: `Nhập giá trị $u_{${n}}$:`,
        solution: `Áp dụng công thức số hạng tổng quát cấp số nhân:\n$$u_{${n}} = u_1 \\cdot q^{${n}-1} = ${u1} \\cdot ${q}^{${n - 1}} = ${un}.$$`,
        diagram: { type: 'numberLine' }
      });
    }
  },

  // 11-15: Giới hạn dãy số
  '11-15': {
    id: '11-15',
    topicTitle: 'Giới hạn của dãy số hữu tỉ',
    grade: 11,
    generate: () => {
      const a = randInt(2, 6);
      const b = randInt(1, 5);
      const c = randInt(2, 4);
      const d = randInt(1, 5);
      // lim (a*n + b) / (c*n + d) = a / c
      return normalizeQuestionContent({
        id: `gen-11-15-${Date.now()}`,
        topicTitle: 'Giới hạn dãy số',
        grade: 11,
        context: `Cho dãy số $(u_n)$ có số hạng tổng quát $u_n = \\frac{${a}n + ${b}}{${c}n + ${d}}$.`,
        ask: 'Tính giới hạn $L = \\lim_{n \\to +\\infty} u_n$.',
        correctOption: `$L = \\frac{${a}}{${c}}$`,
        distractors: [
          `$L = \\frac{${b}}{${d}}$`,
          `$L = +\\infty$`,
          `$L = 0$`
        ],
        tfStatements: [
          {
            text: `Bậc cao nhất ở cả tử và mẫu là bậc 1 theo biến $n$.`,
            isTrue: true,
            explanation: `Tử số là bậc 1, mẫu số là bậc 1.`
          },
          {
            text: `Chia cả tử và mẫu cho $n$, ta được biểu thức $\\frac{${a} + ${b}/n}{${c} + ${d}/n}$.`,
            isTrue: true,
            explanation: `Quy tắc chia cho luỹ thừa bậc cao nhất.`
          },
          {
            text: `Giới hạn $\\lim \\frac{1}{n} = 0$.`,
            isTrue: true,
            explanation: `Giới hạn cơ bản $\\lim 1/n = 0$.`
          },
          {
            text: `Dãy số $(u_n)$ là một cấp số cộng.`,
            isTrue: false,
            explanation: `Dãy phân thức không phải là cấp số cộng.`
          }
        ],
        shortAnswer: `${(a / c).toFixed(2)}`,
        shortAnswerPrompt: `Nhập giá trị $L$ làm tròn đến 2 chữ số thập phân:`,
        solution: `Chia cả tử và mẫu cho $n$:\n$$L = \\lim_{n \\to +\\infty} \\frac{${a}n + ${b}}{${c}n + ${d}} = \\lim_{n \\to +\\infty} \\frac{${a} + \\frac{${b}}{n}}{${c} + \\frac{${d}}{n}} = \\frac{${a} + 0}{${c} + 0} = \\frac{${a}}{${c}}.$$`,
        diagram: { type: 'numberLine' }
      });
    }
  },

  // 11-16: Giới hạn hàm số dạng 0/0
  '11-16': {
    id: '11-16',
    topicTitle: 'Giới hạn hàm số khử dạng vô định 0/0',
    grade: 11,
    generate: () => {
      const x0 = randInt(1, 3);
      const a = randInt(2, 4);
      // (x - x0)(x + a) / (x - x0) = x + a -> limit = x0 + a
      const L = x0 + a;
      const bCoeff = a - x0;
      const cCoeff = -a * x0;
      const numExpr = `x^2 ${bCoeff >= 0 ? `+ ${bCoeff}x` : `${bCoeff}x`} ${cCoeff >= 0 ? `+ ${cCoeff}` : `${cCoeff}`}`;

      return normalizeQuestionContent({
        id: `gen-11-16-${Date.now()}`,
        topicTitle: 'Giới hạn hàm số dạng 0/0',
        grade: 11,
        context: `Cho giới hạn $L = \\lim_{x \\to ${x0}} \\frac{${numExpr}}{x - ${x0}}$.`,
        ask: 'Tính giá trị của giới hạn $L$.',
        correctOption: `$${L}$`,
        distractors: [`$0$`, `$${L + 2}$`, `$+\\infty$`],
        tfStatements: [
          {
            text: `Khi thay $x = ${x0}$, cả tử số và mẫu số đều bằng 0 (dạng vô định $0/0$).`,
            isTrue: true,
            explanation: `Tử số: $(${x0})^2 + (${bCoeff})(${x0}) + (${cCoeff}) = 0$, mẫu số: $0$.`
          },
          {
            text: `Tử số phân tích thành nhân tử là $(x - ${x0})(x + ${a})$.`,
            isTrue: true,
            explanation: `$(x - ${x0})(x + ${a}) = x^2 + (${a} - ${x0})x - ${x0 * a}$.`
          },
          {
            text: `Rút gọn nhân tử chung $(x - ${x0})$ ta được $\\lim_{x \\to ${x0}} (x + ${a})$.`,
            isTrue: true,
            explanation: `Triệt tiêu dạng vô định $0/0$.`
          },
          {
            text: `Giá trị của giới hạn không tồn tại.`,
            isTrue: false,
            explanation: `Giới hạn hữu hạn tồn tại và bằng ${L}.`
          }
        ],
        shortAnswer: `${L}`,
        shortAnswerPrompt: 'Nhập giá trị của giới hạn $L$:',
        solution: `Phân tích đa thức ở tử số thành nhân tử:\n$$${numExpr} = (x - ${x0})(x + ${a})$$\nThay vào giới hạn:\n$$L = \\lim_{x \\to ${x0}} \\frac{(x - ${x0})(x + ${a})}{x - ${x0}} = \\lim_{x \\to ${x0}} (x + ${a}) = ${x0} + ${a} = ${L}.$$`,
        diagram: { type: 'rational', params: { a: 1, b: 0, c: 1, d: 0 } }
      });
    }
  },

  // 11-19: Lôgarit
  '11-19': {
    id: '11-19',
    topicTitle: 'Biến đổi biểu thức và định nghĩa lôgarit',
    grade: 11,
    generate: () => {
      const a = pick([2, 3, 5]);
      const k = randInt(2, 4);
      const b = Math.pow(a, k);

      return normalizeQuestionContent({
        id: `gen-11-19-${Date.now()}`,
        topicTitle: 'Tính giá trị lôgarit',
        grade: 11,
        context: `Cho $a = ${a}$ và $b = ${b}$.`,
        ask: `Tính giá trị của biểu thức $P = \\log_{${a}} ${b}$.`,
        correctOption: `$${k}$`,
        distractors: [`$${k + 1}$`, `$${k - 1}$`, `$${Math.round(b / a)}$`],
        tfStatements: [
          {
            text: `Định nghĩa lôgarit: $\\log_a b = c \\iff a^c = b$ ($a > 0, a \\ne 1, b > 0$).`,
            isTrue: true,
            explanation: `Đúng theo định nghĩa cơ bản của lôgarit.`
          },
          {
            text: `Số $${b}$ có thể viết dưới dạng $${a}^{${k}}$.`,
            isTrue: true,
            explanation: `$${a}^{${k}} = ${b}$.`
          },
          {
            text: `Công thức $\\log_a (a^k) = k$.`,
            isTrue: true,
            explanation: `Tính chất luỹ thừa của lôgarit.`
          },
          {
            text: `Biểu thức $\\log_{${a}} (${b} \\cdot ${a}) = ${k + 2}$.`,
            isTrue: false,
            explanation: `Sai vì $\\log_{${a}} (${b} \\cdot ${a}) = \\log_{${a}} ${b} + 1 = ${k} + 1 = ${k + 1}$.`
          }
        ],
        shortAnswer: `${k}`,
        shortAnswerPrompt: `Nhập giá trị của $P$:`,
        solution: `Ta có $${b} = ${a}^{${k}}$.\nTheo tính chất lôgarit:\n$$P = \\log_{${a}} ${b} = \\log_{${a}} (${a}^{${k}}) = ${k}.$$`,
        diagram: { type: 'numberLine' }
      });
    }
  },

  // 11-21: Phương trình mũ và lôgarit
  '11-21': {
    id: '11-21',
    topicTitle: 'Phương trình mũ cơ bản',
    grade: 11,
    generate: () => {
      const a = pick([2, 3, 5]);
      const expAns = randInt(2, 4);
      const b = Math.pow(a, expAns);
      const c = randInt(1, 3);
      // a^(x + c) = b -> x + c = expAns -> x = expAns - c
      const xSol = expAns - c;

      return normalizeQuestionContent({
        id: `gen-11-21-${Date.now()}`,
        topicTitle: 'Phương trình mũ',
        grade: 11,
        context: `Cho phương trình $${a}^{x + ${c}} = ${b}$.`,
        ask: 'Tìm nghiệm của phương trình đã cho.',
        correctOption: `$x = ${xSol}$`,
        distractors: [`$x = ${xSol + 2}$`, `$x = ${xSol - 1}$`, `$x = ${expAns}$`],
        tfStatements: [
          {
            text: `Số $${b}$ được phân tích thành cơ số $${a}$ là $${b} = ${a}^{${expAns}}$.`,
            isTrue: true,
            explanation: `$${a}^{${expAns}} = ${b}$.`
          },
          {
            text: `Phương trình tương đương với phương trình bậc nhất $x + ${c} = ${expAns}$.`,
            isTrue: true,
            explanation: `Đưa về cùng cơ số $${a}$.`
          },
          {
            text: `Hàm số $y = ${a}^x$ là hàm số đồng biến trên $\\mathbb{R}$ vì cơ số $${a} > 1$.`,
            isTrue: true,
            explanation: `Cơ số lớn hơn 1 thì hàm mũ đồng biến.`
          },
          {
            text: `Phương trình đã cho có hai nghiệm phân biệt.`,
            isTrue: false,
            explanation: `Phương trình mũ cơ bản có nghiệm duy nhất.`
          }
        ],
        shortAnswer: `${xSol}`,
        shortAnswerPrompt: 'Nhập nghiệm $x$ của phương trình:',
        solution: `Đưa hai vế về cùng cơ số $${a}$:\n$$${a}^{x + ${c}} = ${b} \\iff ${a}^{x + ${c}} = ${a}^{${expAns}} \\iff x + ${c} = ${expAns} \\iff x = ${expAns} - ${c} = ${xSol}.$$`,
        diagram: { type: 'numberLine' }
      });
    }
  },

  // 11-27: Thể tích khối chóp
  '11-27': {
    id: '11-27',
    topicTitle: 'Thể tích khối chóp tứ giác đều',
    grade: 11,
    generate: () => {
      const a = randInt(3, 6);
      const h = randInt(3, 9);
      // S_day = a^2, V = 1/3 * a^2 * h
      const Sday = a * a;
      const V = (Sday * h) / 3;

      return normalizeQuestionContent({
        id: `gen-11-27-${Date.now()}`,
        topicTitle: 'Thể tích khối chóp',
        grade: 11,
        context: `Cho hình chóp $S.ABCD$ có đáy $ABCD$ là hình vuông cạnh $a = ${a}$, chiều cao $h = SO = ${h}$.`,
        ask: 'Tính thể tích khối chóp $S.ABCD$.',
        correctOption: `$V = ${V}$`,
        distractors: [`$V = ${V * 3}$`, `$V = ${V + 4}$`, `$V = ${Math.round((Sday * h) / 2)}$`],
        tfStatements: [
          {
            text: `Công thức thể tích khối chóp là $V = \\frac{1}{3} S_{\\text{đáy}} \\cdot h$.`,
            isTrue: true,
            explanation: `Đúng, công thức thể tích chóp có hệ số $1/3$.`
          },
          {
            text: `Diện tích đáy $ABCD$ là $S_{\\text{đáy}} = ${a}^2 = ${Sday}$.`,
            isTrue: true,
            explanation: `Hình vuông cạnh ${a} có diện tích là ${a}^2 = ${Sday}$.`
          },
          {
            text: `Thể tích khối lăng trụ có cùng đáy và chiều cao gấp 3 lần thể tích khối chóp này.`,
            isTrue: true,
            explanation: `$V_{\\text{lăng trụ}} = S \\cdot h = 3 V_{\\text{chóp}}$.`
          },
          {
            text: `Thể tích khối chóp luôn đo bằng đơn vị góc rađian.`,
            isTrue: false,
            explanation: `Thể tích đo bằng đơn vị khối (ví dụ: $cm^3, m^3$).`
          }
        ],
        shortAnswer: `${V}`,
        shortAnswerPrompt: 'Nhập thể tích khối chóp $V$:',
        solution: `Diện tích đáy hình vuông:\n$$S_{\\text{đáy}} = ${a}^2 = ${Sday}.$$\nThể tích khối chóp $S.ABCD$:\n$$V = \\frac{1}{3} S_{\\text{đáy}} \\cdot h = \\frac{1}{3} \\cdot ${Sday} \\cdot ${h} = ${V}.$$`,
        diagram: { type: 'pyramid' }
      });
    }
  },

  // 11-30: Nhân xác suất biến cố độc lập
  '11-30': {
    id: '11-30',
    topicTitle: 'Công thức nhân xác suất cho biến cố độc lập',
    grade: 11,
    generate: () => {
      // P(A) = 0.8, P(B) = 0.7
      const p1 = 0.8;
      const p2 = 0.7;
      const pBoth = Number((p1 * p2).toFixed(2));
      const pNone = Number(((1 - p1) * (1 - p2)).toFixed(2));
      const pAtLeastOne = Number((1 - pNone).toFixed(2));

      return normalizeQuestionContent({
        id: `gen-11-30-${Date.now()}`,
        topicTitle: 'Xác suất độc lập',
        grade: 11,
        context: `Hai xạ thủ $A$ và $B$ độc lập cùng bắn vào một tấm bia mục tiêu. Xác suất bắn trúng bia của xạ thủ $A$ là $0{,}8$; của xạ thủ $B$ là $0{,}7$.`,
        ask: 'Tính xác suất để cả hai xạ thủ đều bắn trúng bia.',
        correctOption: `$0{,}56$`,
        distractors: [`$0{,}50$`, `$0{,}94$`, `$0{,}15$`],
        tfStatements: [
          {
            text: `Hai biến cố bắn trúng của $A$ và $B$ là hai biến cố độc lập.`,
            isTrue: true,
            explanation: `Hai người bắn độc lập không ảnh hưởng lẫn nhau.`
          },
          {
            text: `Xác suất cả hai cùng trúng là $P(AB) = P(A) \\cdot P(B) = 0{,}8 \\cdot 0{,}7 = 0{,}56$.`,
            isTrue: true,
            explanation: `Công thức nhân xác suất cho biến cố độc lập.`
          },
          {
            text: `Xác suất để cả hai người đều bắn trượt là $0{,}06$.`,
            isTrue: true,
            explanation: `$(1 - 0{,}8) \\cdot (1 - 0{,}7) = 0{,}2 \\cdot 0{,}3 = 0{,}06$.`
          },
          {
            text: `Xác suất để có ít nhất một người bắn trúng bia là $0{,}56$.`,
            isTrue: false,
            explanation: `Xác suất có ít nhất một người trúng là $1 - 0{,}06 = 0{,}94$.`
          }
        ],
        shortAnswer: '0.56',
        shortAnswerPrompt: 'Nhập xác suất cả 2 xạ thủ cùng bắn trúng:',
        solution: `Gọi $A$ là biến cố "Xạ thủ $A$ bắn trúng", $B$ là biến cố "Xạ thủ $B$ bắn trúng".\nVì $A$ và $B$ là hai biến cố độc lập nên xác suất cả hai cùng bắn trúng là:\n$$P(AB) = P(A) \\cdot P(B) = 0{,}8 \\cdot 0{,}7 = 0{,}56.$$`,
        diagram: { type: 'numberLine' }
      });
    }
  },

  // 11-31: Ý nghĩa hình học đạo hàm (tiếp tuyến)
  '11-31': {
    id: '11-31',
    topicTitle: 'Hệ số góc tiếp tuyến của đồ thị hàm số',
    grade: 11,
    generate: () => {
      // y = x^2 - 2x + 1, y' = 2x - 2, at x0 = 3 -> y'(3) = 4
      const x0 = randInt(2, 4);
      const a = randInt(1, 2);
      // y = a*x^2 + 1, y' = 2*a*x -> k = 2*a*x0
      const k = 2 * a * x0;

      return normalizeQuestionContent({
        id: `gen-11-31-${Date.now()}`,
        topicTitle: 'Tiếp tuyến của parabol',
        grade: 11,
        context: `Cho hàm số $y = ${a > 1 ? a : ''}x^2 + 1$ có đồ thị $(P)$.`,
        ask: `Tính hệ số góc của tiếp tuyến của $(P)$ tại điểm có hoành độ $x_0 = ${x0}$.`,
        correctOption: `$k = ${k}$`,
        distractors: [`$k = ${k + 2}$`, `$k = ${k - 2}$`, `$k = ${a * x0}$`],
        tfStatements: [
          {
            text: `Đạo hàm của hàm số đã cho là $y' = ${2 * a}x$.`,
            isTrue: true,
            explanation: `$(ax^2 + 1)' = 2ax$.`
          },
          {
            text: `Hệ số góc của tiếp tuyến tại tiếp điểm có hoành độ $x_0$ bằng $k = y'(x_0)$.`,
            isTrue: true,
            explanation: `Ý nghĩa hình học của đạo hàm: $k = f'(x_0)$.`
          },
          {
            text: `Tung độ tiếp điểm là $y_0 = ${a * x0 * x0 + 1}$.`,
            isTrue: true,
            explanation: `$y_0 = ${a} \\cdot (${x0})^2 + 1 = ${a * x0 * x0 + 1}$.`
          },
          {
            text: `Tiếp tuyến của đồ thị luôn vuông góc với trục hoành.`,
            isTrue: false,
            explanation: `Hệ số góc $k = ${k} \\ne \\pm\\infty$ nên tiếp tuyến không vuông góc với $Ox$.`
          }
        ],
        shortAnswer: `${k}`,
        shortAnswerPrompt: 'Nhập giá trị hệ số góc $k$:',
        solution: `Ta có đạo hàm: $y' = ${2 * a}x$.\nHệ số góc của tiếp tuyến tại điểm có hoành độ $x_0 = ${x0}$ là:\n$$k = y'(${x0}) = ${2 * a} \\cdot ${x0} = ${k}.$$`,
        diagram: { type: 'quadratic' }
      });
    }
  },

  // 11-32: Quy tắc tính đạo hàm
  '11-32': {
    id: '11-32',
    topicTitle: 'Đạo hàm của hàm phân thức bậc nhất trên bậc nhất',
    grade: 11,
    generate: () => {
      const a = randInt(2, 4);
      const b = randInt(1, 3);
      // y = (ax + b)/(x + 1) -> y' = (a*1 - b*1)/(x+1)^2 = (a - b)/(x+1)^2
      const det = a - b;

      return normalizeQuestionContent({
        id: `gen-11-32-${Date.now()}`,
        topicTitle: 'Đạo hàm hàm phân thức',
        grade: 11,
        context: `Cho hàm số $y = \\frac{${a}x + ${b}}{x + 1}$.`,
        ask: 'Tìm đạo hàm $y\'$ của hàm số.',
        correctOption: `$y' = \\frac{${det}}{(x + 1)^2}$`,
        distractors: [
          `$y' = \\frac{${det + 2}}{(x + 1)^2}$`,
          `$y' = \\frac{${a}}{1}$`,
          `$y' = \\frac{${a + b}}{(x + 1)^2}$`
        ],
        tfStatements: [
          {
            text: `Tập xác định của hàm số là $D = \\mathbb{R} \\setminus \\{-1\\}$.`,
            isTrue: true,
            explanation: `Mẫu số khác 0 khi $x \\ne -1$.`
          },
          {
            text: `Công thức đạo hàm phân thức bậc nhất: $\\left(\\frac{ax+b}{cx+d}\\right)' = \\frac{ad-bc}{(cx+d)^2}$.`,
            isTrue: true,
            explanation: `Quy tắc tính nhanh đạo hàm: định thức cấp hai $ad - bc$.`
          },
          {
            text: `Tử số của đạo hàm bằng $${a} \\cdot 1 - ${b} \\cdot 1 = ${det}$.`,
            isTrue: true,
            explanation: `Tính định thức: $ad - bc = ${a} - ${b} = ${det}$.`
          },
          {
            text: `Đạo hàm của hàm số triệt tiêu tại $x = 0$.`,
            isTrue: false,
            explanation: `Tử số là hằng số khác không nên đạo hàm không bao giờ bằng 0.`
          }
        ],
        shortAnswer: `${det}`,
        shortAnswerPrompt: `Nhập giá trị tử số của đạo hàm ($ad - bc$):`,
        solution: `Áp dụng công thức tính nhanh đạo hàm hàm phân thức $\\left(\\frac{ax+b}{cx+d}\\right)' = \\frac{ad - bc}{(cx+d)^2}$:\n$$y' = \\frac{${a} \\cdot 1 - ${b} \\cdot 1}{(x + 1)^2} = \\frac{${det}}{(x + 1)^2}.$$`,
        diagram: { type: 'rational', params: { a, b, c: 1, d: 1 } }
      });
    }
  },
  '12-1': {
    id: '12-1',
    topicTitle: 'Tính đơn điệu của hàm số bậc ba',
    grade: 12,
    generate: () => {
      // y = x^3 - 3*m*x + 2, y' = 3x^2 - 3m
      const m = pick([1, 4, 9]);
      const sqrtM = Math.sqrt(m);
      const coeff = 3 * m;

      return normalizeQuestionContent({
        id: `gen-12-1-${Date.now()}`,
        topicTitle: 'Khoảng nghịch biến của hàm số bậc ba',
        grade: 12,
        context: `Cho hàm số $y = x^3 - ${coeff}x + 2$.`,
        ask: 'Tìm khoảng nghịch biến của hàm số đã cho.',
        correctOption: `$(-${sqrtM}; ${sqrtM})$`,
        distractors: [
          `$(-\\infty; -${sqrtM})$`,
          `$(${sqrtM}; +\\infty)$`,
          `$(-${coeff}; ${coeff})$`
        ],
        tfStatements: [
          {
            text: `Tập xác định của hàm số là $D = \\mathbb{R}$.`,
            isTrue: true,
            explanation: `Hàm đa thức xác định trên toàn bộ $\\mathbb{R}$.`
          },
          {
            text: `Đạo hàm của hàm số là $y' = 3x^2 - ${coeff}$.`,
            isTrue: true,
            explanation: `Đạo hàm $(x^3)' = 3x^2$, $(${coeff}x)' = ${coeff}$.`
          },
          {
            text: `Hàm số đồng biến trên khoảng $(-${sqrtM}; ${sqrtM})$.`,
            isTrue: false,
            explanation: `Sai, vì với mọi $x \\in (-${sqrtM}; ${sqrtM})$ thì $y' < 0$ nên hàm số nghịch biến trên khoảng này.`
          },
          {
            text: `Đồ thị hàm số có hai điểm cực trị nằm về hai phía của trục tung.`,
            isTrue: true,
            explanation: `Hai nghiệm của đạo hàm là $x_1 = -${sqrtM} < 0$ và $x_2 = ${sqrtM} > 0$ trái dấu nhau.`
          }
        ],
        shortAnswer: `${sqrtM}`,
        shortAnswerPrompt: `Nhập điểm cực tiểu $x_{CT}$ của hàm số:`,
        solution: `Ta có $y' = 3x^2 - ${coeff} = 3(x^2 - ${m})$.\nCho $y' = 0 \\Leftrightarrow x^2 = ${m} \\Leftrightarrow x = \\pm ${sqrtM}$.\nBảng xét dấu $y'$:\n- $y' > 0$ khi $x \\in (-\\infty; -${sqrtM}) \\cup (${sqrtM}; +\\infty)$ (hàm số đồng biến).\n- $y' < 0$ khi $x \\in (-${sqrtM}; ${sqrtM})$ (hàm số nghịch biến).\nVậy hàm số nghịch biến trên khoảng $(-${sqrtM}; ${sqrtM})$ và đồng biến trên các khoảng $(-\\infty; -${sqrtM})$, $(${sqrtM}; +\\infty)$.`,
        diagram: {
          type: 'cubic',
          params: {
            a: 1,
            b: 0,
            c: -coeff,
            d: 2,
            label: `y = x³ - ${coeff}x + 2`
          }
        }
      });
    }
  },

  // 12-2: Cực trị hàm phân thức
  '12-2': {
    id: '12-2',
    topicTitle: 'Tiệm cận và cực trị hàm phân thức $y = \\frac{ax+b}{cx+d}$',
    grade: 12,
    generate: () => {
      const a = randInt(1, 3);
      const b = randInt(1, 5);
      const x0 = randInt(1, 3);
      // y = (a*x + b)/(x - x0)
      // Vertical asymptote: x = x0
      // Horizontal asymptote: y = a

      return normalizeQuestionContent({
        id: `gen-12-2-${Date.now()}`,
        topicTitle: 'Đường tiệm cận của đồ thị hàm phân thức',
        grade: 12,
        context: `Cho hàm số $y = \\frac{${a === 1 ? '' : a}x + ${b}}{x - ${x0}}$.`,
        ask: 'Tìm phương trình đường tiệm cận ngang của đồ thị hàm số.',
        correctOption: `$y = ${a}$`,
        distractors: [`$x = ${x0}$`, `$y = ${x0}$`, `$x = -${x0}$`],
        tfStatements: [
          {
            text: `Tập xác định của hàm số là $D = \\mathbb{R} \\setminus \\{${x0}\\}$.`,
            isTrue: true,
            explanation: `Mẫu số $x - ${x0} \\ne 0 \\Leftrightarrow x \\ne ${x0}$.`
          },
          {
            text: `Đường tiệm cận đứng của đồ thị hàm số là $x = ${x0}$.`,
            isTrue: true,
            explanation: `Vì $\\lim_{x \\to ${x0}^+} y = +\\infty$, suy ra $x = ${x0}$ là TCĐ.`
          },
          {
            text: `Đường tiệm cận ngang của đồ thị hàm số là $y = ${a}$.`,
            isTrue: true,
            explanation: `Vì $\\lim_{x \\to \\pm\\infty} y = \\frac{${a}}{1} = ${a}$.`
          },
          {
            text: `Tâm đối xứng của đồ thị có tọa độ là $I(${a}; ${x0})$.`,
            isTrue: false,
            explanation: `Sai, giao điểm hai tiệm cận có tọa độ là $I(${x0}; ${a})$ (hoành độ là TCĐ, tung độ là TCN).`
          }
        ],
        shortAnswer: `${x0}`,
        shortAnswerPrompt: `Nhập hoành độ giao điểm của hai đường tiệm cận:`,
        solution: `Ta có:\n- $\\lim_{x \\to \\pm\\infty} \\frac{${a === 1 ? '' : a}x + ${b}}{x - ${x0}} = ${a} \\Rightarrow$ Tiệm cận ngang $y = ${a}$.\n- $\\lim_{x \\to ${x0}^+} y = +\\infty \\Rightarrow$ Tiệm cận đứng $x = ${x0}$.\nTâm đối xứng của đồ thị là $I(${x0}; ${a})$.`,
        diagram: {
          type: 'rational',
          params: {
            a,
            b,
            c: 1,
            d: -x0,
            x0,
            label: `y = (${a === 1 ? '' : a}x + ${b})/(x - ${x0})`
          }
        }
      });
    }
  },

  // 12-6: Vectơ và Hệ tọa độ Oxyz
  '12-6': {
    id: '12-6',
    topicTitle: 'Tọa độ điểm và khoảng cách trong không gian Oxyz',
    grade: 12,
    generate: () => {
      const xA = randInt(-3, 3);
      const yA = randInt(-3, 3);
      const zA = randInt(1, 4);

      const xB = xA + 3;
      const yB = yA + 4;
      const zB = zA; // distance = sqrt(3^2 + 4^2) = 5

      const AB = 5;

      return {
        id: `gen-12-6-${Date.now()}`,
        topicTitle: 'Khoảng cách giữa hai điểm trong Oxyz',
        grade: 12,
        context: `Trong không gian $Oxyz$, cho hai điểm $A(${xA}; ${yA}; ${zA})$ và $B(${xB}; ${yB}; ${zB})$.`,
        ask: 'Tính độ dài đoạn thẳng $AB$.',
        correctOption: `$${AB}$`,
        distractors: [`$${AB + 2}$`, `$${AB * 2}$`, `$\\sqrt{${AB + 10}}$`],
        tfStatements: [
          {
            text: `Tọa độ vectơ $\\vec{AB} = (3; 4; 0)$.`,
            isTrue: true,
            explanation: `$\\vec{AB} = (${xB}-${xA}; ${yB}-${yA}; ${zB}-${zA}) = (3; 4; 0)$.`
          },
          {
            text: `Trung điểm $M$ của đoạn thẳng $AB$ có cao độ $z_M = ${zA}$.`,
            isTrue: true,
            explanation: `$z_M = \\frac{${zA} + ${zB}}{2} = ${zA}$.`
          },
          {
            text: `Độ dài đoạn thẳng $AB$ bằng $5$.`,
            isTrue: true,
            explanation: `$AB = \\sqrt{3^2 + 4^2 + 0^2} = \\sqrt{25} = 5$.`
          },
          {
            text: `Vectơ $\\vec{AB}$ cùng phương với vectơ $\\vec{k} = (0; 0; 1)$.`,
            isTrue: false,
            explanation: `Sai vì thành phần $z$ của $\\vec{AB}$ bằng $0$, vectơ $\\vec{AB}$ song song với mặt phẳng $(Oxy)$.`
          }
        ],
        shortAnswer: `${AB}`,
        shortAnswerPrompt: `Nhập độ dài đoạn thẳng $AB$:`,
        solution: `Ta có vectơ $\\vec{AB} = (${xB} - ${xA}; ${yB} - ${yA}; ${zB} - ${zA}) = (3; 4; 0)$.\nĐộ dài đoạn thẳng $AB$ là:\n$$AB = |\\vec{AB}| = \\sqrt{3^2 + 4^2 + 0^2} = \\sqrt{9 + 16} = 5.$$`,
        diagram: { type: 'box' }
      };
    }
  },

  // 12-11: Tích phân & Diện tích hình phẳng
  '12-11': {
    id: '12-11',
    topicTitle: 'Tích phân xác định',
    grade: 12,
    generate: () => {
      const a = randInt(1, 3);
      // \int_0^1 (2ax + 3) dx = [a*x^2 + 3x]_0^1 = a + 3
      const result = a + 3;

      return {
        id: `gen-12-11-${Date.now()}`,
        topicTitle: 'Tính tích phân của hàm đa thức',
        grade: 12,
        context: `Cho tích phân $I = \\int_0^1 (${2 * a}x + 3) \\, dx$.`,
        ask: 'Tính giá trị của tích phân $I$.',
        correctOption: `$${result}$`,
        distractors: [`$${result + 2}$`, `$${2 * a + 3}$`, `$${result - 1}$`],
        tfStatements: [
          {
            text: `Một nguyên hàm của hàm số $f(x) = ${2 * a}x + 3$ là $F(x) = ${a}x^2 + 3x$.`,
            isTrue: true,
            explanation: `Vì $F'(x) = 2 \\cdot ${a}x + 3 = ${2 * a}x + 3$.`
          },
          {
            text: `Giá trị của $F(1) = ${a + 3}$.`,
            isTrue: true,
            explanation: `$F(1) = ${a}(1)^2 + 3(1) = ${a + 3}$.`
          },
          {
            text: `Giá trị của $F(0) = 0$.`,
            isTrue: true,
            explanation: `$F(0) = ${a}(0)^2 + 3(0) = 0$.`
          },
          {
            text: `Tích phân $I$ nhận giá trị âm.`,
            isTrue: false,
            explanation: `Sai, vì $f(x) > 0$ với mọi $x \\in [0; 1]$ nên $I > 0$.`
          }
        ],
        shortAnswer: `${result}`,
        shortAnswerPrompt: `Nhập giá trị của tích phân $I$:`,
        solution: `Ta có:\n$$I = \\int_0^1 (${2 * a}x + 3) \\, dx = \\left[ ${a}x^2 + 3x \\right]_0^1 = (${a} \\cdot 1^2 + 3 \\cdot 1) - 0 = ${result}.$$`,
        diagram: { type: 'integral' }
      };
    }
  },

  // 12-14: Phương trình mặt phẳng và mặt cầu Oxyz
  '12-14': {
    id: '12-14',
    topicTitle: 'Phương trình mặt cầu trong không gian Oxyz',
    grade: 12,
    generate: () => {
      const a = randInt(1, 3);
      const b = randInt(-3, -1);
      const c = randInt(2, 4);
      const R = randInt(2, 5);
      const R2 = R * R;

      return {
        id: `gen-12-14-${Date.now()}`,
        topicTitle: 'Tọa độ tâm và bán kính mặt cầu',
        grade: 12,
        context: `Trong không gian $Oxyz$, cho mặt cầu $(S): (x - ${a})^2 + (y + ${Math.abs(b)})^2 + (z - ${c})^2 = ${R2}$.`,
        ask: 'Tìm tọa độ tâm $I$ và bán kính $R$ của mặt cầu $(S)$.',
        correctOption: `$I(${a}; ${b}; ${c}), \\ R = ${R}$`,
        distractors: [
          `$I(-${a}; ${Math.abs(b)}; -${c}), \\ R = ${R}$`,
          `$I(${a}; ${b}; ${c}), \\ R = ${R2}$`,
          `$I(${a}; ${Math.abs(b)}; ${c}), \\ R = ${R}$`
        ],
        tfStatements: [
          {
            text: `Mặt cầu có tâm $I(${a}; ${b}; ${c})$.`,
            isTrue: true,
            explanation: `Theo dạng chuẩn $(x-a)^2 + (y-b)^2 + (z-c)^2 = R^2$, tâm $I$ có tọa độ $(${a}; ${b}; ${c})$.`
          },
          {
            text: `Bán kính của mặt cầu là $R = ${R2}$.`,
            isTrue: false,
            explanation: `Sai, $R^2 = ${R2} \\Rightarrow R = \\sqrt{${R2}} = ${R}$.`
          },
          {
            text: `Điểm $A(${a}; ${b}; ${c + R})$ nằm trên mặt cầu $(S)$.`,
            isTrue: true,
            explanation: `Khoảng cách $IA = \\sqrt{0^2 + 0^2 + ${R}^2} = ${R} = R$ nên $A$ thuộc $(S)$.`
          },
          {
            text: `Mặt phẳng $(Oxy)$ có phương trình là $z = 0$.`,
            isTrue: true,
            explanation: `Mọi điểm trên mặt phẳng $(Oxy)$ đều có cao độ $z = 0$.`
          }
        ],
        shortAnswer: `${R}`,
        shortAnswerPrompt: `Nhập bán kính $R$ của mặt cầu:`,
        solution: `Phương trình mặt cầu có dạng chuẩn $(x - a)^2 + (y - b)^2 + (z - c)^2 = R^2$.\nTừ đề bài:\n- Tọa độ tâm: $I(${a}; ${b}; ${c})$\n- Bán kính: $R = \\sqrt{${R2}} = ${R}$.`,
        diagram: { type: 'box' }
      };
    }
  },

  // 12-18: Xác suất Bayes
  '12-18': {
    id: '12-18',
    topicTitle: 'Xác suất toàn phần và công thức Bayes trong y tế',
    grade: 12,
    generate: () => {
      // Disease rate 2%, Test accuracy 95%, false positive 5%
      // P(D) = 0.02, P(T|D) = 0.95, P(T|not D) = 0.05
      // P(T) = 0.02 * 0.95 + 0.98 * 0.05 = 0.019 + 0.049 = 0.068
      // P(D|T) = 0.019 / 0.068 approx 0.2794
      return {
        id: `gen-12-18-${Date.now()}`,
        topicTitle: 'Công thức xác suất toàn phần & Bayes',
        grade: 12,
        context: `Một tỉ lệ mắc một căn bệnh trong cộng đồng là $2\\%$. Một bộ kit xét nghiệm cho kết quả dương tính đối với $95\\%$ người mắc bệnh, và cho kết quả dương tính giả đối với $5\\%$ người khỏe mạnh.`,
        ask: 'Tính xác suất để một người được chọn ngẫu nhiên có kết quả xét nghiệm dương tính.',
        correctOption: `$0{,}068$ (hay $6{,}8\\%$)`,
        distractors: [`$0{,}95$`, `$0{,}02$`, `$0{,}05$`],
        tfStatements: [
          {
            text: `Gọi $B$ là biến cố người đó mắc bệnh, thì $P(B) = 0{,}02$ và $P(\\overline{B}) = 0{,}98$.`,
            isTrue: true,
            explanation: `Xác suất người mắc bệnh là 2% = 0.02, người không mắc bệnh là 98% = 0.98.`
          },
          {
            text: `Xác suất dương tính khi có bệnh là $P(T \\mid B) = 0{,}95$.`,
            isTrue: true,
            explanation: `Độ nhạy của xét nghiệm là 95%.`
          },
          {
            text: `Theo công thức xác suất toàn phần, $P(T) = P(B)P(T \\mid B) + P(\\overline{B})P(T \\mid \\overline{B})$.`,
            isTrue: true,
            explanation: `Đây là công thức xác suất toàn phần chính xác.`
          },
          {
            text: `Nếu một người nhận kết quả dương tính, xác suất họ thực sự mắc bệnh lớn hơn $90\\%$.`,
            isTrue: false,
            explanation: `Sai vì theo công thức Bayes, $P(B \\mid T) = \\frac{0{,}019}{0{,}068} \\approx 27{,}94\\% < 90\\%$ do tỉ lệ bệnh trong cộng đồng thấp.`
          }
        ],
        shortAnswer: '0.068',
        shortAnswerPrompt: `Nhập giá trị xác suất xét nghiệm dương tính (lấy 3 chữ số thập phân):`,
        solution: `Gọi $B$ là biến cố người được xét nghiệm mắc bệnh $\\Rightarrow P(B) = 0{,}02$, $P(\\overline{B}) = 0{,}98$.\nGọi $T$ là biến cố xét nghiệm cho kết quả dương tính.\n- $P(T \\mid B) = 0{,}95$\n- $P(T \\mid \\overline{B}) = 0{,}05$\nÁp dụng công thức xác suất toàn phần:\n$$P(T) = P(B) \\cdot P(T \\mid B) + P(\\overline{B}) \\cdot P(T \\mid \\overline{B})$$\n$$P(T) = 0{,}02 \\cdot 0{,}95 + 0{,}98 \\cdot 0{,}05 = 0{,}019 + 0{,}049 = 0{,}068.$$\nVậy xác suất để người xét nghiệm có kết quả dương tính là $0{,}068$ (tức $6{,}8\\%$).`
      };
    }
  },

  // 12-3: Giá trị lớn nhất & nhỏ nhất
  '12-3': {
    id: '12-3',
    topicTitle: 'Giá trị lớn nhất và nhỏ nhất của hàm số trên đoạn',
    grade: 12,
    generate: () => {
      // f(x) = x^3 - 3x on [0; 2]
      // f'(x) = 3x^2 - 3 = 0 => x = 1 (in [0; 2])
      // f(0) = 0, f(1) = -2, f(2) = 2
      // min = -2 at x = 1, max = 2 at x = 2
      const a = randInt(2, 4);
      // f(x) = x^3 - 3*a^2*x on [0; 2*a]
      // f'(x) = 3(x^2 - a^2) => x = a in [0; 2*a]
      // f(0) = 0, f(a) = -2*a^3, f(2a) = 8a^3 - 6a^3 = 2a^3
      const coeff = 3 * a * a;
      const maxVal = 2 * Math.pow(a, 3);
      const minVal = -2 * Math.pow(a, 3);
      const rightEnd = 2 * a;

      return normalizeQuestionContent({
        id: `gen-12-3-${Date.now()}`,
        topicTitle: 'GTLN và GTNN của hàm bậc ba trên đoạn',
        grade: 12,
        context: `Cho hàm số $f(x) = x^3 - ${coeff}x$ trên đoạn $[0; ${rightEnd}]$.`,
        ask: `Tìm giá trị nhỏ nhất của hàm số trên đoạn $[0; ${rightEnd}]$.`,
        correctOption: `${minVal}`,
        distractors: [`0`, `${maxVal}`, `${-a}`],
        tfStatements: [
          {
            text: `Hàm số $f(x)$ liên tục trên đoạn $[0; ${rightEnd}]$.`,
            isTrue: true,
            explanation: `Hàm đa thức liên tục trên toàn bộ $\\mathbb{R}$ nên liên tục trên đoạn $[0; ${rightEnd}]$.`
          },
          {
            text: `Phương trình $f'(x) = 0$ có đúng một nghiệm thuộc khoảng $(0; ${rightEnd})$ là $x = ${a}$.`,
            isTrue: true,
            explanation: `$f'(x) = 3x^2 - ${coeff} = 0 \\iff x = ${a} \\in (0; ${rightEnd})$.`
          },
          {
            text: `Giá trị lớn nhất của hàm số trên đoạn $[0; ${rightEnd}]$ bằng ${maxVal}.`,
            isTrue: true,
            explanation: `Ta có $f(0) = 0, f(${a}) = ${minVal}, f(${rightEnd}) = ${maxVal} \\implies \\max = ${maxVal}$.`
          },
          {
            text: `Giá trị nhỏ nhất của hàm số đạt được tại đầu mút $x = 0$.`,
            isTrue: false,
            explanation: `Sai, GTNN đạt tại điểm cực tiểu $x = ${a}$ và có giá trị bằng ${minVal} < 0$.`
          }
        ],
        shortAnswer: `${minVal}`,
        shortAnswerPrompt: `Nhập giá trị nhỏ nhất của hàm số:`,
        solution: `Ta có $f'(x) = 3x^2 - ${coeff} = 3(x^2 - ${a*a})$.\nCho $f'(x) = 0 \\iff x = ${a}$ (do $x \\in (0; ${rightEnd})$).\nTính giá trị:\n- $f(0) = 0$\n- $f(${a}) = ${a}^3 - ${coeff} \\cdot ${a} = ${minVal}$\n- $f(${rightEnd}) = (${rightEnd})^3 - ${coeff} \\cdot ${rightEnd} = ${maxVal}$\nSo sánh các giá trị ta kết luận:\n$$\\min_{[0; ${rightEnd}]} f(x) = ${minVal} \\quad (\\text{tại } x = ${a}), \\quad \\max_{[0; ${rightEnd}]} f(x) = ${maxVal} \\quad (\\text{tại } x = ${rightEnd}).$$`,
        diagram: { type: 'appliedMaxMin' }
      });
    }
  },

  // 12-7: Hệ trục toạ độ Oxyz
  '12-7': {
    id: '12-7',
    topicTitle: 'Toạ độ của điểm và hình chiếu vuông góc trong Oxyz',
    grade: 12,
    generate: () => {
      const x = randInt(1, 6);
      const y = randInt(-5, -1);
      const z = randInt(2, 7);

      return normalizeQuestionContent({
        id: `gen-12-7-${Date.now()}`,
        topicTitle: 'Hình chiếu vuông góc của điểm trong không gian Oxyz',
        grade: 12,
        context: `Trong không gian $Oxyz$, cho điểm $M(${x}; ${y}; ${z})$.`,
        ask: 'Tìm toạ độ hình chiếu vuông góc của điểm $M$ lên mặt phẳng toạ độ $(Oxy)$.',
        correctOption: `$(${x}; ${y}; 0)$`,
        distractors: [
          `$(${x}; 0; ${z})$`,
          `$(0; ${y}; ${z})$`,
          `$(${x}; 0; 0)$`
        ],
        tfStatements: [
          {
            text: `Khoảng cách từ điểm $M$ đến mặt phẳng $(Oxy)$ bằng $|${z}| = ${Math.abs(z)}$.`,
            isTrue: true,
            explanation: `Khoảng cách từ $M(x; y; z)$ đến $(Oxy)$ là $d(M, (Oxy)) = |z|$.`
          },
          {
            text: `Hình chiếu của $M$ lên trục toạ độ $Oz$ có toạ độ là $(0; 0; ${z})$.`,
            isTrue: true,
            explanation: `Chiếu lên trục $Oz$ thì giữ nguyên cao độ $z$, các toạ độ $x, y$ bằng 0.`
          },
          {
            text: `Vectơ $\\vec{OM}$ có toạ độ là $(${x}; ${y}; ${z})$.`,
            isTrue: true,
            explanation: `Toạ độ của điểm $M$ chính là toạ độ của vectơ vị trí $\\vec{OM}$.`
          },
          {
            text: `Điểm đối xứng với $M$ qua gốc toạ độ $O$ là $(${x}; ${y}; ${z})$.`,
            isTrue: false,
            explanation: `Sai, điểm đối xứng qua gốc $O$ phải đổi dấu cả 3 toạ độ: $(-${x}; ${-y}; ${-z})$.`
          }
        ],
        shortAnswer: `${Math.abs(z)}`,
        shortAnswerPrompt: `Nhập khoảng cách từ điểm $M$ đến mặt phẳng toạ độ $(Oxy)$:`,
        solution: `Hình chiếu vuông góc của điểm $M(x_0; y_0; z_0)$ lên mặt phẳng $(Oxy)$ có toạ độ là $(x_0; y_0; 0)$.\nDo đó hình chiếu của $M(${x}; ${y}; ${z})$ lên $(Oxy)$ là $M'(${x}; ${y}; 0)$.\nKhoảng cách từ $M$ đến $(Oxy)$ là $d = |z| = ${Math.abs(z)}$.`,
        diagram: { type: 'box' }
      });
    }
  },

  // 12-8: Biểu thức toạ độ các phép toán vectơ
  '12-8': {
    id: '12-8',
    topicTitle: 'Tích vô hướng và góc giữa hai vectơ trong không gian Oxyz',
    grade: 12,
    generate: () => {
      const u1 = randInt(1, 3);
      const u2 = randInt(-2, 2);
      const u3 = randInt(1, 3);

      const v1 = randInt(1, 3);
      const v2 = randInt(-2, 2);
      const v3 = randInt(1, 3);

      const dotProduct = u1 * v1 + u2 * v2 + u3 * v3;

      return normalizeQuestionContent({
        id: `gen-12-8-${Date.now()}`,
        topicTitle: 'Tích vô hướng của hai vectơ Oxyz',
        grade: 12,
        context: `Trong không gian $Oxyz$, cho hai vectơ $\\vec{u} = (${u1}; ${u2}; ${u3})$ và $\\vec{v} = (${v1}; ${v2}; ${v3})$.`,
        ask: 'Tính tích vô hướng $\\vec{u} \\cdot \\vec{v}$.',
        correctOption: `${dotProduct}`,
        distractors: [
          `${dotProduct + 2}`,
          `${dotProduct - 3}`,
          `${u1 * v1 - u2 * v2 + u3 * v3}`
        ],
        tfStatements: [
          {
            text: `Độ dài của vectơ $\\vec{u}$ là $|\\vec{u}| = \\sqrt{${u1*u1 + u2*u2 + u3*u3}}$.`,
            isTrue: true,
            explanation: `Công thức độ dài: $|\\vec{u}| = \\sqrt{x^2 + y^2 + z^2} = \\sqrt{${u1}^2 + (${u2})^2 + ${u3}^2} = \\sqrt{${u1*u1 + u2*u2 + u3*u3}}$.`
          },
          {
            text: `Vectơ tổng $\\vec{u} + \\vec{v} = (${u1 + v1}; ${u2 + v2}; ${u3 + v3})$.`,
            isTrue: true,
            explanation: `Cộng toạ độ tương ứng của hai vectơ.`
          },
          {
            text: `Tích vô hướng $\\vec{u} \\cdot \\vec{v} = ${dotProduct}$.`,
            isTrue: true,
            explanation: `Áp dụng công thức $\\vec{u} \\cdot \\vec{v} = x_1 x_2 + y_1 y_2 + z_1 z_2 = ${dotProduct}$.`
          },
          {
            text: `Hai vectơ $\\vec{u}$ và $\\vec{v}$ vuông góc với nhau.`,
            isTrue: dotProduct === 0,
            explanation: dotProduct === 0 ? `Đúng vì tích vô hướng bằng 0.` : `Sai vì tích vô hướng $\\vec{u} \\cdot \\vec{v} = ${dotProduct} \\ne 0$.`
          }
        ],
        shortAnswer: `${dotProduct}`,
        shortAnswerPrompt: `Nhập giá trị tích vô hướng $\\vec{u} \\cdot \\vec{v}$:`,
        solution: `Áp dụng biểu thức toạ độ của tích vô hướng trong không gian:\n$$\\vec{u} \\cdot \\vec{v} = u_1 v_1 + u_2 v_2 + u_3 v_3 = (${u1}) \\cdot (${v1}) + (${u2}) \\cdot (${v2}) + (${u3}) \\cdot (${v3}) = ${dotProduct}.$$`,
        diagram: { type: 'box' }
      });
    }
  },

  // 12-9a: Khoảng biến thiên & tứ phân vị ghép nhóm
  '12-9a': {
    id: '12-9a',
    topicTitle: 'Khoảng biến thiên của mẫu số liệu ghép nhóm',
    grade: 12,
    generate: () => {
      const a0 = randInt(10, 40);
      const step = 5;
      const numGroups = 4;
      const ak = a0 + numGroups * step;
      const R = ak - a0;

      return normalizeQuestionContent({
        id: `gen-12-9a-${Date.now()}`,
        topicTitle: 'Khoảng biến thiên mẫu số liệu ghép nhóm',
        grade: 12,
        context: `Một mẫu số liệu được ghép thành các nhóm: $[${a0}; ${a0+step})$, $[${a0+step}; ${a0+2*step})$, $[${a0+2*step}; ${a0+3*step})$, $[${a0+3*step}; ${ak})$.`,
        ask: 'Tìm khoảng biến thiên $R$ của mẫu số liệu ghép nhóm trên.',
        correctOption: `${R}`,
        distractors: [`${step}`, `${ak}`, `${a0}`],
        tfStatements: [
          {
            text: `Độ dài của mỗi nhóm số liệu là $L = ${step}$.`,
            isTrue: true,
            explanation: `Độ dài mỗi nhóm: ${a0+step} - ${a0} = ${step}.`
          },
          {
            text: `Đầu mút trái của nhóm đầu tiên là $a_1 = ${a0}$.`,
            isTrue: true,
            explanation: `Nhóm đầu tiên là $[${a0}; ${a0+step})$.`
          },
          {
            text: `Khoảng biến thiên của mẫu số liệu là $R = ${ak} - ${a0} = ${R}$.`,
            isTrue: true,
            explanation: `Công thức: $R = a_k - a_1 = ${ak} - ${a0} = ${R}$.`
          },
          {
            text: `Khoảng biến thiên phụ thuộc vào tần số của các nhóm.`,
            isTrue: false,
            explanation: `Khoảng biến thiên chỉ phụ thuộc vào đầu mút của nhóm đầu tiên và nhóm cuối cùng, không phụ thuộc vào tần số.`
          }
        ],
        shortAnswer: `${R}`,
        shortAnswerPrompt: `Nhập giá trị khoảng biến thiên $R$:`,
        solution: `Khoảng biến thiên của mẫu số liệu ghép nhóm bằng hiệu giữa đầu mút phải của nhóm cuối cùng và đầu mút trái của nhóm đầu tiên:\n$$R = ${ak} - ${a0} = ${R}.$$`,
        diagram: { type: 'histogram' }
      });
    }
  },

  // 12-13: Ứng dụng hình học của tích phân (Diện tích hình phẳng)
  '12-13': {
    id: '12-13',
    topicTitle: 'Tính diện tích hình phẳng bằng tích phân',
    grade: 12,
    generate: () => {
      // S = int_0^a x^2 dx = a^3 / 3
      const a = pick([3, 6]);
      const area = Math.pow(a, 3) / 3;

      return normalizeQuestionContent({
        id: `gen-12-13-${Date.now()}`,
        topicTitle: 'Diện tích hình phẳng giới hạn bởi parabol và trục hoành',
        grade: 12,
        context: `Tính diện tích hình phẳng $S$ giới hạn bởi parabol $y = x^2$, trục hoành $Ox$ và đường thẳng $x = ${a}$.`,
        ask: `Tính giá trị của diện tích hình phẳng $S$.`,
        correctOption: `${area}`,
        distractors: [`${Math.pow(a, 2)}`, `${Math.pow(a, 3)}`, `${area / 2}`],
        tfStatements: [
          {
            text: `Hàm số $y = x^2 \\ge 0$ với mọi $x \\in [0; ${a}]$.`,
            isTrue: true,
            explanation: `Bình phương của một số thực luôn không âm.`
          },
          {
            text: `Công thức tính diện tích là $S = \\int_0^{${a}} x^2 \\, dx$.`,
            isTrue: true,
            explanation: `Vì $x^2 \\ge 0$ trên đoạn $[0; ${a}]$ nên $|x^2| = x^2$.`
          },
          {
            text: `Một nguyên hàm của $x^2$ là $\\frac{x^3}{3}$.`,
            isTrue: true,
            explanation: `$\\int x^2 dx = \\frac{x^3}{3} + C$.`
          },
          {
            text: `Diện tích hình phẳng có giá trị âm nếu đồ thị nằm phía dưới trục hoành.`,
            isTrue: false,
            explanation: `Sai, diện tích luôn là một đại lượng không âm $S \\ge 0$ do có dấu giá trị tuyệt đối $|f(x)|$.`
          }
        ],
        shortAnswer: `${area}`,
        shortAnswerPrompt: `Nhập giá trị diện tích hình phẳng:`,
        solution: `Diện tích hình phẳng cần tính là:\n$$S = \\int_0^{${a}} |x^2| \\, dx = \\int_0^{${a}} x^2 \\, dx = \\left[ \\frac{x^3}{3} \\right]_0^{${a}} = \\frac{${a}^3}{3} - 0 = ${area}.$$`,
        diagram: { type: 'integral' }
      });
    }
  },

  // 12-15: Phương trình đường thẳng trong không gian
  '12-15': {
    id: '12-15',
    topicTitle: 'Vectơ chỉ phương của đường thẳng trong không gian Oxyz',
    grade: 12,
    generate: () => {
      const x0 = randInt(1, 4);
      const y0 = randInt(-3, 3);
      const z0 = randInt(1, 5);

      const a = randInt(1, 4);
      const b = randInt(-3, -1);
      const c = randInt(2, 5);

      return normalizeQuestionContent({
        id: `gen-12-15-${Date.now()}`,
        topicTitle: 'Phương trình tham số của đường thẳng Oxyz',
        grade: 12,
        context: `Trong không gian $Oxyz$, cho đường thẳng $d$ có phương trình tham số:\n$$\\begin{cases} x = ${x0} + ${a}t \\\\ y = ${y0} ${b < 0 ? b : '+ ' + b}t \\\\ z = ${z0} + ${c}t \\end{cases} \\quad (t \\in \\mathbb{R}).$$`,
        ask: 'Tìm một vectơ chỉ phương của đường thẳng $d$.',
        correctOption: `$\\vec{u} = (${a}; ${b}; ${c})$`,
        distractors: [
          `$\\vec{u} = (${x0}; ${y0}; ${z0})$`,
          `$\\vec{u} = (${-a}; ${b}; ${c})$`,
          `$\\vec{u} = (${a}; ${-b}; ${-c})$`
        ],
        tfStatements: [
          {
            text: `Đường thẳng $d$ đi qua điểm $M(${x0}; ${y0}; ${z0})$.`,
            isTrue: true,
            explanation: `Thay $t = 0$ ta được toạ độ điểm $M(${x0}; ${y0}; ${z0}) \\in d$.`
          },
          {
            text: `Một vectơ chỉ phương của $d$ là $\\vec{u} = (${a}; ${b}; ${c})$.`,
            isTrue: true,
            explanation: `Hệ số trước tham số $t$ chính là các toạ độ của VTCP.`
          },
          {
            text: `Vectơ $2\\vec{u} = (${2*a}; ${2*b}; ${2*c})$ cũng là một vectơ chỉ phương của $d$.`,
            isTrue: true,
            explanation: `Bất kỳ vectơ nào cùng phương khác $\\vec{0}$ với $\\vec{u}$ đều là VTCP của $d$.`
          },
          {
            text: `Phương trình chính tắc của $d$ là $\\frac{x - ${a}}{${x0}} = \\frac{y - ${b}}{${y0}} = \\frac{z - ${c}}{${z0}}$.`,
            isTrue: false,
            explanation: `Sai, phương trình chính tắc phải có toạ độ điểm ở tử số và toạ độ VTCP ở mẫu số: $\\frac{x - ${x0}}{${a}} = \\frac{y - ${y0}}{${b}} = \\frac{z - ${z0}}{${c}}$.`
          }
        ],
        shortAnswer: `${a}`,
        shortAnswerPrompt: `Nhập hoành độ $u_1$ của vectơ chỉ phương $\\vec{u} = (u_1; u_2; u_3)$:`,
        solution: `Phương trình tham số của đường thẳng có dạng:\n$$\\begin{cases} x = x_0 + at \\\\ y = y_0 + bt \\\\ z = z_0 + ct \\end{cases}$$\nTrong đó $(a; b; c)$ là toạ độ của vectơ chỉ phương $\\vec{u}$.\nDo đó một VTCP của đường thẳng là $\\vec{u} = (${a}; ${b}; ${c})$.`,
        diagram: { type: 'prism' }
      });
    }
  },

  // 12-16: Góc trong không gian Oxyz
  '12-16': {
    id: '12-16',
    topicTitle: 'Góc giữa hai mặt phẳng trong không gian Oxyz',
    grade: 12,
    generate: () => {
      // (P): x + y = 0, (Q): y + z = 0 => cos = 1 / (sqrt(2)*sqrt(2)) = 1/2 => angle = 60 deg
      return normalizeQuestionContent({
        id: `gen-12-16-${Date.now()}`,
        topicTitle: 'Góc giữa hai mặt phẳng trong không gian Oxyz',
        grade: 12,
        context: `Trong không gian $Oxyz$, cho hai mặt phẳng $(P): x + y - 1 = 0$ và $(Q): y + z + 2 = 0$.`,
        ask: 'Tính góc giữa hai mặt phẳng $(P)$ và $(Q)$.',
        correctOption: `$60^\\circ$`,
        distractors: [`$30^\\circ$`, `$45^\\circ$`, `$90^\\circ$`],
        tfStatements: [
          {
            text: `Vectơ pháp tuyến của $(P)$ là $\\vec{n}_P = (1; 1; 0)$.`,
            isTrue: true,
            explanation: `Hệ số trước $x, y, z$ của $(P)$ lần lượt là $1, 1, 0$.`
          },
          {
            text: `Vectơ pháp tuyến của $(Q)$ là $\\vec{n}_Q = (0; 1; 1)$.`,
            isTrue: true,
            explanation: `Hệ số trước $x, y, z$ của $(Q)$ lần lượt là $0, 1, 1$.`
          },
          {
            text: `$\\cos((P), (Q)) = \\frac{|\\vec{n}_P \\cdot \\vec{n}_Q|}{|\\vec{n}_P| \\cdot |\\vec{n}_Q|} = \\frac{1}{\\sqrt{2} \\cdot \\sqrt{2}} = \\frac{1}{2}$.`,
            isTrue: true,
            explanation: `Tích vô hướng $\\vec{n}_P \\cdot \\vec{n}_Q = 1 \\cdot 0 + 1 \\cdot 1 + 0 \\cdot 1 = 1$. Độ dài mỗi vectơ là $\\sqrt{2}$.`
          },
          {
            text: `Góc giữa hai mặt phẳng có thể là góc tù ($> 90^\\circ$).`,
            isTrue: false,
            explanation: `Sai, theo định nghĩa góc giữa hai mặt phẳng $\\varphi$ luôn thoả mãn $0^\\circ \\le \\varphi \\le 90^\\circ$.`
          }
        ],
        shortAnswer: '60',
        shortAnswerPrompt: `Nhập số đo góc giữa hai mặt phẳng (độ):`,
        solution: `Ta có VTPT của $(P)$ là $\\vec{n}_P = (1; 1; 0)$ và của $(Q)$ là $\\vec{n}_Q = (0; 1; 1)$.\nÁp dụng công thức cosin góc giữa hai mặt phẳng:\n$$\\cos \\varphi = \\frac{|\\vec{n}_P \\cdot \\vec{n}_Q|}{|\\vec{n}_P| \\cdot |\\vec{n}_Q|} = \\frac{|1 \\cdot 0 + 1 \\cdot 1 + 0 \\cdot 1|}{\\sqrt{1^2+1^2+0^2} \\cdot \\sqrt{0^2+1^2+1^2}} = \\frac{1}{\\sqrt{2} \\cdot \\sqrt{2}} = \\frac{1}{2}.$$\nDo $0^\\circ \\le \\varphi \\le 90^\\circ$ nên $\\varphi = 60^\\circ$.`,
        diagram: { type: 'pyramid' }
      });
    }
  },

  // 12-19: Công thức Bayes đảo ngược
  '12-19': {
    id: '12-19',
    topicTitle: 'Công thức Bayes tính xác suất hậu nghiệm',
    grade: 12,
    generate: () => {
      // Factory with 2 machines: Machine 1 produces 60% of products with 1% defective
      // Machine 2 produces 40% with 2% defective
      // P(M1) = 0.6, P(D|M1) = 0.01; P(M2) = 0.4, P(D|M2) = 0.02
      // P(D) = 0.6*0.01 + 0.4*0.02 = 0.006 + 0.008 = 0.014
      // P(M1|D) = 0.006 / 0.014 = 6/14 = 3/7 approx 42.86%
      return normalizeQuestionContent({
        id: `gen-12-19-${Date.now()}`,
        topicTitle: 'Công thức xác suất toàn phần trong sản xuất công nghiệp',
        grade: 12,
        context: `Một nhà máy có hai phân xưởng cùng sản xuất một loại chi tiết. Phân xưởng I sản xuất $60\\%$ tổng số chi tiết với tỉ lệ phế phẩm là $1\\%$. Phân xưởng II sản xuất $40\\%$ tổng số chi tiết với tỉ lệ phế phẩm là $2\\%$. Lấy ngẫu nhiên một chi tiết từ kho.`,
        ask: 'Tính xác suất để chi tiết lấy ra là phế phẩm.',
        correctOption: `$0{,}014$ (hay $1{,}4\\%$)`,
        distractors: [`$0{,}03$`, `$0{,}015$`, `$0{,}02$`],
        tfStatements: [
          {
            text: `Gọi $A_1, A_2$ lần lượt là biến cố chi tiết do xưởng I, xưởng II sản xuất, thì $P(A_1) = 0{,}6$ và $P(A_2) = 0{,}4$.`,
            isTrue: true,
            explanation: `Hai biến cố tạo thành một hệ đầy đủ.`
          },
          {
            text: `Tỉ lệ phế phẩm của xưởng I là $P(B \\mid A_1) = 0{,}01$.`,
            isTrue: true,
            explanation: `Đúng theo giả thiết đề bài.`
          },
          {
            text: `Xác suất chi tiết lấy ra là phế phẩm được tính theo công thức xác suất toàn phần là $P(B) = 0{,}014$.`,
            isTrue: true,
            explanation: `$P(B) = 0{,}6 \\cdot 0{,}01 + 0{,}4 \\cdot 0{,}02 = 0{,}006 + 0{,}008 = 0{,}014$.`
          },
          {
            text: `Nếu chi tiết lấy ra là phế phẩm, xác suất nó do phân xưởng I sản xuất lớn hơn do phân xưởng II sản xuất.`,
            isTrue: false,
            explanation: `Sai, vì phân xưởng I đóng góp $0{,}006$ phế phẩm, còn xưởng II đóng góp $0{,}008$ phế phẩm $\\implies P(A_2 \\mid B) = \\frac{8}{14} > P(A_1 \\mid B) = \\frac{6}{14}$.`
          }
        ],
        shortAnswer: '0.014',
        shortAnswerPrompt: `Nhập giá trị xác suất chi tiết lấy ra là phế phẩm:`,
        solution: `Gọi $A_1$ là biến cố chi tiết do phân xưởng I sản xuất $\\implies P(A_1) = 0{,}6$.\nGọi $A_2$ là biến cố chi tiết do phân xưởng II sản xuất $\\implies P(A_2) = 0{,}4$.\nGọi $B$ là biến cố chi tiết lấy ra là phế phẩm.\nTheo giả thiết:\n- $P(B \\mid A_1) = 0{,}01$\n- $P(B \\mid A_2) = 0{,}02$\nÁp dụng công thức xác suất toàn phần:\n$$P(B) = P(A_1) P(B \\mid A_1) + P(A_2) P(B \\mid A_2) = 0{,}6 \\cdot 0{,}01 + 0{,}4 \\cdot 0{,}02 = 0{,}006 + 0{,}008 = 0{,}014.$$`,
        diagram: { type: 'numberLine' }
      });
    }
  },

  // 12-cd1-b1: Biến ngẫu nhiên rời rạc & Kỳ vọng
  '12-cd1-b1': {
    id: '12-cd1-b1',
    topicTitle: 'Kỳ vọng toán học của biến ngẫu nhiên rời rạc',
    grade: 12,
    generate: () => {
      // X takes values 1, 2, 3 with probabilities 0.2, 0.5, 0.3
      // E(X) = 1*0.2 + 2*0.5 + 3*0.3 = 0.2 + 1.0 + 0.9 = 2.1
      return normalizeQuestionContent({
        id: `gen-12-cd1-b1-${Date.now()}`,
        topicTitle: 'Tính kỳ vọng của biến ngẫu nhiên rời rạc',
        grade: 12,
        context: `Biến ngẫu nhiên rời rạc $X$ có bảng phân bố xác suất như sau:\n$$\\begin{array}{|c|c|c|c|} \\hline X & 1 & 2 & 3 \\\\ \\hline P & 0{,}2 & 0{,}5 & 0{,}3 \\\\ \\hline \\end{array}$$`,
        ask: 'Tính kỳ vọng toán học $E(X)$ của biến ngẫu nhiên $X$.',
        correctOption: `$2{,}1$`,
        distractors: [`$2{,}0$`, `$2{,}3$`, `$1{,}9$`],
        tfStatements: [
          {
            text: `Tổng các xác suất trong bảng bằng $0{,}2 + 0{,}5 + 0{,}3 = 1$.`,
            isTrue: true,
            explanation: `Điều kiện chuẩn hoá của phân bố xác suất luôn là $\\sum p_i = 1$.`
          },
          {
            text: `Kỳ vọng $E(X) = 1 \\cdot 0{,}2 + 2 \\cdot 0{,}5 + 3 \\cdot 0{,}3 = 2{,}1$.`,
            isTrue: true,
            explanation: `Công thức kỳ vọng: $E(X) = \\sum x_i p_i = 2{,}1$.`
          },
          {
            text: `Kỳ vọng của biến ngẫu nhiên $2X + 1$ là $E(2X + 1) = 2 E(X) + 1 = 5{,}2$.`,
            isTrue: true,
            explanation: `Tính chất tuyến tính của kỳ vọng: $E(aX + b) = aE(X) + b = 2(2{,}1) + 1 = 5{,}2$.`
          },
          {
            text: `Kỳ vọng $E(X)$ bắt buộc phải là một giá trị mà $X$ có thể nhận được.`,
            isTrue: false,
            explanation: `Sai, kỳ vọng là giá trị trung bình theo nghĩa xác suất, không nhất thiết thuộc tập giá trị của $X$ (ví dụ $E(X) = 2{,}1 \\notin \\{1, 2, 3\\}$).`
          }
        ],
        shortAnswer: '2.1',
        shortAnswerPrompt: `Nhập giá trị kỳ vọng $E(X)$:`,
        solution: `Áp dụng công thức tính kỳ vọng toán học của biến ngẫu nhiên rời rạc:\n$$E(X) = \\sum_{i=1}^3 x_i p_i = 1 \\cdot 0{,}2 + 2 \\cdot 0{,}5 + 3 \\cdot 0{,}3 = 0{,}2 + 1{,}0 + 0{,}9 = 2{,}1.$$`,
        diagram: { type: 'numberLine' }
      });
    }
  },

  // 12-cd1-b2: Phân bố nhị thức B(n, p)
  '12-cd1-b2': {
    id: '12-cd1-b2',
    topicTitle: 'Kỳ vọng và phương sai của phân bố nhị thức B(n, p)',
    grade: 12,
    generate: () => {
      const n = pick([10, 20, 50]);
      const p = 0.2; // E = n * 0.2
      const E = n * p;
      const V = n * p * (1 - p);

      return normalizeQuestionContent({
        id: `gen-12-cd1-b2-${Date.now()}`,
        topicTitle: 'Số đặc trưng của biến ngẫu nhiên phân bố nhị thức',
        grade: 12,
        context: `Biến ngẫu nhiên $X$ tuân theo phân bố nhị thức $B(${n}; 0{,}2)$.`,
        ask: 'Tính kỳ vọng toán học $E(X)$.',
        correctOption: `${E}`,
        distractors: [`${E * 2}`, `${V}`, `${E + 1}`],
        tfStatements: [
          {
            text: `Số phép thử Bernoulli độc lập là $n = ${n}$.`,
            isTrue: true,
            explanation: `Tham số thứ nhất trong ký hiệu $B(n, p)$ là số phép thử $n = ${n}$.`
          },
          {
            text: `Xác suất thành công ở mỗi phép thử là $p = 0{,}2$.`,
            isTrue: true,
            explanation: `Tham số thứ hai là $p = 0{,}2$.`
          },
          {
            text: `Kỳ vọng toán học $E(X) = n \\cdot p = ${n} \\cdot 0{,}2 = ${E}$.`,
            isTrue: true,
            explanation: `Công thức kỳ vọng của phân bố nhị thức: $E(X) = np = ${E}$.`
          },
          {
            text: `Phương sai của $X$ bằng $V(X) = np = ${E}$.`,
            isTrue: false,
            explanation: `Sai, công thức phương sai là $V(X) = np(1 - p) = ${n} \\cdot 0{,}2 \\cdot 0{,}8 = ${V}$.`
          }
        ],
        shortAnswer: `${E}`,
        shortAnswerPrompt: `Nhập giá trị kỳ vọng $E(X)$:`,
        solution: `Với biến ngẫu nhiên $X \\sim B(n, p)$, ta có các công thức đặc trưng:\n- Kỳ vọng: $E(X) = np = ${n} \\cdot 0{,}2 = ${E}$.\n- Phương sai: $V(X) = np(1 - p) = ${n} \\cdot 0{,}2 \\cdot 0{,}8 = ${V}$.\n- Độ lệch chuẩn: $\\sigma(X) = \\sqrt{V(X)} = \\sqrt{${V}}$.`,
        diagram: { type: 'numberLine' }
      });
    }
  },

  // 12-cd3-b5: Lãi đơn & Lãi kép
  '12-cd3-b5': {
    id: '12-cd3-b5',
    topicTitle: 'Công thức lãi kép trong bài toán tài chính',
    grade: 12,
    generate: () => {
      const A = randInt(10, 50) * 10; // millions, e.g., 200tr
      const r = pick([6, 7, 8]); // %/year
      const n = 2; // years
      const rate = r / 100;
      const Sn = Math.round(A * Math.pow(1 + rate, n) * 100) / 100;

      return normalizeQuestionContent({
        id: `gen-12-cd3-b5-${Date.now()}`,
        topicTitle: 'Tính tiền tích luỹ theo lãi kép',
        grade: 12,
        context: `Bác Ba gửi tiết kiệm $A = ${A}$ triệu đồng vào ngân hàng với lãi suất $r = ${r}\\%$/năm theo hình thức lãi kép định kỳ hàng năm. Giả sử lãi suất không đổi và bác không rút tiền trong suốt quá trình gửi.`,
        ask: `Tính số tiền cả gốc lẫn lãi bác Ba nhận được sau $2$ năm gửi (triệu đồng).`,
        correctOption: `${Sn}`,
        distractors: [
          `${A + A * rate * 2}`,
          `${Math.round(A * Math.pow(1 + rate, 3) * 100) / 100}`,
          `${A * 2}`
        ],
        tfStatements: [
          {
            text: `Công thức tính số tiền nhận về sau $n$ năm theo lãi kép là $S_n = A(1 + r)^n$.`,
            isTrue: true,
            explanation: `Đây là công thức lãi kép chuẩn.`
          },
          {
            text: `Tiền lãi sau năm thứ nhất là $A \\cdot r = ${A} \\cdot ${rate} = ${A * rate}$ triệu đồng.`,
            isTrue: true,
            explanation: `Tiền lãi năm đầu tính trên số vốn ban đầu.`
          },
          {
            text: `Số tiền nhận về sau 2 năm là $S_2 = ${A} \\cdot (1 + ${rate})^2 = ${Sn}$ triệu đồng.`,
            isTrue: true,
            explanation: `Tính toán: $S_2 = ${A} \\cdot ${(1 + rate).toFixed(2)}^2 = ${Sn}$.`
          },
          {
            text: `Số tiền nhận theo lãi kép luôn ít hơn số tiền tính theo hình thức lãi đơn.`,
            isTrue: false,
            explanation: `Sai, lãi kép có hiện tượng "lãi mẹ đẻ lãi con" nên luôn mang lại số tiền lớn hơn lãi đơn sau cùng kỳ hạn ($n > 1$).`
          }
        ],
        shortAnswer: `${Sn}`,
        shortAnswerPrompt: `Nhập số tiền nhận về sau 2 năm (triệu đồng):`,
        solution: `Áp dụng công thức lãi kép:\n$$S_n = A(1 + r)^n$$\nThay số: $A = ${A}$ triệu đồng, $r = ${r}\\% = ${rate}$, $n = 2$ năm:\n$$S_2 = ${A} \\cdot (1 + ${rate})^2 = ${A} \\cdot ${(1+rate)*(1+rate)} = ${Sn} \\text{ triệu đồng.}$$`,
        diagram: { type: 'numberLine' }
      });
    }
  },

  // 12-17: Mặt cầu trong Oxyz
  '12-17': {
    id: '12-17',
    topicTitle: 'Phương trình mặt cầu trong không gian Oxyz',
    grade: 12,
    generate: () => {
      const a = randInt(-3, 4);
      const b = randInt(-3, 4);
      const c = randInt(-3, 4);
      const R = randInt(2, 6);
      const R2 = R * R;
      const fmt = (x: number, varName: string) => {
        if (x === 0) return `${varName}^2`;
        return x > 0 ? `(${varName} - ${x})^2` : `(${varName} + ${Math.abs(x)})^2`;
      };
      const sphereEq = `${fmt(a, 'x')} + ${fmt(b, 'y')} + ${fmt(c, 'z')} = ${R2}`;
      const centerStr = `I(${a}; ${b}; ${c})`;
      return normalizeQuestionContent({
        id: `gen-12-17-${Date.now()}`,
        topicTitle: 'Phương trình mặt cầu trong không gian Oxyz',
        grade: 12,
        context: `Trong không gian $Oxyz$, cho mặt cầu $(S)$ có phương trình: $$${sphereEq}$$`,
        ask: `Tọa độ tâm $I$ và bán kính $R$ của mặt cầu $(S)$ là:`,
        correctOption: `$${centerStr}$ và $R = ${R}$`,
        distractors: [
          `$I(${-a}; ${-b}; ${-c})$ và $R = ${R}$`,
          `$${centerStr}$ và $R = ${R2}$`,
          `$I(${-a}; ${-b}; ${-c})$ và $R = ${R2}$`
        ],
        tfStatements: [
          {
            text: `Tâm của mặt cầu $(S)$ là điểm $${centerStr}$.`,
            isTrue: true,
            explanation: `Từ phương trình chuẩn $(x-a)^2 + (y-b)^2 + (z-c)^2 = R^2$, tâm là $${centerStr}$.`
          },
          {
            text: `Bán kính của mặt cầu là $R = ${R2}$.`,
            isTrue: false,
            explanation: `Sai, bán kính là $R = \\sqrt{${R2}} = ${R}$.`
          },
          {
            text: `Điểm gốc tọa độ $O(0; 0; 0)$ nằm ngoài mặt cầu khi $OI > R$.`,
            isTrue: true,
            explanation: `Đúng, khoảng cách từ $O$ đến tâm lớn hơn bán kính.`
          },
          {
            text: `Mặt phẳng toạ độ $(Oxy)$ cắt mặt cầu $(S)$ nếu khoảng cách $|c| < ${R}$.`,
            isTrue: true,
            explanation: `Đúng, khoảng cách từ $I(${a}; ${b}; ${c})$ đến $(Oxy)$ là $|c|$. Mặt cầu cắt $(Oxy)$ khi $|c| < R$.`
          }
        ],
        shortAnswer: `${R}`,
        shortAnswerPrompt: `Nhập bán kính $R$ của mặt cầu $(S)$:`,
        solution: `Phương trình chuẩn của mặt cầu có dạng:\n$$(x - a)^2 + (y - b)^2 + (z - c)^2 = R^2$$\nSo sánh với phương trình đã cho:\n- Tâm $I(a; b; c) = ${centerStr}$\n- Bán kính $R = \\sqrt{${R2}} = ${R}$.`,
        diagram: { type: 'circle' }
      });
    }
  },

  // 12-12: Tích phân cơ bản
  '12-12': {
    id: '12-12',
    topicTitle: 'Tích phân hàm đa thức',
    grade: 12,
    generate: () => {
      const a = randInt(1, 3);
      const c = randInt(1, 4);
      const upper = randInt(1, 3);
      const val = a * upper * upper + c * upper;
      return normalizeQuestionContent({
        id: `gen-12-12-${Date.now()}`,
        topicTitle: 'Tích phân hàm đa thức',
        grade: 12,
        context: `Cho tích phân $I = \\int_0^{${upper}} (${2*a}x + ${c}) \\, dx$.`,
        ask: `Giá trị của tích phân $I$ bằng:`,
        correctOption: `$${val}$`,
        distractors: [
          `$${val + 3}$`,
          `$${val - 2}$`,
          `$${val + 5}$`
        ],
        tfStatements: [
          {
            text: `Một nguyên hàm của hàm số $f(x) = ${2*a}x + ${c}$ là $F(x) = ${a}x^2 + ${c}x$.`,
            isTrue: true,
            explanation: `Đạo hàm $F'(x) = ${2*a}x + ${c} = f(x)$.`
          },
          {
            text: `Theo định nghĩa Newton-Leibniz, $\\int_0^{${upper}} f(x) dx = F(${upper}) - F(0)$.`,
            isTrue: true,
            explanation: `Đúng, đây là công thức định nghĩa tích phân.`
          },
          {
            text: `Giá trị tích phân $I$ luôn là một số âm.`,
            isTrue: false,
            explanation: `Sai, hàm số dương trên đoạn $[0; ${upper}]$ nên tích phân mang giá trị dương.`
          },
          {
            text: `Giá trị của tích phân $I$ bằng $${val}$.`,
            isTrue: true,
            explanation: `Tính: $F(${upper}) = ${a} \\cdot ${upper}^2 + ${c} \\cdot ${upper} = ${val}$, $F(0) = 0 \\implies I = ${val}$.`
          }
        ],
        shortAnswer: `${val}`,
        shortAnswerPrompt: `Nhập giá trị tích phân $I$:`,
        solution: `Ta có:\n$$I = \\int_0^{${upper}} (${2*a}x + ${c}) \\, dx = \\left. (${a}x^2 + ${c}x) \\right|_0^{${upper}} = (${a} \\cdot ${upper}^2 + ${c} \\cdot ${upper}) - 0 = ${val}.$$`,
        diagram: { type: 'integral' }
      });
    }
  },

  // 12-4b: Điểm uốn đồ thị hàm số
  '12-4b': {
    id: '12-4b',
    topicTitle: 'Tọa độ điểm uốn của đồ thị hàm bậc ba',
    grade: 12,
    generate: () => {
      const x0 = randInt(-2, 3);
      const a = pick([1, -1]);
      const c = randInt(-4, 4);
      const d = randInt(-3, 3);
      const y0 = a * Math.pow(x0, 3) - 3 * a * x0 * Math.pow(x0, 2) + c * x0 + d;
      const bCoeff = -3 * a * x0;
      const funcStr = `y = ${a === 1 ? 'x^3' : '-x^3'} ${bCoeff !== 0 ? (bCoeff > 0 ? `+ ${bCoeff}x^2` : `- ${Math.abs(bCoeff)}x^2`) : ''} ${c !== 0 ? (c > 0 ? `+ ${c}x` : `- ${Math.abs(c)}x`) : ''} ${d !== 0 ? (d > 0 ? `+ ${d}` : `- ${Math.abs(d)}`) : ''}`;
      return normalizeQuestionContent({
        id: `gen-12-4b-${Date.now()}`,
        topicTitle: 'Tọa độ điểm uốn của đồ thị hàm bậc ba',
        grade: 12,
        context: `Cho hàm số $${funcStr}$.`,
        ask: `Tọa độ tâm đối xứng (điểm uốn) $U$ của đồ thị hàm số là:`,
        correctOption: `$U(${x0}; ${y0})$`,
        distractors: [
          `$U(${-x0}; ${y0})$`,
          `$U(${x0}; ${-y0})$`,
          `$U(${x0 + 1}; ${y0 - 2})$`
        ],
        tfStatements: [
          {
            text: `Hoành độ điểm uốn thỏa mãn phương trình đạo hàm cấp hai $y'' = 0$.`,
            isTrue: true,
            explanation: `Đúng, với hàm số bậc ba, điểm uốn là nghiệm duy nhất của $y'' = 0$.`
          },
          {
            text: `Hoành độ điểm uốn của hàm số là $x_0 = ${x0}$.`,
            isTrue: true,
            explanation: `Tính $y'' = 6(${a})x + 2(${bCoeff}) = 0 \\iff x = ${x0}$.`
          },
          {
            text: `Đồ thị hàm số bậc ba luôn nhận điểm uốn làm tâm đối xứng.`,
            isTrue: true,
            explanation: `Đúng, mọi đồ thị hàm số bậc ba đều nhận điểm uốn làm tâm đối xứng.`
          },
          {
            text: `Tung độ điểm uốn là $y_0 = ${y0 + 5}$.`,
            isTrue: false,
            explanation: `Sai, thay $x = ${x0}$ vào phương trình ta được $y_0 = ${y0}$.`
          }
        ],
        shortAnswer: `${x0}`,
        shortAnswerPrompt: `Nhập hoành độ điểm uốn $x_U$:`,
        solution: `Ta có:\n- $y' = 3(${a})x^2 + 2(${bCoeff})x + ${c}$\n- $y'' = 6(${a})x + 2(${bCoeff})$\nCho $y'' = 0 \\iff x = ${x0}$. Thay vào hàm số tìm được $y = ${y0}$.\nVậy tâm đối xứng (điểm uốn) là $U(${x0}; ${y0})$.`,
        diagram: { type: 'cubic' }
      });
    }
  },

  // 10-19: Phương trình đường thẳng
  '10-19': {
    id: '10-19',
    topicTitle: 'Phương trình tổng quát của đường thẳng',
    grade: 10,
    generate: () => {
      const x0 = randInt(-3, 4);
      const y0 = randInt(-3, 4);
      const a = randNonZero(-4, 4);
      const b = randNonZero(-4, 4);
      const c = -a * x0 - b * y0;
      const cStr = c > 0 ? `+ ${c}` : c < 0 ? `- ${Math.abs(c)}` : '';
      const eqStr = `${a}x ${b > 0 ? `+ ${b}y` : `- ${Math.abs(b)}y`} ${cStr} = 0`;
      return normalizeQuestionContent({
        id: `gen-10-19-${Date.now()}`,
        topicTitle: 'Phương trình tổng quát của đường thẳng',
        grade: 10,
        context: `Trong mặt phẳng toạ độ $Oxy$, cho đường thẳng $\\Delta$ đi qua điểm $M(${x0}; ${y0})$ và nhận véctơ $\\vec{n} = (${a}; ${b})$ làm véctơ pháp tuyến.`,
        ask: `Phương trình tổng quát của đường thẳng $\\Delta$ là:`,
        correctOption: `$${eqStr}$`,
        distractors: [
          `$${a}x ${-b > 0 ? `+ ${-b}y` : `- ${Math.abs(-b)}y`} ${cStr} = 0$`,
          `$${b}x ${a > 0 ? `+ ${a}y` : `- ${Math.abs(a)}y`} ${cStr} = 0$`,
          `$${a}x ${b > 0 ? `+ ${b}y` : `- ${Math.abs(b)}y`} ${-c > 0 ? `+ ${-c}` : `- ${Math.abs(c)}`} = 0$`
        ],
        tfStatements: [
          {
            text: `Véctơ pháp tuyến của đường thẳng $\\Delta$ là $\\vec{n} = (${a}; ${b})$.`,
            isTrue: true,
            explanation: `Theo giả thiết đề bài.`
          },
          {
            text: `Một véctơ chỉ phương của $\\Delta$ có thể chọn là $\\vec{u} = (${-b}; ${a})$.`,
            isTrue: true,
            explanation: `Vì $\\vec{n} \\cdot \\vec{u} = ${a}(${-b}) + ${b}(${a}) = 0$.`
          },
          {
            text: `Đường thẳng $\\Delta$ đi qua điểm $M(${x0}; ${y0})$.`,
            isTrue: true,
            explanation: `Thay toạ độ $M$ vào phương trình thỏa mãn.`
          },
          {
            text: `Hệ số góc của đường thẳng $\\Delta$ luôn luôn bằng $1$.`,
            isTrue: false,
            explanation: `Hệ số góc của đường thẳng là $k = -\\frac{a}{b} = -\\frac{${a}}{${b}}$.`
          }
        ],
        shortAnswer: `${c}`,
        shortAnswerPrompt: `Nhập giá trị hệ số tự do $c$ trong phương trình $ax + by + c = 0$:`,
        solution: `Phương trình tổng quát của đường thẳng đi qua $M(x_0; y_0)$ với VTPT $\\vec{n} = (a; b)$ là:\n$$a(x - x_0) + b(y - y_0) = 0$$\nThay số: $$${a}(x - (${x0})) + ${b}(y - (${y0})) = 0 \\iff ${eqStr}.$$`
      });
    }
  },

  // 11-3: Tập xác định lượng giác
  '11-3': {
    id: '11-3',
    topicTitle: 'Tập xác định của hàm số lượng giác',
    grade: 11,
    generate: () => {
      const a = randInt(1, 4);
      return normalizeQuestionContent({
        id: `gen-11-3-${Date.now()}`,
        topicTitle: 'Tập xác định của hàm số lượng giác',
        grade: 11,
        context: `Cho hàm số $y = \\tan(${a}x)$.`,
        ask: `Tập xác định của hàm số là:`,
        correctOption: `$D = \\mathbb{R} \\setminus \\left\\{ \\frac{\\pi}{${2*a}} + \\frac{k\\pi}{${a}}, k \\in \\mathbb{Z} \\right\\}$`,
        distractors: [
          `$D = \\mathbb{R} \\setminus \\left\\{ \\frac{k\\pi}{${a}}, k \\in \\mathbb{Z} \\right\\}$`,
          `$D = \\mathbb{R}$`,
          `$D = \\mathbb{R} \\setminus \\left\\{ \\frac{\\pi}{2} + k\\pi, k \\in \\mathbb{Z} \\right\\}$`
        ],
        tfStatements: [
          {
            text: `Hàm số $y = \\tan(${a}x)$ xác định khi $\\cos(${a}x) \\ne 0$.`,
            isTrue: true,
            explanation: `Vì $\\tan(${a}x) = \\frac{\\sin(${a}x)}{\\cos(${a}x)}$.`
          },
          {
            text: `Phương trình $\\cos(${a}x) = 0 \\iff ${a}x = \\frac{\\pi}{2} + k\\pi \\iff x = \\frac{\\pi}{${2*a}} + \\frac{k\\pi}{${a}}$ ($k \\in \\mathbb{Z}$).`,
            isTrue: true,
            explanation: `Nghiệm phương trình lượng giác cơ bản của hàm cos.`
          },
          {
            text: `Hàm số $y = \\tan(${a}x)$ là hàm số chẵn.`,
            isTrue: false,
            explanation: `Sai, hàm số $\\tan$ là hàm số lẻ.`
          },
          {
            text: `Chu kì tuần hoàn của hàm số là $T = \\frac{\\pi}{${a}}$.`,
            isTrue: true,
            explanation: `Chu kì của hàm $y = \\tan(\\omega x)$ là $T = \\frac{\\pi}{|\\omega|} = \\frac{\\pi}{${a}}$.`
          }
        ],
        shortAnswer: `${a}`,
        shortAnswerPrompt: `Nhập giá trị hệ số góc $a$ của biến trong hàm số:`,
        solution: `Điều kiện xác định của hàm số $y = \\tan(${a}x)$ là:\n$$\\cos(${a}x) \\ne 0 \\iff ${a}x \\ne \\frac{\\pi}{2} + k\\pi \\iff x \\ne \\frac{\\pi}{${2*a}} + \\frac{k\\pi}{${a}} \\quad (k \\in \\mathbb{Z}).$$\nVậy tập xác định là $D = \\mathbb{R} \\setminus \\left\\{ \\frac{\\pi}{${2*a}} + \\frac{k\\pi}{${a}}, k \\in \\mathbb{Z} \\right\\}$.`,
        diagram: { type: 'trig' }
      });
    }
  }
};

// Guarantee all generators automatically pass through single-pass normalization:
Object.keys(TOPIC_GENERATORS).forEach((key) => {
  const origGenerate = TOPIC_GENERATORS[key].generate;
  TOPIC_GENERATORS[key].generate = () => normalizeQuestionContent(origGenerate());
});

/**
 * Smart generator resolver that finds the best matching generator
 * for any lesson ID across Grades 10, 11, and 12.
 */
export function getGeneratorForLesson(lessonId: string, grade: Grade = 12): GeneratorDef {
  if (TOPIC_GENERATORS[lessonId]) {
    return TOPIC_GENERATORS[lessonId];
  }

  // 1. Grade 10 fallbacks:
  if (lessonId.startsWith('10-')) {
    if (lessonId === '10-4' || lessonId === '10-rev2') return TOPIC_GENERATORS['10-3'];
    if (lessonId === '10-rev3') return TOPIC_GENERATORS['10-5'];
    if (lessonId.includes('10-7') || lessonId.includes('10-8') || lessonId.includes('10-9') || lessonId.includes('rev4')) return TOPIC_GENERATORS['10-10'];
    if (lessonId.includes('10-12') || lessonId.includes('10-13') || lessonId.includes('10-14') || lessonId.includes('rev5')) return TOPIC_GENERATORS['10-2'];
    if (lessonId.includes('10-15') || lessonId.includes('10-18-pt') || lessonId.includes('rev6')) return TOPIC_GENERATORS['10-16'];
    if (lessonId.includes('10-19') || lessonId.includes('10-20') || lessonId.includes('10-22') || lessonId.includes('rev7')) return TOPIC_GENERATORS['10-21'];
    if (lessonId.includes('10-23') || lessonId.includes('10-25') || lessonId.includes('rev8')) return TOPIC_GENERATORS['10-24'];
    if (lessonId.includes('10-27') || lessonId.includes('rev9')) return TOPIC_GENERATORS['10-26'];
    return TOPIC_GENERATORS['10-1'];
  }

  // 2. Grade 11 fallbacks:
  if (lessonId.startsWith('11-')) {
    if (lessonId.includes('11-3') || lessonId.includes('rev1')) return TOPIC_GENERATORS['11-1'];
    if (lessonId.includes('11-5') || lessonId.includes('rev2')) return TOPIC_GENERATORS['11-6'];
    if (lessonId.includes('11-8') || lessonId.includes('11-9') || lessonId.includes('rev3')) return TOPIC_GENERATORS['11-6'];
    if (lessonId.includes('11-10') || lessonId.includes('11-11') || lessonId.includes('11-12') || lessonId.includes('11-13') || lessonId.includes('11-14') || lessonId.includes('rev4')) return TOPIC_GENERATORS['11-27'];
    if (lessonId.includes('11-17') || lessonId.includes('rev5')) return TOPIC_GENERATORS['11-16'];
    if (lessonId.includes('11-18') || lessonId.includes('11-20') || lessonId.includes('rev6')) return TOPIC_GENERATORS['11-19'];
    if (lessonId.includes('11-22') || lessonId.includes('11-23') || lessonId.includes('11-24') || lessonId.includes('11-25') || lessonId.includes('11-26') || lessonId.includes('rev7')) return TOPIC_GENERATORS['11-27'];
    if (lessonId.includes('11-28') || lessonId.includes('11-29') || lessonId.includes('rev8')) return TOPIC_GENERATORS['11-30'];
    if (lessonId.includes('11-33') || lessonId.includes('rev9')) return TOPIC_GENERATORS['11-31'];
    return TOPIC_GENERATORS['11-1'];
  }

  // 3. Grade 12 fallbacks:
  if (lessonId.startsWith('12-')) {
    if (lessonId.includes('12-4b') || lessonId.includes('12-5') || lessonId.includes('rev1')) return TOPIC_GENERATORS['12-1'];
    if (lessonId.includes('rev2')) return TOPIC_GENERATORS['12-7'];
    if (lessonId.includes('12-9') || lessonId.includes('rev3')) return TOPIC_GENERATORS['12-9a'];
    if (lessonId.includes('12-12') || lessonId.includes('rev4')) return TOPIC_GENERATORS['12-13'];
    if (lessonId.includes('12-17') || lessonId.includes('rev5')) return TOPIC_GENERATORS['12-15'];
    if (lessonId.includes('rev6')) return TOPIC_GENERATORS['12-19'];
    return TOPIC_GENERATORS['12-1'];
  }

  // Grade-level fallback
  if (grade === 10) return TOPIC_GENERATORS['10-1'];
  if (grade === 11) return TOPIC_GENERATORS['11-1'];
  return TOPIC_GENERATORS['12-1'];
}

/**
 * Procedural generator for a complete 2025 THPT Exam conforming strictly to Ministry of Education guidelines:
 * - Part I: 12 MCQ (3.0 pts)
 * - Part II: 4 True/False (4.0 pts)
 * - Part III: 6 Short Answer (3.0 pts)
 */
export function generateFullExam2025(schoolName = 'TRƯỜNG THPT CHUYÊN TOÁN - THẦY PHẠM BẢO ANH') {
  const code = `${randInt(101, 899)}`;
  const allKeys = Object.keys(TOPIC_GENERATORS);

  // 1. Part I: 12 MCQ
  const part1Questions: any[] = [];
  for (let i = 0; i < 12; i++) {
    const key = pick(allKeys);
    const qData = TOPIC_GENERATORS[key].generate();

    const optionsRaw = [
      { label: 'A' as const, content: qData.correctOption },
      { label: 'B' as const, content: qData.distractors[0] || '1' },
      { label: 'C' as const, content: qData.distractors[1] || '2' },
      { label: 'D' as const, content: qData.distractors[2] || '3' }
    ];

    const shuffled = shuffle(optionsRaw);
    const correctLabel = (shuffled.findIndex(o => o.content === qData.correctOption) === 0 ? 'A' :
      shuffled.findIndex(o => o.content === qData.correctOption) === 1 ? 'B' :
      shuffled.findIndex(o => o.content === qData.correctOption) === 2 ? 'C' : 'D') as 'A' | 'B' | 'C' | 'D';

    const labeledOptions = shuffled.map((o, idx) => ({
      label: (['A', 'B', 'C', 'D'][idx]) as 'A' | 'B' | 'C' | 'D',
      content: o.content
    }));

    part1Questions.push({
      id: `p1-q${i + 1}`,
      number: i + 1,
      stem: normalizeMathContent(`${qData.context} ${qData.ask}`),
      options: labeledOptions,
      correctAnswer: correctLabel,
      solution: qData.solution,
      diagram: qData.diagram
    });
  }

  // 2. Part II: 4 True / False
  const part2Questions: any[] = [];
  const tfKeys = ['12-1', '12-2', '12-6', '12-14'];
  for (let i = 0; i < 4; i++) {
    const key = tfKeys[i] || pick(allKeys);
    const qData = TOPIC_GENERATORS[key].generate();

    const subQuestions = qData.tfStatements.map((tf, sIdx) => ({
      id: `p2-q${i + 1}-${['a', 'b', 'c', 'd'][sIdx]}`,
      label: (['a', 'b', 'c', 'd'][sIdx]) as 'a' | 'b' | 'c' | 'd',
      text: normalizeMathContent(tf.text),
      isCorrect: tf.isTrue,
      explanation: tf.explanation
    }));

    part2Questions.push({
      id: `p2-q${i + 1}`,
      number: i + 1,
      stem: normalizeMathContent(qData.context),
      subQuestions,
      solution: qData.solution,
      diagram: qData.diagram
    });
  }

  // 3. Part III: 6 Short Answer
  const part3Questions: any[] = [];
  const saKeys = ['12-1', '12-6', '12-11', '12-14', '11-6', '12-18'];
  for (let i = 0; i < 6; i++) {
    const key = saKeys[i] || pick(allKeys);
    const qData = TOPIC_GENERATORS[key].generate();

    part3Questions.push({
      id: `p3-q${i + 1}`,
      number: i + 1,
      stem: normalizeMathContent(`${qData.context} ${qData.shortAnswerPrompt || qData.ask}`),
      correctAnswer: qData.shortAnswer,
      solution: qData.solution,
      diagram: qData.diagram
    });
  }

  return {
    id: `exam-${Date.now()}`,
    code,
    config: {
      grade: 12 as const,
      type: 'tn' as const,
      format: 'full' as const,
      schoolName,
      studentName: '',
      studentCode: ''
    },
    title: 'ĐỀ THI TỐT NGHIỆP THPT QUỐC GIA NĂM 2025 - MÔN TOÁN',
    durationMinutes: 90,
    createdAt: new Date().toLocaleDateString('vi-VN'),
    part1: part1Questions,
    part2: part2Questions,
    part3: part3Questions
  };
}
