import { Chapter, Grade, Lesson } from '../types/math';

export const CURRICULUM: Record<Grade, Chapter[]> = {
  10: [
    {
      title: 'Chương I. Mệnh đề và tập hợp',
      grade: 10,
      lessons: [
        {
          id: '10-1',
          title: 'Bài 1. Mệnh đề toán học',
          grade: 10,
          chapterIndex: 0,
          chapterTitle: 'Chương I. Mệnh đề và tập hợp',
          theoryHtml: `
            <p>Mệnh đề là một khẳng định đúng hoặc một khẳng định sai. Không có mệnh đề nào vừa đúng vừa sai.</p>
            <p>Phủ định của mệnh đề $P$ là mệnh đề $\\overline{P}$. $\\overline{P}$ đúng khi $P$ sai, và ngược lại.</p>
          `,
          formulas: [
            '\\overline{\\forall x \\in X, P(x)} \\Leftrightarrow \\exists x \\in X, \\overline{P(x)}',
            '\\overline{\\exists x \\in X, P(x)} \\Leftrightarrow \\forall x \\in X, \\overline{P(x)}',
            'P \\Rightarrow Q \\text{ sai khi và chỉ khi } P \\text{ đúng và } Q \\text{ sai}'
          ],
          keyNotes: [
            'Khi phủ định mệnh đề chứa $\\forall$ chuyển thành $\\exists$ và ngược lại.',
            'Dấu $>$ phủ định thành $\\le$, dấu $\\ge$ phủ định thành $<$.',
            'Định lí đảo: Nếu $P \\Rightarrow Q$ đúng thì mệnh đề đảo $Q \\Rightarrow P$ chưa chắc đúng.'
          ],
          diagramType: 'numberLine'
        },
        {
          id: '10-2',
          title: 'Bài 2. Tập hợp và các phép toán trên tập hợp',
          grade: 10,
          chapterIndex: 0,
          chapterTitle: 'Chương I. Mệnh đề và tập hợp',
          theoryHtml: `
            <p>Tập hợp gồm các phần tử xác định. Có 3 phép toán cơ bản: Giao, Hợp và Hiệu của hai tập hợp.</p>
          `,
          formulas: [
            'A \\cap B = \\{x \\mid x \\in A \\text{ và } x \\in B\\}',
            'A \\cup B = \\{x \\mid x \\in A \\text{ hoặc } x \\in B\\}',
            'A \\setminus B = \\{x \\mid x \\in A \\text{ và } x \\notin B\\}',
            'C_E A = E \\setminus A \\quad (A \\subset E)'
          ],
          keyNotes: [
            'Khoảng $(a; b)$, đoạn $[a; b]$, nửa khoảng $[a; b)$ hoặc $(a; b]$.',
            'Khi biểu diễn trên trục số, phần không thuộc tập hợp ta gạch chéo bỏ.'
          ],
          diagramType: 'numberLine'
        }
      ]
    },
    {
      title: 'Chương II. Bất phương trình & Hệ BPT bậc nhất hai ẩn',
      grade: 10,
      lessons: [
        {
          id: '10-3',
          title: 'Bài 3. Bất phương trình bậc nhất hai ẩn',
          grade: 10,
          chapterIndex: 1,
          chapterTitle: 'Chương II. Bất phương trình & Hệ BPT bậc nhất hai ẩn',
          theoryHtml: `
            <p>BPT dạng $ax + by \\le c$ (hoặc $<, >, \\ge$) với $a^2 + b^2 \\ne 0$. Đường thẳng $ax + by = c$ chia mặt phẳng thành hai nửa mặt phẳng bờ $d$.</p>
          `,
          formulas: [
            'ax + by \\le c',
            '\\text{Thử điểm } O(0; 0) \\text{ để xác định nửa mặt phẳng nghiệm}'
          ],
          keyNotes: [
            'Miền nghiệm của hệ BPT là giao của các miền nghiệm thành phần, thường là một đa giác lồi.',
            'Giá trị lớn nhất / nhỏ nhất của $F(x; y) = ax + by$ luôn đạt tại một trong các đỉnh của miền đa giác nghiệm.'
          ]
        }
      ]
    },
    {
      title: 'Chương III. Hệ thức lượng trong tam giác',
      grade: 10,
      lessons: [
        {
          id: '10-5',
          title: 'Bài 5. Định lí côsin và định lí sin',
          grade: 10,
          chapterIndex: 2,
          chapterTitle: 'Chương III. Hệ thức lượng trong tam giác',
          theoryHtml: `
            <p>Hệ thức lượng liên kết độ dài 3 cạnh và 3 góc trong tam giác bất kì, hỗ trợ giải tam giác và đo đạc thực địa.</p>
          `,
          formulas: [
            'a^2 = b^2 + c^2 - 2bc\\cos A',
            '\\frac{a}{\\sin A} = \\frac{b}{\\sin B} = \\frac{c}{\\sin C} = 2R',
            'S = \\frac{1}{2}ab\\sin C = \\frac{abc}{4R} = pr = \\sqrt{p(p-a)(p-b)(p-c)}'
          ],
          keyNotes: [
            'Biết 2 cạnh và góc xen giữa: dùng định lí côsin tính cạnh thứ 3.',
            'Biết 1 cạnh và 2 góc kề: dùng định lí sin tính bán kính $R$ và các cạnh còn lại.'
          ]
        }
      ]
    },
    {
      title: 'Chương IV. Vectơ',
      grade: 10,
      lessons: [
        {
          id: '10-7',
          title: 'Bài 7. Các phép toán vectơ & Tích vô hướng',
          grade: 10,
          chapterIndex: 3,
          chapterTitle: 'Chương IV. Vectơ',
          theoryHtml: `
            <p>Vectơ là đoạn thẳng có hướng. Quy tắc 3 điểm: $\\vec{AB} + \\vec{BC} = \\vec{AC}$. Quy tắc hình bình hành: $\\vec{AB} + \\vec{AD} = \\vec{AC}$.</p>
          `,
          formulas: [
            '\\vec{u} \\cdot \\vec{v} = |\\vec{u}| \\cdot |\\vec{v}| \\cos(\\vec{u}, \\vec{v})',
            '\\vec{u} \\perp \\vec{v} \\Leftrightarrow \\vec{u} \\cdot \\vec{v} = 0',
            '|\\vec{u}| = \\sqrt{u_1^2 + u_2^2}, \\quad \\vec{u} \\cdot \\vec{v} = u_1 v_1 + u_2 v_2'
          ],
          keyNotes: [
            'Trung điểm $M$ của $AB$: $\\vec{MA} + \\vec{MB} = \\vec{0}$, với mọi điểm $O$: $\\vec{OA} + \\vec{OB} = 2\\vec{OM}$.',
            'Trọng tâm $G$ của tam giác $ABC$: $\\vec{GA} + \\vec{GB} + \\vec{GC} = \\vec{0}$.'
          ]
        }
      ]
    },
    {
      title: 'Chương V. Phương pháp tọa độ trong mặt phẳng Oxy',
      grade: 10,
      lessons: [
        {
          id: '10-18',
          title: 'Bài 18. Phương trình đường thẳng và đường tròn',
          grade: 10,
          chapterIndex: 4,
          chapterTitle: 'Chương V. Phương pháp tọa độ trong mặt phẳng Oxy',
          theoryHtml: `
            <p>Đường thẳng qua $M(x_0; y_0)$ có VTPT $\\vec{n}=(a; b)$: $a(x-x_0) + b(y-y_0) = 0$.</p>
          `,
          formulas: [
            '\\Delta: ax + by + c = 0',
            'd(M, \\Delta) = \\frac{|ax_0 + by_0 + c|}{\\sqrt{a^2 + b^2}}',
            '(C): (x - a)^2 + (y - b)^2 = R^2'
          ],
          keyNotes: [
            'VTCP $\\vec{u} = (u_1; u_2) \\Rightarrow$ VTPT $\\vec{n} = (-u_2; u_1)$.',
            'Vị trí tương đối: $d(I, \\Delta) < R$ cắt tại 2 điểm; $d=R$ tiếp xúc; $d > R$ không giao.'
          ]
        }
      ]
    }
  ],
  11: [
    {
      title: 'Chương I. Hàm số lượng giác & Phương trình lượng giác',
      grade: 11,
      lessons: [
        {
          id: '11-1',
          title: 'Bài 1. Giá trị lượng giác & Công thức lượng giác',
          grade: 11,
          chapterIndex: 0,
          chapterTitle: 'Chương I. Hàm số lượng giác & Phương trình lượng giác',
          theoryHtml: `
            <p>Góc lượng giác: $\\pi\\text{ rad} = 180^\\circ$. Các hệ thức lượng giác cơ bản và công thức cộng, góc nhân đôi.</p>
          `,
          formulas: [
            '\\sin(a \\pm b) = \\sin a\\cos b \\pm \\cos a\\sin b',
            '\\cos(a \\pm b) = \\cos a\\cos b \\mp \\sin a\\sin b',
            '\\sin 2a = 2\\sin a\\cos a, \\quad \\cos 2a = \\cos^2 a - \\sin^2 a = 2\\cos^2 a - 1 = 1 - 2\\sin^2 a',
            '\\sin x = \\sin \\alpha \\Leftrightarrow x = \\alpha + k2\\pi \\text{ hoặc } x = \\pi - \\alpha + k2\\pi'
          ],
          keyNotes: [
            'Hàm số $y = \\sin x$ tuần hoàn chu kì $2\\pi$, hàm lẻ.',
            'Hàm số $y = \\cos x$ tuần hoàn chu kì $2\\pi$, hàm chẵn.',
            'Hàm số $y = \\tan x$ tuần hoàn chu kì $\\pi$, xác định khi $x \\ne \\frac{\\pi}{2} + k\\pi$.'
          ],
          diagramType: 'trig'
        }
      ]
    },
    {
      title: 'Chương II. Dãy số. Cấp số cộng và cấp số nhân',
      grade: 11,
      lessons: [
        {
          id: '11-6',
          title: 'Bài 6. Cấp số cộng và cấp số nhân',
          grade: 11,
          chapterIndex: 1,
          chapterTitle: 'Chương II. Dãy số. Cấp số cộng và cấp số nhân',
          theoryHtml: `
            <p>Cấp số cộng có công sai $d$: $u_{n+1} = u_n + d$. Cấp số nhân có công bội $q$: $u_{n+1} = u_n \\cdot q$.</p>
          `,
          formulas: [
            'CSC: u_n = u_1 + (n - 1)d, \\quad S_n = \\frac{n(u_1 + u_n)}{2} = \\frac{n[2u_1 + (n - 1)d]}{2}',
            'CSN: u_n = u_1 \\cdot q^{n - 1}, \\quad S_n = u_1 \\frac{1 - q^n}{1 - q} \\quad (q \\ne 1)',
            'CSN lùi vô hạn (|q| < 1): S = \\frac{u_1}{1 - q}'
          ],
          keyNotes: [
            'Ba số $a, b, c$ lập thành CSC $\\Leftrightarrow a + c = 2b$.',
            'Ba số $a, b, c$ lập thành CSN $\\Leftrightarrow ac = b^2$.'
          ]
        }
      ]
    },
    {
      title: 'Chương III. Giới hạn & Hàm số liên tục',
      grade: 11,
      lessons: [
        {
          id: '11-15',
          title: 'Bài 15. Giới hạn của hàm số và dãy số',
          grade: 11,
          chapterIndex: 2,
          chapterTitle: 'Chương III. Giới hạn & Hàm số liên tục',
          theoryHtml: `
            <p>Khử các dạng vô định $\\frac{0}{0}, \\frac{\\infty}{\\infty}, \\infty - \\infty$. Phương pháp phân tích nhân tử hoặc nhân lượng liên hợp.</p>
          `,
          formulas: [
            '\\lim_{x \\to x_0} \\frac{f(x)}{g(x)} \\quad (\\text{dạng } 0/0)',
            '\\lim_{n \\to \\infty} \\frac{a n^k + \\dots}{b n^k + \\dots} = \\frac{a}{b}',
            'f(x) \\text{ liên tục tại } x_0 \\Leftrightarrow \\lim_{x \\to x_0} f(x) = f(x_0)'
          ],
          keyNotes: [
            'Nếu $f$ liên tục trên $[a; b]$ và $f(a) \\cdot f(b) < 0$ thì phương trình $f(x) = 0$ có ít nhất 1 nghiệm thuộc khoảng $(a; b)$.'
          ]
        }
      ]
    },
    {
      title: 'Chương IV. Hàm số mũ và hàm số lôgarit',
      grade: 11,
      lessons: [
        {
          id: '11-20',
          title: 'Bài 20. Lôgarit, hàm mũ & Phương trình mũ - lôgarit',
          grade: 11,
          chapterIndex: 3,
          chapterTitle: 'Chương IV. Hàm số mũ và hàm số lôgarit',
          theoryHtml: `
            <p>Định nghĩa lôgarit: $\\log_a b = \\alpha \\Leftrightarrow a^\\alpha = b$ ($0 < a \\ne 1, b > 0$).</p>
          `,
          formulas: [
            '\\log_a (xy) = \\log_a x + \\log_a y, \\quad \\log_a \\frac{x}{y} = \\log_a x - \\log_a y',
            '\\log_a x^\\alpha = \\alpha \\log_a x, \\quad \\log_a b = \\frac{\\log_c b}{\\log_c a}',
            'a^x = b \\Leftrightarrow x = \\log_a b \\quad (b > 0)',
            '\\log_a f(x) = b \\Leftrightarrow f(x) = a^b'
          ],
          keyNotes: [
            'Khi giải phương trình / bất phương trình lôgarit, luôn đặt ĐIỀU KIỆN biểu thức dưới dấu log > 0 trước tiên.',
            'Cơ số $a > 1$: hàm đồng biến, cùng chiều BPT. Cơ số $0 < a < 1$: nghịch biến, đổi chiều BPT.'
          ]
        }
      ]
    },
    {
      title: 'Chương V. Quan hệ vuông góc trong không gian',
      grade: 11,
      lessons: [
        {
          id: '11-25',
          title: 'Bài 25. Đường thẳng vuông góc mặt phẳng & Khoảng cách',
          grade: 11,
          chapterIndex: 4,
          chapterTitle: 'Chương V. Quan hệ vuông góc trong không gian',
          theoryHtml: `
            <p>Đường thẳng $d \\perp (P)$ nếu $d$ vuông góc với hai đường thẳng cắt nhau nằm trong $(P)$.</p>
          `,
          formulas: [
            'd \\perp a, d \\perp b \\quad (a, b \\subset (P), a \\cap b = O) \\Rightarrow d \\perp (P)',
            'd \\perp (P) \\Rightarrow d \\perp c \\quad (\\forall c \\subset (P))',
            'V_{ch\\acute{o}p} = \\frac{1}{3} S_{day} \\cdot h, \\quad V_{l\\u{a}ng\\,tr\\u{u}} = S_{day} \\cdot h'
          ],
          keyNotes: [
            'Định lí ba đường vuông góc.',
            'Góc giữa đường thẳng và mặt phẳng là góc giữa đường thẳng đó và hình chiếu vuông góc của nó lên mặt phẳng.'
          ],
          diagramType: 'pyramid'
        }
      ]
    }
  ],
  12: [
    {
      title: 'Chương I. Ứng dụng đạo hàm để khảo sát hàm số',
      grade: 12,
      lessons: [
        {
          id: '12-1',
          title: 'Bài 1. Tính đơn điệu của hàm số',
          grade: 12,
          chapterIndex: 0,
          chapterTitle: 'Chương I. Ứng dụng đạo hàm để khảo sát hàm số',
          theoryHtml: `
            <p>Cho hàm số $y = f(x)$ có đạo hàm trên khoảng $K$. Nếu $f'(x) \\ge 0$ với mọi $x \\in K$ (bằng 0 tại hữu hạn điểm) thì $f$ đồng biến trên $K$.</p>
          `,
          formulas: [
            'f\'(x) > 0 \\quad (\\forall x \\in K) \\Rightarrow f \\text{ đồng biến trên } K',
            'f\'(x) < 0 \\quad (\\forall x \\in K) \\Rightarrow f \\text{ nghịch biến trên } K',
            'y = ax^3 + bx^2 + cx + d \\Rightarrow y\' = 3ax^2 + 2bx + c'
          ],
          keyNotes: [
            'Hàm phân thức $y = \\frac{ax+b}{cx+d}$ có $y\' = \\frac{ad-bc}{(cx+d)^2}$, luôn đồng biến hoặc nghịch biến trên từng khoảng xác định, không bao giờ kết luận "trên $\\mathbb{R} \\setminus \\{-d/c\\}$".'
          ],
          diagramType: 'cubic'
        },
        {
          id: '12-2',
          title: 'Bài 2. Cực trị của hàm số',
          grade: 12,
          chapterIndex: 0,
          chapterTitle: 'Chương I. Ứng dụng đạo hàm để khảo sát hàm số',
          theoryHtml: `
            <p>Điểm $x_0$ là điểm cực trị nếu đạo hàm $f'(x)$ đổi dấu khi $x$ đi qua $x_0$.</p>
            <p>Quy tắc 2: Nếu $f'(x_0) = 0$ và $f''(x_0) < 0 \\Rightarrow x_0$ là điểm cực đại; nếu $f''(x_0) > 0 \\Rightarrow x_0$ là điểm cực tiểu.</p>
          `,
          formulas: [
            'f\'(x_0) = 0, \\quad f\'\'(x_0) < 0 \\Rightarrow x_0 \\text{ là điểm cực đại}',
            'f\'(x_0) = 0, \\quad f\'\'(x_0) > 0 \\Rightarrow x_0 \\text{ là điểm cực tiểu}',
            '\\text{Cực đại: đổi dấu từ } + \\to - ; \\quad \\text{Cực tiểu: đổi dấu từ } - \\to +'
          ],
          keyNotes: [
            'Phân biệt: "Điểm cực trị của hàm số" ($x_0$), "Giá trị cực trị" ($y_0 = f(x_0)$), "Điểm cực trị của đồ thị" ($M(x_0; y_0)$).'
          ],
          diagramType: 'cubic'
        },
        {
          id: '12-3',
          title: 'Bài 3. Giá trị lớn nhất và nhỏ nhất của hàm số',
          grade: 12,
          chapterIndex: 0,
          chapterTitle: 'Chương I. Ứng dụng đạo hàm để khảo sát hàm số',
          theoryHtml: `
            <p>Tìm GTLN, GTNN trên đoạn $[a; b]$: Tính $f(a), f(b)$ và các giá trị $f(x_i)$ tại các nghiệm $x_i \\in [a; b]$ của $f'(x) = 0$. So sánh các giá trị tìm được.</p>
          `,
          formulas: [
            '\\max_{[a;b]} f(x) = \\max \\{ f(a), f(b), f(x_1), f(x_2), \\dots \\}',
            '\\min_{[a;b]} f(x) = \\min \\{ f(a), f(b), f(x_1), f(x_2), \\dots \\}'
          ],
          keyNotes: [
            'Ứng dụng thực tế: Thiết lập hàm mục tiêu $f(x)$, xác định điều kiện biến $x$, tìm $x$ để hàm đạt max hoặc min.'
          ],
          diagramType: 'appliedMaxMin'
        },
        {
          id: '12-4',
          title: 'Bài 4. Đường tiệm cận của đồ thị hàm số',
          grade: 12,
          chapterIndex: 0,
          chapterTitle: 'Chương I. Ứng dụng đạo hàm để khảo sát hàm số',
          theoryHtml: `
            <p>Tiệm cận đứng: $\\lim_{x \\to x_0^\\pm} y = \\pm\\infty \\Rightarrow x = x_0$ là TCĐ.</p>
            <p>Tiệm cận ngang: $\\lim_{x \\to \\pm\\infty} y = y_0 \\Rightarrow y = y_0$ là TCN.</p>
            <p>Tiệm cận xiên: $y = ax + b$ khi $\\lim_{x \\to \\pm\\infty} [f(x) - (ax + b)] = 0$.</p>
          `,
          formulas: [
            'y = \\frac{ax+b}{cx+d} \\Rightarrow \\text{TCĐ: } x = -\\frac{d}{c}, \\quad \\text{TCN: } y = \\frac{a}{c}',
            'y = \\frac{ax^2+bx+c}{px+q} = mx + n + \\frac{r}{px+q} \\Rightarrow \\text{TCX: } y = mx + n'
          ],
          keyNotes: [
            'Tâm đối xứng của đồ thị hàm phân thức bậc nhất là giao điểm của hai đường tiệm cận $I(-d/c; a/c)$.'
          ],
          diagramType: 'rational',
          diagramParams: {
            a: 2,
            b: 1,
            c: 1,
            d: -1,
            xRange: [-4, 6],
            yRange: [-3, 7],
            caption: 'Đồ thị hàm số y = (2x + 1)/(x − 1)'
          }
        }
      ]
    },
    {
      title: 'Chương II. Vectơ và Hệ trục tọa độ Oxyz trong không gian',
      grade: 12,
      lessons: [
        {
          id: '12-6',
          title: 'Bài 6. Vectơ và Hệ trục tọa độ Oxyz',
          grade: 12,
          chapterIndex: 1,
          chapterTitle: 'Chương II. Vectơ và Hệ trục tọa độ Oxyz trong không gian',
          theoryHtml: `
            <p>Hệ tọa độ $Oxyz$ gồm 3 trục vuông góc từng đôi một. $M(x; y; z) \\Leftrightarrow \\vec{OM} = x\\vec{i} + y\\vec{j} + z\\vec{k}$.</p>
          `,
          formulas: [
            '\\vec{u} \\cdot \\vec{v} = u_1 v_1 + u_2 v_2 + u_3 v_3',
            '|\\vec{u}| = \\sqrt{u_1^2 + u_2^2 + u_3^2}',
            '\\cos(\\vec{u}, \\vec{v}) = \\frac{\\vec{u} \\cdot \\vec{v}}{|\\vec{u}| \\cdot |\\vec{v}|}',
            '[\\vec{u}, \\vec{v}] = (u_2 v_3 - u_3 v_2; u_3 v_1 - u_1 v_3; u_1 v_2 - u_2 v_1)'
          ],
          keyNotes: [
            'Tích có hướng $[\\vec{u}, \\vec{v}]$ vuông góc với cả $\\vec{u}$ và $\\vec{v}$.',
            'Hình chiếu của $M(x; y; z)$ lên $(Oxy)$ là $(x; y; 0)$, lên trục $Ox$ là $(x; 0; 0)$.'
          ],
          diagramType: 'box'
        }
      ]
    },
    {
      title: 'Chương III. Mức độ phân tán của mẫu số liệu ghép nhóm',
      grade: 12,
      lessons: [
        {
          id: '12-9',
          title: 'Bài 9. Phương sai & Độ lệch chuẩn của mẫu ghép nhóm',
          grade: 12,
          chapterIndex: 2,
          chapterTitle: 'Chương III. Mức độ phân tán của mẫu số liệu ghép nhóm',
          theoryHtml: `
            <p>Đo độ phân tán của mẫu số liệu ghép nhóm quanh giá trị trung bình $\\bar{x}$.</p>
          `,
          formulas: [
            '\\bar{x} = \\frac{1}{n} \\sum n_i c_i \\quad (c_i: \\text{giá trị đại diện})',
            's^2 = \\frac{1}{n} \\sum n_i (c_i - \\bar{x})^2 = \\frac{1}{n} \\sum n_i c_i^2 - \\bar{x}^2',
            's = \\sqrt{s^2} \\quad (\\text{độ lệch chuẩn})',
            'R = a_{k+1} - a_1 \\quad (\\text{khoảng biến thiên}), \\quad \\Delta_Q = Q_3 - Q_1'
          ],
          keyNotes: [
            'Độ lệch chuẩn $s$ càng nhỏ thì số liệu càng tập trung quanh số trung bình $\\bar{x}$, tính ổn định càng cao.'
          ],
          diagramType: 'histogram'
        }
      ]
    },
    {
      title: 'Chương IV. Nguyên hàm và Tích phân',
      grade: 12,
      lessons: [
        {
          id: '12-11',
          title: 'Bài 11. Nguyên hàm và các phương pháp tính',
          grade: 12,
          chapterIndex: 3,
          chapterTitle: 'Chương IV. Nguyên hàm và Tích phân',
          theoryHtml: `
            <p>Hàm số $F(x)$ là nguyên hàm của $f(x)$ nếu $F'(x) = f(x)$. Kí hiệu: $\\int f(x)dx = F(x) + C$.</p>
          `,
          formulas: [
            '\\int x^\\alpha dx = \\frac{x^{\\alpha+1}}{\\alpha+1} + C \\quad (\\alpha \\ne -1)',
            '\\int \\frac{1}{x} dx = \\ln|x| + C, \\quad \\int e^x dx = e^x + C',
            '\\int \\cos x dx = \\sin x + C, \\quad \\int \\sin x dx = -\\cos x + C',
            '\\int u dv = uv - \\int v du \\quad (\\text{từng phần: Nhất lô, nhì đa, tam lượng, tứ mũ})'
          ],
          keyNotes: [
            'Đổi biến số: $\\int f(u(x)) u\'(x) dx = \\int f(u) du$.'
          ]
        },
        {
          id: '12-12',
          title: 'Bài 12. Tích phân & Ứng dụng hình học',
          grade: 12,
          chapterIndex: 3,
          chapterTitle: 'Chương IV. Nguyên hàm và Tích phân',
          theoryHtml: `
            <p>Định nghĩa Newton-Leibniz: $\\int_a^b f(x)dx = F(b) - F(a)$. Ứng dụng tính diện tích hình phẳng và thể tích khối tròn xoay.</p>
          `,
          formulas: [
            'S = \\int_a^b |f(x) - g(x)| dx',
            'V_{Ox} = \\pi \\int_a^b [f(x)]^2 dx',
            's(t) = \\int_{t_1}^{t_2} v(t) dt \\quad (\\text{quãng đường từ vận tốc})'
          ],
          keyNotes: [
            'Khi phá dấu giá trị tuyệt đối tính diện tích, tìm nghiệm của $f(x) - g(x) = 0$ trên $(a; b)$ để chia đoạn tích phân.'
          ],
          diagramType: 'integral'
        }
      ]
    },
    {
      title: 'Chương V. Phương pháp tọa độ trong không gian Oxyz',
      grade: 12,
      lessons: [
        {
          id: '12-14',
          title: 'Bài 14. Mặt phẳng, Đường thẳng & Mặt cầu',
          grade: 12,
          chapterIndex: 4,
          chapterTitle: 'Chương V. Phương pháp tọa độ trong không gian Oxyz',
          theoryHtml: `
            <p>Phương trình mặt phẳng qua $M(x_0; y_0; z_0)$ có VTPT $\\vec{n}=(A; B; C)$: $A(x-x_0) + B(y-y_0) + C(z-z_0) = 0$.</p>
          `,
          formulas: [
            '(P): Ax + By + Cz + D = 0',
            'd(M, (P)) = \\frac{|Ax_0 + By_0 + Cz_0 + D|}{\\sqrt{A^2 + B^2 + C^2}}',
            'd: \\frac{x - x_0}{a} = \\frac{y - y_0}{b} = \\frac{z - z_0}{c}',
            '(S): (x-a)^2 + (y-b)^2 + (z-c)^2 = R^2'
          ],
          keyNotes: [
            'Đường thẳng vuông góc mặt phẳng: $\\vec{u}_d \\parallel \\vec{n}_P$.',
            'Hai mặt phẳng vuông góc: $\\vec{n}_1 \\cdot \\vec{n}_2 = 0$.'
          ],
          diagramType: 'box'
        }
      ]
    },
    {
      title: 'Chương VI. Xác suất có điều kiện và Công thức Bayes',
      grade: 12,
      lessons: [
        {
          id: '12-18',
          title: 'Bài 18. Xác suất có điều kiện & Công thức Bayes',
          grade: 12,
          chapterIndex: 5,
          chapterTitle: 'Chương VI. Xác suất có điều kiện và Công thức Bayes',
          theoryHtml: `
            <p>Xác suất của biến cố $A$ với điều kiện biến cố $B$ đã xảy ra: $P(A \\mid B) = \\frac{P(AB)}{P(B)}$.</p>
          `,
          formulas: [
            'P(AB) = P(B) \\cdot P(A \\mid B)',
            'P(A) = P(B)P(A \\mid B) + P(\\overline{B})P(A \\mid \\overline{B}) \\quad (\\text{toàn phần})',
            'P(B \\mid A) = \\frac{P(B)P(A \\mid B)}{P(A)} \\quad (\\text{công thức Bayes})'
          ],
          keyNotes: [
            'Công thức Bayes ứng dụng rộng rãi trong chẩn đoán xét nghiệm y khoa, kiểm định chất lượng sản phẩm công nghiệp và bảo hiểm.'
          ]
        }
      ]
    }
  ]
};
