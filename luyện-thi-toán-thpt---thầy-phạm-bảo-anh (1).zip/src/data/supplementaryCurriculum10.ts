import { Chapter, Lesson } from '../types/math';

/**
 * BỔ SUNG TOÀN DIỆN CHƯƠNG TRÌNH TOÁN 10 THEO CHUẨN GDPT 2018
 * Thầy Phạm Bảo Anh - Luyện Thi Toán THPT Quốc Gia
 */
export const SUPPLEMENTARY_LESSONS_10: Lesson[] = [
  // --- CHƯƠNG I: MỆNH ĐỀ & TẬP HỢP ---
  {
    id: '10-rev1',
    title: 'Bài tập cuối chương I. Mệnh đề và Tập hợp',
    grade: 10,
    chapterIndex: 0,
    chapterTitle: 'Chương I. Mệnh đề và tập hợp',
    theoryHtml: `
      <p>Tổng kết kiến thức trọng tâm Chương I:</p>
      <ul class="list-disc list-inside space-y-1.5 pl-2">
        <li>Mệnh đề phủ định của $\\forall x \\in X, P(x)$ là $\\exists x \\in X, \\overline{P(x)}$.</li>
        <li>Các phép toán tập hợp trên trục số: Giao $A \\cap B$, Hợp $A \\cup B$, Hiệu $A \\setminus B$ và Phần bù $C_{\\mathbb{R}} A$.</li>
        <li>Tìm tham số $m$ để hai khoảng, đoạn có giao khác rỗng hoặc $A \\subset B$.</li>
      </ul>
    `,
    formulas: [
      'A \\cap B \\ne \\emptyset \\iff \\exists x \\in A \\text{ và } x \\in B',
      'C_{\\mathbb{R}} [a; b) = (-\\infty; a) \\cup [b; +\\infty)'
    ],
    keyNotes: [
      'Vẽ trục số và gạch bỏ phần không thuộc tập hợp để tránh nhầm lẫn ngoặc vuông $[$ (lấy đầu mút) và ngoặc tròn $($ (không lấy đầu mút).'
    ],
    diagramType: 'numberLine',
    sgkRef: '10-CH1-REV',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-10'
  },

  // --- CHƯƠNG II: BẤT PHƯƠNG TRÌNH & HỆ BPT BẬC NHẤT HAI ẨN ---
  {
    id: '10-4',
    title: 'Bài 4. Hệ bất phương trình bậc nhất hai ẩn & Miền nghiệm',
    grade: 10,
    chapterIndex: 1,
    chapterTitle: 'Chương II. Bất phương trình & Hệ BPT bậc nhất hai ẩn',
    theoryHtml: `
      <p>Hệ bất phương trình bậc nhất hai ẩn gồm hai hay nhiều bất phương trình bậc nhất hai ẩn $x, y$.</p>
      <div class="space-y-1.5 mt-2">
        <p><strong>Quy trình biểu diễn miền nghiệm:</strong></p>
        <ol class="list-decimal list-inside space-y-1 pl-2">
          <li>Trên mặt phẳng toạ độ $Oxy$, vẽ các đường thẳng biên tương ứng của từng bất phương trình.</li>
          <li>Gạch bỏ nửa mặt phẳng không phải là miền nghiệm của từng bất phương trình (thử với điểm gốc $O(0; 0)$).</li>
          <li>Phần mặt phẳng không bị gạch (miền đa giác lồi) chính là miền nghiệm chung của hệ.</li>
        </ol>
      </div>
    `,
    formulas: [
      '\\begin{cases} a_1 x + b_1 y \\le c_1 \\\\ a_2 x + b_2 y \\le c_2 \\\\ x \\ge 0, \\, y \\ge 0 \\end{cases}',
      'F(x, y) = ax + by \\implies \\max / \\min \\text{ đạt tại các đỉnh của miền nghiệm}'
    ],
    keyNotes: [
      'Đường thẳng có nét liền nếu có dấu $\\le, \\ge$ (lấy biên); nét đứt nếu là dấu $<, >$ (không lấy biên).'
    ],
    diagramType: 'quadratic',
    sgkRef: '10-CH2-B4',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-10'
  },
  {
    id: '10-rev2',
    title: 'Bài tập cuối chương II. Bất phương trình & Hệ BPT bậc nhất hai ẩn',
    grade: 10,
    chapterIndex: 1,
    chapterTitle: 'Chương II. Bất phương trình & Hệ BPT bậc nhất hai ẩn',
    theoryHtml: `
      <p>Phương pháp giải bài toán kinh tế tối ưu hoá lợi nhuận bằng hệ bất phương trình bậc nhất hai ẩn:</p>
      <p>Gọi $x, y$ lần lượt là số lượng sản phẩm loại A và loại B cần sản xuất. Lập hệ điều kiện về nguyên liệu, nhân công và tìm giá trị lớn nhất của hàm lợi nhuận tại các đỉnh đa giác.</p>
    `,
    formulas: ['F(x, y) = c_1 x + c_2 y \\to \\max'],
    keyNotes: ['Tọa độ các đỉnh của miền nghiệm được xác định bằng cách giải hệ 2 phương trình bậc nhất 2 ẩn của các cặp đường thẳng cắt nhau.'],
    diagramType: 'quadratic',
    sgkRef: '10-CH2-REV',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-10'
  },

  // --- CHƯƠNG III: HỆ THỨC LƯỢNG TRONG TAM GIÁC ---
  {
    id: '10-6',
    title: 'Bài 6. Hệ thức lượng và Các công thức tính diện tích tam giác',
    grade: 10,
    chapterIndex: 2,
    chapterTitle: 'Chương III. Hệ thức lượng trong tam giác',
    theoryHtml: `
      <p>Năm công thức tính diện tích tam giác $ABC$ kinh điển:</p>
      <ol class="list-decimal list-inside space-y-1.5 pl-2">
        <li>$S = \\frac{1}{2} a \\cdot h_a = \\frac{1}{2} b \\cdot h_b = \\frac{1}{2} c \\cdot h_c$.</li>
        <li>$S = \\frac{1}{2} ab \\sin C = \\frac{1}{2} bc \\sin A = \\frac{1}{2} ca \\sin B$.</li>
        <li>$S = \\frac{abc}{4R}$ ($R$ là bán kính đường tròn ngoại tiếp).</li>
        <li>$S = p \\cdot r$ ($p = \\frac{a+b+c}{2}$ là nửa chu vi, $r$ là bán kính đường tròn nội tiếp).</li>
        <li>Công thức Heron: $S = \\sqrt{p(p-a)(p-b)(p-c)}$.</li>
      </ol>
      <p class="mt-2 font-bold text-teal-800">Độ dài đường trung tuyến:</p>
      $$m_a^2 = \\frac{2(b^2 + c^2) - a^2}{4}$$
    `,
    formulas: [
      'a^2 = b^2 + c^2 - 2bc \\cos A, \\quad \\frac{a}{\\sin A} = \\frac{b}{\\sin B} = \\frac{c}{\\sin C} = 2R',
      'S = \\sqrt{p(p-a)(p-b)(p-c)} = p \\cdot r = \\frac{abc}{4R} = \\frac{1}{2}ab\\sin C',
      'm_a^2 = \\frac{2(b^2+c^2)-a^2}{4}'
    ],
    keyNotes: [
      'Tam giác tù khi và chỉ khi có một góc có $\\cos < 0$, tam giác vuông khi $\\cos = 0$, tam giác nhọn khi cả ba góc có $\\cos > 0$.'
    ],
    diagramType: 'pyramid',
    sgkRef: '10-CH3-B6',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-10'
  },
  {
    id: '10-rev3',
    title: 'Bài tập cuối chương III. Hệ thức lượng trong tam giác',
    grade: 10,
    chapterIndex: 2,
    chapterTitle: 'Chương III. Hệ thức lượng trong tam giác',
    theoryHtml: `
      <p>Ứng dụng hệ thức lượng giải bài toán đo đạc thực tế: Tính khoảng cách giữa hai điểm không thể đến được, đo chiều cao ngọn tháp, hải đăng trên biển bằng giác kế.</p>
    `,
    formulas: ['h = d \\cdot \\frac{\\sin \\alpha \\cdot \\sin \\beta}{\\sin(\\beta - \\alpha)}'],
    keyNotes: ['Áp dụng linh hoạt định lý Sin khi biết 1 cạnh và 2 góc; áp dụng định lý Côsin khi biết 2 cạnh và góc kẹp giữa.'],
    diagramType: 'pyramid',
    sgkRef: '10-CH3-REV',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-10'
  },

  // --- CHƯƠNG IV: VECTƠ LỚP 10 ---
  {
    id: '10-8',
    title: 'Bài 8. Tổng và hiệu của hai vectơ',
    grade: 10,
    chapterIndex: 3,
    chapterTitle: 'Chương IV. Vectơ',
    theoryHtml: `
      <p>Hai quy tắc vàng của phép cộng vectơ:</p>
      <ul class="list-disc list-inside space-y-1.5 pl-2">
        <li><strong>Quy tắc ba điểm (Quy tắc nối đuôi):</strong> $\\vec{AB} + \\vec{BC} = \\vec{AC}$.</li>
        <li><strong>Quy tắc hình bình hành:</strong> Nếu $ABCD$ là hình bình hành thì $\\vec{AB} + \\vec{AD} = \\vec{AC}$.</li>
        <li><strong>Quy tắc trừ:</strong> $\\vec{AB} - \\vec{AC} = \\vec{CB}$ (chung gốc thì đảo đuôi).</li>
      </ul>
    `,
    formulas: [
      '\\vec{AB} + \\vec{BC} = \\vec{AC}, \\quad \\vec{AB} + \\vec{AD} = \\vec{AC} \\quad (ABCD \\text{ là HBH})',
      '\\vec{OA} + \\vec{OB} = 2\\vec{OI} \\quad (I \\text{ là trung điểm } AB)'
    ],
    keyNotes: [
      'Vectơ đối của $\\vec{a}$ là $-\\vec{a}$ có cùng độ dài nhưng ngược hướng: $\\vec{a} + (-\\vec{a}) = \\vec{0}$.'
    ],
    diagramType: 'numberLine',
    sgkRef: '10-CH4-B8',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-10'
  },
  {
    id: '10-10',
    title: 'Bài 10. Vectơ trong mặt phẳng toạ độ Oxy',
    grade: 10,
    chapterIndex: 3,
    chapterTitle: 'Chương IV. Vectơ',
    theoryHtml: `
      <p>Cho toạ độ $A(x_A; y_A)$ và $B(x_B; y_B)$:</p>
      <ul class="list-disc list-inside space-y-1 pl-2">
        <li>$\\vec{AB} = (x_B - x_A; y_B - y_A)$.</li>
        <li>Độ dài đoạn thẳng: $AB = |\\vec{AB}| = \\sqrt{(x_B - x_A)^2 + (y_B - y_A)^2}$.</li>
        <li>Trung điểm $I$ của $AB$: $x_I = \\frac{x_A + x_B}{2}, \\, y_I = \\frac{y_A + y_B}{2}$.</li>
        <li>Trọng tâm $G$ tam giác $ABC$: $x_G = \\frac{x_A+x_B+x_C}{3}, \\, y_G = \\frac{y_A+y_B+y_C}{3}$.</li>
      </ul>
    `,
    formulas: [
      '\\vec{AB} = (x_B - x_A; y_B - y_A)',
      '|\\vec{u}| = \\sqrt{x^2 + y^2}, \\quad \\vec{u} \\cdot \\vec{v} = x_1 x_2 + y_1 y_2'
    ],
    keyNotes: [
      'Hai vectơ cùng phương: $\\vec{u} \\parallel \\vec{v} \\iff x_1 y_2 - x_2 y_1 = 0$.',
      'Hai vectơ vuông góc: $\\vec{u} \\perp \\vec{v} \\iff x_1 x_2 + y_1 y_2 = 0$.'
    ],
    diagramType: 'numberLine',
    sgkRef: '10-CH4-B10',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-10'
  },
  {
    id: '10-11',
    title: 'Bài 11. Tích vô hướng của hai vectơ',
    grade: 10,
    chapterIndex: 3,
    chapterTitle: 'Chương IV. Vectơ',
    theoryHtml: `
      <p>Định nghĩa: $\\vec{a} \\cdot \\vec{b} = |\\vec{a}| \\cdot |\\vec{b}| \\cdot \\cos(\\vec{a}, \\vec{b})$.</p>
      <p>Bình phương vô hướng bằng bình phương độ dài: $\\vec{a}^2 = |\\vec{a}|^2$.</p>
    `,
    formulas: [
      '\\vec{a} \\cdot \\vec{b} = |\\vec{a}| |\\vec{b}| \\cos(\\vec{a}, \\vec{b})',
      '\\cos(\\vec{a}, \\vec{b}) = \\frac{\\vec{a} \\cdot \\vec{b}}{|\\vec{a}| |\\vec{b}|} = \\frac{x_1 x_2 + y_1 y_2}{\\sqrt{x_1^2+y_1^2}\\sqrt{x_2^2+y_2^2}}'
    ],
    keyNotes: ['Tích vô hướng của hai vectơ là một SỐ THỰC, không phải là một vectơ.'],
    diagramType: 'numberLine',
    sgkRef: '10-CH4-B11',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-10'
  },

  // --- CHƯƠNG V: THỐNG KÊ KHÔNG GHÉP NHÓM LỚP 10 ---
  {
    id: '10-13',
    title: 'Bài 13. Các số đặc trưng đo xu thế trung tâm (Mẫu không ghép nhóm)',
    grade: 10,
    chapterIndex: 4,
    chapterTitle: 'Chương V. Các số đặc trưng của mẫu số liệu không ghép nhóm',
    theoryHtml: `
      <p>Cho mẫu số liệu đã sắp xếp theo thứ tự không giảm $x_1 \\le x_2 \\le \\dots \\le x_n$:</p>
      <ul class="list-disc list-inside space-y-1 pl-2">
        <li><strong>Số trung bình $\\bar{x}$:</strong> $\\bar{x} = \\frac{x_1 + x_2 + \\dots + x_n}{n}$.</li>
        <li><strong>Trung vị $M_e$:</strong> Nếu $n$ lẻ, $M_e = x_{\\frac{n+1}{2}}$. Nếu $n$ chẵn, $M_e = \\frac{x_{n/2} + x_{n/2+1}}{2}$.</li>
        <li><strong>Tứ phân vị:</strong> $Q_2 = M_e$; $Q_1$ là trung vị của nửa dưới; $Q_3$ là trung vị của nửa trên.</li>
        <li><strong>Mốt $M_o$:</strong> Giá trị xuất hiện với tần số lớn nhất.</li>
      </ul>
    `,
    formulas: [
      '\\bar{x} = \\frac{1}{n} \\sum_{i=1}^n x_i',
      '\\Delta_Q = Q_3 - Q_1 \\quad (\\text{Khoảng tứ phân vị})'
    ],
    keyNotes: ['Khi tìm trung vị và tứ phân vị, bước đầu tiên BẮT BUỘC là phải sắp xếp dãy số liệu theo thứ tự tăng dần.'],
    diagramType: 'histogram',
    sgkRef: '10-CH5-B13',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-10'
  },
  {
    id: '10-14',
    title: 'Bài 14. Các số đặc trưng đo độ phân tán (Phương sai, Độ lệch chuẩn)',
    grade: 10,
    chapterIndex: 4,
    chapterTitle: 'Chương V. Các số đặc trưng của mẫu số liệu không ghép nhóm',
    theoryHtml: `
      <p>Các đại lượng đo độ phân tán của dữ liệu quanh giá trị trung bình:</p>
      <ul class="list-disc list-inside space-y-1 pl-2">
        <li>Khoảng biến thiên $R = x_{\\max} - x_{\\min}$.</li>
        <li>Phương sai: $s^2 = \\frac{1}{n} \\sum_{i=1}^n (x_i - \\bar{x})^2 = \\frac{1}{n} \\sum_{i=1}^n x_i^2 - (\\bar{x})^2$.</li>
        <li>Độ lệch chuẩn: $s = \\sqrt{s^2}$.</li>
      </ul>
    `,
    formulas: [
      's^2 = \\frac{1}{n}\\sum x_i^2 - (\\bar{x})^2, \\quad s = \\sqrt{s^2}'
    ],
    keyNotes: ['Độ lệch chuẩn có cùng đơn vị đo với số liệu ban đầu, thuận tiện cho việc so sánh độ rủi ro hay độ biến động.'],
    diagramType: 'histogram',
    sgkRef: '10-CH5-B14',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-10'
  }
];

/**
 * CÁC CHƯƠNG BỔ SUNG CỦA HỌC KỲ II LỚP 10 (Hàm số, Conic, Tổ hợp, Xác suất)
 */
export const SUPPLEMENTARY_CHAPTERS_10_HK2: Chapter[] = [
  {
    title: 'Chương VI. Hàm số, Đồ thị và Ứng dụng',
    grade: 10,
    lessons: [
      {
        id: '10-16',
        title: 'Bài 16. Hàm số bậc hai y = ax² + bx + c',
        grade: 10,
        chapterIndex: 5,
        chapterTitle: 'Chương VI. Hàm số, Đồ thị và Ứng dụng',
        theoryHtml: `
          <p>Hàm số bậc hai $y = ax^2 + bx + c$ ($a \\ne 0$) có đồ thị là một Parabol:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Đỉnh $I\\left(-\\frac{b}{2a}; -\\frac{\\Delta}{4a}\\right)$.</li>
            <li>Trục đối xứng là đường thẳng $x = -\\frac{b}{2a}$.</li>
            <li>Bề lõm: Quay lên trên khi $a > 0$ (hàm số đạt GTNN tại đỉnh); quay xuống dưới khi $a < 0$ (đạt GTLN tại đỉnh).</li>
          </ul>
        `,
        formulas: [
          'I\\left(-\\frac{b}{2a}; -\\frac{\\Delta}{4a}\\right), \\quad x = -\\frac{b}{2a}',
          'a > 0 \\implies y_{\\min} = -\\frac{\\Delta}{4a}; \\quad a < 0 \\implies y_{\\max} = -\\frac{\\Delta}{4a}'
        ],
        keyNotes: ['Tung độ đỉnh chính là giá trị lớn nhất hoặc nhỏ nhất của tam thức bậc hai trên toàn bộ $\\mathbb{R}$.'],
        diagramType: 'quadratic',
        diagramParams: { a: 1, b: 0, c: 0 },
        sgkRef: '10-CH6-B16',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-10'
      },
      {
        id: '10-17',
        title: 'Bài 17. Dấu của tam thức bậc hai và Bất phương trình bậc hai',
        grade: 10,
        chapterIndex: 5,
        chapterTitle: 'Chương VI. Hàm số, Đồ thị và Ứng dụng',
        theoryHtml: `
          <p>Định lý về dấu của tam thức bậc hai $f(x) = ax^2 + bx + c$ ($a \\ne 0$):</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Nếu $\\Delta < 0$: $f(x)$ luôn CÙNG DẤU với hệ số $a$ với mọi $x \\in \\mathbb{R}$.</li>
            <li>Nếu $\\Delta = 0$: $f(x)$ cùng dấu với $a$ với mọi $x \\ne -\\frac{b}{2a}$.</li>
            <li>Nếu $\\Delta > 0$: $f(x)$ có 2 nghiệm phân biệt $x_1 < x_2$. Quy tắc: <em>"Trong trái, ngoài cùng"</em> (trong khoảng hai nghiệm trái dấu với $a$, ngoài khoảng hai nghiệm cùng dấu với $a$).</li>
          </ul>
        `,
        formulas: [
          'ax^2 + bx + c > 0 \\, (\\forall x \\in \\mathbb{R}) \\iff \\begin{cases} a > 0 \\\\ \\Delta < 0 \\end{cases}',
          'ax^2 + bx + c \\le 0 \\, (\\forall x \\in \\mathbb{R}) \\iff \\begin{cases} a < 0 \\\\ \\Delta \\le 0 \\end{cases}'
        ],
        keyNotes: ['Khi bất phương trình có tham số đứng trước $x^2$ (hệ số $a$ chứa tham số $m$), BẮT BUỘC phải xét trường hợp $a = 0$ trước.'],
        diagramType: 'quadratic',
        diagramParams: { a: 1, b: -2, c: -3 },
        sgkRef: '10-CH6-B17',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-10'
      }
    ]
  },
  {
    title: 'Chương VII. Phương pháp toạ độ trong mặt phẳng Oxy',
    grade: 10,
    lessons: [
      {
        id: '10-21',
        title: 'Bài 21. Đường tròn trong mặt phẳng toạ độ Oxy',
        grade: 10,
        chapterIndex: 6,
        chapterTitle: 'Chương VII. Phương pháp toạ độ trong mặt phẳng Oxy',
        theoryHtml: `
          <p>Đường tròn $(C)$ có tâm $I(a; b)$ và bán kính $R > 0$ có phương trình chính tắc:</p>
          $$(x - a)^2 + (y - b)^2 = R^2$$
          <p>Phương trình tổng quát: $x^2 + y^2 - 2ax - 2by + c = 0$ là đường tròn khi và chỉ khi $a^2 + b^2 - c > 0$. Khi đó tâm $I(a; b)$ và bán kính $R = \\sqrt{a^2 + b^2 - c}$.</p>
        `,
        formulas: [
          '(x - a)^2 + (y - b)^2 = R^2',
          'R = \\sqrt{a^2 + b^2 - c} \\quad (a^2 + b^2 - c > 0)',
          'd(I, \\Delta) = R \\iff \\Delta \\text{ tiếp xúc với đường tròn}'
        ],
        keyNotes: ['Phương trình tiếp tuyến của $(C)$ tại điểm $M_0(x_0; y_0) \\in (C)$: $(x_0 - a)(x - a) + (y_0 - b)(y - b) = R^2$.'],
        diagramType: 'circle',
        sgkRef: '10-CH7-B21',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-10'
      },
      {
        id: '10-22',
        title: 'Bài 22. Ba đường conic (Elip, Hypebol, Parabol)',
        grade: 10,
        chapterIndex: 6,
        chapterTitle: 'Chương VII. Phương pháp toạ độ trong mặt phẳng Oxy',
        theoryHtml: `
          <p>Phương trình chính tắc của ba đường Conic:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li><strong>Elip $(E)$:</strong> $\\frac{x^2}{a^2} + \\frac{y^2}{b^2} = 1$ ($a > b > 0$). Tiêu cự $2c$ với $c = \\sqrt{a^2 - b^2}$, hai tiêu điểm $F_1(-c; 0), F_2(c; 0)$.</li>
            <li><strong>Hypebol $(H)$:</strong> $\\frac{x^2}{a^2} - \\frac{y^2}{b^2} = 1$ ($a, b > 0$). Tiêu cự $2c$ với $c = \\sqrt{a^2 + b^2}$, hai tiệm cận $y = \\pm \\frac{b}{a}x$.</li>
            <li><strong>Parabol $(P)$:</strong> $y^2 = 2px$ ($p > 0$). Tiêu điểm $F\\left(\\frac{p}{2}; 0\\right)$, đường chuẩn $\\Delta: x = -\\frac{p}{2}$.</li>
          </ul>
        `,
        formulas: [
          '\\frac{x^2}{a^2} + \\frac{y^2}{b^2} = 1 \\implies c^2 = a^2 - b^2 \\quad (\\text{Elip})',
          '\\frac{x^2}{a^2} - \\frac{y^2}{b^2} = 1 \\implies c^2 = a^2 + b^2 \\quad (\\text{Hypebol})',
          'y^2 = 2px \\implies F\\left(\\frac{p}{2}; 0\\right), \\, x = -\\frac{p}{2} \\quad (\\text{Parabol})'
        ],
        keyNotes: [
          'Tâm sai của đường conic $e = \\frac{c}{a}$: Elip có $0 < e < 1$, Parabol có $e = 1$, Hypebol có $e > 1$.'
        ],
        diagramType: 'circle',
        sgkRef: '10-CH7-B22',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-10'
      }
    ]
  },
  {
    title: 'Chương VIII. Đại số tổ hợp',
    grade: 10,
    lessons: [
      {
        id: '10-23',
        title: 'Bài 23. Quy tắc cộng và Quy tắc nhân',
        grade: 10,
        chapterIndex: 7,
        chapterTitle: 'Chương VIII. Đại số tổ hợp',
        theoryHtml: `
          <p>Hai quy tắc đếm nền tảng:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li><strong>Quy tắc cộng:</strong> Nếu một công việc có thể thực hiện theo một trong hai phương án loại trừ nhau (phương án 1 có $m$ cách, phương án 2 có $n$ cách) thì có $m + n$ cách thực hiện.</li>
            <li><strong>Quy tắc nhân:</strong> Nếu một công việc gồm hai công đoạn liên tiếp (công đoạn 1 có $m$ cách, công đoạn 2 có $n$ cách) thì có $m \\cdot n$ cách thực hiện.</li>
          </ul>
        `,
        formulas: [
          'N = m + n \\quad (\\text{Quy tắc cộng - Hoặc})',
          'N = m \\cdot n \\quad (\\text{Quy tắc nhân - Và / Liên tiếp})'
        ],
        keyNotes: ['Phương án (hoặc) thì CỘNG; công đoạn (liên tiếp) thì NHÂN.'],
        diagramType: 'numberLine',
        sgkRef: '10-CH8-B23',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-10'
      },
      {
        id: '10-24',
        title: 'Bài 24. Hoán vị, Chỉnh hợp và Tổ hợp',
        grade: 10,
        chapterIndex: 7,
        chapterTitle: 'Chương VIII. Đại số tổ hợp',
        theoryHtml: `
          <p>Phân biệt rõ ràng Hoán vị, Chỉnh hợp và Tổ hợp:</p>
          <ul class="list-disc list-inside space-y-2 pl-2">
            <li><strong>Hoán vị của $n$ phần tử ($P_n$):</strong> Sắp xếp thứ tự $n$ phần tử. $P_n = n!$.</li>
            <li><strong>Chỉnh hợp chập $k$ của $n$ ($A_n^k$):</strong> Chọn $k$ phần tử và CÓ THỨ TỰ. $A_n^k = \\frac{n!}{(n-k)!}$.</li>
            <li><strong>Tổ hợp chập $k$ của $n$ ($C_n^k$):</strong> Chọn $k$ phần tử và KHÔNG PHÂN BIỆT THỨ TỰ. $C_n^k = \\frac{n!}{k!(n-k)!}$.</li>
          </ul>
        `,
        formulas: [
          'P_n = n!, \\quad A_n^k = \\frac{n!}{(n-k)!}, \\quad C_n^k = \\frac{n!}{k!(n-k)!}',
          'C_n^k = C_n^{n-k}, \\quad C_{n-1}^{k-1} + C_{n-1}^k = C_n^k \\quad (\\text{Công thức Pascal})'
        ],
        keyNotes: [
          'Chìa khóa phân biệt: Có xếp thứ tự (như chức vụ, vị trí, xếp hàng) dùng $A_n^k$; chỉ chọn ra một nhóm (như lập đội tuyển, chọn tổ công tác) dùng $C_n^k$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH8-B24',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-10'
      },
      {
        id: '10-25',
        title: 'Bài 25. Nhị thức Newton',
        grade: 10,
        chapterIndex: 7,
        chapterTitle: 'Chương VIII. Đại số tổ hợp',
        theoryHtml: `
          <p>Khai triển nhị thức Newton với số mũ $n = 4$ và $n = 5$ trong chương trình lớp 10:</p>
          $$(a + b)^4 = C_4^0 a^4 + C_4^1 a^3 b + C_4^2 a^2 b^2 + C_4^3 ab^3 + C_4^4 b^4$$
          $$(a + b)^5 = C_5^0 a^5 + C_5^1 a^4 b + C_5^2 a^3 b^2 + C_5^3 a^2 b^3 + C_5^4 ab^4 + C_5^5 b^5$$
        `,
        formulas: [
          '(a + b)^4 = a^4 + 4a^3b + 6a^2b^2 + 4ab^3 + b^4',
          '(a + b)^5 = a^5 + 5a^4b + 10a^3b^2 + 10a^2b^3 + 5ab^4 + b^5'
        ],
        keyNotes: ['Khi khai triển $(a - b)^n$, dấu của các số hạng sẽ đan xen: $+ , - , + , - , \\dots$'],
        diagramType: 'numberLine',
        sgkRef: '10-CH8-B25',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-10'
      }
    ]
  },
  {
    title: 'Chương IX. Tính xác suất theo định nghĩa cổ điển',
    grade: 10,
    lessons: [
      {
        id: '10-26',
        title: 'Bài 26. Biến cố và Định nghĩa cổ điển của xác suất',
        grade: 10,
        chapterIndex: 8,
        chapterTitle: 'Chương IX. Tính xác suất theo định nghĩa cổ điển',
        theoryHtml: `
          <p>Không gian mẫu $\\Omega$ là tập hợp tất cả các kết quả có thể xảy ra của một phép thử ngẫu nhiên. Biến cố $A \\subset \\Omega$.</p>
          <p><strong>Định nghĩa cổ điển:</strong> Nếu các kết quả của phép thử đồng khả năng xuất hiện thì xác suất của biến cố $A$ là:</p>
          $$P(A) = \\frac{n(A)}{n(\\Omega)} = \\frac{|A|}{|\\Omega|}$$
        `,
        formulas: [
          'P(A) = \\frac{n(A)}{n(\\Omega)}, \\quad 0 \\le P(A) \\le 1',
          'P(\\Omega) = 1, \\quad P(\\emptyset) = 0, \\quad P(\\overline{A}) = 1 - P(A)'
        ],
        keyNotes: ['Định nghĩa cổ điển CHỈ ÁP DỤNG ĐƯỢC khi không gian mẫu hữu hạn và các kết quả là ĐỒNG KHẢ NĂNG xuất hiện.'],
        diagramType: 'numberLine',
        sgkRef: '10-CH9-B26',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-10'
      }
    ]
  }
];
