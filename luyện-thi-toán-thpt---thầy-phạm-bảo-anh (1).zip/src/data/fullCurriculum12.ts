import { Chapter } from '../types/math';

/**
 * CHƯƠNG TRÌNH TOÁN 12 TOÀN DIỆN - CHUẨN GDPT 2018 (KẾT NỐI TRI THỨC VỚI CUỘC SỐNG)
 * Biên soạn & Chuẩn hóa: Thầy Phạm Bảo Anh (Dạy học Toán PBA)
 * Đầy đủ 6 Chương SGK + Hoạt động thực hành trải nghiệm + 3 Chuyên đề học tập
 */
export const FULL_CURRICULUM_GRADE_12: Chapter[] = [
  // =========================================================================
  // CHƯƠNG I. ỨNG DỤNG ĐẠO HÀM ĐỂ KHẢO SÁT VÀ VẼ ĐỒ THỊ HÀM SỐ
  // =========================================================================
  {
    title: 'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị của hàm số',
    grade: 12,
    lessons: [
      {
        id: '12-1',
        title: 'Bài 1. Tính đơn điệu và cực trị của hàm số',
        grade: 12,
        chapterIndex: 0,
        chapterTitle: 'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị của hàm số',
        theoryHtml: `
          <p><strong>1. Tính đơn điệu của hàm số:</strong></p>
          <p>Cho hàm số $y = f(x)$ có đạo hàm trên khoảng $K$.</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Nếu $f'(x) > 0$ với mọi $x \\in K$ thì $f(x)$ đồng biến trên $K$.</li>
            <li>Nếu $f'(x) < 0$ với mọi $x \\in K$ thì $f(x)$ nghịch biến trên $K$.</li>
            <li>Nếu $f'(x) \\ge 0$ (hoặc $\\le 0$) với mọi $x \\in K$ và $f'(x) = 0$ chỉ tại hữu hạn điểm thì $f(x)$ đồng biến (hoặc nghịch biến) trên $K$.</li>
          </ul>
          <p class="mt-2"><strong>2. Cực trị của hàm số:</strong></p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Điểm $x_0$ là điểm cực đại của hàm số nếu tồn tại $(a; b) \\subset D$ chứa $x_0$ sao cho $f(x) < f(x_0)$ với mọi $x \\in (a; b) \\setminus \\{x_0\\}$.</li>
            <li><strong>Dấu hiệu 1:</strong> Nếu $f'(x)$ đổi dấu từ dương sang âm khi $x$ qua $x_0$ thì $x_0$ là điểm cực đại. Nếu đổi dấu từ âm sang dương thì $x_0$ là điểm cực tiểu.</li>
            <li><strong>Dấu hiệu 2:</strong> Nếu $f'(x_0) = 0$ và $f''(x_0) < 0 \\implies x_0$ cực đại; nếu $f''(x_0) > 0 \\implies x_0$ cực tiểu.</li>
          </ul>
        `,
        formulas: [
          'f\'(x) > 0 \\, (\\forall x \\in K) \\implies f \\text{ đồng biến trên } K',
          'f\'(x) < 0 \\, (\\forall x \\in K) \\implies f \\text{ nghịch biến trên } K',
          'f\'(x_0) = 0, \\, f\'\'(x_0) < 0 \\implies x_0 \\text{ là điểm cực đại}',
          'f\'(x_0) = 0, \\, f\'\'(x_0) > 0 \\implies x_0 \\text{ là điểm cực tiểu}',
          'y = ax^3 + bx^2 + cx + d \\implies y\' = 3ax^2 + 2bx + c'
        ],
        keyNotes: [
          'Hàm phân thức $y = \\frac{ax+b}{cx+d}$ có $y\' = \\frac{ad-bc}{(cx+d)^2}$, luôn đồng biến hoặc nghịch biến trên từng khoảng xác định, không bao giờ kết luận "trên $\\mathbb{R} \\setminus \\{-d/c\\}$".',
          'Phân biệt: "Điểm cực trị của hàm số" ($x_0$), "Giá trị cực trị của hàm số" ($y_0 = f(x_0)$), và "Điểm cực trị của đồ thị hàm số" ($M(x_0; y_0)$).'
        ],
        diagramType: 'cubic',
        sgkRef: '12-CH1-B1',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Standard'
      },
      {
        id: '12-2',
        title: 'Bài 2. Giá trị lớn nhất và giá trị nhỏ nhất của hàm số',
        grade: 12,
        chapterIndex: 0,
        chapterTitle: 'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị của hàm số',
        theoryHtml: `
          <p><strong>1. Định nghĩa:</strong></p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Số $M$ là giá trị lớn nhất (GTLN) của $f(x)$ trên tập $D$ nếu $f(x) \\le M$ với mọi $x \\in D$ và tồn tại $x_0 \\in D$ sao cho $f(x_0) = M$. Ký hiệu $\\max_D f(x) = M$.</li>
            <li>Số $m$ là giá trị nhỏ nhất (GTNN) của $f(x)$ trên $D$ nếu $f(x) \\ge m$ với mọi $x \\in D$ và tồn tại $x_0 \\in D$ sao cho $f(x_0) = m$. Ký hiệu $\\min_D f(x) = m$.</li>
          </ul>
          <p class="mt-2"><strong>2. Quy trình tìm GTLN, GTNN trên đoạn $[a; b]$:</strong></p>
          <ol class="list-decimal list-inside space-y-1 pl-2">
            <li>Tìm các nghiệm $x_1, x_2, \\dots, x_n \\in (a; b)$ của phương trình $f'(x) = 0$ hoặc nơi $f'(x)$ không xác định.</li>
            <li>Tính các giá trị $f(a), f(b), f(x_1), \\dots, f(x_n)$.</li>
            <li>So sánh và kết luận: số lớn nhất trong các giá trị đó là GTLN, số nhỏ nhất là GTNN.</li>
          </ol>
        `,
        formulas: [
          '\\max_{[a;b]} f(x) = \\max \\{ f(a), f(b), f(x_1), f(x_2), \\dots \\}',
          '\\min_{[a;b]} f(x) = \\min \\{ f(a), f(b), f(x_1), f(x_2), \\dots \\}',
          'y = f(x) \\text{ liên tục trên đoạn } [a;b] \\implies \\text{luôn đạt GTLN và GTNN trên } [a;b]'
        ],
        keyNotes: [
          'Nếu tìm GTLN, GTNN trên khoảng mở $(a; b)$ hoặc khoảng vô tận, BẮT BUỘC phải lập bảng biến thiên để kết luận.',
          'Hàm số đơn điệu trên $[a; b]$ thì GTLN và GTNN luôn đạt tại hai đầu mút $a$ và $b$.'
        ],
        diagramType: 'appliedMaxMin',
        sgkRef: '12-CH1-B2',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Standard'
      },
      {
        id: '12-3',
        title: 'Bài 3. Đường tiệm cận của đồ thị hàm số',
        grade: 12,
        chapterIndex: 0,
        chapterTitle: 'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị của hàm số',
        theoryHtml: `
          <p><strong>1. Tiệm cận đứng (TCĐ):</strong></p>
          <p>Đường thẳng $x = x_0$ là TCĐ của đồ thị hàm số $y = f(x)$ nếu ít nhất một trong các điều kiện sau thoả mãn:</p>
          $$\\lim_{x \\to x_0^+} f(x) = \\pm\\infty \\quad \\text{hoặc} \\quad \\lim_{x \\to x_0^-} f(x) = \\pm\\infty.$$
          <p><strong>2. Tiệm cận ngang (TCN):</strong></p>
          <p>Đường thẳng $y = y_0$ là TCN của đồ thị hàm số $y = f(x)$ nếu:</p>
          $$\\lim_{x \\to +\\infty} f(x) = y_0 \\quad \\text{hoặc} \\quad \\lim_{x \\to -\\infty} f(x) = y_0.$$
          <p><strong>3. Tiệm cận xiên (TCX):</strong></p>
          <p>Đường thẳng $y = ax + b$ ($a \\ne 0$) là TCX của đồ thị hàm số nếu:</p>
          $$\\lim_{x \\to +\\infty} [f(x) - (ax + b)] = 0 \\quad \\text{hoặc} \\quad \\lim_{x \\to -\\infty} [f(x) - (ax + b)] = 0.$$
          <p>Công thức tính: $a = \\lim_{x \\to \\pm\\infty} \\frac{f(x)}{x}$ và $b = \\lim_{x \\to \\pm\\infty} [f(x) - ax]$.</p>
        `,
        formulas: [
          'y = \\frac{ax+b}{cx+d} \\implies \\text{TCĐ: } x = -\\frac{d}{c}, \\quad \\text{TCN: } y = \\frac{a}{c}',
          'y = \\frac{ax^2+bx+c}{px+q} = mx + n + \\frac{r}{px+q} \\implies \\text{TCX: } y = mx + n, \\quad \\text{TCĐ: } x = -\\frac{q}{p}',
          'a = \\lim_{x \\to \\pm\\infty} \\frac{f(x)}{x}, \\quad b = \\lim_{x \\to \\pm\\infty} [f(x) - ax]'
        ],
        keyNotes: [
          'Hàm đa thức (bậc 2, bậc 3, bậc 4 trùng phương) KHÔNG có bất kỳ đường tiệm cận nào.',
          'Đồ thị hàm phân thức hữu tỉ có bậc tử = bậc mẫu thì có TCN; bậc tử = bậc mẫu + 1 thì có TCX.',
          'Giao điểm của hai đường tiệm cận của hàm bậc nhất/bậc nhất là tâm đối xứng của đồ thị.'
        ],
        diagramType: 'rational',
        diagramParams: {
          a: 2,
          b: 1,
          c: 1,
          d: -1,
          xRange: [-4, 6],
          yRange: [-3, 7],
          caption: 'Đồ thị hàm số y = (2x + 1)/(x − 1)'
        },
        sgkRef: '12-CH1-B3',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Standard'
      },
      {
        id: '12-4b',
        title: 'Bài 4. Khảo sát sự biến thiên và vẽ đồ thị của hàm số',
        grade: 12,
        chapterIndex: 0,
        chapterTitle: 'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị của hàm số',
        theoryHtml: `
          <p>Sơ đồ tổng quát khảo sát hàm số $y = f(x)$ gồm 3 bước cơ bản:</p>
          <ol class="list-decimal list-inside space-y-1.5 pl-2">
            <li><strong>Tập xác định:</strong> Tìm tập xác định $D$ của hàm số.</li>
            <li><strong>Sự biến thiên:</strong>
              <ul class="list-disc list-inside pl-4 text-xs">
                <li>Tính $y'$, tìm các điểm tại đó $y' = 0$ hoặc $y'$ không xác định.</li>
                <li>Xét dấu $y'$ và lập bảng biến thiên (chỉ rõ đồng biến, nghịch biến, cực trị).</li>
                <li>Tìm giới hạn tại vô cực và các tiệm cận (đứng, ngang, xiên nếu có).</li>
              </ul>
            </li>
            <li><strong>Vẽ đồ thị:</strong> Xác định các điểm đặc biệt (giao với $Ox, Oy$, tâm đối xứng, trục đối xứng) rồi vẽ đường cong.</li>
          </ol>
          <div class="mt-3 p-3 bg-teal-50/80 rounded-lg border border-teal-200">
            <p class="font-bold text-teal-900">Các dạng đồ thị trọng tâm:</p>
            <p>- Hàm bậc ba: $y = ax^3 + bx^2 + cx + d$ ($a \\ne 0$). Đồ thị nhận điểm uốn $U\\left(-\\frac{b}{3a}; f\\left(-\\frac{b}{3a}\\right)\\right)$ làm tâm đối xứng.</p>
            <p>- Hàm phân thức bậc nhất / bậc nhất: $y = \\frac{ax+b}{cx+d}$ ($c \\ne 0, ad-bc \\ne 0$). Nhận giao điểm 2 tiệm cận $I\\left(-\\frac{d}{c}; \\frac{a}{c}\\right)$ làm tâm đối xứng.</p>
            <p>- Hàm phân thức bậc hai / bậc nhất: $y = \\frac{ax^2+bx+c}{px+q}$ có tiệm cận xiên và tiệm cận đứng.</p>
          </div>
        `,
        formulas: [
          'y = ax^3 + bx^2 + cx + d \\implies U\\left(-\\frac{b}{3a}; y_U\\right) \\text{ là tâm đối xứng}',
          'y = \\frac{ax+b}{cx+d} \\implies I\\left(-\\frac{d}{c}; \\frac{a}{c}\\right) \\text{ là tâm đối xứng}',
          'y = \\frac{ax^2+bx+c}{px+q} = mx + n + \\frac{r}{px+q} \\implies \\text{TCX: } y = mx + n'
        ],
        keyNotes: [
          'Điểm uốn của hàm bậc ba luôn luôn là tâm đối xứng của đồ thị.',
          'Đồ thị hàm phân thức $y = \\frac{ax+b}{cx+d}$ luôn có 2 trục đối xứng là 2 đường phân giác của các góc tạo bởi hai đường tiệm cận.',
          'Chú ý nhận dạng nhanh dấu của các hệ số $a, b, c, d$ dựa vào: giao điểm với trục tung $Oy$ ($x=0$), tiệm cận đứng, tiệm cận ngang và tọa độ điểm cực trị.'
        ],
        diagramType: 'cubic',
        diagramParams: { a: 1, b: 0, c: -3, d: 2 },
        sgkRef: '12-CH1-B4',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-5',
        title: 'Bài 5. Ứng dụng đạo hàm để giải quyết một số vấn đề liên quan đến thực tiễn',
        grade: 12,
        chapterIndex: 0,
        chapterTitle: 'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị của hàm số',
        theoryHtml: `
          <p>Các bài toán tối ưu hóa trong đời sống, kinh tế và vật lý được giải quyết chặt chẽ thông qua đạo hàm:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li><strong>Vật lý:</strong> Vận tốc tức thời $v(t) = s'(t)$, gia tốc tức thời $a(t) = v'(t) = s''(t)$. Vận tốc đạt cực đại khi $v'(t) = a(t) = 0$.</li>
            <li><strong>Kinh tế - Tài chính:</strong> Hàm doanh thu $R(x) = x \\cdot p(x)$, hàm chi phí $C(x)$, hàm lợi nhuận $P(x) = R(x) - C(x)$. Lợi nhuận tối đa khi $P'(x) = 0 \\iff R'(x) = C'(x)$ (doanh thu biên bằng chi phí biên).</li>
            <li><strong>Hình học & Sản xuất:</strong> Cắt tôn làm hộp thể tích lớn nhất, thiết kế vỏ lon hình trụ diện tích toàn phần nhỏ nhất với dung tích cho trước.</li>
          </ul>
        `,
        formulas: [
          'v(t) = s\'(t), \\quad a(t) = v\'(t) = s\'\'(t)',
          'P(x) = R(x) - C(x) \\implies P\'(x) = 0 \\iff R\'(x) = C\'(x)',
          'V_{\\text{lon trụ}} = \\pi r^2 h, \\quad S_{\\text{tp}} = 2\\pi r^2 + 2\\pi rh \\implies \\text{Tối ưu khi } h = 2r'
        ],
        keyNotes: [
          'Luôn luôn đặt điều kiện xác định chặt chẽ cho biến số thực tế (chiều dài $x > 0$, số sản phẩm $x \\in \\mathbb{N}^*$).',
          'Nếu miền giá trị là một khoảng mở $(a; b)$ mà hàm số chỉ có đúng một điểm cực trị thì cực trị đó chính là GTLN (hoặc GTNN) trên toàn khoảng.'
        ],
        diagramType: 'appliedMaxMin',
        diagramParams: {},
        sgkRef: '12-CH1-B5',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-rev1',
        title: 'Bài tập cuối chương I',
        grade: 12,
        chapterIndex: 0,
        chapterTitle: 'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị của hàm số',
        theoryHtml: `
          <p>Tổng hợp hệ thống phương pháp giải toàn bộ Chương I theo ma trận đề thi tốt nghiệp THPT Quốc gia:</p>
          <div class="space-y-2 mt-2">
            <p><strong>1. Đơn điệu:</strong> Xét dấu $f'(x)$ hoặc dùng tham số $m$: hàm bậc ba đồng biến trên $\\mathbb{R} \\iff a > 0, \\Delta' \\le 0$.</p>
            <p><strong>2. Cực trị:</strong> Nghiệm bội lẻ của $f'(x)=0$ là điểm cực trị; đếm cực trị của hàm hợp $y = f(u(x))$ và $y = |f(x)|$.</p>
            <p><strong>3. Max - Min:</strong> Phương pháp bảng biến thiên trên khoảng và so sánh giá trị đầu mút trên đoạn $[a; b]$.</p>
            <p><strong>4. Tiệm cận:</strong> Đếm số đường tiệm cận đứng và tiệm cận ngang / xiên.</p>
          </div>
        `,
        formulas: [
          'y = ax^3+bx^2+cx+d \\text{ đồng biến trên } \\mathbb{R} \\iff a > 0, \\, b^2 - 3ac \\le 0',
          '\\text{Số cực trị của } y = |f(x)| = m + n \\, (m: \\text{cực trị của } f, \\, n: \\text{nghiệm đơn } f(x)=0)',
          '\\text{Hàm } y = \\frac{ax+b}{cx+d} \\text{ không có cực trị, luôn đơn điệu trên từng khoảng xác định}'
        ],
        keyNotes: [
          'Cực trị của đồ thị hàm số là điểm $M(x_0; y_0)$ trong mặt phẳng toạ độ, phân biệt với điểm cực trị của hàm số là $x_0$.',
          'Đề thi mới có định dạng Trắc nghiệm Đúng/Sai với 4 ý liên hoàn khảo sát một bảng biến thiên cho trước.'
        ],
        diagramType: 'cubic',
        diagramParams: { a: 1, b: 0, c: -3, d: 2 },
        sgkRef: '12-CH1-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG II. VECTƠ VÀ HỆ TRỤC TOẠ ĐỘ TRONG KHÔNG GIAN
  // =========================================================================
  {
    title: 'Chương II. Vectơ và Hệ trục toạ độ trong không gian',
    grade: 12,
    lessons: [
      {
        id: '12-6',
        title: 'Bài 6. Vectơ trong không gian',
        grade: 12,
        chapterIndex: 1,
        chapterTitle: 'Chương II. Vectơ và Hệ trục toạ độ trong không gian',
        theoryHtml: `
          <p><strong>1. Khái niệm vectơ trong không gian:</strong></p>
          <p>Vectơ trong không gian là đoạn thẳng có hướng. Các khái niệm độ dài, giá của vectơ, hai vectơ cùng phương, cùng hướng, ngược hướng, bằng nhau, vectơ-không hoàn toàn tương tự trong mặt phẳng.</p>
          <p><strong>2. Các quy tắc vectơ:</strong></p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li><strong>Quy tắc ba điểm:</strong> $\\vec{AB} + \\vec{BC} = \\vec{AC}$.</li>
            <li><strong>Quy tắc hình bình hành:</strong> Nếu $ABCD$ là hình bình hành thì $\\vec{AB} + \\vec{AD} = \\vec{AC}$.</li>
            <li><strong>Quy tắc hình hộp:</strong> Nếu $ABCD.A'B'C'D'$ là hình hộp thì $\\vec{AB} + \\vec{AD} + \\vec{AA'} = \\vec{AC'}$.</li>
            <li><strong>Tích vô hướng:</strong> $\\vec{u} \\cdot \\vec{v} = |\\vec{u}| \\cdot |\\vec{v}| \\cdot \\cos(\\vec{u}, \\vec{v})$.</li>
          </ul>
        `,
        formulas: [
          '\\vec{AB} + \\vec{AD} + \\vec{AA\'} = \\vec{AC\'} \\quad (\\text{Quy tắc hình hộp})',
          '\\vec{GA} + \\vec{GB} + \\vec{GC} + \\vec{GD} = \\vec{0} \\quad (G \\text{ là trọng tâm tứ diện } ABCD)',
          '\\vec{u} \\cdot \\vec{v} = |\\vec{u}| \\cdot |\\vec{v}| \\cdot \\cos(\\vec{u}, \\vec{v})',
          '\\vec{u} \\perp \\vec{v} \\iff \\vec{u} \\cdot \\vec{v} = 0'
        ],
        keyNotes: [
          'Ba vectơ $\\vec{a}, \\vec{b}, \\vec{c}$ được gọi là đồng phẳng nếu các giá của chúng cùng song song với một mặt phẳng.',
          'Điều kiện đồng phẳng: $\\vec{c} = m\\vec{a} + n\\vec{b}$ với $\\vec{a}, \\vec{b}$ không cùng phương.'
        ],
        diagramType: 'box',
        sgkRef: '12-CH2-B6',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Standard'
      },
      {
        id: '12-7',
        title: 'Bài 7. Hệ trục toạ độ trong không gian',
        grade: 12,
        chapterIndex: 1,
        chapterTitle: 'Chương II. Vectơ và Hệ trục toạ độ trong không gian',
        theoryHtml: `
          <p>Hệ trục toạ độ Đề-các vuông góc trong không gian $Oxyz$ gồm 3 trục toạ độ $Ox, Oy, Oz$ vuông góc từng đôi một tại gốc toạ độ $O$. Các vectơ đơn vị tương ứng là $\\vec{i}, \\vec{j}, \\vec{k}$ thoả mãn:</p>
          $$\\vec{i}^2 = \\vec{j}^2 = \\vec{k}^2 = 1, \\quad \\vec{i} \\cdot \\vec{j} = \\vec{j} \\cdot \\vec{k} = \\vec{k} \\cdot \\vec{i} = 0.$$
          <p>Toạ độ của điểm $M(x; y; z) \\iff \\vec{OM} = x\\vec{i} + y\\vec{j} + z\\vec{k}$.</p>
          <p>Toạ độ của vectơ $\\vec{u} = (x; y; z) \\iff \\vec{u} = x\\vec{i} + y\\vec{j} + z\\vec{k}$.</p>
        `,
        formulas: [
          '\\vec{u} = (x; y; z) \\iff \\vec{u} = x\\vec{i} + y\\vec{j} + z\\vec{k}',
          'M(x; y; z) \\implies M\'_{\\text{hình chiếu lên } (Oxy)} = (x; y; 0), \\quad M\'_{(Ox)} = (x; 0; 0)',
          'd(M, (Oxy)) = |z|, \\quad d(M, (Oxz)) = |y|, \\quad d(M, (Oyz)) = |x|'
        ],
        keyNotes: [
          'Hình chiếu vuông góc của điểm lên mặt phẳng toạ độ nào thì giữ nguyên toạ độ tương ứng, toạ độ còn lại bằng 0.',
          'Hình chiếu vuông góc lên trục toạ độ nào thì chỉ giữ toạ độ của trục đó, hai toạ độ còn lại bằng 0.'
        ],
        diagramType: 'box',
        diagramParams: {},
        sgkRef: '12-CH2-B7',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-8',
        title: 'Bài 8. Biểu thức toạ độ của các phép toán vectơ',
        grade: 12,
        chapterIndex: 1,
        chapterTitle: 'Chương II. Vectơ và Hệ trục toạ độ trong không gian',
        theoryHtml: `
          <p>Cho $\\vec{u} = (x_1; y_1; z_1)$ và $\\vec{v} = (x_2; y_2; z_2)$ và số thực $k$:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Cộng, trừ: $\\vec{u} \\pm \\vec{v} = (x_1 \\pm x_2; y_1 \\pm y_2; z_1 \\pm z_2)$.</li>
            <li>Nhân với số thực: $k\\vec{u} = (kx_1; ky_1; kz_1)$.</li>
            <li>Tích vô hướng: $\\vec{u} \\cdot \\vec{v} = x_1 x_2 + y_1 y_2 + z_1 z_2$.</li>
            <li>Độ dài vectơ: $|\\vec{u}| = \\sqrt{x_1^2 + y_1^2 + z_1^2}$.</li>
            <li>Góc giữa hai vectơ: $\\cos(\\vec{u}, \\vec{v}) = \\frac{\\vec{u} \\cdot \\vec{v}}{|\\vec{u}| \\cdot |\\vec{v}|} = \\frac{x_1 x_2 + y_1 y_2 + z_1 z_2}{\\sqrt{x_1^2+y_1^2+z_1^2}\\sqrt{x_2^2+y_2^2+z_2^2}}$.</li>
            <li>Hai vectơ cùng phương: $\\vec{u} \\parallel \\vec{v} \\iff \\frac{x_1}{x_2} = \\frac{y_1}{y_2} = \\frac{z_1}{z_2}$ (với mẫu khác 0).</li>
          </ul>
        `,
        formulas: [
          '\\vec{u} \\cdot \\vec{v} = x_1 x_2 + y_1 y_2 + z_1 z_2',
          '|\\vec{u}| = \\sqrt{x_1^2 + y_1^2 + z_1^2}, \\quad AB = |\\vec{AB}| = \\sqrt{(x_B-x_A)^2 + (y_B-y_A)^2 + (z_B-z_A)^2}',
          'I_{\\text{trung điểm } AB} = \\left(\\frac{x_A+x_B}{2}; \\frac{y_A+y_B}{2}; \\frac{z_A+z_B}{2}\\right)',
          '[\\vec{u}, \\vec{v}] = (y_1 z_2 - z_1 y_2; \\, z_1 x_2 - x_1 z_2; \\, x_1 y_2 - y_1 x_2)'
        ],
        keyNotes: [
          '$\\vec{u} \\perp \\vec{v} \\iff \\vec{u} \\cdot \\vec{v} = 0 \\iff x_1 x_2 + y_1 y_2 + z_1 z_2 = 0$.',
          'Toạ độ trọng tâm tam giác $ABC$: $G = \\frac{A+B+C}{3}$; toạ độ trọng tâm tứ diện $ABCD$: $G = \\frac{A+B+C+D}{4}$.'
        ],
        diagramType: 'pyramid',
        diagramParams: {},
        sgkRef: '12-CH2-B8',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-rev2',
        title: 'Bài tập cuối chương II',
        grade: 12,
        chapterIndex: 1,
        chapterTitle: 'Chương II. Vectơ và Hệ trục toạ độ trong không gian',
        theoryHtml: `
          <p>Tổng kết kỹ năng giải toán hình học không gian bằng phương pháp toạ độ hoá:</p>
          <ol class="list-decimal list-inside space-y-1 pl-2">
            <li><strong>Chọn hệ trục $Oxyz$ thích hợp:</strong> Chọn gốc $O$ tại đỉnh có 3 cạnh đôi một vuông góc (hình hộp chữ nhật, hình chóp có cạnh bên vuông góc đáy).</li>
            <li><strong>Xác định toạ độ các đỉnh:</strong> Gán toạ độ dựa trên kích thước bài toán.</li>
            <li><strong>Tính toán bằng công thức vectơ:</strong> Tính góc, tính khoảng cách, tính diện tích, thể tích.</li>
          </ol>
        `,
        formulas: [
          'S_{\\Delta ABC} = \\frac{1}{2} |[\\vec{AB}, \\vec{AC}]|',
          'V_{ABCD} = \\frac{1}{6} |[\\vec{AB}, \\vec{AC}] \\cdot \\vec{AD}|'
        ],
        keyNotes: [
          'Tích có hướng $[\\vec{u}, \\vec{v}]$ vuông góc với cả $\\vec{u}$ và $\\vec{v}$.',
          'Ba vectơ đồng phẳng khi và chỉ khi $[\\vec{u}, \\vec{v}] \\cdot \\vec{w} = 0$.'
        ],
        diagramType: 'prism',
        diagramParams: {},
        sgkRef: '12-CH2-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG III. CÁC SỐ ĐẶC TRƯNG ĐO MỨC ĐỘ PHÂN TÁN MẪU SỐ LIỆU GHÉP NHÓM
  // =========================================================================
  {
    title: 'Chương III. Các số đặc trưng đo mức độ phân tán của mẫu số liệu ghép nhóm',
    grade: 12,
    lessons: [
      {
        id: '12-9a',
        title: 'Bài 9. Khoảng biến thiên và khoảng tứ phân vị',
        grade: 12,
        chapterIndex: 2,
        chapterTitle: 'Chương III. Các số đặc trưng đo mức độ phân tán của mẫu số liệu ghép nhóm',
        theoryHtml: `
          <p>Các số đặc trưng đo mức độ phân tán của mẫu số liệu ghép nhóm:</p>
          <ul class="list-disc list-inside space-y-2 pl-2">
            <li><strong>Khoảng biến thiên $R$:</strong> $R = a_k - a_1$, trong đó $a_1$ là đầu mút trái của nhóm đầu tiên và $a_k$ là đầu mút phải của nhóm cuối cùng.</li>
            <li><strong>Khoảng tứ phân vị $\\Delta_Q$:</strong> $\\Delta_Q = Q_3 - Q_1$.</li>
            <li><strong>Công thức tính tứ phân vị $Q_1, Q_3$:</strong>
              $$\\text{Tứ phân vị thứ } p \\ (p=1,3): \\quad Q_p = a_m + \\frac{\\frac{p \\cdot n}{4} - C}{n_m} \\cdot (a_{m+1} - a_m)$$
              trong đó nhóm $[a_m; a_{m+1})$ là nhóm chứa $Q_p$, $n_m$ là tần số của nhóm đó, $C$ là tần số tích luỹ của các nhóm đứng trước.
            </li>
          </ul>
        `,
        formulas: [
          'R = a_{k+1} - a_1',
          '\\Delta_Q = Q_3 - Q_1',
          'Q_1 = a_m + \\frac{\\frac{n}{4} - C}{n_m} (a_{m+1} - a_m), \\quad Q_3 = a_m + \\frac{\\frac{3n}{4} - C}{n_m} (a_{m+1} - a_m)'
        ],
        keyNotes: [
          'Khoảng tứ phân vị đo độ phân tán của 50% số liệu ở chính giữa, ít bị ảnh hưởng bởi các giá trị ngoại lai bất thường.',
          'Số liệu được coi là giá trị bất thường nếu $x < Q_1 - 1{,}5\\Delta_Q$ hoặc $x > Q_3 + 1{,}5\\Delta_Q$.'
        ],
        diagramType: 'histogram',
        diagramParams: {},
        sgkRef: '12-CH3-B9',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-9',
        title: 'Bài 10. Phương sai và độ lệch chuẩn',
        grade: 12,
        chapterIndex: 2,
        chapterTitle: 'Chương III. Các số đặc trưng đo mức độ phân tán của mẫu số liệu ghép nhóm',
        theoryHtml: `
          <p>Đo độ phân tán của mẫu số liệu ghép nhóm quanh giá trị trung bình $\\bar{x}$.</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li><strong>Giá trị đại diện:</strong> Của nhóm $[a_i; a_{i+1})$ là $c_i = \\frac{a_i + a_{i+1}}{2}$.</li>
            <li><strong>Số trung bình:</strong> $\\bar{x} = \\frac{1}{n} \\sum_{i=1}^k n_i c_i$.</li>
            <li><strong>Phương sai $s^2$:</strong> $s^2 = \\frac{1}{n} \\sum_{i=1}^k n_i (c_i - \\bar{x})^2 = \\frac{1}{n} \\sum_{i=1}^k n_i c_i^2 - \\bar{x}^2$.</li>
            <li><strong>Độ lệch chuẩn $s$:</strong> $s = \\sqrt{s^2}$.</li>
          </ul>
        `,
        formulas: [
          '\\bar{x} = \\frac{1}{n} \\sum n_i c_i \\quad (c_i: \\text{giá trị đại diện})',
          's^2 = \\frac{1}{n} \\sum n_i (c_i - \\bar{x})^2 = \\frac{1}{n} \\sum n_i c_i^2 - \\bar{x}^2',
          's = \\sqrt{s^2} \\quad (\\text{độ lệch chuẩn})'
        ],
        keyNotes: [
          'Độ lệch chuẩn $s$ càng nhỏ thì số liệu càng tập trung quanh số trung bình $\\bar{x}$, tính ổn định càng cao.',
          'Khi hai mẫu số liệu có cùng đơn vị đo và số trung bình xấp xỉ nhau, mẫu nào có phương sai nhỏ hơn thì đồng đều hơn.'
        ],
        diagramType: 'histogram',
        sgkRef: '12-CH3-B10',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Standard'
      },
      {
        id: '12-rev3',
        title: 'Bài tập cuối chương III',
        grade: 12,
        chapterIndex: 2,
        chapterTitle: 'Chương III. Các số đặc trưng đo mức độ phân tán của mẫu số liệu ghép nhóm',
        theoryHtml: `
          <p>Quy trình bấm máy tính Casio FX-580VN X / FX-880BTG tính nhanh toàn bộ các số đặc trưng mẫu ghép nhóm:</p>
          <ol class="list-decimal list-inside space-y-1 pl-2">
            <li>Vào chế độ Thống kê (Menu 6 -> 1 biến). Bật cột tần số (Frequency = On).</li>
            <li>Nhập giá trị đại diện của từng nhóm $c_i = \\frac{a_i + a_{i+1}}{2}$ vào cột $x$.</li>
            <li>Nhập tần số $n_i$ tương ứng vào cột Tần số.</li>
            <li>Bấm OPTN -> 3 (1-Variable Calc) để đọc ngay: Số trung bình $\\bar{x}$, Phương sai $s^2$, Độ lệch chuẩn $s$.</li>
          </ol>
        `,
        formulas: [
          '\\bar{x} = \\frac{1}{n} \\sum_{i=1}^k n_i c_i, \\quad s^2 = \\frac{1}{n} \\sum_{i=1}^k n_i c_i^2 - (\\bar{x})^2',
          's = \\sqrt{s^2}'
        ],
        keyNotes: [
          'Mẫu số liệu có phương sai và độ lệch chuẩn càng nhỏ thì dữ liệu càng đồng đều và tập trung quanh giá trị trung bình.',
          'Cần phân biệt độ lệch chuẩn của mẫu hiệu chỉnh $s_{n-1}$ và độ lệch chuẩn mẫu $s_n$ trong chương trình THPT.'
        ],
        diagramType: 'histogram',
        diagramParams: {},
        sgkRef: '12-CH3-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      }
    ]
  },

  // =========================================================================
  // HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM (HỌC KỲ I)
  // =========================================================================
  {
    title: 'Hoạt động thực hành trải nghiệm (Học kỳ I)',
    grade: 12,
    lessons: [
      {
        id: '12-exp1',
        title: 'Khảo sát và vẽ đồ thị hàm số với phần mềm GeoGebra',
        grade: 12,
        chapterIndex: 3,
        chapterTitle: 'Hoạt động thực hành trải nghiệm (Học kỳ I)',
        theoryHtml: `
          <p>Sử dụng phần mềm toán học động GeoGebra để trực quan hoá khảo sát hàm số:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Lệnh <code>Extremum(f)</code>: Tìm các điểm cực trị của hàm số.</li>
            <li>Lệnh <code>InflectionPoint(f)</code>: Xác định điểm uốn của đồ thị hàm bậc ba.</li>
            <li>Lệnh <code>Asymptote(f)</code>: Vẽ đường tiệm cận đứng, ngang, xiên.</li>
            <li>Tạo thanh trượt tham số <code>m</code> để quan sát sự di chuyển của đồ thị khi tham số thay đổi.</li>
          </ul>
        `,
        formulas: ['\\text{GeoGebra: } y = x^3 - 3x^2 + 2, \\quad \\text{Asymptote}(f)'],
        keyNotes: ['GeoGebra là công cụ chuẩn được Bộ GD&ĐT khuyến khích sử dụng trong giảng dạy THPT.'],
        diagramType: 'cubic',
        diagramParams: { a: 1, b: -3, c: 0, d: 2 },
        sgkRef: '12-EXP-1',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-exp2',
        title: 'Vẽ vectơ tổng của ba vectơ trong không gian bằng phần mềm GeoGebra',
        grade: 12,
        chapterIndex: 3,
        chapterTitle: 'Hoạt động thực hành trải nghiệm (Học kỳ I)',
        theoryHtml: `
          <p>Sử dụng GeoGebra 3D Calculator để dựng các khối hộp, dựng ba vectơ chung gốc $\\vec{u}, \\vec{v}, \\vec{w}$ và dựng vectơ tổng theo quy tắc hình hộp:</p>
          $$\\vec{s} = \\vec{u} + \\vec{v} + \\vec{w}.$$
        `,
        formulas: ['\\vec{u} + \\vec{v} + \\vec{w} = \\vec{s} \\quad (\\text{Vectơ đường chéo hình hộp})'],
        keyNotes: ['Rèn luyện tư duy trực quan không gian 3 chiều và khả năng mô hình hoá bằng toạ độ.'],
        diagramType: 'box',
        sgkRef: '12-EXP-2',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-exp3',
        title: 'Độ dài gang tay (gang tay của bạn dài bao nhiêu?)',
        grade: 12,
        chapterIndex: 3,
        chapterTitle: 'Hoạt động thực hành trải nghiệm (Học kỳ I)',
        theoryHtml: `
          <p>Thu thập số liệu thực tế về độ dài gang tay (cm) của học sinh trong lớp:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Ghép nhóm số liệu độ dài gang tay thành các khoảng bằng nhau $[a_i; a_{i+1})$.</li>
            <li>Tính số trung bình $\\bar{x}$, phương sai $s^2$, độ lệch chuẩn $s$.</li>
            <li>Xác định khoảng tứ phân vị và nhận xét về độ đồng đều kích thước gang tay giữa học sinh nam và nữ.</li>
          </ul>
        `,
        formulas: [
          '\\bar{x} = \\frac{1}{n} \\sum n_i c_i, \\quad s = \\sqrt{\\frac{1}{n} \\sum n_i c_i^2 - \\bar{x}^2}',
          '\\Delta_Q = Q_3 - Q_1'
        ],
        keyNotes: ['Ứng dụng thống kê thực tế để hiểu rõ ý nghĩa của độ phân tán trong đời sống thường nhật.'],
        diagramType: 'histogram',
        sgkRef: '12-EXP-3',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG IV. NGUYÊN HÀM VÀ TÍCH PHÂN
  // =========================================================================
  {
    title: 'Chương IV. Nguyên hàm và Tích phân',
    grade: 12,
    lessons: [
      {
        id: '12-11',
        title: 'Bài 11. Nguyên hàm',
        grade: 12,
        chapterIndex: 4,
        chapterTitle: 'Chương IV. Nguyên hàm và Tích phân',
        theoryHtml: `
          <p><strong>1. Định nghĩa nguyên hàm:</strong></p>
          <p>Hàm số $F(x)$ là nguyên hàm của $f(x)$ trên $K$ nếu $F'(x) = f(x)$ với mọi $x \\in K$. Kí hiệu: $\\int f(x)dx = F(x) + C$.</p>
          <p><strong>2. Tính chất cơ bản:</strong></p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>$\\int k f(x) dx = k \\int f(x) dx \\quad (k \\ne 0)$.</li>
            <li>$\\int [f(x) \\pm g(x)] dx = \\int f(x) dx \\pm \\int g(x) dx$.</li>
          </ul>
        `,
        formulas: [
          '\\int x^\\alpha dx = \\frac{x^{\\alpha+1}}{\\alpha+1} + C \\quad (\\alpha \\ne -1)',
          '\\int \\frac{1}{x} dx = \\ln|x| + C, \\quad \\int e^x dx = e^x + C, \\quad \\int a^x dx = \\frac{a^x}{\\ln a} + C',
          '\\int \\cos x dx = \\sin x + C, \\quad \\int \\sin x dx = -\\cos x + C',
          '\\int \\frac{1}{\\cos^2 x} dx = \\tan x + C, \\quad \\int \\frac{1}{\\sin^2 x} dx = -\\cot x + C'
        ],
        keyNotes: [
          'Đổi biến số: $\\int f(u(x)) u\'(x) dx = \\int f(u) du$.',
          'Từng phần: $\\int u dv = uv - \\int v du$. Thứ tự ưu tiên chọn $u$: "Nhất lô, nhì đa, tam lượng, tứ mũ".'
        ],
        diagramType: 'integral',
        sgkRef: '12-CH4-B11',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Standard'
      },
      {
        id: '12-12',
        title: 'Bài 12. Tích phân',
        grade: 12,
        chapterIndex: 4,
        chapterTitle: 'Chương IV. Nguyên hàm và Tích phân',
        theoryHtml: `
          <p><strong>1. Định nghĩa tích phân (Công thức Newton - Leibniz):</strong></p>
          $$\\int_a^b f(x) dx = F(b) - F(a) = \\left[ F(x) \\right]_a^b$$
          <p><strong>2. Tính chất cốt lõi:</strong></p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>$\\int_a^a f(x)dx = 0; \\quad \\int_a^b f(x)dx = -\\int_b^a f(x)dx$.</li>
            <li>$\\int_a^b f(x)dx = \\int_a^c f(x)dx + \\int_c^b f(x)dx$.</li>
            <li>Tích phân không phụ thuộc vào biến: $\\int_a^b f(x)dx = \\int_a^b f(t)dt$.</li>
          </ul>
        `,
        formulas: [
          '\\int_a^b f(x)dx = F(b) - F(a)',
          '\\int_a^b [u \\cdot v\'] dx = [uv]_a^b - \\int_a^b v \\, du',
          's(t) = \\int_{t_1}^{t_2} v(t) dt \\quad (\\text{Quãng đường chuyển động})'
        ],
        keyNotes: [
          'Khi đổi biến tích phân BẮT BUỘC phải đổi cận tương ứng.',
          'Nếu hàm $f(x)$ liên tục trên $[-a; a]$: hàm lẻ có $\\int_{-a}^a f(x)dx = 0$, hàm chẵn có $\\int_{-a}^a f(x)dx = 2\\int_0^a f(x)dx$.'
        ],
        diagramType: 'integral',
        sgkRef: '12-CH4-B12',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Standard'
      },
      {
        id: '12-13',
        title: 'Bài 13. Ứng dụng hình học của tích phân',
        grade: 12,
        chapterIndex: 4,
        chapterTitle: 'Chương IV. Nguyên hàm và Tích phân',
        theoryHtml: `
          <p>Tích phân có hai ứng dụng hình học cốt lõi trong đề thi THPT:</p>
          <div class="space-y-3 mt-2">
            <div class="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <p class="font-bold text-teal-800">1. Diện tích hình phẳng:</p>
              <p>- Giới hạn bởi đồ thị $y = f(x)$, $Ox$, $x = a, x = b$: $S = \\int_a^b |f(x)| \\, dx$.</p>
              <p>- Giới hạn bởi 2 đồ thị $y = f(x)$ và $y = g(x)$ trên đoạn $[a; b]$: $S = \\int_a^b |f(x) - g(x)| \\, dx$.</p>
            </div>
            <div class="p-2.5 bg-slate-50 rounded-lg border border-slate-200">
              <p class="font-bold text-teal-800">2. Thể tích vật thể & khối tròn xoay:</p>
              <p>- Thiết diện vuông góc với $Ox$ tại $x$ là $S(x)$: $V = \\int_a^b S(x) \\, dx$.</p>
              <p>- Hình phẳng quay quanh $Ox$: $V = \\pi \\int_a^b [f(x)]^2 \\, dx$.</p>
            </div>
          </div>
        `,
        formulas: [
          'S = \\int_a^b |f(x) - g(x)| \\, dx',
          'V_{\\text{vật thể}} = \\int_a^b S(x) \\, dx',
          'V_{\\text{xoay quanh } Ox} = \\pi \\int_a^b f^2(x) \\, dx'
        ],
        keyNotes: [
          'Khi tính diện tích không cần vẽ hình nếu giải trước phương trình hoành độ giao điểm $f(x) - g(x) = 0$ để chia các khoảng phá dấu trị tuyệt đối.',
          'Công thức thể tích khối tròn xoay BẮT BUỘC có hệ số $\\pi$, công thức diện tích và thể tích thiết diện KHÔNG có $\\pi$.'
        ],
        diagramType: 'integral',
        diagramParams: {},
        sgkRef: '12-CH4-B13',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-rev4',
        title: 'Bài tập cuối chương IV',
        grade: 12,
        chapterIndex: 4,
        chapterTitle: 'Chương IV. Nguyên hàm và Tích phân',
        theoryHtml: `
          <p>Tổng kết 2 phương pháp kinh điển tính nguyên hàm và tích phân:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li><strong>Đổi biến số:</strong> Đặt $u = u(x) \\implies du = u'(x)dx$. Khi tính tích phân phải nhớ ĐỔI CẬN.</li>
            <li><strong>Tích phân từng phần:</strong> $\\int u \\, dv = uv - \\int v \\, du$. Thứ tự ưu tiên chọn $u$: <em>"Nhất lô, nhì đa, tam lượng, tứ mũ"</em>.</li>
          </ul>
        `,
        formulas: [
          '\\int f(u(x)) \\cdot u\'(x) \\, dx = \\int f(u) \\, du',
          '\\int_a^b u \\, dv = \\left[ u \\cdot v \\right]_a^b - \\int_a^b v \\, du',
          '\\int_a^b f(x) \\, dx = \\int_a^c f(x) \\, dx + \\int_c^b f(x) \\, dx'
        ],
        keyNotes: [
          'Tích phân không phụ thuộc vào biến số: $\\int_a^b f(x)dx = \\int_a^b f(t)dt = \\int_a^b f(u)du$.',
          'Nhớ luôn cộng hằng số $C$ khi tính nguyên hàm.'
        ],
        diagramType: 'integral',
        diagramParams: {},
        sgkRef: '12-CH4-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG V. PHƯƠNG PHÁP TOẠ ĐỘ TRONG KHÔNG GIAN
  // =========================================================================
  {
    title: 'Chương V. Phương pháp toạ độ trong không gian',
    grade: 12,
    lessons: [
      {
        id: '12-14',
        title: 'Bài 14. Phương trình mặt phẳng',
        grade: 12,
        chapterIndex: 5,
        chapterTitle: 'Chương V. Phương pháp toạ độ trong không gian',
        theoryHtml: `
          <p><strong>1. Vectơ pháp tuyến của mặt phẳng:</strong></p>
          <p>Vectơ $\\vec{n} \\ne \\vec{0}$ vuông góc với mặt phẳng $(P)$ được gọi là VTPT của $(P)$. Nếu $\\vec{a}, \\vec{b}$ là cặp VTCP không cùng phương thì $\\vec{n} = [\\vec{a}, \\vec{b}]$.</p>
          <p><strong>2. Phương trình tổng quát của mặt phẳng:</strong></p>
          <p>Mặt phẳng qua $M_0(x_0; y_0; z_0)$ có VTPT $\\vec{n} = (A; B; C)$ có phương trình:</p>
          $$A(x - x_0) + B(y - y_0) + C(z - z_0) = 0 \\iff Ax + By + Cz + D = 0.$$
          <p><strong>3. Phương trình mặt phẳng theo đoạn chắn:</strong> Đi qua $A(a; 0; 0), B(0; b; 0), C(0; 0; c)$ là $\\frac{x}{a} + \\frac{y}{b} + \\frac{z}{c} = 1$.</p>
        `,
        formulas: [
          '(P): Ax + By + Cz + D = 0 \\quad (A^2+B^2+C^2 > 0)',
          '\\frac{x}{a} + \\frac{y}{b} + \\frac{z}{c} = 1 \\quad (\\text{Phương trình đoạn chắn})',
          'd(M_0, (P)) = \\frac{|Ax_0 + By_0 + Cz_0 + D|}{\\sqrt{A^2 + B^2 + C^2}}'
        ],
        keyNotes: [
          'Hai mặt phẳng vuông góc: $\\vec{n}_1 \\cdot \\vec{n}_2 = 0 \\iff A_1 A_2 + B_1 B_2 + C_1 C_2 = 0$.',
          'Mặt phẳng $(Oxy)$ có phương trình $z = 0$, mặt phẳng $(Oxz)$ có $y = 0$, mặt phẳng $(Oyz)$ có $x = 0$.'
        ],
        diagramType: 'box',
        sgkRef: '12-CH5-B14',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Standard'
      },
      {
        id: '12-15',
        title: 'Bài 15. Phương trình đường thẳng trong không gian',
        grade: 12,
        chapterIndex: 5,
        chapterTitle: 'Chương V. Phương pháp toạ độ trong không gian',
        theoryHtml: `
          <p>Đường thẳng $\\Delta$ đi qua điểm $M_0(x_0; y_0; z_0)$ và có vectơ chỉ phương $\\vec{u} = (a; b; c)$ ($a^2+b^2+c^2 > 0$):</p>
          <div class="mt-2 space-y-2">
            <p><strong>1. Phương trình tham số:</strong></p>
            $$\\begin{cases} x = x_0 + at \\\\ y = y_0 + bt \\\\ z = z_0 + ct \\end{cases} \\quad (t \\in \\mathbb{R})$$
            <p><strong>2. Phương trình chính tắc (khi $a, b, c \\ne 0$):</strong></p>
            $$\\frac{x - x_0}{a} = \\frac{y - y_0}{b} = \\frac{z - z_0}{c}$$
          </div>
        `,
        formulas: [
          '\\Delta: \\begin{cases} x = x_0 + at \\\\ y = y_0 + bt \\\\ z = z_0 + ct \\end{cases}',
          '\\frac{x - x_0}{a} = \\frac{y - y_0}{b} = \\frac{z - z_0}{c}',
          'd(M, \\Delta) = \\frac{|[\\vec{M_0M}, \\vec{u}]|}{|\\vec{u}|}'
        ],
        keyNotes: [
          'Một đường thẳng có vô số vectơ chỉ phương (cùng phương với nhau) và vô số cách viết phương trình tham số.',
          'Chuyển từ phương trình tham số sang chính tắc bằng cách rút tham số $t$ từ mỗi phương trình.'
        ],
        diagramType: 'prism',
        diagramParams: {},
        sgkRef: '12-CH5-B15',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-16',
        title: 'Bài 16. Công thức tính góc trong không gian',
        grade: 12,
        chapterIndex: 5,
        chapterTitle: 'Chương V. Phương pháp toạ độ trong không gian',
        theoryHtml: `
          <p>Ba công thức tính góc cơ bản bằng toạ độ:</p>
          <ul class="list-disc list-inside space-y-2 pl-2">
            <li><strong>Góc giữa hai đường thẳng $d_1, d_2$:</strong>
              $$\\cos(d_1, d_2) = \\frac{|\\vec{u}_1 \\cdot \\vec{u}_2|}{|\\vec{u}_1| \\cdot |\\vec{u}_2|} \\quad (0^\\circ \\le \\varphi \\le 90^\\circ)$$
            </li>
            <li><strong>Góc giữa hai mặt phẳng $(P), (Q)$:</strong>
              $$\\cos((P), (Q)) = \\frac{|\\vec{n}_P \\cdot \\vec{n}_Q|}{|\\vec{n}_P| \\cdot |\\vec{n}_Q|} \\quad (0^\\circ \\le \\varphi \\le 90^\\circ)$$
            </li>
            <li><strong>Góc giữa đường thẳng $d$ và mặt phẳng $(P)$:</strong>
              $$\\sin(d, (P)) = \\frac{|\\vec{u} \\cdot \\vec{n}_P|}{|\\vec{u}| \\cdot |\\vec{n}_P|} \\quad (0^\\circ \\le \\varphi \\le 90^\\circ)$$
            </li>
          </ul>
        `,
        formulas: [
          '\\cos(d_1, d_2) = \\frac{|\\vec{u}_1 \\cdot \\vec{u}_2|}{|\\vec{u}_1| \\cdot |\\vec{u}_2|}',
          '\\cos((P), (Q)) = \\frac{|\\vec{n}_P \\cdot \\vec{n}_Q|}{|\\vec{n}_P| \\cdot |\\vec{n}_Q|}',
          '\\sin(d, (P)) = \\frac{|\\vec{u} \\cdot \\vec{n}_P|}{|\\vec{u}| \\cdot |\\vec{n}_P|}'
        ],
        keyNotes: [
          'Góc giữa hai đường thẳng và góc giữa hai mặt phẳng dùng hàm COSIN có trị tuyệt đối ở tử số.',
          'Góc giữa đường thẳng và mặt phẳng dùng hàm SIN (vì góc giữa đường thẳng và VTPT là góc phụ).'
        ],
        diagramType: 'pyramid',
        diagramParams: {},
        sgkRef: '12-CH5-B16',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-17',
        title: 'Bài 17. Phương trình mặt cầu',
        grade: 12,
        chapterIndex: 5,
        chapterTitle: 'Chương V. Phương pháp toạ độ trong không gian',
        theoryHtml: `
          <p>Mặt cầu $(S)$ có tâm $I(a; b; c)$ và bán kính $R > 0$ có phương trình chính tắc:</p>
          $$(x - a)^2 + (y - b)^2 + (z - c)^2 = R^2$$
          <p>Phương trình tổng quát: $x^2 + y^2 + z^2 - 2ax - 2by - 2cz + d = 0$ là mặt cầu khi và chỉ khi:</p>
          $$a^2 + b^2 + c^2 - d > 0 \\implies R = \\sqrt{a^2 + b^2 + c^2 - d}$$
          <p><strong>Vị trí tương đối với mặt phẳng $(P)$ có khoảng cách $h = d(I, (P))$:</strong></p>
          <p>- $h > R$: Mặt phẳng không cắt mặt cầu.</p>
          <p>- $h = R$: Mặt phẳng tiếp xúc mặt cầu tại tiếp điểm $H$ (hình chiếu vuông góc của $I$ lên $(P)$).</p>
          <p>- $h < R$: Mặt phẳng cắt mặt cầu theo đường tròn giao tuyến có bán kính $r = \\sqrt{R^2 - h^2}$.</p>
        `,
        formulas: [
          '(x - a)^2 + (y - b)^2 + (z - c)^2 = R^2',
          'R = \\sqrt{a^2 + b^2 + c^2 - d} \\quad (a^2+b^2+c^2-d > 0)',
          'r_{\\text{giao tuyến}} = \\sqrt{R^2 - [d(I, (P))]^2}'
        ],
        keyNotes: [
          'Hệ số trước $x^2, y^2, z^2$ phải bằng nhau. Nếu khác 1 cần chia cả hai vế cho hệ số đó trước khi tìm tâm và bán kính.',
          'Mặt cầu tiếp xúc với mặt phẳng toạ độ $(Oxy) \\implies R = |z_I|$; tiếp xúc trục $Ox \\implies R = \\sqrt{y_I^2 + z_I^2}$.'
        ],
        diagramType: 'circle',
        diagramParams: {},
        sgkRef: '12-CH5-B17',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-rev5',
        title: 'Bài tập cuối chương V',
        grade: 12,
        chapterIndex: 5,
        chapterTitle: 'Chương V. Phương pháp toạ độ trong không gian',
        theoryHtml: `
          <p>Tổng kết vị trí tương đối và khoảng cách trong không gian Oxyz:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Khoảng cách từ điểm $M(x_0; y_0; z_0)$ đến mặt phẳng $(P): Ax + By + Cz + D = 0$:</li>
            $$d(M, (P)) = \\frac{|Ax_0 + By_0 + Cz_0 + D|}{\\sqrt{A^2 + B^2 + C^2}}$$
            <li>Khoảng cách giữa hai đường thẳng chéo nhau $\\Delta_1, \\Delta_2$:</li>
            $$d(\\Delta_1, \\Delta_2) = \\frac{|[\\vec{u}_1, \\vec{u}_2] \\cdot \\vec{M_1 M_2}|}{|[\\vec{u}_1, \\vec{u}_2]|}$$
          </ul>
        `,
        formulas: [
          'd(M, (P)) = \\frac{|Ax_0 + By_0 + Cz_0 + D|}{\\sqrt{A^2 + B^2 + C^2}}',
          'd(\\Delta_1, \\Delta_2) = \\frac{|[\\vec{u}_1, \\vec{u}_2] \\cdot \\vec{M_1 M_2}|}{|[\\vec{u}_1, \\vec{u}_2]|}'
        ],
        keyNotes: [
          'Vị trí tương đối giữa đường thẳng và mặt cầu: xét khoảng cách từ tâm $I$ đến đường thẳng so với bán kính $R$.',
          'Khi viết phương trình mặt phẳng đi qua 1 điểm và chứa đường thẳng, VTPT là tích có hướng của VTCP đường thẳng và vectơ nối điểm với 1 điểm trên đường.'
        ],
        diagramType: 'box',
        diagramParams: {},
        sgkRef: '12-CH5-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG VI. XÁC SUẤT CÓ ĐIỀU KIỆN
  // =========================================================================
  {
    title: 'Chương VI. Xác suất có điều kiện',
    grade: 12,
    lessons: [
      {
        id: '12-18',
        title: 'Bài 18. Xác suất có điều kiện',
        grade: 12,
        chapterIndex: 6,
        chapterTitle: 'Chương VI. Xác suất có điều kiện',
        theoryHtml: `
          <p><strong>1. Định nghĩa xác suất có điều kiện:</strong></p>
          <p>Xác suất của biến cố $A$ với điều kiện biến cố $B$ đã xảy ra (với $P(B) > 0$) được kí hiệu là $P(A \\mid B)$ và xác định bởi:</p>
          $$P(A \\mid B) = \\frac{P(A \\cap B)}{P(B)}.$$
          <p><strong>2. Công thức nhân xác suất:</strong></p>
          $$P(A \\cap B) = P(B) \\cdot P(A \\mid B) = P(A) \\cdot P(B \\mid A).$$
          <p>Nếu $A, B$ độc lập thì $P(A \\mid B) = P(A)$ và $P(A \\cap B) = P(A) \\cdot P(B)$.</p>
        `,
        formulas: [
          'P(A \\mid B) = \\frac{P(AB)}{P(B)} \\quad (P(B) > 0)',
          'P(AB) = P(B) \\cdot P(A \\mid B) = P(A) \\cdot P(B \\mid A)',
          'A, B \\text{ độc lập} \\iff P(AB) = P(A)P(B)'
        ],
        keyNotes: [
          'Cần phân biệt rõ: $P(AB)$ là xác suất cả $A$ và $B$ cùng xảy ra, còn $P(A \\mid B)$ là xác suất của $A$ khi đã biết $B$ chắc chắn xảy ra.',
          'Dùng sơ đồ cây hoặc bảng số liệu chéo $2 \\times 2$ giúp giải toán xác suất có điều kiện rất nhanh và trực quan.'
        ],
        diagramType: 'numberLine',
        sgkRef: '12-CH6-B18',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Standard'
      },
      {
        id: '12-19',
        title: 'Bài 19. Công thức xác suất toàn phần và công thức Bayes',
        grade: 12,
        chapterIndex: 6,
        chapterTitle: 'Chương VI. Xác suất có điều kiện',
        theoryHtml: `
          <p>Cho hệ đầy đủ các biến cố $A_1, A_2, \\dots, A_n$ đôi một xung khắc và $A_1 \\cup A_2 \\cup \\dots \\cup A_n = \\Omega$ với $P(A_i) > 0$. Với biến cố $B$ bất kỳ:</p>
          <div class="mt-2 space-y-2">
            <p><strong>1. Công thức xác suất toàn phần:</strong></p>
            $$P(B) = \\sum_{i=1}^n P(A_i) \\cdot P(B \\mid A_i)$$
            <p><strong>2. Công thức Bayes:</strong></p>
            $$P(A_k \\mid B) = \\frac{P(A_k) \\cdot P(B \\mid A_k)}{P(B)} = \\frac{P(A_k) \\cdot P(B \\mid A_k)}{\\sum_{i=1}^n P(A_i) \\cdot P(B \\mid A_i)}$$
          </div>
          <p class="mt-2 text-xs text-slate-600 italic">Ứng dụng thực tế: Đánh giá độ tin cậy của xét nghiệm y tế, lọc thư rác (Spam filter), kiểm định chất lượng dây chuyền sản xuất.</p>
        `,
        formulas: [
          'P(B) = P(A)P(B \\mid A) + P(\\overline{A})P(B \\mid \\overline{A})',
          'P(A \\mid B) = \\frac{P(A)P(B \\mid A)}{P(A)P(B \\mid A) + P(\\overline{A})P(B \\mid \\overline{A})}',
          'P(A \\cap B) = P(A) \\cdot P(B \\mid A)'
        ],
        keyNotes: [
          'Công thức Bayes cho phép "đảo ngược điều kiện": từ xác suất biết nguyên nhân dẫn tới kết quả $P(B \\mid A)$, suy ra xác suất biết kết quả là do nguyên nhân đó gây ra $P(A \\mid B)$.',
          'Nên vẽ Sơ đồ cây (Tree Diagram) để nhân xác suất dọc theo các nhánh và cộng xác suất các nhánh thỏa mãn biến cố.'
        ],
        diagramType: 'numberLine',
        diagramParams: {},
        sgkRef: '12-CH6-B19',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-rev6',
        title: 'Bài tập cuối chương VI',
        grade: 12,
        chapterIndex: 6,
        chapterTitle: 'Chương VI. Xác suất có điều kiện',
        theoryHtml: `
          <p>Tổng kết phương pháp phân tích bài toán xác suất có điều kiện:</p>
          <ol class="list-decimal list-inside space-y-1.5 pl-2">
            <li>Xác định không gian mẫu và đặt tên chính xác các biến cố tiền đề ($A, \\overline{A}$) và biến cố kết quả ($B$).</li>
            <li>Điền xác suất vào từng nhánh của sơ đồ cây.</li>
            <li>Dùng công thức nhân xác suất $P(A \\cap B) = P(A) \\cdot P(B \\mid A)$.</li>
            <li>Tính xác suất hậu nghiệm bằng công thức Bayes.</li>
          </ol>
        `,
        formulas: [
          'P(B \\mid A) = \\frac{P(A \\cap B)}{P(A)} \\quad (P(A) > 0)',
          'A, B \\text{ độc lập} \\iff P(A \\cap B) = P(A) \\cdot P(B)'
        ],
        keyNotes: [
          'Đọc kĩ đề: "Biết rằng..." hoặc "trong điều kiện..." là dấu hiệu của xác suất có điều kiện.',
          'Cần phân biệt rõ giữa $P(A \\cap B)$ (xác suất xảy ra đồng thời cả $A$ và $B$) và $P(B \\mid A)$ (xác suất xảy ra $B$ khi $A$ đã xảy ra).'
        ],
        diagramType: 'numberLine',
        diagramParams: {},
        sgkRef: '12-CH6-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      }
    ]
  },

  // =========================================================================
  // HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM (HỌC KỲ II)
  // =========================================================================
  {
    title: 'Hoạt động thực hành trải nghiệm (Học kỳ II)',
    grade: 12,
    lessons: [
      {
        id: '12-exp4',
        title: 'Tính nguyên hàm và tích phân với phần mềm GeoGebra',
        grade: 12,
        chapterIndex: 7,
        chapterTitle: 'Hoạt động thực hành trải nghiệm (Học kỳ II)',
        theoryHtml: `
          <p>Sử dụng phần mềm toán học GeoGebra để tính toán và biểu diễn hình học tích phân:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Lệnh <code>Integral(f, a, b)</code>: Tính giá trị tích phân $\\int_a^b f(x) dx$ và tô màu diện tích dưới đường cong.</li>
            <li>Lệnh <code>IntegralBetween(f, g, a, b)</code>: Tính diện tích hình phẳng giới hạn giữa hai đồ thị $f(x)$ và $g(x)$.</li>
            <li>Lệnh tính xấp xỉ bằng tổng Riemann: <code>LowerSum(f, a, b, n)</code> và <code>UpperSum(f, a, b, n)</code>.</li>
          </ul>
        `,
        formulas: [
          '\\text{GeoGebra: } \\text{Integral}(f, a, b) = F(b) - F(a)',
          '\\text{IntegralBetween}(f, g, a, b) = \\int_a^b |f(x) - g(x)| dx'
        ],
        keyNotes: ['GeoGebra giúp kiểm tra nhanh đáp án diện tích hình phẳng và quan sát trực quan tổng tích phân Riemann.'],
        diagramType: 'integral',
        sgkRef: '12-EXP-4',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-exp5',
        title: 'Mô phỏng bài toán xác suất bằng phần mềm GeoGebra',
        grade: 12,
        chapterIndex: 7,
        chapterTitle: 'Hoạt động thực hành trải nghiệm (Học kỳ II)',
        theoryHtml: `
          <p>Mô phỏng phép thử ngẫu nhiên lặp lại nhiều lần bằng GeoGebra:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Lệnh <code>RandomBetween(min, max)</code>: Sinh số nguyên ngẫu nhiên mô phỏng tung xúc xắc hoặc đồng xu.</li>
            <li>Vẽ biểu đồ tần suất thực nghiệm để so sánh tần suất với xác suất lý thuyết (Định luật số lớn).</li>
            <li>Mô phỏng sơ đồ cây xác suất có điều kiện và phân bố nhị thức.</li>
          </ul>
        `,
        formulas: [
          'f_n(A) = \\frac{m}{n} \\xrightarrow{n \\to \\infty} P(A) \\quad (\\text{Định luật số lớn})'
        ],
        keyNotes: ['Khi số phép thử $n$ rất lớn, tần suất thực nghiệm sẽ hội tụ về xác suất lý thuyết.'],
        diagramType: 'numberLine',
        sgkRef: '12-EXP-5',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-exp6',
        title: 'Lập kế hoạch tài chính cá nhân',
        grade: 12,
        chapterIndex: 7,
        chapterTitle: 'Hoạt động thực hành trải nghiệm (Học kỳ II)',
        theoryHtml: `
          <p>Vận dụng toán tài chính để xây dựng kế hoạch quản lý chi tiêu và đầu tư cá nhân:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li><strong>Quy tắc ngân sách 50/30/20:</strong> 50% thu nhập cho nhu cầu thiết yếu, 30% cho mong muốn cá nhân, 20% cho tiết kiệm và đầu tư.</li>
            <li><strong>Lập bảng tính Excel / Google Sheets:</strong> Tính số tiền tích luỹ hàng tháng với lãi suất kép để đạt mục tiêu tài chính cụ thể.</li>
            <li><strong>Tính toán nợ vay:</strong> Lập lịch trả nợ vay mua nhà/xe theo phương pháp niên kim (dư nợ giảm dần).</li>
          </ul>
        `,
        formulas: [
          'FV = PV(1 + r)^n, \\quad S_n = M \\frac{(1+r)[(1+r)^n - 1]}{r}',
          'm = \\frac{A \\cdot r(1+r)^n}{(1+r)^n - 1}'
        ],
        keyNotes: ['Giúp học sinh chuẩn bị nền tảng tài chính thông minh khi bước vào cuộc sống đại học và trưởng thành.'],
        diagramType: 'numberLine',
        sgkRef: '12-EXP-6',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      }
    ]
  },

  // =========================================================================
  // CHUYÊN ĐỀ 1. BIẾN NGẪU NHIÊN RỜI RẠC VÀ CÁC SỐ ĐẶC TRƯNG
  // =========================================================================
  {
    title: 'Chuyên đề 1. Biến ngẫu nhiên rời rạc và các số đặc trưng',
    grade: 12,
    lessons: [
      {
        id: '12-cd1-b1',
        title: 'Bài 1. Biến ngẫu nhiên rời rạc và các số đặc trưng',
        grade: 12,
        chapterIndex: 8,
        chapterTitle: 'Chuyên đề 1. Biến ngẫu nhiên rời rạc và các số đặc trưng',
        theoryHtml: `
          <p>Biến ngẫu nhiên rời rạc $X$ nhận các giá trị $x_1, x_2, \\dots, x_n$ với các xác suất tương ứng $p_1, p_2, \\dots, p_n$ thoả mãn $p_i \\ge 0$ và $\\sum p_i = 1$.</p>
          <p><strong>Các số đặc trưng:</strong></p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Kỳ vọng (Giá trị trung bình): $E(X) = \\sum_{i=1}^n x_i p_i$.</li>
            <li>Phương sai: $V(X) = E(X^2) - [E(X)]^2 = \\sum_{i=1}^n x_i^2 p_i - [E(X)]^2$.</li>
            <li>Độ lệch chuẩn: $\\sigma(X) = \\sqrt{V(X)}$.</li>
          </ul>
        `,
        formulas: [
          'E(X) = \\sum_{i=1}^n x_i p_i, \\quad \\sum_{i=1}^n p_i = 1',
          'V(X) = E(X^2) - [E(X)]^2, \\quad \\sigma(X) = \\sqrt{V(X)}',
          'E(aX + b) = aE(X) + b, \\quad V(aX + b) = a^2 V(X)'
        ],
        keyNotes: [
          'Kỳ vọng phản ánh giá trị trung bình theo nghĩa xác suất nếu phép thử được lặp lại nhiều lần.',
          'Phương sai và độ lệch chuẩn phản ánh mức độ phân tán hoặc rủi ro của biến ngẫu nhiên quanh kỳ vọng.'
        ],
        diagramType: 'numberLine',
        sgkRef: '12-CD1-B1',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-cd1-b2',
        title: 'Bài 2. Biến ngẫu nhiên có phân bố nhị thức và áp dụng',
        grade: 12,
        chapterIndex: 8,
        chapterTitle: 'Chuyên đề 1. Biến ngẫu nhiên rời rạc và các số đặc trưng',
        theoryHtml: `
          <p>Biến ngẫu nhiên $X$ là số lần thành công trong $n$ phép thử Bernoulli độc lập với xác suất thành công ở mỗi phép thử là $p$ ($0 < p < 1$). Khi đó $X$ tuân theo phân bố nhị thức, ký hiệu $X \\sim B(n, p)$.</p>
          <p>Công thức xác suất:</p>
          $$P(X = k) = C_n^k p^k (1 - p)^{n - k} \\quad (k = 0, 1, 2, \\dots, n)$$
          <p>Các số đặc trưng:</p>
          $$E(X) = np, \\quad V(X) = np(1 - p), \\quad \\sigma(X) = \\sqrt{np(1 - p)}$$
        `,
        formulas: [
          'P(X = k) = C_n^k p^k (1-p)^{n-k}',
          'E(X) = np, \\quad V(X) = np(1-p)',
          '\\sigma(X) = \\sqrt{np(1-p)}'
        ],
        keyNotes: [
          'Ứng dụng kiểm định chất lượng: tỉ lệ sản phẩm hỏng, xác suất bắn trúng mục tiêu trong $n$ phát đạn.',
          'Số lần thành công có khả năng xảy ra lớn nhất là số nguyên $k$ thoả mãn: $np - (1 - p) \\le k \\le np + p$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '12-CD1-B2',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-cd1-rev',
        title: 'Bài tập cuối chuyên đề 1',
        grade: 12,
        chapterIndex: 8,
        chapterTitle: 'Chuyên đề 1. Biến ngẫu nhiên rời rạc và các số đặc trưng',
        theoryHtml: `
          <p>Tổng kết dạng toán phân phối xác suất và ứng dụng vào thực tế kinh doanh, đầu tư:</p>
          <ol class="list-decimal list-inside space-y-1 pl-2">
            <li>Lập bảng phân bố xác suất của biến ngẫu nhiên $X$.</li>
            <li>Tính các số đặc trưng $E(X), V(X), \\sigma(X)$ để so sánh mức độ lợi nhuận và rủi ro của các phương án.</li>
            <li>Áp dụng mô hình phân bố nhị thức $B(n, p)$ khi kiểm tra xác suất có $k$ sản phẩm hỏng hoặc $k$ lượt thành công.</li>
          </ol>
        `,
        formulas: [
          'P(X = k) = C_n^k p^k (1-p)^{n-k}',
          'E(X) = np, \\quad V(X) = np(1-p)'
        ],
        keyNotes: ['Khi hai dự án có cùng kỳ vọng lợi nhuận $E(X)$, nên chọn dự án có phương sai $V(X)$ nhỏ hơn để giảm rủi ro.'],
        diagramType: 'numberLine',
        sgkRef: '12-CD1-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      }
    ]
  },

  // =========================================================================
  // CHUYÊN ĐỀ 2. ỨNG DỤNG TOÁN HỌC ĐỂ GIẢI QUYẾT MỘT SỐ BÀI TOÁN TỐI ƯU
  // =========================================================================
  {
    title: 'Chuyên đề 2. Ứng dụng toán học để giải quyết một số bài toán tối ưu',
    grade: 12,
    lessons: [
      {
        id: '12-cd2-b3',
        title: 'Bài 3. Vận dụng hệ bất phương trình bậc nhất hai ẩn để giải quyết một số bài toán quy hoạch tuyến tính',
        grade: 12,
        chapterIndex: 9,
        chapterTitle: 'Chuyên đề 2. Ứng dụng toán học để giải quyết một số bài toán tối ưu',
        theoryHtml: `
          <p>Bài toán quy hoạch tuyến tính: Tìm giá trị lớn nhất hoặc nhỏ nhất của hàm mục tiêu $F(x, y) = ax + by + c$ trên miền đa giác nghiệm của hệ bất phương trình bậc nhất hai ẩn.</p>
          <p><strong>Định lý tối ưu trên miền lồi:</strong> Giá trị lớn nhất (hoặc nhỏ nhất) của hàm mục tiêu $F(x, y)$ luôn đạt được tại một trong các đỉnh của miền đa giác nghiệm.</p>
        `,
        formulas: [
          'F(x, y) = ax + by + c',
          '\\max F(x, y) = \\max \\{ F(A), F(B), F(C), \\dots \\} \\quad (A, B, C \\text{ là các đỉnh đa giác})'
        ],
        keyNotes: [
          'Quy trình 3 bước: Xác định hệ điều kiện -> Vẽ miền nghiệm đa giác -> Tính giá trị hàm mục tiêu tại các đỉnh và chọn GTLN/GTNN.'
        ],
        diagramType: 'quadratic',
        sgkRef: '12-CD2-B3',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-cd2-b4',
        title: 'Bài 4. Vận dụng đạo hàm để giải quyết một số bài toán tối ưu trong thực tiễn',
        grade: 12,
        chapterIndex: 9,
        chapterTitle: 'Chuyên đề 2. Ứng dụng toán học để giải quyết một số bài toán tối ưu',
        theoryHtml: `
          <p>Phương pháp mô hình hoá toán học: Chuyển bài toán thực tế (tiết kiệm chi phí, tối ưu thời gian di chuyển, tối đa hoá lợi nhuận) thành bài toán tìm cực trị hàm số $y = f(x)$ trên miền xác định $D$.</p>
        `,
        formulas: [
          'f\'(x) = 0 \\implies x_0 \\text{ (nghiệm cực trị duy nhất trên khoảng)}',
          '\\text{Chi phí nhỏ nhất } \\iff C\'(x) = 0'
        ],
        keyNotes: [
          'Luôn kiểm tra tính thực tế của nghiệm (nghiệm dương, nguyên nếu cần).'
        ],
        diagramType: 'appliedMaxMin',
        sgkRef: '12-CD2-B4',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-cd2-rev',
        title: 'Bài tập cuối chuyên đề 2',
        grade: 12,
        chapterIndex: 9,
        chapterTitle: 'Chuyên đề 2. Ứng dụng toán học để giải quyết một số bài toán tối ưu',
        theoryHtml: `
          <p>Tổng hợp các bài toán tối ưu kinh tế, sản xuất và kỹ thuật:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Tối ưu sản lượng sản xuất của nhà máy với nguồn nguyên liệu và nhân công giới hạn.</li>
            <li>Tối ưu kích thước bao bì, hộp chứa, ống dẫn để tiết kiệm vật liệu nhất.</li>
            <li>Lộ trình di chuyển kết hợp đường bộ và đường thuỷ sao cho thời gian là ít nhất.</li>
          </ul>
        `,
        formulas: [
          'F(x, y) = ax + by \\to \\max/\\min \\text{ tại đỉnh}',
          'f\'(x) = 0 \\implies \\text{điểm dừng}'
        ],
        keyNotes: ['Phải lập luận chặt chẽ: hàm số đạt cực trị tại nghiệm duy nhất và đó chính là giá trị tối ưu toàn cục.'],
        diagramType: 'appliedMaxMin',
        sgkRef: '12-CD2-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      }
    ]
  },

  // =========================================================================
  // CHUYÊN ĐỀ 3. ỨNG DỤNG TOÁN HỌC TRONG MỘT SỐ VẤN ĐỀ LIÊN QUAN ĐẾN TÀI CHÍNH
  // =========================================================================
  {
    title: 'Chuyên đề 3. Ứng dụng toán học trong một số vấn đề liên quan đến tài chính',
    grade: 12,
    lessons: [
      {
        id: '12-cd3-b5',
        title: 'Bài 5. Tiền tệ. Lãi suất',
        grade: 12,
        chapterIndex: 10,
        chapterTitle: 'Chuyên đề 3. Ứng dụng toán học trong một số vấn đề liên quan đến tài chính',
        theoryHtml: `
          <p>Các mô hình tính lãi cơ bản:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li><strong>Lãi đơn:</strong> Tiền lãi chỉ tính trên vốn gốc ban đầu: $S_n = A(1 + n \\cdot r)$.</li>
            <li><strong>Lãi kép định kỳ:</strong> Lãi nhập vào vốn sau mỗi kỳ: $S_n = A(1 + r)^n$.</li>
            <li><strong>Lãi kép liên tục:</strong> Khi kỳ ghép lãi tiến tới vô cùng: $S(t) = A \\cdot e^{rt}$.</li>
          </ul>
        `,
        formulas: [
          'S_n = A(1 + n \\cdot r) \\quad (\\text{Lãi đơn})',
          'S_n = A(1 + r)^n \\quad (\\text{Lãi kép})',
          'S(t) = A \\cdot e^{rt} \\quad (\\text{Lãi kép liên tục})'
        ],
        keyNotes: [
          'Kỳ hạn lãi và lãi suất phải cùng đơn vị thời gian (tháng, quý, năm).'
        ],
        diagramType: 'numberLine',
        sgkRef: '12-CD3-B5',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-cd3-b6',
        title: 'Bài 6. Tín dụng. Vay nợ',
        grade: 12,
        chapterIndex: 10,
        chapterTitle: 'Chuyên đề 3. Ứng dụng toán học trong một số vấn đề liên quan đến tài chính',
        theoryHtml: `
          <p>Bài toán vay vốn ngân hàng số tiền ban đầu $A$, lãi suất $r$/kỳ hạn, trả đều đặn số tiền $m$ vào cuối mỗi kỳ trong $n$ kỳ hạn:</p>
          $$m = \\frac{A \\cdot r(1 + r)^n}{(1 + r)^n - 1}$$
          <p>Dư nợ còn lại sau $k$ kỳ trả tiền:</p>
          $$D_k = A(1 + r)^k - m \\frac{(1 + r)^k - 1}{r}$$
        `,
        formulas: [
          'm = \\frac{A \\cdot r(1 + r)^n}{(1 + r)^n - 1}',
          'D_k = A(1 + r)^k - m \\frac{(1 + r)^k - 1}{r}'
        ],
        keyNotes: [
          'Đây là bài toán vay mua nhà, mua xe trả góp phổ biến nhất trong thực tế.'
        ],
        diagramType: 'numberLine',
        sgkRef: '12-CD3-B6',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-cd3-b7',
        title: 'Bài 7. Đầu tư tài chính. Lập kế hoạch tài chính cá nhân',
        grade: 12,
        chapterIndex: 10,
        chapterTitle: 'Chuyên đề 3. Ứng dụng toán học trong một số vấn đề liên quan đến tài chính',
        theoryHtml: `
          <p>Định giá dòng tiền theo thời gian: Giá trị hiện tại $PV$ và Giá trị tương lai $FV$.</p>
          $$PV = \\frac{FV}{(1 + r)^n}$$
          <p>Gửi tiết kiệm định kỳ (Gửi góp): Đầu mỗi tháng gửi số tiền $M$ vào ngân hàng với lãi suất $r$/tháng, sau $n$ tháng nhận về:</p>
          $$S_n = \\frac{M(1 + r)}{r} \\left[ (1 + r)^n - 1 \\right]$$
        `,
        formulas: [
          'PV = \\frac{FV}{(1 + r)^n}',
          'S_n = \\frac{M(1 + r)}{r} \\left[ (1 + r)^n - 1 \\right]'
        ],
        keyNotes: [
          'Quy tắc 72: Số năm ước tính để số vốn tăng gấp đôi xấp xỉ bằng $\\frac{72}{\\text{lãi suất (\\%)}}$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '12-CD3-B7',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      },
      {
        id: '12-cd3-rev',
        title: 'Bài tập cuối chuyên đề 3',
        grade: 12,
        chapterIndex: 10,
        chapterTitle: 'Chuyên đề 3. Ứng dụng toán học trong một số vấn đề liên quan đến tài chính',
        theoryHtml: `
          <p>Tổng kết bài toán tài chính ứng dụng:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>So sánh hiệu quả các kênh đầu tư (tiết kiệm, trái phiếu, cổ phiếu).</li>
            <li>Tính toán lãi kép và thời gian thu hồi vốn đầu tư.</li>
            <li>Lập kế hoạch tài chính cá nhân: dự phòng khẩn cấp, mua sắm lớn, quỹ hưu trí.</li>
          </ul>
        `,
        formulas: [
          'FV = PV(1 + r)^n',
          'm = \\frac{A \\cdot r(1 + r)^n}{(1 + r)^n - 1}'
        ],
        keyNotes: ['Toán tài chính là kỹ năng sống thiết yếu cho học sinh bước vào đời.'],
        diagramType: 'numberLine',
        sgkRef: '12-CD3-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-12'
      }
    ]
  }
];
