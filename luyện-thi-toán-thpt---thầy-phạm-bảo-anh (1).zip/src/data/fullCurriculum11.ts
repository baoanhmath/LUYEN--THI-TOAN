import { Chapter } from '../types/math';

/**
 * CHƯƠNG TRÌNH TOÁN 11 TOÀN DIỆN - CHUẨN GDPT 2018 (KẾT NỐI TRI THỨC VỚI CUỘC SỐNG)
 * Biên soạn & Chuẩn hóa: Thầy Phạm Bảo Anh (Dạy học Toán PBA)
 */
export const FULL_CURRICULUM_GRADE_11: Chapter[] = [
  // =========================================================================
  // CHƯƠNG I. HÀM SỐ LƯỢNG GIÁC VÀ PHƯƠNG TRÌNH LƯỢNG GIÁC
  // =========================================================================
  {
    title: 'CHƯƠNG I. HÀM SỐ LƯỢNG GIÁC VÀ PHƯƠNG TRÌNH LƯỢNG GIÁC.',
    grade: 11,
    lessons: [
      {
        id: '11-1',
        title: 'Bài 1. Giá trị lượng giác của góc lượng giác.',
        grade: 11,
        chapterIndex: 0,
        chapterTitle: 'CHƯƠNG I. HÀM SỐ LƯỢNG GIÁC VÀ PHƯƠNG TRÌNH LƯỢNG GIÁC.',
        theoryHtml: `
          <p>Góc lượng giác: Đơn vị radian, $\\pi\\text{ rad} = 180^\\circ$. Với cung tròn bán kính $R$, độ dài cung có số đo $\\alpha$ rad là $l = R|\\alpha|$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Giá trị lượng giác trên đường tròn đơn vị:</strong></p>
            <p>$\\sin \\alpha = y_M, \\quad \\cos \\alpha = x_M, \\quad \\tan \\alpha = \\frac{\\sin \\alpha}{\\cos \\alpha} \\, (\\alpha \\ne \\frac{\\pi}{2} + k\\pi), \\quad \\cot \\alpha = \\frac{\\cos \\alpha}{\\sin \\alpha} \\, (\\alpha \\ne k\\pi)$.</p>
            <p><strong>2. Các hệ thức cơ bản:</strong></p>
            <p>$\\sin^2 \\alpha + \\cos^2 \\alpha = 1, \\quad 1 + \\tan^2 \\alpha = \\frac{1}{\\cos^2 \\alpha}, \\quad 1 + \\cot^2 \\alpha = \\frac{1}{\\sin^2 \\alpha}, \\quad \\tan \\alpha \\cdot \\cot \\alpha = 1$.</p>
            <p><strong>3. Giá trị lượng giác các góc liên kết:</strong> Cung đối, cung bù, cung hơn kém $\\pi$, cung phụ nhau ("Cos đối, Sin bù, Phụ chéo, Hơn kém $\\pi$ Tang và Cotang").</p>
          </div>
        `,
        formulas: [
          '\\sin^2 \\alpha + \\cos^2 \\alpha = 1, \\quad 1 + \\tan^2 \\alpha = \\frac{1}{\\cos^2 \\alpha}',
          '\\sin(-\\alpha) = -\\sin\\alpha, \\quad \\cos(-\\alpha) = \\cos\\alpha',
          '\\sin(\\pi - \\alpha) = \\sin\\alpha, \\quad \\cos(\\pi - \\alpha) = -\\cos\\alpha',
          '\\sin\\left(\\frac{\\pi}{2} - \\alpha\\right) = \\cos\\alpha, \\quad \\cos\\left(\\frac{\\pi}{2} - \\alpha\\right) = \\sin\\alpha'
        ],
        keyNotes: [
          'Dấu của các giá trị lượng giác phụ thuộc vào góc phần tư của điểm biểu diễn trên đường tròn lượng giác.',
          'Khi chuyển đổi giữa độ và radian: $a^\\circ = a \\cdot \\frac{\\pi}{180}$ rad; $\\alpha\\text{ rad} = \\alpha \\cdot \\left(\\frac{180}{\\pi}\\right)^\\circ$.'
        ],
        diagramType: 'trig',
        sgkRef: '11-CH1-B1',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-2',
        title: 'Bài 2. Công thức lượng giác.',
        grade: 11,
        chapterIndex: 0,
        chapterTitle: 'CHƯƠNG I. HÀM SỐ LƯỢNG GIÁC VÀ PHƯƠNG TRÌNH LƯỢNG GIÁC.',
        theoryHtml: `
          <p>Hệ thống công thức lượng giác biến đổi bắt buộc phải thuộc lòng:</p>
          <div class="space-y-2 mt-2">
            <p><strong>1. Công thức cộng:</strong></p>
            <p>$\\cos(a \\pm b) = \\cos a \\cos b \\mp \\sin a \\sin b$, $\\quad \\sin(a \\pm b) = \\sin a \\cos b \\pm \\cos a \\sin b$.</p>
            <p>$\\tan(a \\pm b) = \\frac{\\tan a \\pm \\tan b}{1 \\mp \\tan a \\tan b}$.</p>
            <p><strong>2. Công thức nhân đôi và hạ bậc:</strong></p>
            <p>$\\sin 2a = 2\\sin a \\cos a$, $\\quad \\cos 2a = \\cos^2 a - \\sin^2 a = 2\\cos^2 a - 1 = 1 - 2\\sin^2 a$.</p>
            <p>$\\cos^2 a = \\frac{1 + \\cos 2a}{2}$, $\\quad \\sin^2 a = \\frac{1 - \\cos 2a}{2}$.</p>
            <p><strong>3. Công thức biến đổi tích thành tổng & tổng thành tích:</strong></p>
            <p>$\\cos a \\cos b = \\frac{1}{2}[\\cos(a-b) + \\cos(a+b)]$, $\\quad \\sin a \\sin b = \\frac{1}{2}[\\cos(a-b) - \\cos(a+b)]$.</p>
            <p>$\\sin a \\cos b = \\frac{1}{2}[\\sin(a+b) + \\sin(a-b)]$.</p>
            <p>$\\cos u + \\cos v = 2\\cos\\frac{u+v}{2}\\cos\\frac{u-v}{2}, \\quad \\sin u + \\sin v = 2\\sin\\frac{u+v}{2}\\cos\\frac{u-v}{2}$.</p>
          </div>
        `,
        formulas: [
          '\\cos(a \\pm b) = \\cos a \\cos b \\mp \\sin a \\sin b',
          '\\sin(a \\pm b) = \\sin a \\cos b \\pm \\cos a \\sin b',
          '\\cos 2a = 2\\cos^2 a - 1 = 1 - 2\\sin^2 a, \\quad \\sin 2a = 2\\sin a \\cos a',
          '\\tan(a + b) = \\frac{\\tan a + \\tan b}{1 - \\tan a\\tan b}'
        ],
        keyNotes: [
          'Nhớ quy tắc câu vè: "Cos thì cos cos sin sin, sin thì sin cos cos sin rõ ràng; Cos thì đổi dấu đàng hoàng, Sin thì giữ dấu chẳng màng đổi thay".',
          'Khi giải toán cần chú ý đồng nhất cung góc trước khi áp dụng công thức.'
        ],
        diagramType: 'trig',
        sgkRef: '11-CH1-B2',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-3',
        title: 'Bài 3. Hàm số lượng giác.',
        grade: 11,
        chapterIndex: 0,
        chapterTitle: 'CHƯƠNG I. HÀM SỐ LƯỢNG GIÁC VÀ PHƯƠNG TRÌNH LƯỢNG GIÁC.',
        theoryHtml: `
          <p>Khảo sát 4 hàm số lượng giác cơ bản:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li><strong>$y = \\sin x$:</strong> TXĐ $\\mathbb{R}$, tập giá trị $[-1; 1]$, hàm số LẺ, tuần hoàn chu kỳ $2\\pi$. Đồng biến trên $(-\\pi/2 + k2\\pi; \\pi/2 + k2\\pi)$.</li>
            <li><strong>$y = \\cos x$:</strong> TXĐ $\\mathbb{R}$, tập giá trị $[-1; 1]$, hàm số CHẴN, tuần hoàn chu kỳ $2\\pi$. Đồng biến trên $(-\\pi + k2\\pi; k2\\pi)$.</li>
            <li><strong>$y = \\tan x$:</strong> TXĐ $D = \\mathbb{R} \\setminus \\{\\frac{\\pi}{2} + k\\pi\\}$, tập giá trị $\\mathbb{R}$, hàm số LẺ, tuần hoàn chu kỳ $\\pi$. Đồng biến trên từng khoảng $(-\\pi/2 + k\\pi; \\pi/2 + k\\pi)$.</li>
            <li><strong>$y = \\cot x$:</strong> TXĐ $D = \\mathbb{R} \\setminus \\{k\\pi\\}$, tập giá trị $\\mathbb{R}$, hàm số LẺ, tuần hoàn chu kỳ $\\pi$. Nghịch biến trên từng khoảng $(k\\pi; \\pi + k\\pi)$.</li>
          </ul>
        `,
        formulas: [
          'y = \\sin(\\omega x + \\varphi) \\implies T = \\frac{2\\pi}{|\\omega|}',
          'y = \\cos(\\omega x + \\varphi) \\implies T = \\frac{2\\pi}{|\\omega|}',
          'y = \\tan(\\omega x + \\varphi) \\implies T = \\frac{\\pi}{|\\omega|}'
        ],
        keyNotes: [
          'Chỉ duy nhất hàm $y = \\cos x$ là hàm chẵn (đồ thị đối xứng qua trục tung $Oy$), ba hàm còn lại là hàm lẻ (đối xứng qua gốc toạ độ $O$).',
          'Hàm $y = \\tan x$ không có GTLN và GTNN trên TXĐ.'
        ],
        diagramType: 'trig',
        sgkRef: '11-CH1-B3',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-4',
        title: 'Bài 4. Phương trình lượng giác cơ bản.',
        grade: 11,
        chapterIndex: 0,
        chapterTitle: 'CHƯƠNG I. HÀM SỐ LƯỢNG GIÁC VÀ PHƯƠNG TRÌNH LƯỢNG GIÁC.',
        theoryHtml: `
          <p>Nghiệm của các phương trình lượng giác cơ bản ($k \\in \\mathbb{Z}$):</p>
          <div class="space-y-2 mt-2">
            <p>1. $\\sin x = \\sin \\alpha \\iff \\begin{cases} x = \\alpha + k2\\pi \\\\ x = \\pi - \\alpha + k2\\pi \\end{cases}$</p>
            <p>2. $\\cos x = \\cos \\alpha \\iff x = \\pm \\alpha + k2\\pi$</p>
            <p>3. $\\tan x = \\tan \\alpha \\iff x = \\alpha + k\\pi$</p>
            <p>4. $\\cot x = \\cot \\alpha \\iff x = \\alpha + k\\pi$</p>
            <p class="font-bold text-teal-800">Phương trình bậc nhất đối với $\\sin x$ và $\\cos x$:</p>
            <p>$a\\sin x + b\\cos x = c$ có nghiệm khi và chỉ khi $a^2 + b^2 \\ge c^2$. Chia hai vế cho $\\sqrt{a^2 + b^2}$ để đưa về $\\sin(x + \\varphi) = \\frac{c}{\\sqrt{a^2 + b^2}}$.</p>
          </div>
        `,
        formulas: [
          '\\sin x = \\sin \\alpha \\iff x = \\alpha + k2\\pi \\text{ hoặc } x = \\pi - \\alpha + k2\\pi',
          '\\cos x = \\cos \\alpha \\iff x = \\pm \\alpha + k2\\pi',
          '\\tan x = \\tan \\alpha \\iff x = \\alpha + k\\pi',
          'a\\sin x + b\\cos x = c \\text{ có nghiệm} \\iff a^2 + b^2 \\ge c^2'
        ],
        keyNotes: [
          'Phương trình $\\sin x = m$ và $\\cos x = m$ có nghiệm khi và chỉ khi $|m| \\le 1$.',
          'Không bao giờ được dùng lẫn lộn giữa đơn vị độ ($^\\circ$) và radian trong cùng một công thức nghiệm.'
        ],
        diagramType: 'trig',
        sgkRef: '11-CH1-B4',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-rev1',
        title: 'Bài tập cuối chương I.',
        grade: 11,
        chapterIndex: 0,
        chapterTitle: 'CHƯƠNG I. HÀM SỐ LƯỢNG GIÁC VÀ PHƯƠNG TRÌNH LƯỢNG GIÁC.',
        theoryHtml: `
          <p>Hệ thống hoá kiến thức Chương I: Lượng giác và phương trình lượng giác.</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Biến đổi biểu thức lượng giác sử dụng công thức cộng, nhân đôi, biến đổi tổng thành tích.</li>
            <li>Tìm tập xác định, chu kỳ và giá trị lớn nhất, nhỏ nhất của hàm số lượng giác.</li>
            <li>Giải phương trình lượng giác cơ bản và phương trình đưa về phương trình bậc hai đối với một hàm số lượng giác.</li>
            <li>Đếm số nghiệm của phương trình lượng giác trên một khoảng, đoạn cho trước.</li>
          </ul>
        `,
        formulas: [
          '\\sin x + \\cos x = \\sqrt{2}\\sin\\left(x + \\frac{\\pi}{4}\\right)',
          '-\\sqrt{a^2+b^2} \\le a\\sin x + b\\cos x \\le \\sqrt{a^2+b^2}',
          '\\sin 3x = 3\\sin x - 4\\sin^3 x, \\quad \\cos 3x = 4\\cos^3 x - 3\\cos x'
        ],
        keyNotes: [
          'Khi tìm nghiệm trên khoảng $[a; b]$, cho nghiệm theo $k$ kẹp giữa $a$ và $b$ rồi giải tìm $k \\in \\mathbb{Z}$.',
          'Biểu diễn các họ nghiệm lên đường tròn lượng giác để kiểm tra xem có điểm ngọn trùng nhau hay không.'
        ],
        diagramType: 'trig',
        sgkRef: '11-CH1-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG II. DÃY SỐ. CẤP SỐ CỘNG VÀ CẤP SỐ NHÂN
  // =========================================================================
  {
    title: 'CHƯƠNG II. DÃY SỐ. CẤP SỐ CỘNG VÀ CẤP SỐ NHÂN.',
    grade: 11,
    lessons: [
      {
        id: '11-5',
        title: 'Bài 5. Dãy số.',
        grade: 11,
        chapterIndex: 1,
        chapterTitle: 'CHƯƠNG II. DÃY SỐ. CẤP SỐ CỘNG VÀ CẤP SỐ NHÂN.',
        theoryHtml: `
          <p>Dãy số $(u_n)$ là một hàm số xác định trên tập các số nguyên dương $\\mathbb{N}^*$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Cách cho một dãy số:</strong> Bằng công thức số hạng tổng quát; bằng hệ thức truy hồi; hoặc bằng lời miêu tả.</p>
            <p><strong>2. Dãy số tăng, dãy số giảm:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>$(u_n)$ tăng khi $u_{n+1} > u_n, \\, \\forall n \\in \\mathbb{N}^*$ (hoặc xét hiệu $u_{n+1} - u_n > 0$).</li>
              <li>$(u_n)$ giảm khi $u_{n+1} < u_n, \\, \\forall n \\in \\mathbb{N}^*$ (hoặc xét hiệu $u_{n+1} - u_n < 0$).</li>
            </ul>
            <p><strong>3. Dãy số bị chặn:</strong></p>
            <p>Bị chặn trên nếu tồn tại $M$ sao cho $u_n \\le M$; bị chặn dưới nếu tồn tại $m$ sao cho $u_n \\ge m$. Dãy vừa bị chặn trên vừa bị chặn dưới gọi là bị chặn.</p>
          </div>
        `,
        formulas: [
          'u_{n+1} - u_n > 0 \\implies (u_n) \\text{ tăng}',
          'u_{n+1} - u_n < 0 \\implies (u_n) \\text{ giảm}',
          'm \\le u_n \\le M \\, (\\forall n \\in \\mathbb{N}^*) \\implies (u_n) \\text{ bị chặn}'
        ],
        keyNotes: [
          'Nếu dãy số có mọi số hạng dương $u_n > 0$, ta có thể so sánh tỉ số $\\frac{u_{n+1}}{u_n}$ với 1 để xét tính tăng giảm.',
          'Mọi dãy số tăng và bị chặn trên thì luôn có giới hạn hữu hạn (Định lý Weierstrass).'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CH2-B5',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-6',
        title: 'Bài 6. Cấp số cộng.',
        grade: 11,
        chapterIndex: 1,
        chapterTitle: 'CHƯƠNG II. DÃY SỐ. CẤP SỐ CỘNG VÀ CẤP SỐ NHÂN.',
        theoryHtml: `
          <p>Cấp số cộng $(u_n)$ có số hạng đầu $u_1$ và công sai $d$ thoả mãn: $u_{n+1} = u_n + d$ với mọi $n \\ge 1$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Số hạng tổng quát:</strong> $u_n = u_1 + (n - 1)d \\quad (n \\ge 2)$.</p>
            <p><strong>2. Tính chất các số hạng:</strong> $u_k = \\frac{u_{k-1} + u_{k+1}}{2} \\quad (k \\ge 2)$.</p>
            <p><strong>3. Tổng $n$ số hạng đầu tiên:</strong></p>
            <p>$$S_n = u_1 + u_2 + \\dots + u_n = \\frac{n(u_1 + u_n)}{2} = \\frac{n[2u_1 + (n - 1)d]}{2}$$</p>
          </div>
        `,
        formulas: [
          'u_{n+1} = u_n + d',
          'u_n = u_1 + (n - 1)d',
          'S_n = \\frac{n(u_1 + u_n)}{2} = \\frac{n[2u_1 + (n - 1)d]}{2}',
          'a, b, c \\text{ lập thành CSC} \\iff a + c = 2b'
        ],
        keyNotes: [
          'Ba số $a, b, c$ lập thành cấp số cộng khi và chỉ khi $a + c = 2b$.',
          'Nếu công sai $d > 0$ thì CSC là dãy tăng; nếu $d < 0$ thì CSC là dãy giảm; nếu $d = 0$ thì CSC là dãy không đổi.'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CH2-B6',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-7',
        title: 'Bài 7. Cấp số nhân.',
        grade: 11,
        chapterIndex: 1,
        chapterTitle: 'CHƯƠNG II. DÃY SỐ. CẤP SỐ CỘNG VÀ CẤP SỐ NHÂN.',
        theoryHtml: `
          <p>Cấp số nhân $(u_n)$ có số hạng đầu $u_1$ và công bội $q$ thoả mãn: $u_{n+1} = u_n \\cdot q$ (với mọi $n \\ge 1$).</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Số hạng tổng quát:</strong> $u_n = u_1 \\cdot q^{n-1} \\quad (n \\ge 2)$.</p>
            <p><strong>2. Tính chất:</strong> $u_k^2 = u_{k-1} \\cdot u_{k+1} \\quad (k \\ge 2)$.</p>
            <p><strong>3. Tổng $n$ số hạng đầu:</strong> $S_n = \\frac{u_1(1 - q^n)}{1 - q} \\quad (q \\ne 1)$. Nếu $q = 1$ thì $S_n = n u_1$.</p>
            <p><strong>4. Tổng cấp số nhân lùi vô hạn ($|q| < 1$):</strong> $S = \\frac{u_1}{1 - q}$.</p>
          </div>
        `,
        formulas: [
          'u_{n+1} = u_n \\cdot q',
          'u_n = u_1 \\cdot q^{n-1}',
          'S_n = \\frac{u_1(1 - q^n)}{1 - q} \\quad (q \\ne 1)',
          'S = \\frac{u_1}{1 - q} \\quad (|q| < 1, \\, \\text{CSN lùi vô hạn})',
          'a, b, c \\text{ lập thành CSN} \\iff ac = b^2'
        ],
        keyNotes: [
          'Ứng dụng thực tế: Tăng trưởng dân số, lãi kép ngân hàng, sự phân rã phóng xạ.',
          'Chú ý dấu của công bội $q$: nếu $q < 0$ thì các số hạng của cấp số nhân đan dấu (dương, âm xen kẽ).'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CH2-B7',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-rev2',
        title: 'Bài tập cuối chương II.',
        grade: 11,
        chapterIndex: 1,
        chapterTitle: 'CHƯƠNG II. DÃY SỐ. CẤP SỐ CỘNG VÀ CẤP SỐ NHÂN.',
        theoryHtml: `
          <p>Tổng kết đối chiếu Cấp số cộng và Cấp số nhân:</p>
          <div class="overflow-x-auto mt-2">
            <table class="w-full text-xs text-left border border-slate-200">
              <thead class="bg-teal-50">
                <tr>
                  <th class="p-2 border">Đặc trưng</th>
                  <th class="p-2 border">Cấp số cộng (CSC)</th>
                  <th class="p-2 border">Cấp số nhân (CSN)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="p-2 border font-medium">Quy luật</td>
                  <td class="p-2 border">$u_{n+1} = u_n + d$</td>
                  <td class="p-2 border">$u_{n+1} = u_n \\cdot q$</td>
                </tr>
                <tr>
                  <td class="p-2 border font-medium">Số hạng thứ $n$</td>
                  <td class="p-2 border">$u_n = u_1 + (n-1)d$</td>
                  <td class="p-2 border">$u_n = u_1 \\cdot q^{n-1}$</td>
                </tr>
                <tr>
                  <td class="p-2 border font-medium">Tổng $n$ số hạng</td>
                  <td class="p-2 border">$S_n = \\frac{n(u_1 + u_n)}{2}$</td>
                  <td class="p-2 border">$S_n = \\frac{u_1(1-q^n)}{1-q}$</td>
                </tr>
                <tr>
                  <td class="p-2 border font-medium">Liên hệ 3 số hạng liên tiếp</td>
                  <td class="p-2 border">$a + c = 2b$</td>
                  <td class="p-2 border">$ac = b^2$</td>
                </tr>
              </tbody>
            </table>
          </div>
        `,
        formulas: [
          'u_k = \\frac{u_{k-1} + u_{k+1}}{2} \\quad (\\text{CSC})',
          'u_k^2 = u_{k-1} \\cdot u_{k+1} \\quad (\\text{CSN})',
          'S = \\frac{u_1}{1 - q} \\quad (|q| < 1)'
        ],
        keyNotes: [
          'Giải hệ phương trình tìm $u_1$ và $d$ (hoặc $q$) là phương pháp cơ bản nhất trong các bài toán cấp số.',
          'Các bài toán liên quan đến tổng dãy số có quy luật kết hợp giữa CSC và CSN.'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CH2-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG III. CÁC SỐ ĐẶC TRƯNG ĐO XU THẾ TRUNG TÂM CỦA MẪU SỐ LIỆU GHÉP NHÓM
  // =========================================================================
  {
    title: 'CHƯƠNG III. CÁC SỐ ĐẶC TRƯNG ĐO XU THẾ TRUNG TÂM CỦA MẪU SỐ LIỆU GHÉP NHÓM.',
    grade: 11,
    lessons: [
      {
        id: '11-8',
        title: 'Bài 8. Mẫu số liệu ghép nhóm.',
        grade: 11,
        chapterIndex: 2,
        chapterTitle: 'CHƯƠNG III. CÁC SỐ ĐẶC TRƯNG ĐO XU THẾ TRUNG TÂM CỦA MẪU SỐ LIỆU GHÉP NHÓM.',
        theoryHtml: `
          <p>Mẫu số liệu ghép nhóm được biểu diễn dưới dạng các khoảng nửa khoảng $[a_i; a_{i+1})$ cùng tần số $n_i$ tương ứng.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Giá trị đại diện của nhóm:</strong> Trung điểm của nửa khoảng $[a_i; a_{i+1})$ là $c_i = \\frac{a_i + a_{i+1}}{2}$.</p>
            <p><strong>2. Độ dài của nhóm:</strong> $h_i = a_{i+1} - a_i$.</p>
            <p><strong>3. Cỡ mẫu:</strong> $n = \\sum_{i=1}^k n_i = n_1 + n_2 + \\dots + n_k$.</p>
            <p><strong>4. Tần số tích luỹ:</strong> Tần số tích luỹ $cf_i$ của nhóm $i$ là tổng tần số của các nhóm từ nhóm 1 đến nhóm $i$.</p>
          </div>
        `,
        formulas: [
          'c_i = \\frac{a_i + a_{i+1}}{2}',
          'n = \\sum_{i=1}^k n_i',
          'cf_i = n_1 + n_2 + \\dots + n_i'
        ],
        keyNotes: [
          'Ghép nhóm giúp thu gọn và phân tích các tập dữ liệu liên tục có cỡ mẫu lớn (chiều cao, cân nặng, thu nhập, thời gian).',
          'Quy tắc chọn khoảng ghép nhóm nên đảm bảo độ dài các nhóm bằng nhau để biểu đồ và số đo chuẩn xác.'
        ],
        diagramType: 'histogram',
        sgkRef: '11-CH3-B8',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-9',
        title: 'Bài 9. Các số đặc trưng đo xu thế trung tâm.',
        grade: 11,
        chapterIndex: 2,
        chapterTitle: 'CHƯƠNG III. CÁC SỐ ĐẶC TRƯNG ĐO XU THẾ TRUNG TÂM CỦA MẪU SỐ LIỆU GHÉP NHÓM.',
        theoryHtml: `
          <p>Các công thức tính số đặc trưng đo xu thế trung tâm cho mẫu ghép nhóm:</p>
          <ul class="list-disc list-inside space-y-2 pl-2">
            <li><strong>Số trung bình:</strong> $\\bar{x} = \\frac{1}{n} \\sum_{i=1}^k n_i c_i$.</li>
            <li><strong>Trung vị $M_e$:</strong> Xác định nhóm $[a_m; a_{m+1})$ chứa trung vị (nhóm đầu tiên có tần số tích luỹ $\\ge \\frac{n}{2}$):
              $$M_e = a_m + \\frac{\\frac{n}{2} - C}{n_m}(a_{m+1} - a_m)$$
              trong đó $C = cf_{m-1}$ là tần số tích luỹ nhóm trước nhóm $m$, $n_m$ là tần số của nhóm chứa trung vị.
            </li>
            <li><strong>Tứ phân vị:</strong> $Q_1$ xác định nhóm chứa tứ phân vị thứ nhất (tần số tích luỹ $\\ge \\frac{n}{4}$); $Q_3$ (tần số tích luỹ $\\ge \\frac{3n}{4}$).</li>
            <li><strong>Mốt $M_o$:</strong> Nhóm $[a_j; a_{j+1})$ có tần số lớn nhất:
              $$M_o = a_j + \\frac{n_j - n_{j-1}}{(n_j - n_{j-1}) + (n_j - n_{j+1})}(a_{j+1} - a_j)$$
            </li>
          </ul>
        `,
        formulas: [
          '\\bar{x} = \\frac{\\sum n_i c_i}{n}',
          'M_e = a_m + \\frac{\\frac{n}{2} - C}{n_m}(a_{m+1} - a_m)',
          'M_o = a_j + \\frac{n_j - n_{j-1}}{(n_j - n_{j-1}) + (n_j - n_{j+1})}(a_{j+1} - a_j)'
        ],
        keyNotes: [
          'Trung vị $M_e$ không bị ảnh hưởng bởi các giá trị bất thường (ngoại lai), trong khi số trung bình rất nhạy cảm với các số cực đoan.',
          'Mốt có thể không duy nhất nếu có nhiều nhóm cùng đạt tần số cực đại.'
        ],
        diagramType: 'histogram',
        sgkRef: '11-CH3-B9',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-rev3',
        title: 'Bài tập cuối chương III.',
        grade: 11,
        chapterIndex: 2,
        chapterTitle: 'CHƯƠNG III. CÁC SỐ ĐẶC TRƯNG ĐO XU THẾ TRUNG TÂM CỦA MẪU SỐ LIỆU GHÉP NHÓM.',
        theoryHtml: `
          <p>Luyện tập tổng hợp tính toán và phân tích ý nghĩa các số đặc trưng đo xu thế trung tâm:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Lập bảng phân bố tần số ghép nhóm và bảng tần số tích luỹ.</li>
            <li>Tính số trung bình $\\bar{x}$, trung vị $M_e$, các tứ phân vị $Q_1, Q_2, Q_3$ và mốt $M_o$.</li>
            <li>So sánh xu thế trung tâm của hai mẫu số liệu ghép nhóm để đưa ra kết luận thực tiễn.</li>
          </ul>
        `,
        formulas: [
          'Q_1 = a_p + \\frac{\\frac{n}{4} - cf_{p-1}}{n_p}(a_{p+1} - a_p)',
          'Q_3 = a_q + \\frac{\\frac{3n}{4} - cf_{q-1}}{n_q}(a_{q+1} - a_q)',
          '\\Delta_Q = Q_3 - Q_1 \\quad (\\text{Khoảng tứ phân vị})'
        ],
        keyNotes: [
          'Khi hai mẫu có số trung bình xấp xỉ nhau, cần so sánh thêm trung vị và khoảng tứ phân vị để đánh giá độ chụm và phân bố dữ liệu.',
          'Luôn nhớ $Q_2 = M_e$ (tứ phân vị thứ hai chính là trung vị).'
        ],
        diagramType: 'histogram',
        sgkRef: '11-CH3-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG IV. QUAN HỆ SONG SONG TRONG KHÔNG GIAN
  // =========================================================================
  {
    title: 'CHƯƠNG IV. QUAN HỆ SONG SONG TRONG KHÔNG GIAN.',
    grade: 11,
    lessons: [
      {
        id: '11-10',
        title: 'Bài 10. Đường thẳng và mặt phẳng trong không gian.',
        grade: 11,
        chapterIndex: 3,
        chapterTitle: 'CHƯƠNG IV. QUAN HỆ SONG SONG TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Các tiên đề và cách xác định mặt phẳng trong không gian:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Các tính chất thừa nhận cơ bản:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Có một và chỉ một mặt phẳng đi qua ba điểm không thẳng hàng.</li>
              <li>Nếu một đường thẳng có hai điểm phân biệt thuộc một mặt phẳng thì mọi điểm của đường thẳng đều thuộc mặt phẳng đó.</li>
              <li>Nếu hai mặt phẳng phân biệt có một điểm chung thì chúng có một đường thẳng chung duy nhất chứa tất cả các điểm chung đó (giao tuyến).</li>
            </ul>
            <p><strong>2. Bốn cách xác định một mặt phẳng:</strong></p>
            <p>Qua 3 điểm không thẳng hàng; qua một đường thẳng và một điểm không thuộc nó; qua hai đường thẳng cắt nhau; qua hai đường thẳng song song.</p>
            <p><strong>3. Vị trí tương đối của hai đường thẳng:</strong> Trùng nhau, cắt nhau, song song, hoặc chéo nhau.</p>
          </div>
        `,
        formulas: [
          '(ABC) \\text{ xác định duy nhất khi } A, B, C \\text{ không thẳng hàng}',
          'd \\cap (P) = \\{M\\} \\text{ hoặc } d \\subset (P) \\text{ hoặc } d \\parallel (P)'
        ],
        keyNotes: [
          'Hai đường thẳng chéo nhau là hai đường thẳng không cùng nằm trong bất kỳ mặt phẳng nào.',
          'Để tìm giao tuyến của 2 mặt phẳng: tìm 2 điểm chung phân biệt, đường thẳng nối 2 điểm đó chính là giao tuyến.'
        ],
        diagramType: 'pyramid',
        sgkRef: '11-CH4-B10',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-11',
        title: 'Bài 11. Hai đường thẳng song song.',
        grade: 11,
        chapterIndex: 3,
        chapterTitle: 'CHƯƠNG IV. QUAN HỆ SONG SONG TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Hai đường thẳng song song trong không gian là hai đường thẳng cùng nằm trong một mặt phẳng và không có điểm chung.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Tiên đề Euclid về đường thẳng song song:</strong> Qua một điểm nằm ngoài đường thẳng cho trước có một và chỉ một đường thẳng song song với đường thẳng đó.</p>
            <p><strong>2. Tính chất bắc cầu:</strong> Hai đường thẳng phân biệt cùng song song với đường thẳng thứ ba thì song song với nhau: $a \\parallel c$ và $b \\parallel c \\implies a \\parallel b$.</p>
            <p><strong>3. Định lý giao tuyến:</strong> Nếu ba mặt phẳng đôi một cắt nhau theo ba giao tuyến phân biệt thì ba giao tuyến đó hoặc đồng quy, hoặc đôi một song song.</p>
          </div>
        `,
        formulas: [
          'a \\parallel c \\text{ và } b \\parallel c \\implies a \\parallel b \\quad (a \\ne b)',
          '(\\alpha) \\cap (\\beta) = d_1, \\, (\\beta) \\cap (\\gamma) = d_2, \\, (\\gamma) \\cap (\\alpha) = d_3 \\implies d_1 \\parallel d_2 \\parallel d_3 \\text{ hoặc } d_1, d_2, d_3 \\text{ đồng quy}'
        ],
        keyNotes: [
          'Phương pháp chứng minh hai đường thẳng song song: dùng tính chất đường trung bình trong tam giác, hình bình hành, hoặc dùng định lý Ta-lét trong tam giác.',
          'Định lý giao tuyến là công cụ đắc lực để tìm giao tuyến khi hai mặt phẳng chứa hai đường thẳng song song.'
        ],
        diagramType: 'pyramid',
        sgkRef: '11-CH4-B11',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-12',
        title: 'Bài 12. Đường thẳng và mặt phẳng song song.',
        grade: 11,
        chapterIndex: 3,
        chapterTitle: 'CHƯƠNG IV. QUAN HỆ SONG SONG TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Đường thẳng $d$ song song với mặt phẳng $(\\alpha)$ nếu chúng không có điểm chung: $d \\parallel (\\alpha)$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Dấu hiệu nhận biết:</strong></p>
            <p>Nếu đường thẳng $d$ không nằm trong $(\\alpha)$ và song song với một đường thẳng $d'$ nằm trong $(\\alpha)$ thì $d \\parallel (\\alpha)$.</p>
            <p><strong>2. Định lý giao tuyến:</strong></p>
            <p>Nếu đường thẳng $d$ song song với $(\\alpha)$ thì bất kỳ mặt phẳng $(\\beta)$ nào chứa $d$ và cắt $(\\alpha)$ theo giao tuyến $d'$ thì $d \\parallel d'$.</p>
            <p><strong>3. Hệ quả:</strong> Nếu hai mặt phẳng cùng song song với một đường thẳng thì giao tuyến của chúng (nếu có) cũng song song với đường thẳng đó.</p>
          </div>
        `,
        formulas: [
          'd \\not\\subset (\\alpha), \\, d \\parallel d\', \\, d\' \\subset (\\alpha) \\implies d \\parallel (\\alpha)',
          'd \\parallel (\\alpha), \\, d \\subset (\\beta), \\, (\\alpha) \\cap (\\beta) = d\' \\implies d \\parallel d\''
        ],
        keyNotes: [
          'Để chứng minh đường song song với mặt: tìm một đường nằm trong mặt phẳng đó mà song song với đường ban đầu.',
          'Ứng dụng then chốt để xác định thiết diện qua một điểm và song song với một đường thẳng.'
        ],
        diagramType: 'prism',
        sgkRef: '11-CH4-B12',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-13',
        title: 'Bài 13. Hai mặt phẳng song song.',
        grade: 11,
        chapterIndex: 3,
        chapterTitle: 'CHƯƠNG IV. QUAN HỆ SONG SONG TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Hai mặt phẳng $(\\alpha)$ và $(\\beta)$ song song với nhau nếu chúng không có điểm chung: $(\\alpha) \\parallel (\\beta)$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Dấu hiệu nhận biết:</strong> Nếu mặt phẳng $(\\alpha)$ chứa 2 đường thẳng cắt nhau $a, b$ và cả hai cùng song song với mặt phẳng $(\\beta)$ thì $(\\alpha) \\parallel (\\beta)$.</p>
            <p><strong>2. Tính chất:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Qua một điểm nằm ngoài một mặt phẳng có duy nhất một mặt phẳng song song với mặt phẳng đó.</li>
              <li>Hai mặt phẳng song song bị cắt bởi mặt phẳng thứ ba thì hai giao tuyến đó song song với nhau.</li>
              <li><strong>Định lý Ta-lét trong không gian:</strong> Ba mặt phẳng đôi một song song chắn trên hai cát tuyến bất kì các đoạn thẳng tương ứng tỉ lệ.</li>
            </ul>
          </div>
        `,
        formulas: [
          'a, b \\subset (\\alpha), \\, a \\cap b = I, \\, a \\parallel (\\beta), \\, b \\parallel (\\beta) \\implies (\\alpha) \\parallel (\\beta)',
          '(\\alpha) \\parallel (\\beta), \\, (\\gamma) \\cap (\\alpha) = a, \\, (\\gamma) \\cap (\\beta) = b \\implies a \\parallel b',
          '\\frac{A_1 B_1}{A_2 B_2} = \\frac{B_1 C_1}{B_2 C_2} = \\frac{A_1 C_1}{A_2 C_2} \\quad (\\text{Định lý Thales không gian})'
        ],
        keyNotes: [
          'Hình lăng trụ và hình hộp có các mặt bên là hình bình hành, hai mặt đáy nằm trên hai mặt phẳng song song và bằng nhau.',
          'Khoảng cách giữa hai mặt phẳng song song là không đổi tại mọi điểm.'
        ],
        diagramType: 'box',
        sgkRef: '11-CH4-B13',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-14',
        title: 'Bài 14. Phép chiếu song song.',
        grade: 11,
        chapterIndex: 3,
        chapterTitle: 'CHƯƠNG IV. QUAN HỆ SONG SONG TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Cho mặt phẳng $(P)$ và đường thẳng $l$ cắt $(P)$. Phép chiếu song song lên $(P)$ theo phương $l$ biến mỗi điểm $M$ thành điểm $M' \\in (P)$ sao cho $MM' \\parallel l$ (hoặc $M' \\equiv M$ nếu $M \\in (P)$).</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>Tính chất của phép chiếu song song:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Biến ba điểm thẳng hàng thành ba điểm thẳng hàng và bảo toàn thứ tự giữa chúng.</li>
              <li>Biến đường thẳng thành đường thẳng, tia thành tia, đoạn thẳng thành đoạn thẳng.</li>
              <li>Biến hai đường thẳng song song thành hai đường thẳng song song hoặc trùng nhau.</li>
              <li>Bảo toàn tỉ số độ dài của hai đoạn thẳng cùng nằm trên một đường thẳng hoặc nằm trên hai đường thẳng song song.</li>
            </ul>
            <p><strong>Quy tắc vẽ hình biểu diễn của các hình không gian:</strong> Hình biểu diễn của hình bình hành là hình bình hành; hình tròn được biểu diễn bởi hình elip.</p>
          </div>
        `,
        formulas: [
          '\\frac{A\'B\'}{C\'D\'} = \\frac{AB}{CD} \\quad (AB \\parallel CD)',
          'M \\text{ là trung điểm } AB \\implies M\' \\text{ là trung điểm } A\'B\''
        ],
        keyNotes: [
          'Phép chiếu song song KHÔNG bảo toàn độ lớn của góc và tỉ số độ dài của hai đoạn thẳng không song song.',
          'Các đường nét thấy vẽ bằng nét liền, nét khuất (bị che lấp) vẽ bằng nét đứt.'
        ],
        diagramType: 'prism',
        sgkRef: '11-CH4-B14',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-rev4',
        title: 'Bài tập cuối chương IV.',
        grade: 11,
        chapterIndex: 3,
        chapterTitle: 'CHƯƠNG IV. QUAN HỆ SONG SONG TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Hệ thống hoá quan hệ song song trong không gian và dựng thiết diện:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Phương pháp tìm giao tuyến của hai mặt phẳng và giao điểm của đường thẳng với mặt phẳng.</li>
            <li>Chứng minh hai đường thẳng song song, đường thẳng song song mặt phẳng, hai mặt phẳng song song.</li>
            <li>Dựng thiết diện của hình chóp, hình lăng trụ cắt bởi một mặt phẳng đi qua một điểm và song song với các đường thẳng/mặt phẳng cho trước.</li>
          </ul>
        `,
        formulas: [
          'd \\parallel (\\alpha) \\iff \\exists d\' \\subset (\\alpha): d \\parallel d\'',
          '(\\alpha) \\parallel (\\beta) \\iff \\exists a, b \\subset (\\alpha), a \\cap b = I, a \\parallel (\\beta), b \\parallel (\\beta)'
        ],
        keyNotes: [
          'Khi dựng thiết diện: lần lượt tìm giao tuyến của mặt phẳng cắt với các mặt của hình đa diện, kết quả là một đa giác khép kín.',
          'Sử dụng định lý giao tuyến để vẽ nhanh các cạnh thiết diện song song.'
        ],
        diagramType: 'pyramid',
        sgkRef: '11-CH4-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG V. GIỚI HẠN. HÀM SỐ LIÊN TỤC
  // =========================================================================
  {
    title: 'CHƯƠNG V. GIỚI HẠN. HÀM SỐ LIÊN TỤC.',
    grade: 11,
    lessons: [
      {
        id: '11-15',
        title: 'Bài 15. Giới hạn của dãy số.',
        grade: 11,
        chapterIndex: 4,
        chapterTitle: 'CHƯƠNG V. GIỚI HẠN. HÀM SỐ LIÊN TỤC.',
        theoryHtml: `
          <p>Dãy số $(u_n)$ có giới hạn là $0$ khi $n \\to +\\infty$ nếu $|u_n|$ có thể nhỏ hơn một số dương bé tuỳ ý kể từ một số hạng nào đó trở đi. Kí hiệu $\\lim u_n = 0$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Các giới hạn cơ bản:</strong></p>
            <p>$\\lim \\frac{1}{n^k} = 0 \\, (k > 0)$, $\\quad \\lim q^n = 0 \\, (|q| < 1)$, $\\quad \\lim c = c$.</p>
            <p><strong>2. Định lý về giới hạn hữu hạn:</strong></p>
            <p>$\\lim(u_n \\pm v_n) = a \\pm b$, $\\quad \\lim(u_n v_n) = ab$, $\\quad \\lim\\frac{u_n}{v_n} = \\frac{a}{b} \\, (b \\ne 0)$.</p>
            <p><strong>3. Tổng cấp số nhân lùi vô hạn ($|q| < 1$):</strong> $S = u_1 + u_1 q + u_1 q^2 + \\dots = \\frac{u_1}{1 - q}$.</p>
          </div>
        `,
        formulas: [
          '\\lim_{n \\to +\\infty} \\frac{1}{n^k} = 0 \\quad (k > 0)',
          '\\lim_{n \\to +\\infty} q^n = 0 \\quad (|q| < 1)',
          'S = \\frac{u_1}{1 - q} \\quad (|q| < 1)'
        ],
        keyNotes: [
          'Phương pháp tính giới hạn phân thức bậc $n$: Chia cả tử và mẫu cho luỹ thừa bậc cao nhất của $n$.',
          'Nếu tử số có bậc nhỏ hơn mẫu số thì giới hạn bằng $0$; nếu cùng bậc thì bằng tỉ số hai hệ số cao nhất; nếu tử lớn hơn thì ra vô cực.'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CH5-B15',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-16',
        title: 'Bài 16. Giới hạn của hàm số.',
        grade: 11,
        chapterIndex: 4,
        chapterTitle: 'CHƯƠNG V. GIỚI HẠN. HÀM SỐ LIÊN TỤC.',
        theoryHtml: `
          <p>Giới hạn của hàm số tại một điểm $\\lim_{x \\to x_0} f(x) = L$ và tại vô cực $\\lim_{x \\to \\pm\\infty} f(x)$. Giới hạn một bên $\\lim_{x \\to x_0^+} f(x)$ và $\\lim_{x \\to x_0^-} f(x)$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>Bốn dạng vô định kinh điển và phương pháp khử:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li><strong>Dạng $\\frac{0}{0}$:</strong> Phân tích thành nhân tử $(x - x_0)$ để triệt tiêu, hoặc nhân chia lượng liên hợp chứa căn thức.</li>
              <li><strong>Dạng $\\frac{\\infty}{\\infty}$:</strong> Chia cả tử và mẫu cho luỹ thừa bậc cao nhất của $x$. Chú ý khi $x \\to -\\infty$ thì $\\sqrt{x^2} = |x| = -x$.</li>
              <li><strong>Dạng $\\infty - \\infty$:</strong> Nhân chia lượng liên hợp để chuyển về dạng $\\frac{\\infty}{\\infty}$ hoặc $\\frac{0}{0}$.</li>
              <li><strong>Dạng $0 \\cdot \\infty$:</strong> Biến đổi đưa về dạng $\\frac{0}{0}$ hoặc $\\frac{\\infty}{\\infty}$.</li>
            </ul>
          </div>
        `,
        formulas: [
          '\\lim_{x \\to x_0} \\frac{f(x)}{g(x)} = \\lim_{x \\to x_0} \\frac{(x - x_0)P(x)}{(x - x_0)Q(x)} = \\lim_{x \\to x_0} \\frac{P(x)}{Q(x)}',
          '\\lim_{x \\to x_0} f(x) = L \\iff \\lim_{x \\to x_0^+} f(x) = \\lim_{x \\to x_0^-} f(x) = L',
          '\\sqrt{A} - \\sqrt{B} = \\frac{A - B}{\\sqrt{A} + \\sqrt{B}}'
        ],
        keyNotes: [
          'Cực kỳ cẩn thận khi $x \\to -\\infty$: $\\sqrt{x^2} = |x| = -x$. Lỗi phổ biến nhất là học sinh quên đổi dấu.',
          'Hàm số có giới hạn tại $x_0$ khi và chỉ khi giới hạn bên trái bằng giới hạn bên phải.'
        ],
        diagramType: 'rational',
        diagramParams: { a: 1, b: 0, c: 1, d: 0 },
        sgkRef: '11-CH5-B16',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-17',
        title: 'Bài 17. Hàm số liên tục.',
        grade: 11,
        chapterIndex: 4,
        chapterTitle: 'CHƯƠNG V. GIỚI HẠN. HÀM SỐ LIÊN TỤC.',
        theoryHtml: `
          <p>Hàm số $y = f(x)$ xác định trên khoảng $(a; b)$ được gọi là liên tục tại điểm $x_0 \\in (a; b)$ nếu:</p>
          $$\\lim_{x \\to x_0} f(x) = f(x_0)$$
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Tính chất các hàm số sơ cấp:</strong> Hàm số đa thức, phân thức hữu tỉ, hàm lượng giác liên tục trên từng khoảng xác định của chúng.</p>
            <p><strong>2. Hàm số liên tục trên một đoạn:</strong> Hàm số liên tục trên $(a; b)$ và $\\lim_{x \\to a^+} f(x) = f(a)$, $\\lim_{x \\to b^-} f(x) = f(b)$.</p>
            <p><strong>3. Định lý Bolzano - Cauchy (chứng minh PT có nghiệm):</strong></p>
            <p>Nếu hàm số $y = f(x)$ liên tục trên đoạn $[a; b]$ và $f(a) \\cdot f(b) < 0$ thì tồn tại ít nhất một điểm $c \\in (a; b)$ sao cho $f(c) = 0$, nghĩa là phương trình $f(x) = 0$ có ít nhất 1 nghiệm thuộc khoảng $(a; b)$.</p>
          </div>
        `,
        formulas: [
          '\\lim_{x \\to x_0} f(x) = f(x_0) \\iff f \\text{ liên tục tại } x_0',
          'f(a) \\cdot f(b) < 0 \\text{ và } f \\text{ liên tục trên } [a; b] \\implies \\exists c \\in (a; b): f(c) = 0'
        ],
        keyNotes: [
          'Để xét tính liên tục của hàm số cho bởi nhiều công thức tại điểm ranh giới $x_0$: cần tính $f(x_0)$, $\\lim_{x \\to x_0^+} f(x)$, và $\\lim_{x \\to x_0^-} f(x)$ rồi so sánh 3 giá trị.',
          'Định lý giá trị trung gian là cơ sở để chứng minh phương trình đại số có nghiệm mà không cần giải phương trình.'
        ],
        diagramType: 'cubic',
        diagramParams: { a: 1, b: 0, c: -3, d: 0 },
        sgkRef: '11-CH5-B17',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-rev5',
        title: 'Bài tập cuối chương V.',
        grade: 11,
        chapterIndex: 4,
        chapterTitle: 'CHƯƠNG V. GIỚI HẠN. HÀM SỐ LIÊN TỤC.',
        theoryHtml: `
          <p>Ôn tập chuyên đề Giới hạn và Hàm số liên tục trong các đề thi THPT:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Kỹ thuật khử các dạng vô định phức tạp chứa đồng thời căn bậc hai và căn bậc ba.</li>
            <li>Phương pháp thêm bớt đại lượng thích hợp để tách biểu thức thành nhiều giới hạn đơn giản.</li>
            <li>Tìm tham số $m$ để hàm số liên tục tại một điểm hoặc liên tục trên toàn trục số.</li>
            <li>Chứng minh phương trình bậc cao hoặc lượng giác có nghiệm trên khoảng cho trước.</li>
          </ul>
        `,
        formulas: [
          'a^3 - b^3 = (a - b)(a^2 + ab + b^2) \\implies a - b = \\frac{a^3 - b^3}{a^2 + ab + b^2}',
          '\\lim_{x \\to 0} \\frac{\\sin x}{x} = 1'
        ],
        keyNotes: [
          'Với dạng chứa cả căn bậc 2 và căn bậc 3 triệt tiêu nhau: thêm bớt hằng số $f(x_0)$ vào tử số rồi tách thành hai phân số độc lập.',
          'Tận dụng máy tính cầm tay (CALC với $x = x_0 \\pm 10^{-6}$) để kiểm tra nhanh kết quả giới hạn.'
        ],
        diagramType: 'rational',
        diagramParams: { a: 1, b: 0, c: 1, d: 0 },
        sgkRef: '11-CH5-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM (HỌC KÌ I)
  // =========================================================================
  {
    title: 'HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM.',
    grade: 11,
    lessons: [
      {
        id: '11-exp1',
        title: 'Một vài áp dụng của Toán học trong tài chính.',
        grade: 11,
        chapterIndex: 5,
        chapterTitle: 'HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM.',
        theoryHtml: `
          <p>Toán học là nền tảng cốt lõi của tài chính hiện đại. Các mô hình tăng trưởng kinh tế, tiết kiệm và vay vốn ngân hàng:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Lãi đơn và Lãi kép:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Lãi đơn: Tiền lãi chỉ tính trên vốn gốc ban đầu: $A = P(1 + r \\cdot n)$.</li>
              <li>Lãi kép: Tiền lãi của kỳ trước được nhập vào vốn để tính lãi cho kỳ kế tiếp: $A = P(1 + r)^n$.</li>
            </ul>
            <p><strong>2. Bài toán gửi tiền định kỳ (Niên kim cố định - Annuity):</strong></p>
            <p>Mỗi tháng gửi vào ngân hàng số tiền $m$ với lãi suất $r$ / tháng. Tổng số tiền sau $n$ tháng:
              $$S_n = m \\frac{(1 + r)[(1 + r)^n - 1]}{r}$$
            </p>
            <p><strong>3. Bài toán trả góp ngân hàng:</strong> Vay số tiền ban đầu $V$, trả đều mỗi tháng $m$ trong $n$ tháng: $m = \\frac{V \\cdot r \\cdot (1 + r)^n}{(1 + r)^n - 1}$.</p>
          </div>
        `,
        formulas: [
          'A = P(1 + r)^n \\quad (\\text{Lãi kép})',
          'S_n = m \\frac{(1 + r)[(1 + r)^n - 1]}{r} \\quad (\\text{Gửi tiết kiệm định kì})',
          'm = \\frac{V \\cdot r \\cdot (1+r)^n}{(1+r)^n - 1} \\quad (\\text{Vay trả góp})'
        ],
        keyNotes: [
          'Công thức gửi định kỳ và vay trả góp đều là ứng dụng trực tiếp từ tổng $n$ số hạng đầu của cấp số nhân.',
          'Chú ý đồng nhất đơn vị thời gian của lãi suất $r$ và số kỳ hạn $n$ (tháng, quý, năm).'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-EXP-FINANCE',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-exp2',
        title: 'Lực căng mặt ngoài của nước.',
        grade: 11,
        chapterIndex: 5,
        chapterTitle: 'HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM.',
        theoryHtml: `
          <p>Ứng dụng hình học và giải tích trong vật lý chất lỏng và hiện tượng mao dẫn:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Hiện tượng căng bề mặt:</strong> Phân tử nước bên trong hút nhau đồng đều, nhưng phân tử ở bề mặt bị hút vào trong, tạo màng mỏng co lại diện tích nhỏ nhất.</p>
            <p><strong>2. Công thức lực căng mặt ngoài:</strong> $F = \\sigma \\cdot l$, trong đó $\\sigma$ là hệ số căng mặt ngoài (N/m), $l$ là chiều dài đường giới hạn mặt thoáng.</p>
            <p><strong>3. Bài toán tối ưu diện tích mặt:</strong> Trong không gian, với cùng một thể tích, hình cầu là hình có diện tích mặt ngoài nhỏ nhất (giải thích tại sao giọt nước tự do có hình cầu).</p>
          </div>
        `,
        formulas: [
          'F = \\sigma \\cdot l \\quad (l = 2\\pi R \\text{ hoặc } l = 2L)',
          'S_{\\text{mặt cầu}} = 4\\pi R^2, \\quad V_{\\text{khối cầu}} = \\frac{4}{3}\\pi R^3'
        ],
        keyNotes: [
          'Minh hoạ toán học: Côn trùng (gọng vó) đi trên mặt nước nhờ lực căng mặt ngoài cân bằng với trọng lượng cơ thể.',
          'Kết nối giữa tính chất vật lý và bài toán cực trị hình học.'
        ],
        diagramType: 'circle',
        sgkRef: '11-EXP-SURFACE',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG VI. HÀM SỐ MŨ VÀ HÀM SỐ LÔGARIT
  // =========================================================================
  {
    title: 'CHƯƠNG VI. HÀM SỐ MŨ VÀ HÀM SỐ LÔGARIT.',
    grade: 11,
    lessons: [
      {
        id: '11-18',
        title: 'Bài 18. Luỹ thừa với số mũ thực.',
        grade: 11,
        chapterIndex: 6,
        chapterTitle: 'CHƯƠNG VI. HÀM SỐ MŨ VÀ HÀM SỐ LÔGARIT.',
        theoryHtml: `
          <p>Mở rộng khái niệm luỹ thừa: số mũ nguyên dương $\\to$ số mũ nguyên $\\to$ số mũ hữu tỉ $\\to$ số mũ thực.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Quy tắc và tính chất luỹ thừa ($a, b > 0$):</strong></p>
            <p>$$a^\\alpha \\cdot a^\\beta = a^{\\alpha+\\beta}, \\quad \\frac{a^\\alpha}{a^\\beta} = a^{\\alpha-\\beta}, \\quad (a^\\alpha)^\\beta = a^{\\alpha\\beta}, \\quad (ab)^\\alpha = a^\\alpha b^\\alpha, \\quad \\left(\\frac{a}{b}\\right)^\\alpha = \\frac{a^\\alpha}{b^\\alpha}$$</p>
            <p><strong>2. Căn bậc $n$ và số mũ hữu tỉ:</strong> $a^{m/n} = \\sqrt[n]{a^m} \\, (a > 0, m \\in \\mathbb{Z}, n \\in \\mathbb{N}, n \\ge 2)$.</p>
            <p><strong>3. So sánh các luỹ thừa:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Khi $a > 1$: $a^\\alpha > a^\\beta \\iff \\alpha > \\beta$.</li>
              <li>Khi $0 < a < 1$: $a^\\alpha > a^\\beta \\iff \\alpha < \\beta$ (đảo chiều bất đẳng thức).</li>
            </ul>
          </div>
        `,
        formulas: [
          'a^\\alpha \\cdot a^\\beta = a^{\\alpha + \\beta}, \\quad (a^\\alpha)^\\beta = a^{\\alpha \\beta}',
          'a > 1: a^\\alpha > a^\\beta \\iff \\alpha > \\beta; \\quad 0 < a < 1: a^\\alpha > a^\\beta \\iff \\alpha < \\beta',
          'a^{m/n} = \\sqrt[n]{a^m} \\quad (a > 0)'
        ],
        keyNotes: [
          'Luỹ thừa với số mũ vô tỉ hoặc hữu tỉ không nguyên $a^\\alpha$ chỉ xác định với cơ số $a > 0$.',
          'Luỹ thừa với số mũ nguyên âm $a^{-n} = \\frac{1}{a^n}$ xác định với $a \\ne 0$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CH6-B18',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-19',
        title: 'Bài 19. Lôgarit.',
        grade: 11,
        chapterIndex: 6,
        chapterTitle: 'CHƯƠNG VI. HÀM SỐ MŨ VÀ HÀM SỐ LÔGARIT.',
        theoryHtml: `
          <p>Cho $a > 0, a \\ne 1$ và $b > 0$. Lôgarit cơ số $a$ của $b$: $\\log_a b = \\alpha \\iff a^\\alpha = b$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Các công thức biến đổi cơ bản:</strong></p>
            <p>$\\log_a(x \\cdot y) = \\log_a x + \\log_a y, \\quad \\log_a\\left(\\frac{x}{y}\\right) = \\log_a x - \\log_a y$.</p>
            <p>$\\log_a(x^\\alpha) = \\alpha \\log_a x, \\quad \\log_{a^\\beta} x = \\frac{1}{\\beta} \\log_a x$.</p>
            <p><strong>2. Công thức đổi cơ số:</strong> $\\log_a b = \\frac{\\log_c b}{\\log_c a} \\quad (c > 0, c \\ne 1)$.</p>
            <p>Đặc biệt: $\\log_a b = \\frac{1}{\\log_b a}, \\quad a^{\\log_c b} = b^{\\log_c a}, \\quad a^{\\log_a b} = b$.</p>
          </div>
        `,
        formulas: [
          '\\log_a(xy) = \\log_a x + \\log_a y, \\quad \\log_a\\left(\\frac{x}{y}\\right) = \\log_a x - \\log_a y',
          '\\log_a b = \\frac{\\log_c b}{\\log_c a}, \\quad a^{\\log_a b} = b',
          '\\log_{a^\\beta} x^\\alpha = \\frac{\\alpha}{\\beta}\\log_a x'
        ],
        keyNotes: [
          'Biểu thức $\\log_a f(x)$ xác định khi và chỉ khi cơ số $a > 0, a \\ne 1$ và biểu thức $f(x) > 0$.',
          'Lôgarit tự nhiên $\\ln x = \\log_e x$ ($e \\approx 2{,}71828$); Lôgarit thập phân $\\lg x = \\log_{10} x$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CH6-B19',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-20',
        title: 'Bài 20. Hàm số mũ và hàm số lôgarit.',
        grade: 11,
        chapterIndex: 6,
        chapterTitle: 'CHƯƠNG VI. HÀM SỐ MŨ VÀ HÀM SỐ LÔGARIT.',
        theoryHtml: `
          <p>Khảo sát đồ thị và tính chất của hàm số mũ $y = a^x$ và hàm số lôgarit $y = \\log_a x$ ($a > 0, a \\ne 1$):</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Hàm số mũ $y = a^x$:</strong> TXĐ $\\mathbb{R}$, tập giá trị $(0; +\\infty)$. Đồ thị luôn qua điểm $(0; 1)$, nhận trục hoành $Ox$ làm tiệm cận ngang.</p>
            <p><strong>2. Hàm số lôgarit $y = \\log_a x$:</strong> TXĐ $(0; +\\infty)$, tập giá trị $\\mathbb{R}$. Đồ thị luôn qua điểm $(1; 0)$, nhận trục tung $Oy$ làm tiệm cận đứng.</p>
            <p><strong>3. Tính đơn điệu:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Khi $a > 1$: Cả hai hàm số đều ĐỒNG BIẾN trên tập xác định.</li>
              <li>Khi $0 < a < 1$: Cả hai hàm số đều NGHỊCH BIẾN trên tập xác định.</li>
            </ul>
            <p>Đồ thị của $y = a^x$ và $y = \\log_a x$ đối xứng nhau qua đường thẳng phân giác $y = x$.</p>
          </div>
        `,
        formulas: [
          'a > 1 \\implies y = a^x \\text{ và } y = \\log_a x \\text{ đồng biến}',
          '0 < a < 1 \\implies y = a^x \\text{ và } y = \\log_a x \\text{ nghịch biến}',
          '\\text{Đồ thị } y = a^x \\text{ và } y = \\log_a x \\text{ đối xứng qua } y = x'
        ],
        keyNotes: [
          'Hàm số mũ $y = a^x$ luôn nhận giá trị dương với mọi $x \\in \\mathbb{R}$.',
          'Đồ thị hàm số mũ không bao giờ cắt trục hoành.'
        ],
        diagramType: 'rational',
        diagramParams: { a: 2, b: 0, c: 0, d: 1 },
        sgkRef: '11-CH6-B20',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-21',
        title: 'Bài 21. Phương trình, bất phương trình mũ và lôgarit.',
        grade: 11,
        chapterIndex: 6,
        chapterTitle: 'CHƯƠNG VI. HÀM SỐ MŨ VÀ HÀM SỐ LÔGARIT.',
        theoryHtml: `
          <p>Các phương pháp giải phương trình và bất phương trình mũ, lôgarit:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Đưa về cùng cơ số:</strong></p>
            <p>$a^{f(x)} = a^{g(x)} \\iff f(x) = g(x)$; $\\quad \\log_a f(x) = \\log_a g(x) \\iff f(x) = g(x) > 0$.</p>
            <p><strong>2. Đặt ẩn phụ:</strong></p>
            <p>Đặt $t = a^x$ (điều kiện $t > 0$); đặt $t = \\log_a x$ ($t \\in \\mathbb{R}$).</p>
            <p><strong>3. Lôgarit hoá / Mũ hoá:</strong> Áp dụng khi hai vế có các cơ số khác nhau.</p>
            <p><strong>4. Quy tắc giải bất phương trình:</strong></p>
            <p>Khi $a > 1$: Giữ nguyên chiều bất đẳng thức.</p>
            <p>Khi $0 < a < 1$: ĐỔI CHIỀU bất đẳng thức ($a^{f(x)} > a^{g(x)} \\iff f(x) < g(x)$).</p>
          </div>
        `,
        formulas: [
          'a^{f(x)} = b \\iff f(x) = \\log_a b \\quad (b > 0)',
          '\\log_a f(x) = b \\iff f(x) = a^b',
          '\\log_a f(x) > \\log_a g(x) \\iff \\begin{cases} f(x) > g(x) > 0 & (a > 1) \\\\ 0 < f(x) < g(x) & (0 < a < 1) \\end{cases}'
        ],
        keyNotes: [
          'Bắt buộc đặt ĐIỀU KIỆN XÁC ĐỊNH cho biểu thức dưới dấu logarit trước khi biến đổi phương trình.',
          'Khi đặt ẩn phụ $t = a^x$, luôn nhớ điều kiện tiên quyết $t > 0$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CH6-B21',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-rev6',
        title: 'Bài tập cuối chương VI.',
        grade: 11,
        chapterIndex: 6,
        chapterTitle: 'CHƯƠNG VI. HÀM SỐ MŨ VÀ HÀM SỐ LÔGARIT.',
        theoryHtml: `
          <p>Hệ thống hoá kiến thức Mũ & Lôgarit và các dạng toán nâng cao:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Rút gọn biểu thức luỹ thừa và lôgarit chứa tham số.</li>
            <li>Tìm tập xác định của hàm số chứa căn thức và biểu thức lôgarit đồng thời.</li>
            <li>Giải phương trình mũ - lôgarit bằng phương pháp hàm số (tính đơn điệu $f(u) = f(v) \\implies u = v$).</li>
            <li>Ứng dụng mô hình hàm mũ trong thực tế: Tăng trưởng vi khuẩn, đồng vị phóng xạ cacbon-14, độ pH, mức cường độ âm decibel.</li>
          </ul>
        `,
        formulas: [
          'N(t) = N_0 \\cdot e^{kt} \\quad (\\text{Quy luật tăng trưởng / phân rã})',
          'L = 10 \\lg\\left(\\frac{I}{I_0}\\right) \\quad (\\text{Mức cường độ âm dB})',
          '\\text{pH} = -\\log[H^+]'
        ],
        keyNotes: [
          'Phương pháp hàm số: Nếu hàm số $f$ luôn đồng biến (hoặc nghịch biến) trên khoảng $K$ thì phương trình $f(u) = f(v)$ có nghiệm duy nhất $u = v$.',
          'Cẩn thận với phép biến đổi $\\log_a x^2 = 2\\log_a |x|$ (phải có dấu trị tuyệt đối nếu chưa biết dấu của $x$).'
        ],
        diagramType: 'rational',
        diagramParams: { a: 2, b: 0, c: 0, d: 1 },
        sgkRef: '11-CH6-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG VII. QUAN HỆ VUÔNG GÓC TRONG KHÔNG GIAN
  // =========================================================================
  {
    title: 'CHƯƠNG VII. QUAN HỆ VUÔNG GÓC TRONG KHÔNG GIAN.',
    grade: 11,
    lessons: [
      {
        id: '11-22',
        title: 'Bài 22. Hai đường thẳng vuông góc.',
        grade: 11,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. QUAN HỆ VUÔNG GÓC TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Góc giữa hai đường thẳng $a$ và $b$ trong không gian là góc giữa hai đường thẳng $a'$ và $b'$ cùng đi qua một điểm và lần lượt song song với $a$ và $b$ ($0^\\circ \\le \\varphi \\le 90^\\circ$).</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Vectơ chỉ phương của đường thẳng:</strong> Vectơ $\\vec{u} \\ne \\vec{0}$ có giá song song hoặc trùng với đường thẳng.</p>
            <p><strong>2. Góc giữa hai vectơ và góc giữa hai đường thẳng:</strong></p>
            <p>$$\\cos(a, b) = |\\cos(\\vec{u}, \\vec{v})| = \\frac{|\\vec{u} \\cdot \\vec{v}|}{|\\vec{u}| \\cdot |\\vec{v}|}$$</p>
            <p><strong>3. Hai đường thẳng vuông góc:</strong> $a \\perp b \\iff (a, b) = 90^\\circ \\iff \\vec{u} \\cdot \\vec{v} = 0$.</p>
          </div>
        `,
        formulas: [
          '\\cos(a, b) = \\frac{|\\vec{u} \\cdot \\vec{v}|}{|\\vec{u}| \\cdot |\\vec{v}|}',
          'a \\perp b \\iff \\vec{u} \\cdot \\vec{v} = 0',
          'a \\parallel b \\text{ và } c \\perp a \\implies c \\perp b'
        ],
        keyNotes: [
          'Hai đường thẳng vuông góc trong không gian CÓ THỂ CẮT NHAU HOẶC CHÉO NHAU.',
          'Góc giữa hai đường thẳng không bao giờ vượt quá $90^\\circ$, khác với góc giữa hai vectơ có thể tù (lên tới $180^\\circ$).'
        ],
        diagramType: 'pyramid',
        sgkRef: '11-CH7-B22',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-23',
        title: 'Bài 23. Đường thẳng vuông góc với mặt phẳng.',
        grade: 11,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. QUAN HỆ VUÔNG GÓC TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Đường thẳng $d$ vuông góc với mặt phẳng $(P)$ nếu $d$ vuông góc với mọi đường thẳng nằm trong $(P)$: $d \\perp (P)$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Dấu hiệu nhận biết:</strong> Nếu đường thẳng $d$ vuông góc với hai đường thẳng cắt nhau cùng nằm trong $(P)$ thì $d \\perp (P)$.</p>
            <p><strong>2. Tính chất then chốt:</strong> Nếu $d \\perp (P)$ thì $d \\perp a$ với mọi đường thẳng $a \\subset (P)$.</p>
            <p><strong>3. Định lý ba đường vuông góc:</strong> Cho đường thẳng $a$ nằm trong $(P)$ và đường thẳng $d$ không vuông góc với $(P)$, có hình chiếu $d'$ trên $(P)$. Khi đó $a \\perp d \\iff a \\perp d'$.</p>
          </div>
        `,
        formulas: [
          'd \\perp a, \\, d \\perp b, \\, a, b \\subset (P), \\, a \\cap b = O \\implies d \\perp (P)',
          'd \\perp (P) \\implies d \\perp c \\quad (\\forall c \\subset (P))',
          'a \\subset (P), \\, a \\perp d \\iff a \\perp d\' \\quad (\\text{Định lý 3 đường vuông góc})'
        ],
        keyNotes: [
          'Để chứng minh hai đường thẳng vuông góc: chứng minh đường này vuông góc với mặt phẳng chứa đường kia.',
          'Trục đường tròn ngoại tiếp đa giác đáy là đường thẳng vuông góc với mặt phẳng đáy tại tâm đường tròn ngoại tiếp.'
        ],
        diagramType: 'pyramid',
        sgkRef: '11-CH7-B23',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-24',
        title: 'Bài 24. Phép chiếu vuông góc. Góc giữa đường thẳng và mặt phẳng.',
        grade: 11,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. QUAN HỆ VUÔNG GÓC TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Phép chiếu vuông góc lên mặt phẳng $(P)$ là phép chiếu song song theo phương vuông góc với $(P)$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Định nghĩa góc giữa đường thẳng và mặt phẳng:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Nếu $d \\perp (P)$ thì góc giữa $d$ và $(P)$ bằng $90^\\circ$.</li>
              <li>Nếu $d$ không vuông góc với $(P)$ thì góc giữa $d$ và $(P)$ là góc giữa $d$ và hình chiếu $d'$ của nó lên $(P)$ ($0^\\circ \\le \\varphi \\le 90^\\circ$).</li>
            </ul>
            <p><strong>2. Quy trình xác định góc $(d, (P))$:</strong></p>
            <p>Bước 1: Tìm giao điểm $A = d \\cap (P)$.</p>
            <p>Bước 2: Chọn điểm $S \\in d$ ($S \\ne A$), dựng $SH \\perp (P)$ tại $H$.</p>
            <p>Bước 3: Nối $AH$, góc cần tìm chính là góc $\\widehat{SAH}$.</p>
          </div>
        `,
        formulas: [
          '\\sin(d, (P)) = \\frac{SH}{SA} = \\frac{d(S, (P))}{SA}',
          '\\cos(d, (P)) = \\frac{|\\vec{u} \\cdot \\vec{n}|}{|\\vec{u}| \\cdot |\\vec{n}|}'
        ],
        keyNotes: [
          'Đỉnh của góc luôn là GIAO ĐIỂM của đường thẳng với mặt phẳng.',
          'Góc giữa cạnh bên của hình chóp đều với mặt đáy luôn bằng nhau đối với tất cả các cạnh bên.'
        ],
        diagramType: 'pyramid',
        sgkRef: '11-CH7-B24',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-25',
        title: 'Bài 25. Hai mặt phẳng vuông góc.',
        grade: 11,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. QUAN HỆ VUÔNG GÓC TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Hai mặt phẳng gọi là vuông góc với nhau nếu góc giữa chúng bằng $90^\\circ$: $(P) \\perp (Q)$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Dấu hiệu nhận biết:</strong> Nếu mặt phẳng $(P)$ chứa một đường thẳng vuông góc với mặt phẳng $(Q)$ thì $(P) \\perp (Q)$.</p>
            <p><strong>2. Các tính chất quan trọng:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Nếu hai mặt phẳng vuông góc với nhau thì bất kỳ đường thẳng nào nằm trong mặt phẳng này và vuông góc với giao tuyến thì vuông góc với mặt phẳng kia.</li>
              <li>Nếu hai mặt phẳng cắt nhau cùng vuông góc với mặt phẳng thứ ba thì giao tuyến của chúng vuông góc với mặt phẳng thứ ba đó.</li>
            </ul>
            <p><strong>3. Góc giữa hai mặt phẳng:</strong> Là góc giữa hai đường thẳng lần lượt nằm trong hai mặt phẳng và cùng vuông góc với giao tuyến tại một điểm.</p>
          </div>
        `,
        formulas: [
          'd \\subset (P), \\, d \\perp (Q) \\implies (P) \\perp (Q)',
          '(P) \\perp (Q), \\, (P) \\cap (Q) = c, \\, d \\subset (P), \\, d \\perp c \\implies d \\perp (Q)',
          '(P) \\perp (R), \\, (Q) \\perp (R), \\, (P) \\cap (Q) = d \\implies d \\perp (R)'
        ],
        keyNotes: [
          "Diện tích hình chiếu: $S' = S \\cdot \\cos\\varphi$, trong đó $\\varphi$ là góc giữa mặt phẳng chứa hình ban đầu và mặt phẳng chiếu.",
          'Cách dựng góc giữa 2 mặt phẳng: Từ chân đường cao dựng vuông góc tới giao tuyến, rồi nối đỉnh xuống điểm đó.'
        ],
        diagramType: 'pyramid',
        sgkRef: '11-CH7-B25',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-26',
        title: 'Bài 26. Khoảng cách.',
        grade: 11,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. QUAN HỆ VUÔNG GÓC TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Hệ thống toàn diện các bài toán khoảng cách trong không gian:</p>
          <div class="space-y-2 mt-2">
            <p><strong>1. Khoảng cách từ điểm $M$ đến mặt phẳng $(P)$:</strong></p>
            <p>Hạ $MH \\perp (P) \\implies d(M, (P)) = MH$.</p>
            <p><em>Quy tắc chuyển điểm:</em> Nếu $AB$ cắt $(P)$ tại $I$ thì $\\frac{d(A, (P))}{d(B, (P))} = \\frac{IA}{IB}$. Luôn chuyển khoảng cách về CHÂN ĐƯỜNG CAO.</p>
            <p><strong>2. Khoảng cách giữa hai đường thẳng chéo nhau $a$ và $b$:</strong></p>
            <p>Dựng mặt phẳng $(P)$ chứa $b$ và song song với $a \\implies d(a, b) = d(a, (P)) = d(M, (P))$ với $M \\in a$.</p>
            <p><strong>3. Đoạn vuông góc chung:</strong> Đoạn thẳng nối hai điểm trên hai đường chéo nhau và vuông góc với cả hai đường.</p>
          </div>
        `,
        formulas: [
          '\\frac{d(A, (P))}{d(B, (P))} = \\frac{IA}{IB} \\quad (AB \\cap (P) = I)',
          'd(a, b) = d(a, (P)) = d(M, (P)) \\quad (b \\subset (P), \\, a \\parallel (P))',
          '\\frac{1}{h^2} = \\frac{1}{a^2} + \\frac{1}{b^2} + \\frac{1}{c^2} \\quad (\\text{Tứ diện vuông đỉnh } O)'
        ],
        keyNotes: [
          'Chân đường cao là "điểm vàng" trong mọi bài toán khoảng cách. Mọi khoảng cách khó đều nên quy về chân đường cao.',
          'Dùng thể tích: $d(A, (BCD)) = \\frac{3V_{ABCD}}{S_{\\Delta BCD}}$.'
        ],
        diagramType: 'pyramid',
        sgkRef: '11-CH7-B26',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-27',
        title: 'Bài 27. Thể tích.',
        grade: 11,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. QUAN HỆ VUÔNG GÓC TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Thể tích các khối đa diện cơ bản trong không gian:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Khối chóp:</strong> $V = \\frac{1}{3} S_{\\text{đáy}} \\cdot h$.</p>
            <p><strong>2. Khối lăng trụ:</strong> $V = S_{\\text{đáy}} \\cdot h$.</p>
            <p><strong>3. Khối hộp chữ nhật:</strong> $V = a \\cdot b \\cdot c$; Khối lập phương: $V = a^3$.</p>
            <p><strong>4. Khối chóp cụt:</strong> $V = \\frac{1}{3} h (S_1 + S_2 + \\sqrt{S_1 S_2})$.</p>
            <p><strong>5. Tỉ số thể tích khối chóp tam giác (Simson):</strong> Cho chóp $S.ABC$, $A' \\in SA, B' \\in SB, C' \\in SC$:
              $$\\frac{V_{S.A'B'C'}}{V_{S.ABC}} = \\frac{SA'}{SA} \\cdot \\frac{SB'}{SB} \\cdot \\frac{SC'}{SC}$$
            </p>
          </div>
        `,
        formulas: [
          'V_{\\text{chóp}} = \\frac{1}{3} S \\cdot h, \\quad V_{\\text{lăng trụ}} = S \\cdot h',
          'V_{\\text{hộp}} = abc, \\quad V_{\\text{lập phương}} = a^3',
          '\\frac{V_{S.A\'B\'C\'}}{V_{S.ABC}} = \\frac{SA\'}{SA} \\cdot \\frac{SB\'}{SB} \\cdot \\frac{SC\'}{SC}'
        ],
        keyNotes: [
          'Công thức tỉ số thể tích Simson CHỈ ÁP DỤNG ĐƯỢC CHO HÌNH CHÓP TAM GIÁC (đáy tam giác). Với đáy tứ giác phải chia thành hai tam giác trước khi tính tỉ số.',
          'Thể tích tứ diện vuông đỉnh $O$: $V = \\frac{1}{6} OA \\cdot OB \\cdot OC$.'
        ],
        diagramType: 'prism',
        sgkRef: '11-CH7-B27',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-rev7',
        title: 'Bài tập cuối chương VII.',
        grade: 11,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. QUAN HỆ VUÔNG GÓC TRONG KHÔNG GIAN.',
        theoryHtml: `
          <p>Tổng kết chuyên đề Hình học không gian vuông góc lớp 11:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Kỹ thuật xác định chân đường cao của hình chóp (chóp đều, chóp có cạnh bên vuông góc đáy, chóp có mặt bên vuông góc đáy).</li>
            <li>Tính góc giữa đường thẳng và mặt phẳng, góc giữa hai mặt phẳng.</li>
            <li>Tính khoảng cách từ điểm đến mặt phẳng và khoảng cách giữa hai đường thẳng chéo nhau.</li>
            <li>Tính diện tích xung quanh, diện tích toàn phần và thể tích khối đa diện.</li>
          </ul>
        `,
        formulas: [
          '\\cos \\varphi = \\frac{|\\vec{n}_1 \\cdot \\vec{n}_2|}{|\\vec{n}_1| \\cdot |\\vec{n}_2|} \\quad (\\text{Góc giữa 2 mặt phẳng})',
          'd(a, b) = \\frac{|[\\vec{u}_1, \\vec{u}_2] \\cdot \\vec{M_1 M_2}|}{|[\\vec{u}_1, \\vec{u}_2]|}'
        ],
        keyNotes: [
          'Hình chóp có mặt bên $(SAB) \\perp$ đáy: chân đường cao của hình chóp chính là chân đường cao kẻ từ đỉnh $S$ xuống giao tuyến $AB$.',
          'Hình chóp có tất cả các cạnh bên bằng nhau: chân đường cao là tâm đường tròn ngoại tiếp của đa giác đáy.'
        ],
        diagramType: 'pyramid',
        sgkRef: '11-CH7-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG VIII. CÁC QUY TẮC TÍNH XÁC SUẤT
  // =========================================================================
  {
    title: 'CHƯƠNG VIII. CÁC QUY TẮC TÍNH XÁC SUẤT.',
    grade: 11,
    lessons: [
      {
        id: '11-28',
        title: 'Bài 28. Biến cố hợp, biến cố giao, biến cố độc lập.',
        grade: 11,
        chapterIndex: 8,
        chapterTitle: 'CHƯƠNG VIII. CÁC QUY TẮC TÍNH XÁC SUẤT.',
        theoryHtml: `
          <p>Mở rộng các khái niệm biến cố và mối quan hệ giữa các biến cố trong phép thử ngẫu nhiên:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li><strong>Biến cố hợp $A \\cup B$:</strong> Xảy ra khi có ít nhất một trong hai biến cố $A$ hoặc $B$ xảy ra.</li>
            <li><strong>Biến cố giao $A \\cap B$ (hay $AB$):</strong> Xảy ra khi cả hai biến cố $A$ và $B$ đồng thời xảy ra.</li>
            <li><strong>Biến cố xung khắc:</strong> $A \\cap B = \\emptyset$ (hai biến cố không thể đồng thời cùng xảy ra).</li>
            <li><strong>Biến cố độc lập:</strong> Hai biến cố $A$ và $B$ được gọi là độc lập nếu việc xảy ra hay không xảy ra của biến cố này không ảnh hưởng tới xác suất xảy ra của biến cố kia: $P(AB) = P(A) \\cdot P(B)$.</li>
          </ul>
        `,
        formulas: [
          'A \\cap B = \\emptyset \\implies A, B \\text{ xung khắc}',
          'P(AB) = P(A) \\cdot P(B) \\iff A, B \\text{ độc lập}',
          '\\overline{A \\cup B} = \\overline{A} \\cap \\overline{B}, \\quad \\overline{A \\cap B} = \\overline{A} \\cup \\overline{B}'
        ],
        keyNotes: [
          'Phân biệt rõ: Xung khắc là quan hệ về TẬP HỢP ($A \\cap B = \\emptyset$), Độc lập là quan hệ về XÁC SUẤT ($P(AB) = P(A)P(B)$).',
          'Hai biến cố cùng có xác suất dương và xung khắc nhau thì không thể độc lập nhau.'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CH8-B28',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-29',
        title: 'Bài 29. Công thức cộng xác suất.',
        grade: 11,
        chapterIndex: 8,
        chapterTitle: 'CHƯƠNG VIII. CÁC QUY TẮC TÍNH XÁC SUẤT.',
        theoryHtml: `
          <p>Hệ thống quy tắc cộng xác suất cho biến cố hợp:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Công thức cộng tổng quát:</strong></p>
            <p>$$P(A \\cup B) = P(A) + P(B) - P(A \\cap B)$$</p>
            <p><strong>2. Khi $A$ và $B$ xung khắc ($A \\cap B = \\emptyset$):</strong></p>
            <p>$$P(A \\cup B) = P(A) + P(B)$$</p>
            <p><strong>3. Công thức biến cố đối:</strong></p>
            <p>$$P(\\overline{A}) = 1 - P(A)$$</p>
            <p>Mở rộng cho 3 biến cố xung khắc đôi một: $P(A \\cup B \\cup C) = P(A) + P(B) + P(C)$.</p>
          </div>
        `,
        formulas: [
          'P(A \\cup B) = P(A) + P(B) - P(AB)',
          'P(A \\cup B) = P(A) + P(B) \\quad (A \\cap B = \\emptyset)',
          'P(\\overline{A}) = 1 - P(A)'
        ],
        keyNotes: [
          'Khi đề bài hỏi xác suất để "có ít nhất một...", luôn nghĩ đến việc tính xác suất biến cố đối "không có cái nào".',
          'Tổng xác suất của một nhóm biến cố tạo thành một hệ đầy đủ luôn bằng $1$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CH8-B29',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-30',
        title: 'Bài 30. Công thức nhân xác suất cho hai biến cố độc lập.',
        grade: 11,
        chapterIndex: 8,
        chapterTitle: 'CHƯƠNG VIII. CÁC QUY TẮC TÍNH XÁC SUẤT.',
        theoryHtml: `
          <p>Quy tắc nhân xác suất khi hai biến cố không phụ thuộc lẫn nhau:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Định lý nhân xác suất:</strong></p>
            <p>Nếu hai biến cố $A$ và $B$ độc lập thì:</p>
            <p>$$P(A \\cap B) = P(A) \\cdot P(B)$$</p>
            <p><strong>2. Tính chất:</strong> Nếu $A$ và $B$ độc lập thì các cặp biến cố sau cũng độc lập:</p>
            <p>$\\overline{A}$ và $B$; $\\quad A$ và $\\overline{B}$; $\\quad \\overline{A}$ và $\\overline{B}$.</p>
            <p><strong>3. Xác suất có ít nhất một trong hai biến cố xảy ra:</strong></p>
            <p>$$P(A \\cup B) = 1 - P(\\overline{A} \\cap \\overline{B}) = 1 - P(\\overline{A}) \\cdot P(\\overline{B})$$</p>
          </div>
        `,
        formulas: [
          'P(AB) = P(A) \\cdot P(B) \\quad (A, B \\text{ độc lập})',
          'P(\\overline{A} \\cdot \\overline{B}) = P(\\overline{A}) \\cdot P(\\overline{B}) = [1 - P(A)][1 - P(B)]',
          'P(A_1 A_2 \\dots A_n) = P(A_1)P(A_2)\\dots P(A_n) \\quad (\\text{Độc lập toàn phần})'
        ],
        keyNotes: [
          'Ví dụ kinh điển: Hai người bắn độc lập vào một bia mục tiêu; tung đồng xu nhiều lần liên tiếp.',
          'Khi tính xác suất "bia bị trúng đạn": tính qua biến cố đối "cả hai người đều bắn trượt".'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CH8-B30',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-rev8',
        title: 'Bài tập cuối chương VIII.',
        grade: 11,
        chapterIndex: 8,
        chapterTitle: 'CHƯƠNG VIII. CÁC QUY TẮC TÍNH XÁC SUẤT.',
        theoryHtml: `
          <p>Luyện tập tổng hợp các quy tắc tính xác suất trong kỳ thi THPT:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Sử dụng sơ đồ hình cây để phân tích không gian mẫu và chuỗi các hành động liên tiếp.</li>
            <li>Kết hợp linh hoạt quy tắc cộng và quy tắc nhân để giải bài toán xác suất thực tế.</li>
            <li>Tính xác suất trong các mô hình kiểm tra y tế, tỷ lệ sản phẩm đạt tiêu chuẩn, độ tin cậy của hệ thống mạng.</li>
          </ul>
        `,
        formulas: [
          'P(A \\cup B) = P(A) + P(B) - P(A)P(B) \\quad (A, B \\text{ độc lập})',
          'P(\\text{ít nhất một}) = 1 - P(\\text{không có cái nào})'
        ],
        keyNotes: [
          'Đọc kĩ đề để nhận biết biến cố độc lập (lấy có hoàn lại, hai người làm độc lập) hay phụ thuộc (lấy không hoàn lại).',
          'Trình bày bài giải rõ ràng các bước: gọi tên biến cố, chỉ ra tính xung khắc hay độc lập, rồi mới áp dụng công thức.'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CH8-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG IX. ĐẠO HÀM
  // =========================================================================
  {
    title: 'CHƯƠNG IX. ĐẠO HÀM.',
    grade: 11,
    lessons: [
      {
        id: '11-31',
        title: 'Bài 31. Định nghĩa và ý nghĩa của đạo hàm.',
        grade: 11,
        chapterIndex: 9,
        chapterTitle: 'CHƯƠNG IX. ĐẠO HÀM.',
        theoryHtml: `
          <p>Đạo hàm của hàm số $y = f(x)$ tại điểm $x_0$:</p>
          $$f'(x_0) = \\lim_{x \\to x_0} \\frac{f(x) - f(x_0)}{x - x_0} = \\lim_{\\Delta x \\to 0} \\frac{\\Delta y}{\\Delta x}$$
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Ý nghĩa hình học của đạo hàm:</strong></p>
            <p>$f'(x_0)$ là hệ số góc $k$ của tiếp tuyến của đồ thị hàm số tại tiếp điểm $M(x_0; f(x_0))$.</p>
            <p>Phương trình tiếp tuyến: $y = f'(x_0)(x - x_0) + f(x_0)$.</p>
            <p><strong>2. Ý nghĩa vật lý của đạo hàm:</strong></p>
            <p>Vận tốc tức thời của chuyển động có phương trình $s(t)$ tại thời điểm $t_0$ là $v(t_0) = s'(t_0)$.</p>
            <p>Cường độ dòng điện tức thời: $i(t) = q'(t)$.</p>
          </div>
        `,
        formulas: [
          'f\'(x_0) = \\lim_{\\Delta x \\to 0} \\frac{f(x_0 + \\Delta x) - f(x_0)}{\\Delta x}',
          'y = f\'(x_0)(x - x_0) + y_0 \\quad (\\text{Phương trình tiếp tuyến})',
          'v(t) = s\'(t)'
        ],
        keyNotes: [
          'Nếu tiếp tuyến song song với đường thẳng $y = ax + b$ thì hệ số góc $f\'(x_0) = a$.',
          'Nếu tiếp tuyến vuông góc với đường thẳng $y = ax + b$ ($a \\ne 0$) thì hệ số góc $f\'(x_0) = -\\frac{1}{a}$.',
          'Hàm số có đạo hàm tại $x_0$ thì chắc chắn liên tục tại $x_0$; điều ngược lại chưa chắc đúng.'
        ],
        diagramType: 'cubic',
        diagramParams: { a: 1, b: 0, c: -3, d: 2 },
        sgkRef: '11-CH9-B31',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-32',
        title: 'Bài 32. Các quy tắc tính đạo hàm.',
        grade: 11,
        chapterIndex: 9,
        chapterTitle: 'CHƯƠNG IX. ĐẠO HÀM.',
        theoryHtml: `
          <p>Bảng đạo hàm các hàm số sơ cấp cơ bản và hàm hợp $u = u(x)$:</p>
          <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs mt-2">
            <div class="p-2 bg-slate-50 rounded border">
              <p class="font-bold text-teal-800">Hàm cơ bản:</p>
              <p>$(x^\\alpha)' = \\alpha x^{\\alpha-1}$</p>
              <p>$(\\sqrt{x})' = \\frac{1}{2\\sqrt{x}}$</p>
              <p>$(\\sin x)' = \\cos x, \\, (\\cos x)' = -\\sin x$</p>
              <p>$(\\tan x)' = \\frac{1}{\\cos^2 x}, \\, (\\cot x)' = -\\frac{1}{\\sin^2 x}$</p>
              <p>$(e^x)' = e^x, \\, (a^x)' = a^x \\ln a$</p>
              <p>$(\\ln x)' = \\frac{1}{x}, \\, (\\log_a x)' = \\frac{1}{x \\ln a}$</p>
            </div>
            <div class="p-2 bg-slate-50 rounded border">
              <p class="font-bold text-teal-800">Hàm hợp $u(x)$:</p>
              <p>$(u^\\alpha)' = \\alpha u^{\\alpha-1} \\cdot u'$</p>
              <p>$(\\sqrt{u})' = \\frac{u'}{2\\sqrt{u}}$</p>
              <p>$(\\sin u)' = u' \\cdot \\cos u$</p>
              <p>$(\\cos u)' = -u' \\cdot \\sin u$</p>
              <p>$(e^u)' = u' \\cdot e^u, \\, (a^u)' = u' \\cdot a^u \\ln a$</p>
              <p>$(\\ln u)' = \\frac{u'}{u}, \\, (\\log_a u)' = \\frac{u'}{u \\ln a}$</p>
            </div>
          </div>
          <p class="mt-2 text-xs font-semibold">Quy tắc đại số: $(u \\pm v)' = u' \\pm v'$, $(uv)' = u'v + uv'$, $\\left(\\frac{u}{v}\\right)' = \\frac{u'v - uv'}{v^2}$.</p>
        `,
        formulas: [
          '(uv)\' = u\'v + uv\', \\quad \\left(\\frac{u}{v}\\right)\' = \\frac{u\'v - uv\'}{v^2}',
          '(f(u))\' = f\'(u) \\cdot u\'(x)',
          '\\left(\\frac{ax+b}{cx+d}\\right)\' = \\frac{ad - bc}{(cx+d)^2}'
        ],
        keyNotes: [
          'Đạo hàm phân thức bậc nhất: tử số là định thức $ad - bc$, mẫu là bình phương $(cx+d)^2$.',
          'Đạo hàm hàm hợp luôn nhớ nhân với $u\'(x)$, đây là sai sót phổ biến nhất của học sinh.'
        ],
        diagramType: 'cubic',
        diagramParams: { a: 1, b: 0, c: -3, d: 2 },
        sgkRef: '11-CH9-B32',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-33',
        title: 'Bài 33. Đạo hàm cấp hai.',
        grade: 11,
        chapterIndex: 9,
        chapterTitle: 'CHƯƠNG IX. ĐẠO HÀM.',
        theoryHtml: `
          <p>Đạo hàm cấp hai của hàm số $y = f(x)$ là đạo hàm của đạo hàm cấp một: $f''(x) = [f'(x)]'$. Kí hiệu là $y''$ hoặc $f''(x)$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Ý nghĩa cơ học:</strong> Gia tốc tức thời của chuyển động thẳng có phương trình $s(t)$ tại thời điểm $t$ là đạo hàm cấp hai của quãng đường:</p>
            <p>$$a(t) = v'(t) = s''(t)$$</p>
            <p><strong>2. Định luật II Newton:</strong> $F = m \\cdot a = m \\cdot s''(t)$.</p>
            <p><strong>3. Điểm uốn và bề lõm của đồ thị:</strong> Nếu $f''(x) > 0$ trên khoảng $K$ thì đồ thị lồi về phía dưới (lõm lên); nếu $f''(x) < 0$ thì đồ thị lồi về phía trên.</p>
          </div>
        `,
        formulas: [
          'f\'\'(x) = [f\'(x)]\'',
          'a(t) = s\'\'(t) \\quad (\\text{Gia tốc tức thời})',
          'F(t) = m \\cdot s\'\'(t)'
        ],
        keyNotes: [
          'Để tính đạo hàm cấp hai: tính đạo hàm cấp một $f\'(x)$ rồi rút gọn tối đa trước khi tiếp tục lấy đạo hàm lần hai.',
          'Đạo hàm cấp hai là công cụ quan trọng để xác định điểm cực trị (Quy tắc 2: $f\'(x_0) = 0, f\'\'(x_0) > 0 \\implies$ cực tiểu).'
        ],
        diagramType: 'cubic',
        diagramParams: { a: 1, b: 0, c: -3, d: 2 },
        sgkRef: '11-CH9-B33',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-rev9',
        title: 'Bài tập cuối chương IX.',
        grade: 11,
        chapterIndex: 9,
        chapterTitle: 'CHƯƠNG IX. ĐẠO HÀM.',
        theoryHtml: `
          <p>Tổng kết chuyên đề Đạo hàm chuẩn bị cho chương trình Giải tích lớp 12:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Kỹ thuật tính đạo hàm hàm hợp phức tạp chứa đa thức, căn thức và lượng giác.</li>
            <li>Các bài toán viết phương trình tiếp tuyến: tại điểm, đi qua điểm, và biết hệ số góc $k$.</li>
            <li>Giải phương trình, bất phương trình chứa đạo hàm $f'(x) = 0$, $f'(x) > 0$.</li>
            <li>Bài toán chuyển động vật lý tính vận tốc lớn nhất, gia tốc tại thời điểm dừng lại.</li>
          </ul>
        `,
        formulas: [
          'y = f\'(x_0)(x - x_0) + y_0 \\quad (\\text{Tiếp tuyến tại tiếp điểm})',
          'v(t) = 0 \\iff \\text{vật đổi chiều chuyển động hoặc dừng lại}',
          'a(t) = s\'\'(t)'
        ],
        keyNotes: [
          'Bài toán tiếp tuyến đi qua điểm $A(x_A; y_A)$: Viết phương trình tiếp tuyến tại $M(x_0; y_0)$ rồi cho điểm $A$ thuộc tiếp tuyến để giải tìm $x_0$.',
          'Đạo hàm là nền tảng sống còn của toàn bộ học kỳ I Toán 12 (khảo sát hàm số, cực trị, GTLN, GTNN).'
        ],
        diagramType: 'cubic',
        diagramParams: { a: 1, b: 0, c: -3, d: 2 },
        sgkRef: '11-CH9-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM (HỌC KÌ II)
  // =========================================================================
  {
    title: 'HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM (HỌC KÌ II).',
    grade: 11,
    lessons: [
      {
        id: '11-exp3',
        title: 'Một vài mô hình toán học đơn giản giải quyết bài toán tối ưu.',
        grade: 11,
        chapterIndex: 10,
        chapterTitle: 'HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM (HỌC KÌ II).',
        theoryHtml: `
          <p>Mô hình hoá toán học để tối ưu hoá chi phí, diện tích, thể tích và lợi nhuận:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Quy trình giải bài toán tối ưu thực tế:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Bước 1: Chọn biến số thích hợp và tìm tập xác định thực tế của biến.</li>
              <li>Bước 2: Thiết lập hàm mục tiêu $f(x)$ đại diện cho đại lượng cần tối ưu (chi phí min, diện tích max, thể tích max).</li>
              <li>Bước 3: Sử dụng đạo hàm $f'(x) = 0$ hoặc bất đẳng thức AM-GM (Cauchy) để tìm điểm tối ưu $x_0$.</li>
              <li>Bước 4: Kiểm tra điều kiện và kết luận ý nghĩa thực tiễn.</li>
            </ul>
            <p><strong>2. Ví dụ kinh điển:</strong> Làm hộp không nắp có thể tích lớn nhất từ tấm tôn hình vuông, làm thùng phuy hình trụ tốn ít nguyên liệu nhất.</p>
          </div>
        `,
        formulas: [
          'V(x) = x(a - 2x)^2 \\quad (\\text{Hộp làm từ tấm tôn cạnh } a)',
          'S_{\\text{tp}}(r) = 2\\pi r^2 + \\frac{2V}{r} \\quad (\\text{Hình trụ có thể tích } V)',
          'f\'(x) = 0 \\implies x_0 \\text{ là điểm cực trị tối ưu}'
        ],
        keyNotes: [
          'Luôn chú ý điều kiện hình học và thực tiễn của biến số (ví dụ $0 < x < a/2$).',
          'Đạo hàm là công cụ tổng quát mạnh nhất để tìm giá trị tối ưu của bất kỳ hàm số khả vi nào.'
        ],
        diagramType: 'appliedMaxMin',
        sgkRef: '11-EXP-OPT',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-exp4',
        title: 'Vẽ hình không gian với phần mềm GeoGebra.',
        grade: 11,
        chapterIndex: 10,
        chapterTitle: 'HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM (HỌC KÌ II).',
        theoryHtml: `
          <p>Ứng dụng công nghệ thông tin trong trực quan hoá hình học không gian 3D:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Giao diện GeoGebra 3D Calculator:</strong> Trục toạ độ $Oxyz$, mặt phẳng toạ độ, công cụ dựng điểm, đường thẳng, mặt phẳng.</p>
            <p><strong>2. Các lệnh dựng hình cơ bản:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Dựng hình chóp: <code>Pyramid(A, B, C, D, h)</code> hoặc chọn đáy và đỉnh.</li>
              <li>Dựng hình lăng trụ, hình hộp chữ nhật, hình lập phương.</li>
              <li>Dựng mặt phẳng đi qua 3 điểm, mặt phẳng qua điểm vuông góc với đường thẳng.</li>
              <li>Dựng giao tuyến của hai mặt phẳng và mặt phẳng cắt khối đa diện tạo thiết diện.</li>
            </ul>
            <p><strong>3. Đo đạc góc và khoảng cách:</strong> Công cụ <code>Angle</code> (đo góc) và <code>Distance</code> (đo khoảng cách).</p>
          </div>
        `,
        formulas: [
          '\\text{GeoGebra 3D: Dựng toạ độ } M(x, y, z)',
          '\\text{Lệnh } \\text{Plane}(A, B, C) \\text{ xác định mặt phẳng } (ABC)'
        ],
        keyNotes: [
          'Khả năng xoay không gian 3D giúp học sinh dễ dàng phát hiện các đường vuông góc và hình dung thiết diện bị khuất.',
          'Hỗ trợ đắc lực trong việc kiểm tra lại kết quả tính góc và khoảng cách trong các bài toán hình học.'
        ],
        diagramType: 'prism',
        sgkRef: '11-EXP-GEOGEBRA',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHUYÊN ĐỀ 1. PHÉP BIẾN HÌNH TRONG MẶT PHẲNG
  // =========================================================================
  {
    title: 'CHUYÊN ĐỀ 1. PHÉP BIẾN HÌNH TRONG MẶT PHẲNG.',
    grade: 11,
    lessons: [
      {
        id: '11-cd1-b1',
        title: 'Bài 1. Phép dời hình và phép đồng dạng.',
        grade: 11,
        chapterIndex: 11,
        chapterTitle: 'CHUYÊN ĐỀ 1. PHÉP BIẾN HÌNH TRONG MẶT PHẲNG.',
        theoryHtml: `
          <p>Phép biến hình là quy tắc đặt tương ứng mỗi điểm $M$ với một điểm $M'$ duy nhất trên mặt phẳng.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Phép dời hình:</strong> Là phép biến hình bảo toàn khoảng cách giữa hai điểm bất kỳ: $M'N' = MN$.</p>
            <p>Tính chất: Biến ba điểm thẳng hàng thành ba điểm thẳng hàng, bảo toàn góc, biến tam giác thành tam giác bằng nó, biến đường tròn bán kính $R$ thành đường tròn cùng bán kính $R$.</p>
            <p><strong>2. Phép đồng dạng tỉ số $k$ ($k > 0$):</strong> Là phép biến hình biến hai điểm $M, N$ thành $M', N'$ sao cho $M'N' = k \\cdot MN$.</p>
            <p>Tính chất: Biến tam giác thành tam giác đồng dạng với tỉ số $k$, biến đường tròn bán kính $R$ thành đường tròn bán kính $kR$.</p>
          </div>
        `,
        formulas: [
          'F(M) = M\', \\, F(N) = N\' \\implies M\'N\' = MN \\quad (\\text{Phép dời hình})',
          'M\'N\' = k \\cdot MN \\quad (k > 0, \\, \\text{Phép đồng dạng})'
        ],
        keyNotes: [
          'Phép dời hình là trường hợp đặc biệt của phép đồng dạng với tỉ số $k = 1$.',
          'Hợp thành của hai phép dời hình là một phép dời hình.'
        ],
        diagramType: 'circle',
        sgkRef: '11-CD1-B1',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-cd1-b2',
        title: 'Bài 2. Phép tịnh tiến, phép quay.',
        grade: 11,
        chapterIndex: 11,
        chapterTitle: 'CHUYÊN ĐỀ 1. PHÉP BIẾN HÌNH TRONG MẶT PHẲNG.',
        theoryHtml: `
          <p>Hai phép dời hình cơ bản thường gặp trong toán học và đời sống:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Phép tịnh tiến theo vectơ $\\vec{v}(a; b)$:</strong></p>
            <p>$T_{\\vec{v}}(M) = M' \\iff \\vec{MM'} = \\vec{v}$.</p>
            <p>Biểu thức toạ độ: $\\begin{cases} x' = x + a \\\\ y' = y + b \\end{cases}$.</p>
            <p><strong>2. Phép quay tâm $I$ góc quay $\\alpha$:</strong></p>
            <p>$Q_{(I, \\alpha)}(M) = M' \\iff IM' = IM$ và góc lượng giác $(IM, IM') = \\alpha$.</p>
            <p>Phép quay tâm gốc toạ độ $O(0; 0)$ góc $\\alpha$:</p>
            <p>$$\\begin{cases} x' = x\\cos\\alpha - y\\sin\\alpha \\\\ y' = x\\sin\\alpha + y\\cos\\alpha \\end{cases}$$</p>
          </div>
        `,
        formulas: [
          'T_{\\vec{v}}(M) = M\' \\iff \\begin{cases} x\' = x + a \\\\ y\' = y + b \\end{cases}',
          'Q_{(O, 90^\\circ)}(M) = M\' \\iff \\begin{cases} x\' = -y \\\\ y\' = x \\end{cases}',
          'Q_{(O, -90^\\circ)}(M) = M\' \\iff \\begin{cases} x\' = y \\\\ y\' = -x \\end{cases}',
          'Q_{(O, 180^\\circ)}(M) = M\' \\iff \\begin{cases} x\' = -x \\\\ y\' = -y \\end{cases} \\quad (\\text{Đối xứng tâm})'
        ],
        keyNotes: [
          'Phép tịnh tiến biến đường thẳng thành đường thẳng song song hoặc trùng với nó.',
          'Phép đối xứng tâm là phép quay góc $180^\\circ$.'
        ],
        diagramType: 'circle',
        sgkRef: '11-CD1-B2',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-cd1-b3',
        title: 'Bài 3. Phép vị tự.',
        grade: 11,
        chapterIndex: 11,
        chapterTitle: 'CHUYÊN ĐỀ 1. PHÉP BIẾN HÌNH TRONG MẶT PHẲNG.',
        theoryHtml: `
          <p>Cho điểm $I$ cố định và số thực $k \\ne 0$. Phép vị tự tâm $I$ tỉ số $k$, kí hiệu $V_{(I, k)}$, biến mỗi điểm $M$ thành $M'$ sao cho:</p>
          $$\\vec{IM'} = k \\cdot \\vec{IM}$$
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Biểu thức toạ độ với tâm $O(0; 0)$:</strong> $\\begin{cases} x' = kx \\\\ y' = ky \\end{cases}$.</p>
            <p><strong>2. Tính chất của phép vị tự tỉ số $k$:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Biến ba điểm thẳng hàng thành ba điểm thẳng hàng và bảo toàn thứ tự.</li>
              <li>Biến đường thẳng thành đường thẳng song song hoặc trùng với nó.</li>
              <li>Biến góc thành góc bằng nó.</li>
              <li>Biến đường tròn bán kính $R$ thành đường tròn có bán kính $|k| \\cdot R$.</li>
            </ul>
          </div>
        `,
        formulas: [
          'V_{(I, k)}(M) = M\' \\iff \\vec{IM\'} = k \\cdot \\vec{IM}',
          'M\'N\' = |k| \\cdot MN',
          'V_{(I, k)}((C(O; R))) = (C\'(O\'; |k|R)) \\text{ với } \\vec{IO\'} = k\\vec{IO}'
        ],
        keyNotes: [
          'Nếu $k = 1$: Phép đồng nhất. Nếu $k = -1$: Phép đối xứng tâm $I$.',
          'Phép vị tự là một phép đồng dạng với tỉ số đồng dạng bằng $|k|$.'
        ],
        diagramType: 'circle',
        sgkRef: '11-CD1-B3',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-cd1-rev',
        title: 'Bài tập cuối chuyên đề 1.',
        grade: 11,
        chapterIndex: 11,
        chapterTitle: 'CHUYÊN ĐỀ 1. PHÉP BIẾN HÌNH TRONG MẶT PHẲNG.',
        theoryHtml: `
          <p>Tổng kết chuyên đề Phép biến hình trong mặt phẳng và ứng dụng giải toán hình học phẳng:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Tìm ảnh của điểm, đường thẳng, đường tròn qua phép tịnh tiến, phép quay, phép vị tự.</li>
            <li>Dùng phép biến hình để giải bài toán quỹ tích và dựng hình.</li>
            <li>Ứng dụng phép vị tự và phép đồng dạng trong chứng minh các bài toán đồng quy, thẳng hàng nổi tiếng (đường thẳng Euler, đường tròn 9 điểm Euler).</li>
          </ul>
        `,
        formulas: [
          'T_{\\vec{v}}(\\Delta) = \\Delta\' \\implies \\Delta\' \\parallel \\Delta \\text{ hoặc } \\Delta\' \\equiv \\Delta',
          'V_{(I, k)}(\\Delta) = \\Delta\' \\implies \\Delta\' \\parallel \\Delta \\text{ hoặc } \\Delta\' \\equiv \\Delta'
        ],
        keyNotes: [
          'Để tìm ảnh của đường thẳng $\\Delta: ax + by + c = 0$ qua phép tịnh tiến $T_{\\vec{v}}$: đường thẳng ảnh có cùng vectơ pháp tuyến $\\Delta\': ax + by + c\' = 0$, lấy 1 điểm thuộc $\\Delta$ tìm ảnh rồi thay vào tìm $c\'$.',
          'Ảnh của đường tròn: tìm ảnh của tâm $I$, bán kính giữ nguyên (phép dời hình) hoặc nhân $|k|$ (phép vị tự).'
        ],
        diagramType: 'circle',
        sgkRef: '11-CD1-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHUYÊN ĐỀ 2. PHƯƠNG PHÁP QUY NẠP TOÁN HỌC VÀ DÃY SỐ
  // =========================================================================
  {
    title: 'CHUYÊN ĐỀ 2. PHƯƠNG PHÁP QUY NẠP TOÁN HỌC VÀ DÃY SỐ.',
    grade: 11,
    lessons: [
      {
        id: '11-cd2-b1',
        title: 'Bài 1. Phương pháp quy nạp toán học.',
        grade: 11,
        chapterIndex: 12,
        chapterTitle: 'CHUYÊN ĐỀ 2. PHƯƠNG PHÁP QUY NẠP TOÁN HỌC VÀ DÃY SỐ.',
        theoryHtml: `
          <p>Phương pháp quy nạp toán học dùng để chứng minh mệnh đề $P(n)$ đúng với mọi số nguyên dương $n \\ge p$:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>Quy trình chứng minh gồm hai bước bắt buộc:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li><strong>Bước 1 (Bước cơ sở):</strong> Kiểm tra mệnh đề $P(n)$ đúng với số nguyên nhỏ nhất $n = p$.</li>
              <li><strong>Bước 2 (Bước quy nạp):</strong> Giả sử mệnh đề đúng với một số tự nhiên bất kì $n = k \\ge p$ (gọi là giả thiết quy nạp). Chứng minh mệnh đề cũng đúng với $n = k + 1$.</li>
            </ul>
            <p><strong>Kết luận:</strong> Theo nguyên lí quy nạp toán học, mệnh đề $P(n)$ đúng với mọi số tự nhiên $n \\ge p$.</p>
          </div>
        `,
        formulas: [
          '1 + 2 + \\dots + n = \\frac{n(n + 1)}{2}',
          '1^2 + 2^2 + \\dots + n^2 = \\frac{n(n + 1)(2n + 1)}{6}',
          '1^3 + 2^3 + \\dots + n^3 = \\left[\\frac{n(n + 1)}{2}\\right]^2',
          '(1 + a)^n \\ge 1 + na \\quad (a > -1, n \\in \\mathbb{N}^* \\, - \\, \\text{BĐT Bernoulli})'
        ],
        keyNotes: [
          'Nếu thiếu một trong hai bước (cơ sở hoặc quy nạp) thì phép chứng minh hoàn toàn mất giá trị logic.',
          'Trong bước quy nạp, luôn phải sử dụng giả thiết quy nạp khi biến đổi để đi tới điều cần chứng minh ở bước $k+1$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CD2-B1',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-cd2-b2',
        title: 'Bài 2. Dãy số và giới hạn của dãy số.',
        grade: 11,
        chapterIndex: 12,
        chapterTitle: 'CHUYÊN ĐỀ 2. PHƯƠNG PHÁP QUY NẠP TOÁN HỌC VÀ DÃY SỐ.',
        theoryHtml: `
          <p>Các phương pháp chuyên sâu xác định số hạng tổng quát của dãy số truy hồi và tính giới hạn:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Dãy số dạng tuyến tính bậc nhất $u_{n+1} = a u_n + b$:</strong></p>
            <p>Nếu $a = 1$: Dãy là CSC có công sai $d = b$.</p>
            <p>Nếu $a \\ne 1$: Đặt $u_n = v_n + c$ với $c = \\frac{b}{1 - a}$ để đưa về CSN $v_{n+1} = a v_n$.</p>
            <p><strong>2. Dãy số dạng phân thức tuyến tính $u_{n+1} = \\frac{a u_n + b}{c u_n + d}$ ($c \\ne 0$):</strong> Dùng phương pháp phương trình đặc trưng hoặc nghịch đảo.</p>
            <p><strong>3. Định lý kẹp giới hạn:</strong> Nếu $v_n \\le u_n \\le w_n$ với mọi $n$ và $\\lim v_n = \\lim w_n = L$ thì $\\lim u_n = L$.</p>
          </div>
        `,
        formulas: [
          'u_{n+1} = a u_n + b \\implies u_n = a^{n-1} u_1 + b \\frac{a^{n-1} - 1}{a - 1} \\quad (a \\ne 1)',
          'v_n \\le u_n \\le w_n, \\, \\lim v_n = \\lim w_n = L \\implies \\lim u_n = L \\quad (\\text{Định lý kẹp})'
        ],
        keyNotes: [
          'Dãy số đơn điệu và bị chặn thì chắc chắn hội tụ (có giới hạn hữu hạn).',
          'Nếu biết dãy số $(u_n)$ hội tụ về $L$, ta lấy giới hạn hai vế của hệ thức truy hồi để tìm $L$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CD2-B2',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-cd2-rev',
        title: 'Bài tập cuối chuyên đề 2.',
        grade: 11,
        chapterIndex: 12,
        chapterTitle: 'CHUYÊN ĐỀ 2. PHƯƠNG PHÁP QUY NẠP TOÁN HỌC VÀ DÃY SỐ.',
        theoryHtml: `
          <p>Tổng kết chuyên đề Quy nạp toán học và Dãy số nâng cao:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Chứng minh các đẳng thức tổng, bất đẳng thức đại số và bài toán chia hết bằng phương pháp quy nạp.</li>
            <li>Tìm công thức số hạng tổng quát của dãy số xác định bởi công thức truy hồi bậc hai $u_{n+2} + p u_{n+1} + q u_n = 0$ (phương trình đặc trưng).</li>
            <li>Ứng dụng dãy số trong giải toán đếm và tổ hợp (dãy số Fibonacci).</li>
          </ul>
        `,
        formulas: [
          'F_1 = 1, F_2 = 1, F_{n+1} = F_n + F_{n-1} \\quad (\\text{Dãy số Fibonacci})',
          '\\lambda^2 + p\\lambda + q = 0 \\quad (\\text{Phương trình đặc trưng dãy tuyến tính bậc 2})'
        ],
        keyNotes: [
          'Khi chứng minh bài toán chia hết bằng quy nạp: biểu diễn $A(k+1) = A(k) + \\dots$ để tận dụng giả thiết chia hết của $A(k)$.',
          'Công thức Binet cho số hạng tổng quát của dãy Fibonacci: $F_n = \\frac{1}{\\sqrt{5}}\\left[\\left(\\frac{1+\\sqrt{5}}{2}\\right)^n - \\left(\\frac{1-\\sqrt{5}}{2}\\right)^n\\right]$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '11-CD2-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHUYÊN ĐỀ 3. HÌNH HỌC KHÔNG GIAN VÀ CÁC YẾU TỐ ĐO LƯỜNG
  // =========================================================================
  {
    title: 'CHUYÊN ĐỀ 3. HÌNH HỌC KHÔNG GIAN VÀ CÁC YẾU TỐ ĐO LƯỜNG.',
    grade: 11,
    lessons: [
      {
        id: '11-cd3-b1',
        title: 'Bài 1. Hình biểu diễn của một hình không gian.',
        grade: 11,
        chapterIndex: 13,
        chapterTitle: 'CHUYÊN ĐỀ 3. HÌNH HỌC KHÔNG GIAN VÀ CÁC YẾU TỐ ĐO LƯỜNG.',
        theoryHtml: `
          <p>Phương pháp dựng hình biểu diễn và các hình chiếu vuông góc của khối đa diện trong kĩ thuật và kiến trúc:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Bản vẽ hình chiếu vuông góc (Phương pháp chiếu góc thứ nhất):</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Hình chiếu đứng: Nhìn từ trước tới.</li>
              <li>Hình chiếu bằng: Nhìn từ trên xuống.</li>
              <li>Hình chiếu cạnh: Nhìn từ trái sang.</li>
            </ul>
            <p><strong>2. Hình chiếu trục đo:</strong> Thể hiện cả ba chiều của vật thể trên một mặt phẳng hình chiếu (hình chiếu trục đo vuông góc đều và xiên góc cân).</p>
            <p><strong>3. Mặt cắt và thiết diện trong kiến trúc:</strong> Dựng giao của vật thể với mặt phẳng cắt để nhìn thấy cấu trúc bên trong.</p>
          </div>
        `,
        formulas: [
          'p = q = r = 1 \\quad (\\text{Hệ số biến dạng hình chiếu trục đo vuông góc đều})',
          '\\widehat{x\'O\'y\'} = \\widehat{y\'O\'z\'} = \\widehat{z\'O\'x\'} = 120^\\circ'
        ],
        keyNotes: [
          'Đường bao thấy vẽ bằng nét liền đậm, đường bao khuất vẽ bằng nét đứt mảnh, đường tâm vẽ bằng nét gạch chấm mảnh.',
          'Kỹ năng đọc bản vẽ kĩ thuật là cầu nối giữa toán học thuần tuý và công nghệ chế tạo.'
        ],
        diagramType: 'box',
        sgkRef: '11-CD3-B1',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-cd3-b2',
        title: 'Bài 2. Khoảng cách và thể tích trong hình học không gian.',
        grade: 11,
        chapterIndex: 13,
        chapterTitle: 'CHUYÊN ĐỀ 3. HÌNH HỌC KHÔNG GIAN VÀ CÁC YẾU TỐ ĐO LƯỜNG.',
        theoryHtml: `
          <p>Ứng dụng công thức đo lường khoảng cách và thể tích giải quyết các bài toán xây dựng, thiết kế và thực tế sản xuất:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Bài toán đo đạc ngoài trời không thể tiếp cận trực tiếp:</strong></p>
            <p>Đo chiều cao của tháp, đỉnh núi, toà nhà bằng giác kế và phương pháp lượng giác tam giác trong không gian.</p>
            <p><strong>2. Tính dung tích bể chứa và vật thể phức tạp:</strong></p>
            <p>Phương pháp phân chia và bổ sung hình khối: Chia vật thể phức tạp thành các khối chóp, lăng trụ, chóp cụt quen thuộc rồi cộng tổng thể tích.</p>
            <p><strong>3. Tỉ số thể tích mở rộng:</strong> Áp dụng công thức tỉ số thể tích của khối đa diện cắt bởi mặt phẳng thiết diện tuỳ ý.</p>
          </div>
        `,
        formulas: [
          'V = \\sum_{i=1}^m V_i \\quad (\\text{Nguyên lý cộng thể tích})',
          'V_{\\text{chóp cụt}} = \\frac{1}{3} h (B + B\' + \\sqrt{B B\'})',
          'h = \\frac{d \\cdot \\sin\\alpha \\sin\\beta}{\\sin(\\beta - \\alpha)} \\quad (\\text{Đo chiều cao bằng giác kế})'
        ],
        keyNotes: [
          'Nguyên lý Cavalieri: Hai khối vật thể có cùng chiều cao và diện tích các thiết diện cắt bởi các mặt phẳng song song với đáy luôn bằng nhau thì hai khối đó có thể tích bằng nhau.',
          'Khi tính thể tích khối đa diện không đều, kỹ thuật ghép thêm phần còn thiếu để tạo khối quen thuộc (hình hộp, chóp) thường hiệu quả hơn phân chia.'
        ],
        diagramType: 'prism',
        sgkRef: '11-CD3-B2',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      },
      {
        id: '11-cd3-rev',
        title: 'Bài tập cuối chuyên đề 3.',
        grade: 11,
        chapterIndex: 13,
        chapterTitle: 'CHUYÊN ĐỀ 3. HÌNH HỌC KHÔNG GIAN VÀ CÁC YẾU TỐ ĐO LƯỜNG.',
        theoryHtml: `
          <p>Tổng kết toàn diện Chuyên đề 3: Các yếu tố đo lường trong không gian và bài toán thực tế:</p>
          <ul class="list-disc list-inside space-y-1.5 pl-2">
            <li>Thiết kế bao bì, vỏ hộp sản phẩm để tối ưu diện tích giấy/kim loại sử dụng.</li>
            <li>Tính toán vật liệu xây dựng (khối lượng bê tông, diện tích mái ngói hình chóp, hình chóp cụt).</li>
            <li>Các bài toán cực trị không gian: tìm vị trí đặt trạm bơm để tổng chiều dài đường ống nước là ngắn nhất.</li>
          </ul>
        `,
        formulas: [
          'S_{\\text{xq}} = \\sum S_{\\text{mặt bên}}, \\quad S_{\\text{tp}} = S_{\\text{xq}} + S_{\\text{đáy}}',
          'd(M, A) + d(M, B) \\text{ đạt min bằng cách lấy điểm đối xứng qua mặt phẳng}'
        ],
        keyNotes: [
          'Bài toán tìm đường đi ngắn nhất trên bề mặt khối đa diện: trải các mặt của khối đa diện lên một mặt phẳng (khai triển hình học), đường thẳng nối hai điểm chính là đường ngắn nhất.',
          'Kết hợp linh hoạt giữa phương pháp tổng hợp hình học và phương pháp toạ độ hoá.'
        ],
        diagramType: 'pyramid',
        sgkRef: '11-CD3-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 11 GDPT 2018'
      }
    ]
  }
];
