import { Chapter, Grade, Lesson } from '../types/math';
import { FULL_CURRICULUM_GRADE_10 } from './fullCurriculum10';
import { FULL_CURRICULUM_GRADE_11 } from './fullCurriculum11';
import { FULL_CURRICULUM_GRADE_12 } from './fullCurriculum12';

export const CURRICULUM: Record<Grade, Chapter[]> = {
  10: FULL_CURRICULUM_GRADE_10,
  11: FULL_CURRICULUM_GRADE_11,
  12: FULL_CURRICULUM_GRADE_12
};
