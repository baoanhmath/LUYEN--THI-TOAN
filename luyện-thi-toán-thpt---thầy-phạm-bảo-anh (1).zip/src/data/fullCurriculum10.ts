import { Chapter } from '../types/math';

/**
 * CHƯƠNG TRÌNH TOÁN 10 TOÀN DIỆN - CHUẨN GDPT 2018 (KẾT NỐI TRI THỨC VỚI CUỘC SỐNG)
 * Biên soạn & Chuẩn hóa: Thầy Phạm Bảo Anh (Dạy học Toán PBA)
 */
export const FULL_CURRICULUM_GRADE_10: Chapter[] = [
  // =========================================================================
  // CHƯƠNG I. MỆNH ĐỀ VÀ TẬP HỢP
  // =========================================================================
  {
    title: 'CHƯƠNG I. MỆNH ĐỀ VÀ TẬP HỢP.',
    grade: 10,
    lessons: [
      {
        id: '10-1',
        title: 'Bài 1. Mệnh đề.',
        grade: 10,
        chapterIndex: 0,
        chapterTitle: 'CHƯƠNG I. MỆNH ĐỀ VÀ TẬP HỢP.',
        theoryHtml: `
          <p>Mệnh đề là một khẳng định đúng hoặc một khẳng định sai. Một khẳng định không thể vừa đúng vừa sai.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Phủ định của một mệnh đề:</strong> Kí hiệu là $\\overline{P}$. Mệnh đề $\\overline{P}$ đúng khi $P$ sai, và sai khi $P$ đúng.</p>
            <p><strong>2. Mệnh đề kéo theo và mệnh đề đảo:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Mệnh đề "Nếu $P$ thì $Q$" kí hiệu là $P \\Rightarrow Q$. Mệnh đề $P \\Rightarrow Q$ chỉ sai khi $P$ đúng mà $Q$ sai.</li>
              <li>Mệnh đề $Q \\Rightarrow P$ được gọi là mệnh đề đảo của $P \\Rightarrow Q$.</li>
              <li>Nếu cả hai mệnh đề $P \\Rightarrow Q$ và $Q \\Rightarrow P$ đều đúng thì $P \\Leftrightarrow Q$ (mệnh đề tương đương).</li>
            </ul>
            <p><strong>3. Kí hiệu với mọi $(\\forall)$ và tồn tại $(\\exists)$:</strong></p>
            <p>Phủ định của $\\forall x \\in X, P(x)$ là $\\exists x \\in X, \\overline{P(x)}$.</p>
            <p>Phủ định của $\\exists x \\in X, P(x)$ là $\\forall x \\in X, \\overline{P(x)}$.</p>
          </div>
        `,
        formulas: [
          '\\overline{\\forall x \\in X, P(x)} \\Leftrightarrow \\exists x \\in X, \\overline{P(x)}',
          '\\overline{\\exists x \\in X, P(x)} \\Leftrightarrow \\forall x \\in X, \\overline{P(x)}',
          'P \\Rightarrow Q \\text{ sai khi và chỉ khi } P \\text{ đúng và } Q \\text{ sai}',
          'P \\Leftrightarrow Q \\text{ đúng khi và chỉ khi } P \\text{ và } Q \\text{ có cùng chân trị}'
        ],
        keyNotes: [
          'Khi phủ định mệnh đề: dấu $>$ đổi thành $\\le$, dấu $<$ đổi thành $\\ge$, dấu $=$ đổi thành $\\ne$.',
          'Lượng từ $\\forall$ chuyển thành $\\exists$ và ngược lại.',
          'Trong định lí toán học dạng $P \\Rightarrow Q$: $P$ là điều kiện đủ, $Q$ là điều kiện cần.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH1-B1',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-2',
        title: 'Bài 2. Tập hợp và các phép toán trên tập hợp.',
        grade: 10,
        chapterIndex: 0,
        chapterTitle: 'CHƯƠNG I. MỆNH ĐỀ VÀ TẬP HỢP.',
        theoryHtml: `
          <p>Tập hợp là khái niệm cơ bản của toán học. Các phép toán trên tập hợp gồm:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Giao của hai tập hợp:</strong> $A \\cap B = \\{x \\mid x \\in A \\text{ và } x \\in B\\}$.</p>
            <p><strong>2. Hợp của hai tập hợp:</strong> $A \\cup B = \\{x \\mid x \\in A \\text{ hoặc } x \\in B\\}$.</p>
            <p><strong>3. Hiệu của hai tập hợp:</strong> $A \\setminus B = \\{x \\mid x \\in A \\text{ và } x \\notin B\\}$.</p>
            <p><strong>4. Phần bù:</strong> Khi $A \\subset E$, phần bù của $A$ trong $E$ là $C_E A = E \\setminus A$.</p>
            <p><strong>5. Các tập con của số thực $\\mathbb{R}$:</strong> Khoảng $(a; b)$, đoạn $[a; b]$, nửa khoảng $[a; b)$, $(a; b]$, $(-\\infty; a)$, $[a; +\\infty)$.</p>
          </div>
        `,
        formulas: [
          'A \\cap B = \\{x \\mid x \\in A \\text{ và } x \\in B\\}',
          'A \\cup B = \\{x \\mid x \\in A \\text{ hoặc } x \\in B\\}',
          'A \\setminus B = \\{x \\mid x \\in A \\text{ và } x \\notin B\\}',
          'C_{\\mathbb{R}} [a; b) = (-\\infty; a) \\cup [b; +\\infty)'
        ],
        keyNotes: [
          'Số phần tử: $n(A \\cup B) = n(A) + n(B) - n(A \\cap B)$.',
          'Biểu diễn trên trục số: phần không thuộc tập hợp ta gạch chéo bỏ.',
          'Cẩn thận với đầu mút: ngoặc vuông $[$ lấy điểm mút, ngoặc tròn $($ không lấy điểm mút.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH1-B2',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-rev1',
        title: 'Bài tập cuối chương I.',
        grade: 10,
        chapterIndex: 0,
        chapterTitle: 'CHƯƠNG I. MỆNH ĐỀ VÀ TẬP HỢP.',
        theoryHtml: `
          <p>Hệ thống hoá toàn bộ kiến thức Chương I: Mệnh đề, Mệnh đề chứa biến, Tập hợp và Các phép toán trên tập con của $\\mathbb{R}$.</p>
          <div class="mt-2 space-y-1 text-slate-700">
            <p>- Dạng 1: Xét tính đúng sai của mệnh đề; phủ định mệnh đề chứa $\\forall, \\exists$.</p>
            <p>- Dạng 2: Thực hiện các phép toán giao, hợp, hiệu trên các khoảng, đoạn.</p>
            <p>- Dạng 3: Bài toán tìm tham số $m$ để $A \\cap B = \\emptyset$, $A \\cap B \\ne \\emptyset$, $A \\subset B$.</p>
          </div>
        `,
        formulas: [
          'A \\subset B \\iff (\\forall x \\in A \\implies x \\in B)',
          'A \\cap B = \\emptyset \\iff \\text{không tồn tại } x \\in A \\cap B',
          'C_E(A \\cup B) = C_E A \\cap C_E B \\quad (\\text{Công thức De Morgan})'
        ],
        keyNotes: [
          'Khi giải bài toán chứa tham số $m$ với các khoảng đoạn, hãy vẽ trực quan hai tập hợp trên trục số để so sánh các đầu mút.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH1-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG II. BẤT PHƯƠNG TRÌNH VÀ HỆ BẤT PHƯƠNG TRÌNH BẬC NHẤT HAI ẨN
  // =========================================================================
  {
    title: 'CHƯƠNG II. BẤT PHƯƠNG TRÌNH VÀ HỆ BẤT PHƯƠNG TRÌNH BẬC NHẤT HAI ẨN.',
    grade: 10,
    lessons: [
      {
        id: '10-3',
        title: 'Bài 3. Bất phương trình bậc nhất hai ẩn.',
        grade: 10,
        chapterIndex: 1,
        chapterTitle: 'CHƯƠNG II. BẤT PHƯƠNG TRÌNH VÀ HỆ BẤT PHƯƠNG TRÌNH BẬC NHẤT HAI ẨN.',
        theoryHtml: `
          <p>Bất phương trình bậc nhất hai ẩn có dạng tổng quát: $ax + by \\le c$ (hoặc $<, >, \\ge$) với $a^2 + b^2 \\ne 0$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>Biểu diễn miền nghiệm trên mặt phẳng $Oxy$:</strong></p>
            <ol class="list-decimal list-inside pl-2">
              <li>Vẽ đường thẳng biên $d: ax + by = c$.</li>
              <li>Lấy một điểm kiểm tra $M(x_0; y_0) \\notin d$ (thường chọn gốc tọa độ $O(0; 0)$ nếu $c \\ne 0$).</li>
              <li>Tính $ax_0 + by_0$ và so sánh với $c$. Nếu thỏa mãn thì nửa mặt phẳng chứa $M$ là miền nghiệm; nếu không thỏa mãn thì nửa mặt phẳng không chứa $M$ là miền nghiệm.</li>
            </ol>
          </div>
        `,
        formulas: [
          'ax + by \\le c \\quad (a^2 + b^2 \\ne 0)',
          '\\text{Thử điểm } O(0; 0): \\text{Nếu } 0 \\le c \\text{ thỏa mãn } \\implies \\text{miền nghiệm chứa } O'
        ],
        keyNotes: [
          'Dấu $\\le, \\ge$: Miền nghiệm tính cả đường thẳng biên (vẽ nét liền).',
          'Dấu $<, >$: Miền nghiệm không tính đường thẳng biên (vẽ nét đứt).'
        ],
        diagramType: 'quadratic',
        sgkRef: '10-CH2-B3',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-4',
        title: 'Bài 4. Hệ bất phương trình bậc nhất hai ẩn.',
        grade: 10,
        chapterIndex: 1,
        chapterTitle: 'CHƯƠNG II. BẤT PHƯƠNG TRÌNH VÀ HỆ BẤT PHƯƠNG TRÌNH BẬC NHẤT HAI ẨN.',
        theoryHtml: `
          <p>Hệ bất phương trình bậc nhất hai ẩn gồm hai hay nhiều bất phương trình bậc nhất hai ẩn.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Miền nghiệm của hệ:</strong> Là giao các miền nghiệm của các bất phương trình thành phần (thường là miền đa giác lồi).</p>
            <p><strong>2. Ứng dụng giải bài toán quy hoạch tuyến tính:</strong></p>
            <p>Giá trị lớn nhất và giá trị nhỏ nhất của biểu thức bậc nhất $F(x; y) = ax + by$ trên miền đa giác lồi $S$ luôn đạt tại một trong các đỉnh của miền đa giác đó.</p>
          </div>
        `,
        formulas: [
          '\\begin{cases} a_1 x + b_1 y \\le c_1 \\\\ a_2 x + b_2 y \\le c_2 \\\\ x \\ge 0, \\, y \\ge 0 \\end{cases}',
          'F(x; y) = ax + by \\implies \\max / \\min \\text{ đạt tại các đỉnh của miền đa giác}'
        ],
        keyNotes: [
          'Các bước tìm $\\max/\\min$ của $F(x; y)$: Xác định toạ độ các đỉnh của miền nghiệm đa giác $\\to$ tính giá trị của $F$ tại từng đỉnh $\\to$ so sánh kết luận.'
        ],
        diagramType: 'quadratic',
        sgkRef: '10-CH2-B4',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-rev2',
        title: 'Bài tập cuối chương II.',
        grade: 10,
        chapterIndex: 1,
        chapterTitle: 'CHƯƠNG II. BẤT PHƯƠNG TRÌNH VÀ HỆ BẤT PHƯƠNG TRÌNH BẬC NHẤT HAI ẨN.',
        theoryHtml: `
          <p>Tổng kết phương pháp giải bài toán tối ưu kinh tế thực tế:</p>
          <p>Gọi $x, y$ là số đơn vị sản phẩm cần sản xuất. Lập hệ điều kiện về nguyên liệu, thời gian, chi phí. Xác định hàm mục tiêu lợi nhuận $F(x; y)$ và tìm phương án tối ưu.</p>
        `,
        formulas: [
          'F(x, y) = c_1 x + c_2 y \\to \\max',
          'A_i x + B_i y \\le K_i \\quad (\\text{ràng buộc tài nguyên})'
        ],
        keyNotes: [
          'Luôn nhớ điều kiện thực tế của ẩn: $x \\ge 0, y \\ge 0$ (hoặc $x, y \\in \\mathbb{N}$).'
        ],
        diagramType: 'quadratic',
        sgkRef: '10-CH2-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG III. HỆ THỨC LƯỢNG TRONG TAM GIÁC
  // =========================================================================
  {
    title: 'CHƯƠNG III. HỆ THỨC LƯỢNG TRONG TAM GIÁC.',
    grade: 10,
    lessons: [
      {
        id: '10-5',
        title: 'Bài 5. Giá trị lượng giác của một góc từ 0° đến 180°.',
        grade: 10,
        chapterIndex: 2,
        chapterTitle: 'CHƯƠNG III. HỆ THỨC LƯỢNG TRONG TAM GIÁC.',
        theoryHtml: `
          <p>Trên nửa đường tròn đơn vị tâm $O(0; 0)$ bán kính $R = 1$ nằm phía trên trục hoành:</p>
          <div class="space-y-1.5 mt-2">
            <p>Với mỗi góc $\\alpha$ ($0^\\circ \\le \\alpha \\le 180^\\circ$), gọi $M(x_0; y_0)$ là điểm tương ứng trên nửa đường tròn. Khi đó:</p>
            <p>$\\sin \\alpha = y_0$, $\\quad \\cos \\alpha = x_0$, $\\quad \\tan \\alpha = \\frac{y_0}{x_0}$ (với $\\alpha \\ne 90^\\circ$), $\\quad \\cot \\alpha = \\frac{x_0}{y_0}$ (với $\\alpha \\ne 0^\\circ, 180^\\circ$).</p>
            <p><strong>Mối quan hệ hai góc bù nhau:</strong> $\\sin(180^\\circ - \\alpha) = \\sin \\alpha$; $\\cos(180^\\circ - \\alpha) = -\\cos \\alpha$; $\\tan(180^\\circ - \\alpha) = -\\tan \\alpha$.</p>
          </div>
        `,
        formulas: [
          '\\sin^2 \\alpha + \\cos^2 \\alpha = 1',
          '1 + \\tan^2 \\alpha = \\frac{1}{\\cos^2 \\alpha} \\quad (\\alpha \\ne 90^\\circ)',
          '\\sin(180^\\circ - \\alpha) = \\sin \\alpha, \\quad \\cos(180^\\circ - \\alpha) = -\\cos \\alpha'
        ],
        keyNotes: [
          'Với $0^\\circ < \\alpha < 180^\\circ$, $\\sin \\alpha$ luôn dương ($\\sin \\alpha > 0$).',
          'Góc nhọn: $\\cos > 0, \\tan > 0$. Góc tù: $\\cos < 0, \\tan < 0$. Góc vuông: $\\cos 90^\\circ = 0$.'
        ],
        diagramType: 'circle',
        sgkRef: '10-CH3-B5',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-6',
        title: 'Bài 6. Hệ thức lượng trong tam giác.',
        grade: 10,
        chapterIndex: 2,
        chapterTitle: 'CHƯƠNG III. HỆ THỨC LƯỢNG TRONG TAM GIÁC.',
        theoryHtml: `
          <p>Các định lý cơ bản và công thức tính diện tích trong tam giác $ABC$ với các cạnh $a, b, c$:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Định lí Côsin:</strong> $a^2 = b^2 + c^2 - 2bc\\cos A$. Hệ quả: $\\cos A = \\frac{b^2 + c^2 - a^2}{2bc}$.</p>
            <p><strong>2. Định lí Sin:</strong> $\\frac{a}{\\sin A} = \\frac{b}{\\sin B} = \\frac{c}{\\sin C} = 2R$.</p>
            <p><strong>3. Công thức tính đường trung tuyến:</strong> $m_a^2 = \\frac{2(b^2 + c^2) - a^2}{4}$.</p>
            <p><strong>4. Các công thức tính diện tích $S$:</strong></p>
            <p>$S = \\frac{1}{2}ah_a = \\frac{1}{2}ab\\sin C = \\frac{abc}{4R} = pr = \\sqrt{p(p-a)(p-b)(p-c)}$ (công thức Heron).</p>
          </div>
        `,
        formulas: [
          'a^2 = b^2 + c^2 - 2bc \\cos A',
          '\\frac{a}{\\sin A} = \\frac{b}{\\sin B} = \\frac{c}{\\sin C} = 2R',
          'S = \\frac{1}{2}ab\\sin C = \\frac{abc}{4R} = pr = \\sqrt{p(p-a)(p-b)(p-c)}',
          'm_a^2 = \\frac{2(b^2+c^2)-a^2}{4}'
        ],
        keyNotes: [
          'Biết 2 cạnh và góc kẹp giữa $\\to$ Định lý Côsin để tìm cạnh còn lại.',
          'Biết 1 cạnh và 2 góc $\\to$ Định lý Sin để tìm bán kính đường tròn ngoại tiếp $R$ và các cạnh còn lại.',
          'Tam giác nhọn: $a^2 < b^2 + c^2$; vuông: $a^2 = b^2 + c^2$; tù: $a^2 > b^2 + c^2$ (với $a$ là cạnh lớn nhất).'
        ],
        diagramType: 'pyramid',
        sgkRef: '10-CH3-B6',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-rev3',
        title: 'Bài tập cuối chương III.',
        grade: 10,
        chapterIndex: 2,
        chapterTitle: 'CHƯƠNG III. HỆ THỨC LƯỢNG TRONG TAM GIÁC.',
        theoryHtml: `
          <p>Ứng dụng hệ thức lượng giải tam giác và đo đạc thực tế:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Đo chiều cao của ngọn tháp, toà nhà khi không thể tiếp cận chân tháp.</li>
            <li>Đo khoảng cách giữa hai vị trí $A$ và $B$ bị ngăn cách bởi hồ nước hoặc đầm lầy.</li>
            <li>Xác định toạ độ tàu thuyền trên biển qua các góc phương vị.</li>
          </ul>
        `,
        formulas: [
          'h = d \\cdot \\frac{\\sin \\alpha \\cdot \\sin \\beta}{\\sin(\\beta - \\alpha)} \\quad (\\text{đo chiều cao gián tiếp})',
          '\\cos A = \\frac{b^2 + c^2 - a^2}{2bc}'
        ],
        keyNotes: [
          'Luôn vẽ hình phác thảo tam giác và ghi rõ các số liệu đã biết trước khi lựa chọn định lý sin hay định lý côsin.'
        ],
        diagramType: 'pyramid',
        sgkRef: '10-CH3-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG IV. VECTƠ
  // =========================================================================
  {
    title: 'CHƯƠNG IV. VECTƠ.',
    grade: 10,
    lessons: [
      {
        id: '10-7',
        title: 'Bài 7. Các khái niệm mở đầu.',
        grade: 10,
        chapterIndex: 3,
        chapterTitle: 'CHƯƠNG IV. VECTƠ.',
        theoryHtml: `
          <p>Vectơ là một đoạn thẳng có hướng (đã chỉ rõ điểm đầu và điểm cuối).</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Giá của vectơ:</strong> Là đường thẳng đi qua điểm đầu và điểm cuối của vectơ.</p>
            <p><strong>2. Hai vectơ cùng phương:</strong> Nếu giá của chúng song song hoặc trùng nhau.</p>
            <p><strong>3. Hai vectơ bằng nhau:</strong> Nếu chúng cùng hướng và cùng độ dài. Kí hiệu $\\vec{a} = \\vec{b}$.</p>
            <p><strong>4. Vectơ-không:</strong> Là vectơ có điểm đầu và điểm cuối trùng nhau, kí hiệu $\\vec{0}$. Độ dài $|\\vec{0}| = 0$, $\\vec{0}$ cùng phương và cùng hướng với mọi vectơ.</p>
          </div>
        `,
        formulas: [
          '|\\vec{AB}| = AB',
          '\\vec{a} = \\vec{b} \\iff |\\vec{a}| = |\\vec{b}| \\text{ và } \\vec{a} \\uparrow\\uparrow \\vec{b}',
          '\\vec{AA} = \\vec{0}'
        ],
        keyNotes: [
          'Hai vectơ cùng hướng thì luôn cùng phương; nhưng cùng phương chưa chắc đã cùng hướng (có thể ngược hướng).',
          'Ba điểm $A, B, C$ thẳng hàng $\\iff \\vec{AB}$ và $\\vec{AC}$ cùng phương.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH4-B7',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-8',
        title: 'Bài 8. Tổng và hiệu của hai vectơ.',
        grade: 10,
        chapterIndex: 3,
        chapterTitle: 'CHƯƠNG IV. VECTƠ.',
        theoryHtml: `
          <p>Các quy tắc cộng và trừ vectơ nền tảng:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Quy tắc ba điểm (nối đuôi):</strong> $\\vec{AB} + \\vec{BC} = \\vec{AC}$.</p>
            <p><strong>2. Quy tắc hình bình hành:</strong> Nếu $ABCD$ là hình bình hành thì $\\vec{AB} + \\vec{AD} = \\vec{AC}$.</p>
            <p><strong>3. Quy tắc trừ (chung gốc):</strong> $\\vec{AB} - \\vec{AC} = \\vec{CB}$.</p>
            <p><strong>4. Tính chất trung điểm và trọng tâm:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>$I$ là trung điểm đoạn $AB \\iff \\vec{IA} + \\vec{IB} = \\vec{0} \\iff \\vec{OA} + \\vec{OB} = 2\\vec{OI}$ (với mọi điểm $O$).</li>
              <li>$G$ là trọng tâm tam giác $ABC \\iff \\vec{GA} + \\vec{GB} + \\vec{GC} = \\vec{0} \\iff \\vec{OA} + \\vec{OB} + \\vec{OC} = 3\\vec{OG}$.</li>
            </ul>
          </div>
        `,
        formulas: [
          '\\vec{AB} + \\vec{BC} = \\vec{AC}',
          '\\vec{AB} - \\vec{AC} = \\vec{CB}',
          '\\vec{OA} + \\vec{OB} = 2\\vec{OI} \\quad (I \\text{ là trung điểm } AB)',
          '\\vec{OA} + \\vec{OB} + \\vec{OC} = 3\\vec{OG} \\quad (G \\text{ là trọng tâm } \\Delta ABC)'
        ],
        keyNotes: [
          'Quy tắc trừ chung gốc: đuôi trước, đầu sau: $\\vec{AB} - \\vec{AC} = \\vec{CB}$.',
          'Vectơ đối của $\\vec{a}$ là $-\\vec{a}$: $\\vec{a} + (-\\vec{a}) = \\vec{0}$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH4-B8',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-9',
        title: 'Bài 9. Tích của một vectơ với một số.',
        grade: 10,
        chapterIndex: 3,
        chapterTitle: 'CHƯƠNG IV. VECTƠ.',
        theoryHtml: `
          <p>Tích của vectơ $\\vec{a}$ với số thực $k \\ne 0$ là một vectơ, kí hiệu là $k\\vec{a}$:</p>
          <div class="space-y-1.5 mt-2">
            <p>- Cùng hướng với $\\vec{a}$ nếu $k > 0$; ngược hướng với $\\vec{a}$ nếu $k < 0$.</p>
            <p>- Độ dài: $|k\\vec{a}| = |k| \\cdot |\\vec{a}|$. Quy ước: $0\\vec{a} = \\vec{0}$, $k\\vec{0} = \\vec{0}$.</p>
            <p><strong>Điều kiện cùng phương:</strong> Vectơ $\\vec{b}$ cùng phương với $\\vec{a} \\ne \\vec{0} \\iff$ tồn tại số thực $k$ sao cho $\\vec{b} = k\\vec{a}$.</p>
            <p><strong>Phân tích một vectơ theo hai vectơ không cùng phương:</strong> Mọi vectơ $\\vec{x}$ đều biểu diễn duy nhất dưới dạng $\\vec{x} = m\\vec{a} + n\\vec{b}$.</p>
          </div>
        `,
        formulas: [
          '|k\\vec{a}| = |k| \\cdot |\\vec{a}|',
          '\\vec{b} \\parallel \\vec{a} (\\vec{a} \\ne \\vec{0}) \\iff \\exists k \\in \\mathbb{R}: \\vec{b} = k\\vec{a}',
          '\\vec{x} = m\\vec{a} + n\\vec{b} \\quad (\\vec{a}, \\vec{b} \\text{ không cùng phương})'
        ],
        keyNotes: [
          'Ba điểm phân biệt $A, B, C$ thẳng hàng khi và chỉ khi tồn tại số $k \\ne 0$ để $\\vec{AB} = k\\vec{AC}$.',
          'Điểm $M$ chia đoạn thẳng $AB$ theo tỉ số $k$: $\\vec{MA} = k\\vec{MB}$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH4-B9',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-10',
        title: 'Bài 10. Vectơ trong mặt phẳng toạ độ.',
        grade: 10,
        chapterIndex: 3,
        chapterTitle: 'CHƯƠNG IV. VECTƠ.',
        theoryHtml: `
          <p>Hệ trục toạ độ $Oxy$ gồm trục hoành $Ox$ với vectơ đơn vị $\\vec{i}=(1; 0)$ và trục tung $Oy$ với vectơ đơn vị $\\vec{j}=(0; 1)$ vuông góc với nhau.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Toạ độ của vectơ:</strong> $\\vec{u} = x\\vec{i} + y\\vec{j} \\iff \\vec{u} = (x; y)$.</p>
            <p><strong>2. Toạ độ của điểm:</strong> Điểm $M(x; y) \\iff \\vec{OM} = (x; y)$.</p>
            <p><strong>3. Cho hai điểm $A(x_A; y_A)$ và $B(x_B; y_B)$:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>$\\vec{AB} = (x_B - x_A; y_B - y_A)$.</li>
              <li>Độ dài đoạn $AB = |\\vec{AB}| = \\sqrt{(x_B - x_A)^2 + (y_B - y_A)^2}$.</li>
              <li>Trung điểm $I$ của $AB$: $x_I = \\frac{x_A + x_B}{2}, \\, y_I = \\frac{y_A + y_B}{2}$.</li>
              <li>Trọng tâm $G$ tam giác $ABC$: $x_G = \\frac{x_A+x_B+x_C}{3}, \\, y_G = \\frac{y_A+y_B+y_C}{3}$.</li>
            </ul>
          </div>
        `,
        formulas: [
          '\\vec{u} = (x_1; y_1), \\, \\vec{v} = (x_2; y_2) \\implies \\vec{u} \\pm \\vec{v} = (x_1 \\pm x_2; y_1 \\pm y_2)',
          'k\\vec{u} = (kx_1; ky_1), \\quad |\\vec{u}| = \\sqrt{x_1^2 + y_1^2}',
          '\\vec{u} \\parallel \\vec{v} \\iff x_1 y_2 - x_2 y_1 = 0'
        ],
        keyNotes: [
          'Toạ độ vectơ $\\vec{AB}$ lấy toạ độ điểm ngọn trừ toạ độ điểm gốc: $(x_B - x_A; y_B - y_A)$.',
          'Hai vectơ cùng phương khi các toạ độ tương ứng tỉ lệ: $\\frac{x_1}{x_2} = \\frac{y_1}{y_2}$ (với mẫu khác 0).'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH4-B10',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-11',
        title: 'Bài 11. Tích vô hướng của hai vectơ.',
        grade: 10,
        chapterIndex: 3,
        chapterTitle: 'CHƯƠNG IV. VECTƠ.',
        theoryHtml: `
          <p>Tích vô hướng của hai vectơ $\\vec{a}$ và $\\vec{b}$ là một SỐ THỰC, kí hiệu là $\\vec{a} \\cdot \\vec{b}$:</p>
          <div class="space-y-1.5 mt-2">
            <p>$$\\vec{a} \\cdot \\vec{b} = |\\vec{a}| \\cdot |\\vec{b}| \\cdot \\cos(\\vec{a}, \\vec{b})$$</p>
            <p><strong>1. Biểu thức toạ độ:</strong> Với $\\vec{a} = (x_1; y_1)$ và $\\vec{b} = (x_2; y_2)$ thì $\\vec{a} \\cdot \\vec{b} = x_1 x_2 + y_1 y_2$.</p>
            <p><strong>2. Hai vectơ vuông góc:</strong> $\\vec{a} \\perp \\vec{b} \\iff \\vec{a} \\cdot \\vec{b} = 0 \\iff x_1 x_2 + y_1 y_2 = 0$.</p>
            <p><strong>3. Góc giữa hai vectơ:</strong> $\\cos(\\vec{a}, \\vec{b}) = \\frac{\\vec{a} \\cdot \\vec{b}}{|\\vec{a}| \\cdot |\\vec{b}|} = \\frac{x_1 x_2 + y_1 y_2}{\\sqrt{x_1^2 + y_1^2}\\sqrt{x_2^2 + y_2^2}}$.</p>
          </div>
        `,
        formulas: [
          '\\vec{a} \\cdot \\vec{b} = |\\vec{a}| |\\vec{b}| \\cos(\\vec{a}, \\vec{b})',
          '\\vec{a} \\cdot \\vec{b} = x_1 x_2 + y_1 y_2',
          '\\vec{a}^2 = |\\vec{a}|^2 = x_1^2 + y_1^2',
          '\\vec{a} \\perp \\vec{b} \\iff x_1 x_2 + y_1 y_2 = 0'
        ],
        keyNotes: [
          'Bình phương vô hướng bằng bình phương độ dài: $\\vec{a}^2 = |\\vec{a}|^2$.',
          'Tích vô hướng là một số, không phải là một vectơ.',
          'Góc giữa hai vectơ nhọn khi $\\vec{a} \\cdot \\vec{b} > 0$; tù khi $\\vec{a} \\cdot \\vec{b} < 0$; vuông khi $\\vec{a} \\cdot \\vec{b} = 0$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH4-B11',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-rev4',
        title: 'Bài tập cuối chương IV.',
        grade: 10,
        chapterIndex: 3,
        chapterTitle: 'CHƯƠNG IV. VECTƠ.',
        theoryHtml: `
          <p>Hệ thống hoá toàn bộ các dạng toán vectơ:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Chứng minh đẳng thức vectơ bằng quy tắc ba điểm, hình bình hành, chèn điểm.</li>
            <li>Phân tích một vectơ theo hai vectơ không cùng phương cho trước.</li>
            <li>Chứng minh ba điểm thẳng hàng, hai đường thẳng song song hoặc vuông góc.</li>
            <li>Tìm tập hợp điểm thỏa mãn đẳng thức vectơ (tâm tỉ cự).</li>
          </ul>
        `,
        formulas: [
          '|\\vec{MA} + \\vec{MB}| = |\\vec{MA} - \\vec{MB}| \\iff MI = \\frac{AB}{2} \\iff \\Delta MAB \\text{ vuông tại } M',
          '\\vec{MA} + k\\vec{MB} = \\vec{0} \\quad (\\text{tâm tỉ cự})'
        ],
        keyNotes: [
          'Kĩ thuật quy về gốc: Khi gặp biểu thức vectơ phức tạp, hãy chèn một điểm cố định (như $O, A$ hoặc trọng tâm $G$) vào tất cả các vectơ.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH4-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG V. CÁC SỐ ĐẶC TRƯNG CỦA MẪU SỐ LIỆU KHÔNG GHÉP NHÓM
  // =========================================================================
  {
    title: 'CHƯƠNG V. CÁC SỐ ĐẶC TRƯNG CỦA MẪU SỐ LIỆU. KHÔNG GHÉP NHÓM.',
    grade: 10,
    lessons: [
      {
        id: '10-12',
        title: 'Bài 12. Số gần đúng và sai số.',
        grade: 10,
        chapterIndex: 4,
        chapterTitle: 'CHƯƠNG V. CÁC SỐ ĐẶC TRƯNG CỦA MẪU SỐ LIỆU. KHÔNG GHÉP NHÓM.',
        theoryHtml: `
          <p>Trong thực tế đo đạc, các kết quả thu được thường là số gần đúng $a$ của số đúng $\\bar{a}$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Sai số tuyệt đối:</strong> $\\Delta_a = |\\bar{a} - a|$. Nếu $\\Delta_a \\le d$ thì $d$ gọi là độ chính xác của số gần đúng $a$, viết $\\bar{a} = a \\pm d$.</p>
            <p><strong>2. Sai số tương đối:</strong> $\\delta_a = \\frac{\\Delta_a}{|a|} \\le \\frac{d}{|a|}$. Sai số tương đối càng nhỏ thì phép đo càng chính xác.</p>
            <p><strong>3. Quy tắc làm tròn số theo độ chính xác $d$:</strong></p>
            <p>Nếu độ chính xác $d$ ở hàng phần trăm thì làm tròn $a$ đến hàng phần chục; nếu $d$ ở hàng đơn vị thì làm tròn đến hàng chục.</p>
          </div>
        `,
        formulas: [
          '\\Delta_a = |\\bar{a} - a| \\le d \\implies a - d \\le \\bar{a} \\le a + d',
          '\\delta_a = \\frac{\\Delta_a}{|a|} \\le \\frac{d}{|a|}'
        ],
        keyNotes: [
          'Hàng của chữ số làm tròn luôn LỚN HƠN MỘT BẬC so với hàng cao nhất của độ chính xác $d$.',
          'Chữ số có nghĩa: Tất cả các chữ số tính từ chữ số khác 0 đầu tiên từ trái sang phải.'
        ],
        diagramType: 'histogram',
        sgkRef: '10-CH5-B12',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-13',
        title: 'Bài 13. Các số đặc trưng đo xu thế trung tâm.',
        grade: 10,
        chapterIndex: 4,
        chapterTitle: 'CHƯƠNG V. CÁC SỐ ĐẶC TRƯNG CỦA MẪU SỐ LIỆU. KHÔNG GHÉP NHÓM.',
        theoryHtml: `
          <p>Cho mẫu số liệu đã sắp xếp không giảm: $x_1 \\le x_2 \\le \\dots \\le x_n$.</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Số trung bình $\\bar{x}$:</strong> $\\bar{x} = \\frac{x_1 + x_2 + \\dots + x_n}{n}$.</p>
            <p><strong>2. Trung vị $M_e$:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Nếu $n$ lẻ: $M_e = x_{\\frac{n+1}{2}}$.</li>
              <li>Nếu $n$ chẵn: $M_e = \\frac{x_{n/2} + x_{n/2+1}}{2}$.</li>
            </ul>
            <p><strong>3. Tứ phân vị:</strong> $Q_2 = M_e$. $Q_1$ là trung vị nửa dưới; $Q_3$ là trung vị nửa trên.</p>
            <p><strong>4. Mốt $M_o$:</strong> Giá trị có tần số xuất hiện lớn nhất trong mẫu.</p>
          </div>
        `,
        formulas: [
          '\\bar{x} = \\frac{1}{n} \\sum_{i=1}^n x_i',
          'Q_2 = M_e, \\quad Q_1 = \\text{Med}(\\text{nửa dưới}), \\quad Q_3 = \\text{Med}(\\text{nửa trên})'
        ],
        keyNotes: [
          'Trung vị $M_e$ không bị ảnh hưởng bởi các giá trị bất thường (dị biệt) lớn hoặc nhỏ quá mức so với số trung bình.',
          'Trước khi tìm trung vị và tứ phân vị, BẮT BUỘC phải sắp xếp mẫu số liệu theo thứ tự tăng dần.'
        ],
        diagramType: 'histogram',
        sgkRef: '10-CH5-B13',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-14',
        title: 'Bài 14. Các số đặc trưng đo độ phân tán.',
        grade: 10,
        chapterIndex: 4,
        chapterTitle: 'CHƯƠNG V. CÁC SỐ ĐẶC TRƯNG CỦA MẪU SỐ LIỆU. KHÔNG GHÉP NHÓM.',
        theoryHtml: `
          <p>Các đại lượng đo mức độ phân tán (biến động) của các số liệu xung quanh giá trị trung tâm:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Khoảng biến thiên:</strong> $R = x_{\\max} - x_{\\min}$.</p>
            <p><strong>2. Khoảng tứ phân vị:</strong> $\\Delta_Q = Q_3 - Q_1$. Đại lượng này không phụ thuộc vào giá trị bất thường.</p>
            <p><strong>3. Giá trị bất thường:</strong> Phần tử $x$ là bất thường nếu $x < Q_1 - 1.5\\Delta_Q$ hoặc $x > Q_3 + 1.5\\Delta_Q$.</p>
            <p><strong>4. Phương sai và độ lệch chuẩn:</strong></p>
            <p>Phương sai: $s^2 = \\frac{1}{n}\\sum_{i=1}^n (x_i - \\bar{x})^2 = \\frac{1}{n}\\sum_{i=1}^n x_i^2 - (\\bar{x})^2$. Độ lệch chuẩn: $s = \\sqrt{s^2}$.</p>
          </div>
        `,
        formulas: [
          'R = x_{\\max} - x_{\\min}, \\quad \\Delta_Q = Q_3 - Q_1',
          's^2 = \\frac{1}{n}\\sum_{i=1}^n x_i^2 - (\\bar{x})^2, \\quad s = \\sqrt{s^2}',
          'x \\text{ là giá trị dị biệt } \\iff x < Q_1 - 1.5\\Delta_Q \\text{ hoặc } x > Q_3 + 1.5\\Delta_Q'
        ],
        keyNotes: [
          'Độ lệch chuẩn $s$ càng nhỏ thì các số liệu càng tập trung đều đặn quanh số trung bình (ổn định cao).',
          'Độ lệch chuẩn có cùng đơn vị đo với số liệu ban đầu, thuận lợi cho việc giải thích ý nghĩa thực tế.'
        ],
        diagramType: 'histogram',
        sgkRef: '10-CH5-B14',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-rev5',
        title: 'Bài tập cuối chương V.',
        grade: 10,
        chapterIndex: 4,
        chapterTitle: 'CHƯƠNG V. CÁC SỐ ĐẶC TRƯNG CỦA MẪU SỐ LIỆU. KHÔNG GHÉP NHÓM.',
        theoryHtml: `
          <p>Ứng dụng thực tế của thống kê mô tả:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>So sánh độ đồng đều về học lực của hai lớp dựa trên số trung bình và độ lệch chuẩn.</li>
            <li>Đánh giá rủi ro đầu tư chứng khoán dựa trên độ lệch chuẩn của tỉ suất sinh lời.</li>
            <li>Phát hiện các sai sót đo đạc nhờ kiểm định giá trị bất thường bằng khoảng tứ phân vị.</li>
          </ul>
        `,
        formulas: [
          's = \\sqrt{\\frac{1}{n}\\sum_{i=1}^n (x_i - \\bar{x})^2}',
          '\\Delta_Q = Q_3 - Q_1'
        ],
        keyNotes: [
          'Khi hai mẫu có số trung bình xấp xỉ nhau, mẫu nào có độ lệch chuẩn nhỏ hơn thì mẫu đó ổn định và đồng đều hơn.'
        ],
        diagramType: 'histogram',
        sgkRef: '10-CH5-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM (HỌC KỲ I)
  // =========================================================================
  {
    title: 'HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM.',
    grade: 10,
    lessons: [
      {
        id: '10-hd1',
        title: 'Tìm hiểu một số kiến thức về tài chính.',
        grade: 10,
        chapterIndex: 5,
        chapterTitle: 'HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM.',
        theoryHtml: `
          <p>Toán học trong quản lý tài chính cá nhân và kinh doanh:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Lãi đơn và lãi kép:</strong></p>
            <p>- Lãi đơn: $S = P(1 + r \\cdot n)$, trong đó tiền lãi không sinh thêm lãi.</p>
            <p>- Lãi kép: $S = P(1 + r)^n$, tiền lãi chu kì trước được cộng vào vốn để tính lãi chu kì sau.</p>
            <p><strong>2. Kế hoạch tài chính & Quản lý thu chi:</strong> Quy tắc chi tiêu 50/30/20 (50% nhu cầu thiết yếu, 30% sở thích, 20% tiết kiệm và đầu tư).</p>
          </div>
        `,
        formulas: [
          'S_n = P(1 + r)^n \\quad (\\text{Lãi kép kì hạn đều})',
          'S = P(1 + n \\cdot r) \\quad (\\text{Lãi đơn})',
          'T = A \\frac{(1+r)[(1+r)^n - 1]}{r} \\quad (\\text{Gửi tiền định kì mỗi tháng})'
        ],
        keyNotes: [
          'Sức mạnh của lãi kép đến từ thời gian $n$ đủ lớn (tăng trưởng hàm mũ).',
          'Luôn quy đổi lãi suất $r$ và số kì hạn $n$ về cùng đơn vị thời gian (năm, quý hoặc tháng).'
        ],
        diagramType: 'histogram',
        sgkRef: '10-HD-TC',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-hd2',
        title: 'Mạng xã hội: Lợi và hại.',
        grade: 10,
        chapterIndex: 5,
        chapterTitle: 'HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM.',
        theoryHtml: `
          <p>Ứng dụng thống kê để phân tích thói quen sử dụng mạng xã hội của học sinh:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Thu thập dữ liệu:</strong> Khảo sát thời gian sử dụng màn hình (screen time), số lượng tương tác, mức độ tập trung học tập.</p>
            <p><strong>2. Phân tích mẫu số liệu:</strong> Tính số trung bình, trung vị, khoảng biến thiên và độ lệch chuẩn để so sánh giữa các nhóm học sinh.</p>
            <p><strong>3. Rút ra kết luận khoa học:</strong> Đánh giá mối tương quan giữa thời gian sử dụng mạng xã hội và kết quả rèn luyện.</p>
          </div>
        `,
        formulas: [
          '\\bar{x} = \\frac{\\sum x_i}{n}, \\quad s = \\sqrt{\\frac{\\sum (x_i - \\bar{x})^2}{n}}'
        ],
        keyNotes: [
          'Sử dụng biểu đồ hộp (box plot) và biểu đồ cột để biểu diễn trực quan kết quả điều tra thực nghiệm.'
        ],
        diagramType: 'histogram',
        sgkRef: '10-HD-MXH',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG VI. HÀM SỐ, ĐỒ THỊ VÀ ỨNG DỤNG
  // =========================================================================
  {
    title: 'CHƯƠNG VI. HÀM SỐ, ĐỒ THỊ VÀ ỨNG DỤNG.',
    grade: 10,
    lessons: [
      {
        id: '10-15',
        title: 'Bài 15. Hàm số.',
        grade: 10,
        chapterIndex: 6,
        chapterTitle: 'CHƯƠNG VI. HÀM SỐ, ĐỒ THỊ VÀ ỨNG DỤNG.',
        theoryHtml: `
          <p>Khái niệm hàm số $y = f(x)$ xác định trên tập hợp $D \\subset \\mathbb{R}$:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Tập xác định $D$:</strong> Tập hợp tất cả các giá trị của $x$ sao cho biểu thức $f(x)$ có nghĩa.</p>
            <p><strong>2. Sự biến thiên của hàm số trên khoảng $(a; b)$:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>Đồng biến: Với mọi $x_1 < x_2 \\implies f(x_1) < f(x_2)$ (đồ thị đi lên từ trái sang phải).</li>
              <li>Nghịch biến: Với mọi $x_1 < x_2 \\implies f(x_1) > f(x_2)$ (đồ thị đi xuống từ trái sang phải).</li>
            </ul>
          </div>
        `,
        formulas: [
          '\\frac{f(x_2) - f(x_1)}{x_2 - x_1} > 0 \\implies f \\text{ đồng biến}',
          '\\frac{f(x_2) - f(x_1)}{x_2 - x_1} < 0 \\implies f \\text{ nghịch biến}'
        ],
        keyNotes: [
          'Điều kiện xác định: phân thức mẫu $\\ne 0$; căn bậc chẵn biểu thức $\\ge 0$; căn ở mẫu biểu thức $> 0$.'
        ],
        diagramType: 'quadratic',
        sgkRef: '10-CH6-B15',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-16',
        title: 'Bài 16. Hàm số bậc hai.',
        grade: 10,
        chapterIndex: 6,
        chapterTitle: 'CHƯƠNG VI. HÀM SỐ, ĐỒ THỊ VÀ ỨNG DỤNG.',
        theoryHtml: `
          <p>Hàm số bậc hai $y = ax^2 + bx + c$ ($a \\ne 0$) có đồ thị là một Parabol $(P)$:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Toạ độ đỉnh:</strong> $I\\left(-\\frac{b}{2a}; -\\frac{\\Delta}{4a}\\right)$ với $\\Delta = b^2 - 4ac$.</p>
            <p><strong>2. Trục đối xứng:</strong> Đường thẳng $x = -\\frac{b}{2a}$.</p>
            <p><strong>3. Bề lõm của Parabol:</strong></p>
            <ul class="list-disc list-inside pl-2">
              <li>$a > 0$: Bề lõm quay lên trên. Hàm số nghịch biến trên $(-\\infty; -b/2a)$ và đồng biến trên $(-b/2a; +\\infty)$. Đạt GTNN tại đỉnh $I$.</li>
              <li>$a < 0$: Bề lõm quay xuống dưới. Hàm số đồng biến trên $(-\\infty; -b/2a)$ và nghịch biến trên $(-b/2a; +\\infty)$. Đạt GTLN tại đỉnh $I$.</li>
            </ul>
          </div>
        `,
        formulas: [
          'I\\left(-\\frac{b}{2a}; -\\frac{\\Delta}{4a}\\right), \\quad x = -\\frac{b}{2a}',
          'a > 0 \\implies y_{\\min} = -\\frac{\\Delta}{4a}; \\quad a < 0 \\implies y_{\\max} = -\\frac{\\Delta}{4a}'
        ],
        keyNotes: [
          'Tung độ đỉnh chính là giá trị cực trị toàn cục của parabol trên toàn $\\mathbb{R}$.',
          'Giao với trục tung $Oy$ tại điểm $(0; c)$. Giao với trục hoành $Ox$ là các nghiệm của $ax^2 + bx + c = 0$.'
        ],
        diagramType: 'quadratic',
        diagramParams: { a: 1, b: 0, c: 0 },
        sgkRef: '10-CH6-B16',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-17',
        title: 'Bài 17. Dấu của tam thức bậc hai.',
        grade: 10,
        chapterIndex: 6,
        chapterTitle: 'CHƯƠNG VI. HÀM SỐ, ĐỒ THỊ VÀ ỨNG DỤNG.',
        theoryHtml: `
          <p>Định lý về dấu của tam thức bậc hai $f(x) = ax^2 + bx + c$ ($a \\ne 0$):</p>
          <div class="space-y-1.5 mt-2">
            <p>- Nếu $\\Delta < 0$: $f(x)$ cùng dấu với hệ số $a$ với mọi $x \\in \\mathbb{R}$.</p>
            <p>- Nếu $\\Delta = 0$: $f(x)$ cùng dấu với hệ số $a$ với mọi $x \\ne -\\frac{b}{2a}$.</p>
            <p>- Nếu $\\Delta > 0$: $f(x)$ có hai nghiệm phân biệt $x_1 < x_2$. Quy tắc nhớ: <em>"Trong trái, ngoài cùng"</em> (trong khoảng $(x_1; x_2)$ trái dấu với $a$, ngoài đoạn $[x_1; x_2]$ cùng dấu với $a$).</p>
          </div>
        `,
        formulas: [
          'ax^2 + bx + c > 0 \\, (\\forall x \\in \\mathbb{R}) \\iff \\begin{cases} a > 0 \\\\ \\Delta < 0 \\end{cases}',
          'ax^2 + bx + c \\le 0 \\, (\\forall x \\in \\mathbb{R}) \\iff \\begin{cases} a < 0 \\\\ \\Delta \\le 0 \\end{cases}'
        ],
        keyNotes: [
          'Nếu bất phương trình chứa tham số ở vị trí $a$, bắt buộc phải xét trường hợp $a = 0$ trước.',
          'Chú ý dấu đẳng thức: $f(x) \\ge 0 \\, (\\forall x) \\iff a > 0$ và $\\Delta \\le 0$.'
        ],
        diagramType: 'quadratic',
        diagramParams: { a: 1, b: -2, c: -3 },
        sgkRef: '10-CH6-B17',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-18-pt',
        title: 'Bài 18. Phương trình quy về phương trình bậc hai.',
        grade: 10,
        chapterIndex: 6,
        chapterTitle: 'CHƯƠNG VI. HÀM SỐ, ĐỒ THỊ VÀ ỨNG DỤNG.',
        theoryHtml: `
          <p>Hai dạng phương trình chứa căn bậc hai quy về phương trình bậc hai chuẩn GDPT 2018:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>Dạng 1:</strong> $\\sqrt{ax^2 + bx + c} = \\sqrt{dx^2 + ex + f}$.</p>
            <p>Phương pháp: Bình phương hai vế thu được $ax^2 + bx + c = dx^2 + ex + f$. Giải phương trình rồi THỬ LẠI các nghiệm vào căn để kết luận nghiệm đúng.</p>
            <p><strong>Dạng 2:</strong> $\\sqrt{ax^2 + bx + c} = dx + e$.</p>
            <p>Phương pháp: Bình phương hai vế $ax^2 + bx + c = (dx + e)^2$ rồi thử lại các nghiệm vào phương trình ban đầu (hoặc đặt điều kiện $dx + e \\ge 0$).</p>
          </div>
        `,
        formulas: [
          '\\sqrt{f(x)} = \\sqrt{g(x)} \\implies f(x) = g(x) \\quad (\\text{sau đó thử lại})',
          '\\sqrt{f(x)} = g(x) \\iff \\begin{cases} g(x) \\ge 0 \\\\ f(x) = [g(x)]^2 \\end{cases}'
        ],
        keyNotes: [
          'Thao tác bình phương là phép biến đổi HỆ QUẢ, có thể làm xuất hiện nghiệm ngoại lai; do đó bước THỬ LẠI nghiệm là bắt buộc.'
        ],
        diagramType: 'quadratic',
        sgkRef: '10-CH6-B18',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-rev6',
        title: 'Bài tập cuối chương VI.',
        grade: 10,
        chapterIndex: 6,
        chapterTitle: 'CHƯƠNG VI. HÀM SỐ, ĐỒ THỊ VÀ ỨNG DỤNG.',
        theoryHtml: `
          <p>Ứng dụng thực tiễn của hàm số bậc hai:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Quỹ đạo chuyển động ném xiên của vật thể dưới tác dụng của trọng lực là đường Parabol.</li>
            <li>Thiết kế cổng vòm Parabol, mặt cầu dây võng, gương hội tụ chảo parabol thu sóng vệ tinh.</li>
            <li>Bài toán kinh tế tối ưu hoá doanh thu $R(p) = p \\cdot q(p)$ và lợi nhuận sản xuất.</li>
          </ul>
        `,
        formulas: [
          'h(t) = h_0 + v_0 t - \\frac{1}{2}g t^2 \\quad (\\text{quỹ đạo rơi tự do / ném vật})',
          'y_{\\max} = -\\frac{\\Delta}{4a} \\quad (a < 0)'
        ],
        keyNotes: [
          'Đỉnh Parabol ứng với độ cao lớn nhất đạt được hoặc tầm bắn xa nhất trong bài toán ném xiên.'
        ],
        diagramType: 'quadratic',
        sgkRef: '10-CH6-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG VII. PHƯƠNG PHÁP TOẠ ĐỘ TRONG MẶT PHẲNG
  // =========================================================================
  {
    title: 'CHƯƠNG VII. PHƯƠNG PHÁP TOẠ ĐỘ TRONG MẶT PHẲNG.',
    grade: 10,
    lessons: [
      {
        id: '10-19',
        title: 'Bài 19. Phương trình đường thẳng.',
        grade: 10,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. PHƯƠNG PHÁP TOẠ ĐỘ TRONG MẶT PHẲNG.',
        theoryHtml: `
          <p>Các dạng phương trình của đường thẳng trong mặt phẳng $Oxy$:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Vectơ pháp tuyến & Phương trình tổng quát:</strong></p>
            <p>Đường thẳng đi qua $M(x_0; y_0)$ có VTPT $\\vec{n}=(a; b)$ ($a^2+b^2 \\ne 0$): $a(x-x_0) + b(y-y_0) = 0 \\iff ax + by + c = 0$.</p>
            <p><strong>2. Vectơ chỉ phương & Phương trình tham số:</strong></p>
            <p>Đường thẳng đi qua $M(x_0; y_0)$ có VTCP $\\vec{u}=(u_1; u_2)$: $\\begin{cases} x = x_0 + u_1 t \\\\ y = y_0 + u_2 t \\end{cases}$ ($t \\in \\mathbb{R}$).</p>
          </div>
        `,
        formulas: [
          'ax + by + c = 0 \\quad (\\vec{n} = (a; b))',
          '\\begin{cases} x = x_0 + u_1 t \\\\ y = y_0 + u_2 t \\end{cases} \\quad (\\vec{u} = (u_1; u_2))',
          '\\vec{u} = (u_1; u_2) \\iff \\vec{n} = (-u_2; u_1)'
        ],
        keyNotes: [
          'Chuyển đổi: VTCP $\\vec{u} = (a; b) \\to$ VTPT $\\vec{n} = (-b; a)$ hoặc $(b; -a)$.',
          'Đường thẳng song song với $ax + by + c = 0$ có dạng $ax + by + c\' = 0$ ($c\' \\ne c$).'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH7-B19',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-20',
        title: 'Bài 20. Đường thẳng trong mặt phẳng toạ độ.',
        grade: 10,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. PHƯƠNG PHÁP TOẠ ĐỘ TRONG MẶT PHẲNG.',
        theoryHtml: `
          <p>Vị trí tương đối, góc và khoảng cách giữa hai đường thẳng:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Vị trí tương đối của $\\Delta_1$ và $\\Delta_2$:</strong> Xét nghiệm hệ hai phương trình bậc nhất hai ẩn (cắt nhau, song song hoặc trùng nhau).</p>
            <p><strong>2. Góc giữa hai đường thẳng:</strong> $\\cos(\\Delta_1, \\Delta_2) = \\frac{|\\vec{n}_1 \\cdot \\vec{n}_2|}{|\\vec{n}_1| |\\vec{n}_2|} = \\frac{|a_1 a_2 + b_1 b_2|}{\\sqrt{a_1^2+b_1^2}\\sqrt{a_2^2+b_2^2}}$.</p>
            <p><strong>3. Khoảng cách từ điểm $M(x_0; y_0)$ đến $\\Delta: ax + by + c = 0$:</strong></p>
            <p>$$d(M, \\Delta) = \\frac{|ax_0 + by_0 + c|}{\\sqrt{a^2 + b^2}}$$</p>
          </div>
        `,
        formulas: [
          'd(M, \\Delta) = \\frac{|ax_0 + by_0 + c|}{\\sqrt{a^2 + b^2}}',
          '\\cos(\\Delta_1, \\Delta_2) = \\frac{|a_1 a_2 + b_1 b_2|}{\\sqrt{a_1^2+b_1^2}\\sqrt{a_2^2+b_2^2}}',
          '\\Delta_1 \\perp \\Delta_2 \\iff a_1 a_2 + b_1 b_2 = 0'
        ],
        keyNotes: [
          'Góc giữa hai đường thẳng luôn là góc nhọn hoặc góc vuông: $0^\\circ \\le \\varphi \\le 90^\\circ$. Do đó tử số trong công thức tính cosin luôn có trị tuyệt đối.',
          'Khoảng cách giữa hai đường thẳng song song: Chọn 1 điểm bất kì trên đường thứ nhất rồi tính khoảng cách tới đường thứ hai.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH7-B20',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-18',
        title: 'Bài 18 (Cũ). Phương trình đường thẳng và đường tròn.',
        grade: 10,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. PHƯƠNG PHÁP TOẠ ĐỘ TRONG MẶT PHẲNG.',
        theoryHtml: `
          <p>Tổng hợp toạ độ phẳng: Đường thẳng qua $M(x_0; y_0)$ có VTPT $\\vec{n}=(a; b)$: $a(x-x_0) + b(y-y_0) = 0$. Đường tròn tâm $I(a; b)$ bán kính $R$.</p>
        `,
        formulas: [
          '\\Delta: ax + by + c = 0',
          'd(M, \\Delta) = \\frac{|ax_0 + by_0 + c|}{\\sqrt{a^2 + b^2}}',
          '(C): (x - a)^2 + (y - b)^2 = R^2'
        ],
        keyNotes: [
          'VTCP $\\vec{u} = (u_1; u_2) \\Rightarrow$ VTPT $\\vec{n} = (-u_2; u_1)$.',
          'Vị trí tương đối: $d(I, \\Delta) < R$ cắt tại 2 điểm; $d=R$ tiếp xúc; $d > R$ không giao.'
        ],
        diagramType: 'circle',
        sgkRef: '10-CH7-B18-OLD',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-21',
        title: 'Bài 21. Đường tròn trong mặt phẳng toạ độ.',
        grade: 10,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. PHƯƠNG PHÁP TOẠ ĐỘ TRONG MẶT PHẲNG.',
        theoryHtml: `
          <p>Phương trình đường tròn $(C)$ trong mặt phẳng toạ độ $Oxy$:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Dạng chính tắc:</strong> Tâm $I(a; b)$, bán kính $R > 0$ có phương trình: $(x - a)^2 + (y - b)^2 = R^2$.</p>
            <p><strong>2. Dạng tổng quát:</strong> $x^2 + y^2 - 2ax - 2by + c = 0$ là đường tròn khi và chỉ khi $a^2 + b^2 - c > 0$. Khi đó tâm $I(a; b)$ và $R = \\sqrt{a^2 + b^2 - c}$.</p>
            <p><strong>3. Phương trình tiếp tuyến tại $M_0(x_0; y_0) \\in (C)$:</strong></p>
            <p>$$(x_0 - a)(x - a) + (y_0 - b)(y - b) = R^2$$</p>
          </div>
        `,
        formulas: [
          '(x - a)^2 + (y - b)^2 = R^2',
          'R = \\sqrt{a^2 + b^2 - c} \\quad (a^2 + b^2 - c > 0)',
          'd(I, \\Delta) = R \\iff \\Delta \\text{ tiếp xúc với đường tròn}'
        ],
        keyNotes: [
          'Hệ số của $x^2$ và $y^2$ trong phương trình tổng quát phải bằng nhau và không có số hạng tích $xy$.',
          'Đường tròn qua 3 điểm (tam giác): Thay toạ độ 3 điểm vào phương trình tổng quát để giải hệ phương trình 3 ẩn $a, b, c$.'
        ],
        diagramType: 'circle',
        sgkRef: '10-CH7-B21',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-22',
        title: 'Bài 22. Ba đường conic.',
        grade: 10,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. PHƯƠNG PHÁP TOẠ ĐỘ TRONG MẶT PHẲNG.',
        theoryHtml: `
          <p>Phương trình chính tắc của ba đường Conic kinh điển:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Elip $(E)$:</strong> $\\frac{x^2}{a^2} + \\frac{y^2}{b^2} = 1$ ($a > b > 0$). Tiêu cự $2c$ với $c^2 = a^2 - b^2$. Tiêu điểm $F_1(-c; 0), F_2(c; 0)$. Độ dài trục lớn $2a$, trục nhỏ $2b$.</p>
            <p><strong>2. Hypebol $(H)$:</strong> $\\frac{x^2}{a^2} - \\frac{y^2}{b^2} = 1$ ($a, b > 0$). Tiêu cự $2c$ với $c^2 = a^2 + b^2$. Hai tiệm cận $y = \\pm \\frac{b}{a}x$.</p>
            <p><strong>3. Parabol $(P)$:</strong> $y^2 = 2px$ ($p > 0$ là tham số tiêu). Tiêu điểm $F\\left(\\frac{p}{2}; 0\\right)$, đường chuẩn $\\Delta: x = -\\frac{p}{2}$.</p>
          </div>
        `,
        formulas: [
          '\\frac{x^2}{a^2} + \\frac{y^2}{b^2} = 1 \\implies c^2 = a^2 - b^2 \\quad (\\text{Elip})',
          '\\frac{x^2}{a^2} - \\frac{y^2}{b^2} = 1 \\implies c^2 = a^2 + b^2 \\quad (\\text{Hypebol})',
          'y^2 = 2px \\implies F\\left(\\frac{p}{2}; 0\\right), \\, x = -\\frac{p}{2} \\quad (\\text{Parabol})'
        ],
        keyNotes: [
          'Tâm sai $e = \\frac{c}{a}$: Elip có $0 < e < 1$, Parabol có $e = 1$, Hypebol có $e > 1$.',
          'Quỹ đạo của các hành tinh quay quanh Mặt Trời là các đường Elip nhận Mặt Trời làm một tiêu điểm (Định luật Kepler).'
        ],
        diagramType: 'circle',
        sgkRef: '10-CH7-B22',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-rev7',
        title: 'Bài tập cuối chương VII.',
        grade: 10,
        chapterIndex: 7,
        chapterTitle: 'CHƯƠNG VII. PHƯƠNG PHÁP TOẠ ĐỘ TRONG MẶT PHẲNG.',
        theoryHtml: `
          <p>Hệ thống hoá phương pháp toạ độ hoá giải các bài toán hình học phẳng phẳng:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Lập phương trình tiếp tuyến chung của hai đường tròn.</li>
            <li>Tìm điểm thuộc đường thẳng cách đều hai điểm hoặc có tổng khoảng cách nhỏ nhất.</li>
            <li>Ứng dụng ba đường conic trong thiết kế tháp làm nguội hypeboloid, gương phản xạ parabol.</li>
          </ul>
        `,
        formulas: [
          'd(I, \\Delta) = R, \\quad \\frac{x^2}{a^2} \\pm \\frac{y^2}{b^2} = 1'
        ],
        keyNotes: [
          'Gốc toạ độ $O$ nên chọn trùng với một đỉnh hoặc trung điểm cạnh có tính chất vuông góc để đơn giản hoá biểu thức toạ độ.'
        ],
        diagramType: 'circle',
        sgkRef: '10-CH7-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG VIII. ĐẠI SỐ TỔ HỢP
  // =========================================================================
  {
    title: 'CHƯƠNG VIII. ĐẠI SỐ TỔ HỢP.',
    grade: 10,
    lessons: [
      {
        id: '10-23',
        title: 'Bài 23. Quy tắc đếm.',
        grade: 10,
        chapterIndex: 8,
        chapterTitle: 'CHƯƠNG VIII. ĐẠI SỐ TỔ HỢP.',
        theoryHtml: `
          <p>Hai quy tắc đếm cơ bản của toán học rời rạc:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Quy tắc cộng (Phương án rời rạc):</strong></p>
            <p>Nếu một công việc có thể hoàn thành bởi một trong hai phương án $A$ hoặc $B$ (không trùng lặp), phương án $A$ có $m$ cách, phương án $B$ có $n$ cách thì có $m + n$ cách hoàn thành công việc.</p>
            <p><strong>2. Quy tắc nhân (Công đoạn liên tiếp):</strong></p>
            <p>Nếu một công việc gồm hai công đoạn liên tiếp $1$ và $2$, công đoạn 1 có $m$ cách, với mỗi cách đó công đoạn 2 có $n$ cách thì có $m \\cdot n$ cách hoàn thành công việc.</p>
            <p><strong>3. Sơ đồ hình cây:</strong> Công cụ trực quan liệt kê tất cả các khả năng của bài toán đếm nhiều bước.</p>
          </div>
        `,
        formulas: [
          'N = m + n \\quad (\\text{Quy tắc cộng - Hoặc})',
          'N = m \\cdot n \\quad (\\text{Quy tắc nhân - Và / Liên tiếp})'
        ],
        keyNotes: [
          'Từ khoá phân biệt: "HOẶC" (phương án độc lập) $\\to$ CỘNG; "VÀ" (công đoạn liên hoàn) $\\to$ NHÂN.',
          'Chú ý điều kiện ràng buộc: Chữ số đầu tiên của số tự nhiên phải khác 0 ($a_1 \\ne 0$).'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH8-B23',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-24',
        title: 'Bài 24. Hoán vị, chỉnh hợp và tổ hợp.',
        grade: 10,
        chapterIndex: 8,
        chapterTitle: 'CHƯƠNG VIII. ĐẠI SỐ TỔ HỢP.',
        theoryHtml: `
          <p>Phân biệt chính xác ba khái niệm tổ hợp:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Hoán vị của $n$ phần tử ($P_n$):</strong> Sắp xếp thứ tự $n$ phần tử. $P_n = n! = n(n-1)\\dots 2 \\cdot 1$.</p>
            <p><strong>2. Chỉnh hợp chập $k$ của $n$ ($A_n^k$):</strong> Chọn $k$ phần tử từ $n$ phần tử và CÓ THỨ TỰ ($1 \\le k \\le n$). $A_n^k = \\frac{n!}{(n-k)!}$.</p>
            <p><strong>3. Tổ hợp chập $k$ của $n$ ($C_n^k$):</strong> Chọn $k$ phần tử từ $n$ phần tử và KHÔNG PHÂN BIỆT THỨ TỰ ($0 \\le k \\le n$). $C_n^k = \\frac{n!}{k!(n-k)!}$.</p>
          </div>
        `,
        formulas: [
          'P_n = n!, \\quad A_n^k = \\frac{n!}{(n-k)!}, \\quad C_n^k = \\frac{n!}{k!(n-k)!}',
          'C_n^k = C_n^{n-k}, \\quad C_{n-1}^{k-1} + C_{n-1}^k = C_n^k \\quad (\\text{Công thức Pascal})'
        ],
        keyNotes: [
          'Mẹo nhớ: Có xếp vị trí, phân công chức vụ cụ thể $\\implies A_n^k$; chỉ chọn ra một nhóm đại diện $\\implies C_n^k$.',
          'Quy ước: $0! = 1$ và $C_n^0 = 1$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH8-B24',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-25',
        title: 'Bài 25. Nhị thức Newton.',
        grade: 10,
        chapterIndex: 8,
        chapterTitle: 'CHƯƠNG VIII. ĐẠI SỐ TỔ HỢP.',
        theoryHtml: `
          <p>Khai triển nhị thức Newton cho trường hợp số mũ $n = 4$ và $n = 5$:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>Số mũ $n = 4$:</strong></p>
            <p>$$(a + b)^4 = a^4 + 4a^3b + 6a^2b^2 + 4ab^3 + b^4$$</p>
            <p><strong>Số mũ $n = 5$:</strong></p>
            <p>$$(a + b)^5 = a^5 + 5a^4b + 10a^3b^2 + 10a^2b^3 + 5ab^4 + b^5$$</p>
            <p>Các hệ số nhị thức chính là các số trên hàng tương ứng của Tam giác Pascal.</p>
          </div>
        `,
        formulas: [
          '(a + b)^4 = C_4^0 a^4 + C_4^1 a^3b + C_4^2 a^2b^2 + C_4^3 ab^3 + C_4^4 b^4',
          '(a + b)^5 = C_5^0 a^5 + C_5^1 a^4b + C_5^2 a^3b^2 + C_5^3 a^2b^3 + C_5^4 ab^4 + C_5^5 b^5'
        ],
        keyNotes: [
          'Số số hạng trong khai triển $(a + b)^n$ luôn là $n + 1$ số hạng.',
          'Khi có dấu trừ $(a - b)^n$, dấu của các số hạng sẽ đan xen nhau: $+ , - , + , - , \\dots$'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH8-B25',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-rev8',
        title: 'Bài tập cuối chương VIII.',
        grade: 10,
        chapterIndex: 8,
        chapterTitle: 'CHƯƠNG VIII. ĐẠI SỐ TỔ HỢP.',
        theoryHtml: `
          <p>Tổng kết phương pháp giải bài toán đếm nâng cao:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Phương pháp phần bù: Tính số trường hợp của bài toán phủ định rồi lấy tổng số khả năng trừ đi.</li>
            <li>Phương pháp vách ngăn (bài toán chia kẹo Euler).</li>
            <li>Tìm hệ số của số hạng chứa $x^k$ trong khai triển nhị thức $(ax + b)^n$.</li>
          </ul>
        `,
        formulas: [
          'n(A) = n(\\Omega) - n(\\overline{A}) \\quad (\\text{Phương pháp biến cố đối / phần bù})'
        ],
        keyNotes: [
          'Bài toán yêu cầu "có ít nhất một..." nên ưu tiên giải bằng phương pháp phần bù (tính trường hợp "không có cái nào").'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH8-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHƯƠNG IX. TÍNH XÁC SUẤT THEO ĐỊNH NGHĨA CỔ ĐIỂN
  // =========================================================================
  {
    title: 'CHƯƠNG IX. TÍNH XÁC SUẤT THEO ĐỊNH NGHĨA CỔ ĐIỂN.',
    grade: 10,
    lessons: [
      {
        id: '10-26',
        title: 'Bài 26. Biến cố và định nghĩa cổ điển của xác suất.',
        grade: 10,
        chapterIndex: 9,
        chapterTitle: 'CHƯƠNG IX. TÍNH XÁC SUẤT THEO ĐỊNH NGHĨA CỔ ĐIỂN.',
        theoryHtml: `
          <p>Phép thử ngẫu nhiên và định nghĩa xác suất cổ điển:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Không gian mẫu $\\Omega$:</strong> Tập hợp tất cả các kết quả có thể xảy ra của một phép thử ngẫu nhiên.</p>
            <p><strong>2. Biến cố $A$:</strong> Là một tập con của không gian mẫu ($A \\subset \\Omega$).</p>
            <p><strong>3. Định nghĩa cổ điển của xác suất:</strong></p>
            <p>Nếu các kết quả của không gian mẫu hữu hạn và ĐỒNG KHẢ NĂNG xuất hiện thì:</p>
            <p>$$P(A) = \\frac{n(A)}{n(\\Omega)} = \\frac{|A|}{|\\Omega|}$$</p>
          </div>
        `,
        formulas: [
          'P(A) = \\frac{n(A)}{n(\\Omega)}, \\quad 0 \\le P(A) \\le 1',
          'P(\\Omega) = 1, \\quad P(\\emptyset) = 0, \\quad P(\\overline{A}) = 1 - P(A)'
        ],
        keyNotes: [
          'Điều kiện áp dụng định nghĩa cổ điển: Không gian mẫu hữu hạn và các kết quả là ĐỒNG KHẢ NĂNG.',
          'Xác suất biến cố đối: $P(\\overline{A}) = 1 - P(A)$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH9-B26',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-27',
        title: 'Bài 27. Thực hành tính xác suất theo định nghĩa cổ điển.',
        grade: 10,
        chapterIndex: 9,
        chapterTitle: 'CHƯƠNG IX. TÍNH XÁC SUẤT THEO ĐỊNH NGHĨA CỔ ĐIỂN.',
        theoryHtml: `
          <p>Kỹ năng phối hợp các quy tắc đếm (Quy tắc cộng, Quy tắc nhân, Chỉnh hợp, Tổ hợp) để tính xác suất:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>Bước 1:</strong> Xác định phép thử và tính số phần tử không gian mẫu $n(\\Omega)$.</p>
            <p><strong>Bước 2:</strong> Mô tả biến cố $A$ dưới dạng các trường hợp loại trừ nhau và tính $n(A)$.</p>
            <p><strong>Bước 3:</strong> Tính tỉ số $P(A) = \\frac{n(A)}{n(\\Omega)}$.</p>
          </div>
        `,
        formulas: [
          'P(A) = \\frac{C_a^k C_b^m}{C_{a+b}^{k+m}} \\quad (\\text{Bài toán lấy mẫu không hoàn lại})'
        ],
        keyNotes: [
          'Lấy ngẫu nhiên $k$ quả cầu từ hộp có $n$ quả cầu: Không gian mẫu luôn là $n(\\Omega) = C_n^k$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH9-B27',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-rev9',
        title: 'Bài tập cuối chương IX.',
        grade: 10,
        chapterIndex: 9,
        chapterTitle: 'CHƯƠNG IX. TÍNH XÁC SUẤT THEO ĐỊNH NGHĨA CỔ ĐIỂN.',
        theoryHtml: `
          <p>Tổng kết bài toán tính xác suất trong đề thi tốt nghiệp THPT và kiểm tra:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Bài toán rút thẻ, gieo xúc xắc, tung đồng xu nhiều lần.</li>
            <li>Bài toán chọn người xếp hàng hoặc lập ban cán sự.</li>
            <li>Bài toán chia bài, bốc thăm trúng thưởng.</li>
          </ul>
        `,
        formulas: [
          'P(A \\cup B) = P(A) + P(B) \\quad (\\text{khi } A \\cap B = \\emptyset)',
          'P(\\overline{A}) = 1 - P(A)'
        ],
        keyNotes: [
          'Khi bài toán có nhiều trường hợp phức tạp, hãy kiểm tra xem biến cố đối $\\overline{A}$ có ít trường hợp hơn không.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CH9-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM (HỌC KỲ II)
  // =========================================================================
  {
    title: 'HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM.',
    grade: 10,
    lessons: [
      {
        id: '10-hd3',
        title: 'Một số nội dung cho hoạt động trải nghiệm hình học.',
        grade: 10,
        chapterIndex: 10,
        chapterTitle: 'HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM.',
        theoryHtml: `
          <p>Thực hành đo đạc ngoài trời và gấp hình học:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Dụng cụ giác kế:</strong> Đo góc nâng và góc hạ tại thực địa.</p>
            <p><strong>2. Vẽ các đường conic trong đời sống:</strong></p>
            <p>- Vẽ đường elip bằng phương pháp sợi dây garô hai cọc tiêu (định nghĩa tiêu điểm $MF_1 + MF_2 = 2a$).</p>
            <p>- Gấp giấy để tạo đường parabol từ một điểm và một đường thẳng.</p>
          </div>
        `,
        formulas: [
          'MF_1 + MF_2 = 2a \\quad (\\text{Vẽ elip bằng sợi dây})'
        ],
        keyNotes: [
          'Sợi dây có độ dài không đổi $2a > F_1 F_2 = 2c$ cố định tại hai đầu tiêu điểm $F_1, F_2$.'
        ],
        diagramType: 'circle',
        sgkRef: '10-HD-HH',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-hd4',
        title: 'Ước tính số cá thể trong một quần thể.',
        grade: 10,
        chapterIndex: 10,
        chapterTitle: 'HOẠT ĐỘNG THỰC HÀNH TRẢI NGHIỆM.',
        theoryHtml: `
          <p>Phương pháp đánh dấu bắt lại (Lincoln - Petersen):</p>
          <div class="space-y-1.5 mt-2">
            <p>Để ước tính kích thước cá thể $N$ của một quần thể động vật hoang dã:</p>
            <p>1. Bắt $M$ cá thể, đánh dấu rồi thả lại vào quần thể.</p>
            <p>2. Sau một thời gian, bắt ngẫu nhiên $n$ cá thể, đếm số cá thể có dấu $m$.</p>
            <p>3. Dựa trên tỉ lệ đồng dạng xác suất: $\\frac{m}{n} \\approx \\frac{M}{N} \\implies N \\approx \\frac{M \\cdot n}{m}$.</p>
          </div>
        `,
        formulas: [
          '\\hat{N} = \\frac{M \\cdot n}{m} \\quad (\\text{Ước tính cỡ quần thể})'
        ],
        keyNotes: [
          'Giả định: Các cá thể có dấu phân bố đều và việc đánh dấu không làm thay đổi xác suất bị bắt lại.'
        ],
        diagramType: 'histogram',
        sgkRef: '10-HD-QT',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHUYÊN ĐỀ 1. HỆ PHƯƠNG TRÌNH BẬC NHẤT BA ẨN
  // =========================================================================
  {
    title: 'CHUYÊN ĐỀ 1. HỆ PHƯƠNG TRÌNH BẬC NHẤT BA ẨN.',
    grade: 10,
    lessons: [
      {
        id: '10-cd1-b1',
        title: 'Bài 1. Hệ phương trình bậc nhất ba ẩn.',
        grade: 10,
        chapterIndex: 11,
        chapterTitle: 'CHUYÊN ĐỀ 1. HỆ PHƯƠNG TRÌNH BẬC NHẤT BA ẨN.',
        theoryHtml: `
          <p>Hệ phương trình bậc nhất ba ẩn có dạng chuẩn:</p>
          $$\\begin{cases} a_1 x + b_1 y + c_1 z = d_1 \\\\ a_2 x + b_2 y + c_2 z = d_2 \\\\ a_3 x + b_3 y + c_3 z = d_3 \\end{cases}$$
          <div class="space-y-1.5 mt-2">
            <p><strong>Phương pháp khử Gauss (khử dần ẩn số):</strong></p>
            <ol class="list-decimal list-inside pl-2">
              <li>Biến đổi hệ về dạng tam giác bằng các phép biến đổi sơ cấp.</li>
              <li>Giải tìm $z$ từ phương trình cuối, thế ngược lên tìm $y$ và $x$.</li>
            </ol>
          </div>
        `,
        formulas: [
          '\\begin{cases} a_1 x + b_1 y + c_1 z = d_1 \\\\ b\'_2 y + c\'_2 z = d\'_2 \\\\ c\'\'_3 z = d\'\'_3 \\end{cases} \\quad (\\text{Hệ tam giác})'
        ],
        keyNotes: [
          'Phép biến đổi sơ cấp: Hoán vị hai phương trình; nhân một phương trình với số khác 0; cộng vào một phương trình một bội số của phương trình khác.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CD1-B1',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-cd1-b2',
        title: 'Bài 2. Ứng dụng của hệ phương trình bậc nhất ba ẩn.',
        grade: 10,
        chapterIndex: 11,
        chapterTitle: 'CHUYÊN ĐỀ 1. HỆ PHƯƠNG TRÌNH BẬC NHẤT BA ẨN.',
        theoryHtml: `
          <p>Ứng dụng hệ ba ẩn trong vật lý, hoá học và cân bằng kinh tế:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Cân bằng phản ứng hoá học phức tạp (bảo toàn nguyên tố).</li>
            <li>Tính dòng điện trong mạng điện nhiều nhánh kín (Định luật Kirchhoff).</li>
            <li>Mô hình cân bằng cung - cầu thị trường của 3 loại hàng hoá liên quan.</li>
            <li>Xác định Parabol $y = ax^2 + bx + c$ đi qua 3 điểm phân biệt cho trước.</li>
          </ul>
        `,
        formulas: [
          '\\sum I_{\\text{vào}} = \\sum I_{\\text{ra}}, \\quad \\sum E = \\sum I \\cdot R'
        ],
        keyNotes: [
          'Khi giải hệ bằng máy tính cầm tay, hãy đảm bảo các phương trình đã được xếp đúng thứ tự ẩn $x, y, z$ và hệ số tự do chuyển sang vế phải.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CD1-B2',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-cd1-rev',
        title: 'Bài tập cuối chuyên đề 1.',
        grade: 10,
        chapterIndex: 11,
        chapterTitle: 'CHUYÊN ĐỀ 1. HỆ PHƯƠNG TRÌNH BẬC NHẤT BA ẨN.',
        theoryHtml: `
          <p>Tổng kết chuyên đề 1: Nhận diện hệ có nghiệm duy nhất, vô số nghiệm hoặc vô nghiệm thông qua phương pháp ma trận và phương pháp thế Gauss.</p>
        `,
        formulas: [
          '0x + 0y + 0z = d \\quad (d \\ne 0 \\implies \\text{vô nghiệm})'
        ],
        keyNotes: [
          'Hệ vô số nghiệm xuất hiện khi một phương trình là tổ hợp tuyến tính của các phương trình còn lại.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CD1-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHUYÊN ĐỀ 2. PHƯƠNG PHÁP QUY NẠP TOÁN HỌC, NHỊ THỨC NEWTON
  // =========================================================================
  {
    title: 'CHUYÊN ĐỀ 2. PHƯƠNG PHÁP QUY NẠP TOÁN HỌC, NHỊ THỨC NEWTON.',
    grade: 10,
    lessons: [
      {
        id: '10-cd2-b3',
        title: 'Bài 3. Phương pháp quy nạp toán học.',
        grade: 10,
        chapterIndex: 12,
        chapterTitle: 'CHUYÊN ĐỀ 2. PHƯƠNG PHÁP QUY NẠP TOÁN HỌC, NHỊ THỨC NEWTON.',
        theoryHtml: `
          <p>Phương pháp chứng minh mệnh đề $P(n)$ đúng với mọi số tự nhiên $n \\ge p$:</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>Bước 1 (Bước cơ sở):</strong> Kiểm tra mệnh đề đúng với $n = p$.</p>
            <p><strong>Bước 2 (Bước quy nạp):</strong> Giả sử mệnh đề đúng với $n = k \\ge p$ (gọi là giả thiết quy nạp), tức là $P(k)$ đúng. Cần chứng minh mệnh đề cũng đúng với $n = k + 1$, tức là $P(k + 1)$ đúng.</p>
            <p><strong>Kết luận:</strong> Theo nguyên lý quy nạp toán học, mệnh đề $P(n)$ đúng với mọi $n \\ge p$.</p>
          </div>
        `,
        formulas: [
          '1 + 2 + \\dots + n = \\frac{n(n+1)}{2}',
          '1^2 + 2^2 + \\dots + n^2 = \\frac{n(n+1)(2n+1)}{6}',
          '(1 + a)^n \\ge 1 + na \\quad (a > -1, n \\in \\mathbb{N}^*, \\text{BĐT Bernoulli})'
        ],
        keyNotes: [
          'Không được bỏ qua Bước 1 (bước cơ sở), vì giả thiết quy nạp có thể suy ra vô lý nếu không có mốc khởi đầu đúng.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CD2-B3',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-cd2-b4',
        title: 'Bài 4. Nhị thức Newton.',
        grade: 10,
        chapterIndex: 12,
        chapterTitle: 'CHUYÊN ĐỀ 2. PHƯƠNG PHÁP QUY NẠP TOÁN HỌC, NHỊ THỨC NEWTON.',
        theoryHtml: `
          <p>Công thức nhị thức Newton tổng quát với số mũ $n$ nguyên dương bất kì:</p>
          $$(a + b)^n = \\sum_{k=0}^n C_n^k a^{n-k} b^k = C_n^0 a^n + C_n^1 a^{n-1}b + \\dots + C_n^n b^n$$
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Số hạng tổng quát thứ $k + 1$:</strong> $T_{k+1} = C_n^k a^{n-k} b^k$.</p>
            <p><strong>2. Tam giác Pascal và tính chất các hệ số:</strong></p>
            <p>$C_n^0 + C_n^1 + \\dots + C_n^n = 2^n$; $\\quad C_n^0 - C_n^1 + C_n^2 - \\dots + (-1)^n C_n^n = 0$.</p>
          </div>
        `,
        formulas: [
          '(a + b)^n = \\sum_{k=0}^n C_n^k a^{n-k} b^k',
          'T_{k+1} = C_n^k a^{n-k} b^k',
          '\\sum_{k=0}^n C_n^k = 2^n'
        ],
        keyNotes: [
          'Số hạng không chứa $x$ tương ứng với số mũ của $x$ bằng 0.',
          'Số hạng có hệ số lớn nhất: So sánh $T_{k+1} \\ge T_k$ và $T_{k+1} \\ge T_{k+2}$.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CD2-B4',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-cd2-rev',
        title: 'Bài tập cuối chuyên đề 2.',
        grade: 10,
        chapterIndex: 12,
        chapterTitle: 'CHUYÊN ĐỀ 2. PHƯƠNG PHÁP QUY NẠP TOÁN HỌC, NHỊ THỨC NEWTON.',
        theoryHtml: `
          <p>Tổng kết ứng dụng của quy nạp và nhị thức Newton:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Chứng minh các bài toán chia hết và bất đẳng thức giải tích.</li>
            <li>Tính tổng các hệ số tổ hợp bằng phương pháp chọn giá trị đặc biệt $x = 1, x = -1$.</li>
            <li>Đạo hàm và tích phân nhị thức Newton để tính tổng tổ hợp nâng cao.</li>
          </ul>
        `,
        formulas: [
          'C_n^0 + C_n^1 + \\dots + C_n^n = 2^n'
        ],
        keyNotes: [
          'Thử thay $a=1, b=1$ hoặc $a=1, b=-1$ để tính tổng các tổ hợp nhanh chóng.'
        ],
        diagramType: 'numberLine',
        sgkRef: '10-CD2-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  },

  // =========================================================================
  // CHUYÊN ĐỀ 3. BA ĐƯỜNG CONIC VÀ ỨNG DỤNG
  // =========================================================================
  {
    title: 'CHUYÊN ĐỀ 3. BA ĐƯỜNG CONIC VÀ ỨNG DỤNG.',
    grade: 10,
    lessons: [
      {
        id: '10-cd3-b5',
        title: 'Bài 5. Elip.',
        grade: 10,
        chapterIndex: 13,
        chapterTitle: 'CHUYÊN ĐỀ 3. BA ĐƯỜNG CONIC VÀ ỨNG DỤNG.',
        theoryHtml: `
          <p>Nghiên cứu sâu về đường Elip $(E): \\frac{x^2}{a^2} + \\frac{y^2}{b^2} = 1$ ($a > b > 0$):</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Bán kính qua tiêu:</strong> $MF_1 = a + ex$, $MF_2 = a - ex$ với tâm sai $e = \\frac{c}{a} < 1$.</p>
            <p><strong>2. Đường chuẩn của Elip:</strong> Hai đường chuẩn tương ứng là $\\Delta_1: x = -\\frac{a}{e} = -\\frac{a^2}{c}$ và $\\Delta_2: x = \\frac{a}{e} = \\frac{a^2}{c}$.</p>
            <p><strong>3. Tính chất quang học:</strong> Tia sáng phát ra từ một tiêu điểm sau khi phản xạ qua elip sẽ hội tụ chính xác tại tiêu điểm còn lại.</p>
          </div>
        `,
        formulas: [
          'MF_1 = a + ex, \\quad MF_2 = a - ex',
          '\\Delta_{1,2}: x = \\pm \\frac{a}{e} = \\pm \\frac{a^2}{c}',
          '\\frac{MF_1}{d(M, \\Delta_1)} = e < 1'
        ],
        keyNotes: [
          'Tỉ số giữa khoảng cách từ điểm $M \\in (E)$ đến tiêu điểm và đến đường chuẩn tương ứng luôn bằng tâm sai $e < 1$.'
        ],
        diagramType: 'circle',
        sgkRef: '10-CD3-B5',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-cd3-b6',
        title: 'Bài 6. Hypebol.',
        grade: 10,
        chapterIndex: 13,
        chapterTitle: 'CHUYÊN ĐỀ 3. BA ĐƯỜNG CONIC VÀ ỨNG DỤNG.',
        theoryHtml: `
          <p>Nghiên cứu sâu về Hypebol $(H): \\frac{x^2}{a^2} - \\frac{y^2}{b^2} = 1$ ($a, b > 0$):</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Bán kính qua tiêu:</strong> $MF_1 = |a + ex|$, $MF_2 = |a - ex|$ với tâm sai $e = \\frac{c}{a} > 1$ ($c = \\sqrt{a^2+b^2}$).</p>
            <p><strong>2. Đường chuẩn:</strong> $\\Delta_1: x = -\\frac{a}{e}$, $\\Delta_2: x = \\frac{a}{e}$.</p>
            <p><strong>3. Định vị âm thanh LORAN:</strong> Hiệu khoảng cách từ vị trí phát tín hiệu đến 2 trạm thu là không đổi, tạo nên nhánh Hypebol định vị.</p>
          </div>
        `,
        formulas: [
          '|MF_1 - MF_2| = 2a',
          '\\frac{MF_1}{d(M, \\Delta_1)} = e > 1',
          'y = \\pm \\frac{b}{a}x \\quad (\\text{Phương trình tiệm cận})'
        ],
        keyNotes: [
          'Hypebol vuông khi $a = b$: phương trình $x^2 - y^2 = a^2$, hai tiệm cận vuông góc nhau $y = \\pm x$.'
        ],
        diagramType: 'circle',
        sgkRef: '10-CD3-B6',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-cd3-b7',
        title: 'Bài 7. Parabol.',
        grade: 10,
        chapterIndex: 13,
        chapterTitle: 'CHUYÊN ĐỀ 3. BA ĐƯỜNG CONIC VÀ ỨNG DỤNG.',
        theoryHtml: `
          <p>Nghiên cứu sâu về Parabol chính tắc $(P): y^2 = 2px$ ($p > 0$):</p>
          <div class="space-y-1.5 mt-2">
            <p><strong>1. Tiêu điểm và đường chuẩn:</strong> $F\\left(\\frac{p}{2}; 0\\right)$, đường chuẩn $\\Delta: x = -\\frac{p}{2}$.</p>
            <p><strong>2. Bán kính qua tiêu:</strong> $MF = d(M, \\Delta) = x_M + \\frac{p}{2}$. Tâm sai $e = 1$.</p>
            <p><strong>3. Ứng dụng quang học:</strong> Chùm tia sáng song song với trục đối xứng sau khi phản xạ trên mặt parabol sẽ hội tụ tại tiêu điểm $F$ (nguyên lý ăng-ten parabol và đèn pha ô tô).</p>
          </div>
        `,
        formulas: [
          'MF = x_M + \\frac{p}{2}',
          'y^2 = 2px \\implies F\\left(\\frac{p}{2}; 0\\right), \\, \\Delta: x = -\\frac{p}{2}'
        ],
        keyNotes: [
          'Mọi điểm trên Parabol luôn cách đều tiêu điểm $F$ và đường chuẩn $\\Delta$.'
        ],
        diagramType: 'quadratic',
        sgkRef: '10-CD3-B7',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-cd3-b8',
        title: 'Bài 8. Sự thống nhất giữa ba đường conic.',
        grade: 10,
        chapterIndex: 13,
        chapterTitle: 'CHUYÊN ĐỀ 3. BA ĐƯỜNG CONIC VÀ ỨNG DỤNG.',
        theoryHtml: `
          <p>Định nghĩa tổng quát thống nhất ba đường conic qua tâm sai $e$:</p>
          <div class="space-y-1.5 mt-2">
            <p>Cho một điểm $F$ cố định (tiêu điểm) và một đường thẳng $\\Delta$ cố định không qua $F$ (đường chuẩn). Tập hợp các điểm $M$ sao cho tỉ số khoảng cách từ $M$ đến $F$ và đến $\\Delta$ bằng một số dương $e$ không đổi:</p>
            <p>$$\\frac{MF}{d(M, \\Delta)} = e$$</p>
            <ul class="list-disc list-inside pl-2">
              <li>Nếu $0 < e < 1$: Đường Conic là một <strong>Elip</strong>.</li>
              <li>Nếu $e = 1$: Đường Conic là một <strong>Parabol</strong>.</li>
              <li>Nếu $e > 1$: Đường Conic là một <strong>Hypebol</strong>.</li>
            </ul>
            <p><strong>Tiết diện mặt nón:</strong> Giao của mặt phẳng với một mặt nón tròn xoay (cắt nghiêng sinh ra elip, song song đường sinh sinh ra parabol, song song trục sinh ra 2 nhánh hypebol).</p>
          </div>
        `,
        formulas: [
          '\\frac{MF}{d(M, \\Delta)} = e \\quad \\begin{cases} 0 < e < 1: \\text{Elip} \\\\ e = 1: \\text{Parabol} \\\\ e > 1: \\text{Hypebol} \\end{cases}'
        ],
        keyNotes: [
          'Đây là định nghĩa hiện đại và đẹp đẽ nhất của hình học giải tích, hợp nhất ba đường cong tưởng chừng riêng biệt vào một công thức duy nhất.'
        ],
        diagramType: 'circle',
        sgkRef: '10-CD3-B8',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      },
      {
        id: '10-cd3-rev',
        title: 'Bài tập cuối chuyên đề 3.',
        grade: 10,
        chapterIndex: 13,
        chapterTitle: 'CHUYÊN ĐỀ 3. BA ĐƯỜNG CONIC VÀ ỨNG DỤNG.',
        theoryHtml: `
          <p>Tổng kết toàn bộ chuyên đề Ba đường Conic và Ứng dụng:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li>Lập phương trình chính tắc của Conic khi biết các yếu tố hình học (tiêu cự, trục lớn/nhỏ, đường chuẩn, qua điểm).</li>
            <li>Chứng minh tính chất tiếp tuyến và quang học của Conic.</li>
            <li>Giải quyết các bài toán kỹ thuật thực tế: quỹ đạo tàu vũ trụ, thiết kế chảo vệ tinh, cổng vòm kiến trúc.</li>
          </ul>
        `,
        formulas: [
          '\\frac{x^2}{a^2} + \\frac{y^2}{b^2} = 1, \\quad \\frac{x^2}{a^2} - \\frac{y^2}{b^2} = 1, \\quad y^2 = 2px'
        ],
        keyNotes: [
          'Tâm sai $e$ quyết định hình dạng và độ dẹt của đường conic.'
        ],
        diagramType: 'circle',
        sgkRef: '10-CD3-REV',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Toán 10 GDPT 2018'
      }
    ]
  }
];
