import { Chapter, Lesson } from '../types/math';

/**
 * BỔ SUNG TOÀN DIỆN CHƯƠNG TRÌNH TOÁN 11 THEO CHUẨN GDPT 2018
 * Thầy Phạm Bảo Anh - Luyện Thi Toán THPT Quốc Gia
 */
export const SUPPLEMENTARY_LESSONS_11: Lesson[] = [
  // --- CHƯƠNG I: LƯỢNG GIÁC ---
  {
    id: '11-2',
    title: 'Bài 2. Công thức lượng giác (Cộng, Nhân đôi, Biến đổi)',
    grade: 11,
    chapterIndex: 0,
    chapterTitle: 'Chương I. Hàm số lượng giác & Phương trình lượng giác',
    theoryHtml: `
      <p>Hệ thống công thức lượng giác biến đổi bắt buộc phải thuộc lòng:</p>
      <div class="space-y-2 mt-2">
        <p><strong>1. Công thức cộng:</strong></p>
        <p>$\\cos(a \\pm b) = \\cos a \\cos b \\mp \\sin a \\sin b$, $\\quad \\sin(a \\pm b) = \\sin a \\cos b \\pm \\cos a \\sin b$</p>
        <p><strong>2. Công thức nhân đôi và hạ bậc:</strong></p>
        <p>$\\sin 2a = 2\\sin a \\cos a$, $\\quad \\cos 2a = \\cos^2 a - \\sin^2 a = 2\\cos^2 a - 1 = 1 - 2\\sin^2 a$</p>
        <p>$\\cos^2 a = \\frac{1 + \\cos 2a}{2}$, $\\quad \\sin^2 a = \\frac{1 - \\cos 2a}{2}$</p>
        <p><strong>3. Công thức biến đổi tích thành tổng & tổng thành tích:</strong></p>
        <p>$\\cos a \\cos b = \\frac{1}{2}[\\cos(a-b) + \\cos(a+b)]$, $\\quad \\cos u + \\cos v = 2\\cos\\frac{u+v}{2}\\cos\\frac{u-v}{2}$</p>
      </div>
    `,
    formulas: [
      '\\cos(a \\pm b) = \\cos a \\cos b \\mp \\sin a \\sin b',
      '\\sin(a \\pm b) = \\sin a \\cos b \\pm \\cos a \\sin b',
      '\\cos 2a = 2\\cos^2 a - 1 = 1 - 2\\sin^2 a, \\quad \\sin 2a = 2\\sin a \\cos a'
    ],
    keyNotes: [
      'Nhớ quy tắc câu vè: "Cos thì cos cos sin sin, sin thì sin cos cos sin rõ ràng; Cos thì đổi dấu đàng hoàng, Sin thì giữ dấu chẳng màng đổi thay".',
      'Khi giải toán cần chú ý đồng nhất cung góc trước khi áp dụng công thức.'
    ],
    diagramType: 'trig',
    sgkRef: '11-CH1-B2',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-3',
    title: 'Bài 3. Hàm số lượng giác (Chu kỳ & Đồ thị)',
    grade: 11,
    chapterIndex: 0,
    chapterTitle: 'Chương I. Hàm số lượng giác & Phương trình lượng giác',
    theoryHtml: `
      <p>Khảo sát 4 hàm số lượng giác cơ bản:</p>
      <ul class="list-disc list-inside space-y-1.5 pl-2">
        <li>$y = \\sin x$: Tập xác định $\\mathbb{R}$, tập giá trị $[-1; 1]$, hàm số LẺ, tuần hoàn chu kỳ $2\\pi$.</li>
        <li>$y = \\cos x$: Tập xác định $\\mathbb{R}$, tập giá trị $[-1; 1]$, hàm số CHẴN, tuần hoàn chu kỳ $2\\pi$.</li>
        <li>$y = \\tan x$: TXĐ $D = \\mathbb{R} \\setminus \\left\\{\\frac{\\pi}{2} + k\\pi\\right\\}$, tập giá trị $\\mathbb{R}$, hàm số LẺ, tuần hoàn chu kỳ $\\pi$.</li>
        <li>$y = \\cot x$: TXĐ $D = \\mathbb{R} \\setminus \\{k\\pi\\}$, tập giá trị $\\mathbb{R}$, hàm số LẺ, tuần hoàn chu kỳ $\\pi$.</li>
      </ul>
    `,
    formulas: [
      'y = \\sin(\\omega x + \\varphi) \\implies T = \\frac{2\\pi}{|\\omega|}',
      'y = \\cos(\\omega x + \\varphi) \\implies T = \\frac{2\\pi}{|\\omega|}',
      'y = \\tan(\\omega x + \\varphi) \\implies T = \\frac{\\pi}{|\\omega|}'
    ],
    keyNotes: [
      'Chỉ duy nhất hàm $y = \\cos x$ là hàm chẵn (đối xứng qua trục tung $Oy$), ba hàm còn lại là hàm lẻ (đối xứng qua gốc toạ độ $O$).'
    ],
    diagramType: 'trig',
    sgkRef: '11-CH1-B3',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-4',
    title: 'Bài 4. Phương trình lượng giác cơ bản',
    grade: 11,
    chapterIndex: 0,
    chapterTitle: 'Chương I. Hàm số lượng giác & Phương trình lượng giác',
    theoryHtml: `
      <p>Nghiệm của các phương trình lượng giác cơ bản ($k \\in \\mathbb{Z}$):</p>
      <div class="space-y-2 mt-2">
        <p>1. $\\sin x = \\sin \\alpha \\iff \\begin{cases} x = \\alpha + k2\\pi \\\\ x = \\pi - \\alpha + k2\\pi \\end{cases}$</p>
        <p>2. $\\cos x = \\cos \\alpha \\iff x = \\pm \\alpha + k2\\pi$</p>
        <p>3. $\\tan x = \\tan \\alpha \\iff x = \\alpha + k\\pi$</p>
        <p>4. $\\cot x = \\cot \\alpha \\iff x = \\alpha + k\\pi$</p>
        <p class="font-bold text-teal-800">Phương trình bậc nhất đối với $\\sin x$ và $\\cos x$:</p>
        <p>$a\\sin x + b\\cos x = c$ có nghiệm khi và chỉ khi $a^2 + b^2 \\ge c^2$.</p>
      </div>
    `,
    formulas: [
      '\\sin x = \\sin \\alpha \\iff x = \\alpha + k2\\pi \\text{ hoặc } x = \\pi - \\alpha + k2\\pi',
      '\\cos x = \\cos \\alpha \\iff x = \\pm \\alpha + k2\\pi',
      'a\\sin x + b\\cos x = c \\text{ có nghiệm} \\iff a^2 + b^2 \\ge c^2'
    ],
    keyNotes: [
      'Phương trình $\\sin x = m$ và $\\cos x = m$ có nghiệm khi và chỉ khi $|m| \\le 1$.',
      'Không bao giờ được dùng lẫn lộn giữa đơn vị độ ($^\\circ$) và radian trong cùng một công thức nghiệm.'
    ],
    diagramType: 'trig',
    sgkRef: '11-CH1-B4',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-rev1',
    title: 'Bài tập cuối chương I. Hàm số & Phương trình lượng giác',
    grade: 11,
    chapterIndex: 0,
    chapterTitle: 'Chương I. Hàm số lượng giác & Phương trình lượng giác',
    theoryHtml: `
      <p>Tổng kết phương pháp giải các dạng toán lượng giác trong đề thi THPT:</p>
      <ul class="list-disc list-inside space-y-1 pl-2">
        <li>Tìm tập xác định của hàm số lượng giác chứa căn thức và phân thức.</li>
        <li>Tìm giá trị lớn nhất, giá trị nhỏ nhất bằng cách đặt ẩn phụ $t = \\sin x$ hoặc dùng bất đẳng thức Cauchy-Schwarz.</li>
        <li>Đếm số nghiệm của phương trình lượng giác trên khoảng, đoạn $[a; b]$ cho trước.</li>
      </ul>
    `,
    formulas: [
      '\\sin x + \\cos x = \\sqrt{2}\\sin\\left(x + \\frac{\\pi}{4}\\right)',
      '-\\sqrt{a^2+b^2} \\le a\\sin x + b\\cos x \\le \\sqrt{a^2+b^2}'
    ],
    keyNotes: [
      'Biểu diễn nghiệm trên đường tròn lượng giác để loại trừ nghiệm trùng hoặc đếm số điểm biểu diễn.'
    ],
    diagramType: 'trig',
    sgkRef: '11-CH1-REV',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },

  // --- CHƯƠNG II: DÃY SỐ, CSC, CSN ---
  {
    id: '11-5',
    title: 'Bài 5. Dãy số (Tính tăng giảm, bị chặn)',
    grade: 11,
    chapterIndex: 1,
    chapterTitle: 'Chương II. Dãy số. Cấp số cộng và cấp số nhân',
    theoryHtml: `
      <p>Dãy số $(u_n)$ là một hàm số xác định trên tập các số nguyên dương $\\mathbb{N}^*$.</p>
      <ul class="list-disc list-inside space-y-1.5 pl-2">
        <li><strong>Dãy số tăng:</strong> $u_{n+1} > u_n$ với mọi $n \\in \\mathbb{N}^*$ (hoặc xét $u_{n+1} - u_n > 0$).</li>
        <li><strong>Dãy số giảm:</strong> $u_{n+1} < u_n$ với mọi $n \\in \\mathbb{N}^*$ (hoặc xét $u_{n+1} - u_n < 0$).</li>
        <li><strong>Dãy số bị chặn:</strong> Bị chặn trên nếu tồn tại $M$ sao cho $u_n \\le M$; bị chặn dưới nếu tồn tại $m$ sao cho $u_n \\ge m$. Dãy vừa bị chặn trên vừa bị chặn dưới gọi là bị chặn.</li>
      </ul>
    `,
    formulas: [
      'u_{n+1} - u_n > 0 \\implies (u_n) \\text{ tăng}',
      'm \\le u_n \\le M \\, (\\forall n \\in \\mathbb{N}^*) \\implies (u_n) \\text{ bị chặn}'
    ],
    keyNotes: [
      'Nếu các số hạng $u_n > 0$, có thể so sánh tỉ số $\\frac{u_{n+1}}{u_n}$ với 1 để kết luận tính tăng/giảm.'
    ],
    diagramType: 'numberLine',
    sgkRef: '11-CH2-B5',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-7',
    title: 'Bài 7. Cấp số nhân',
    grade: 11,
    chapterIndex: 1,
    chapterTitle: 'Chương II. Dãy số. Cấp số cộng và cấp số nhân',
    theoryHtml: `
      <p>Cấp số nhân $(u_n)$ có số hạng đầu $u_1$ và công bội $q$ thoả mãn: $u_{n+1} = u_n \\cdot q$ (với mọi $n \\ge 1$).</p>
      <div class="space-y-1.5 mt-2">
        <p><strong>1. Số hạng tổng quát:</strong> $u_n = u_1 \\cdot q^{n-1} \\quad (n \\ge 2)$.</p>
        <p><strong>2. Tính chất:</strong> $u_k^2 = u_{k-1} \\cdot u_{k+1} \\quad (k \\ge 2)$.</p>
        <p><strong>3. Tổng $n$ số hạng đầu:</strong> $S_n = \\frac{u_1(1 - q^n)}{1 - q} \\quad (q \\ne 1)$. Nếu $q = 1$ thì $S_n = n u_1$.</p>
        <p><strong>4. Tổng cấp số nhân lùi vô hạn ($|q| < 1$):</strong> $S = \\frac{u_1}{1 - q}$.</p>
      </div>
    `,
    formulas: [
      'u_n = u_1 \\cdot q^{n-1}',
      'S_n = \\frac{u_1(1 - q^n)}{1 - q} \\quad (q \\ne 1)',
      'S = \\frac{u_1}{1 - q} \\quad (|q| < 1, \\, \\text{CSN lùi vô hạn})'
    ],
    keyNotes: [
      'Ứng dụng thực tế: Tăng trưởng dân số, lãi kép ngân hàng, sự phân rã phóng xạ, số ca lây nhiễm virus.',
      'Chú ý dấu của công bội $q$: nếu $q < 0$ thì các số hạng của cấp số nhân đan dấu (dương, âm xen kẽ).'
    ],
    diagramType: 'numberLine',
    sgkRef: '11-CH2-B7',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-rev2',
    title: 'Bài tập cuối chương II. Dãy số, Cấp số cộng & Cấp số nhân',
    grade: 11,
    chapterIndex: 1,
    chapterTitle: 'Chương II. Dãy số. Cấp số cộng và cấp số nhân',
    theoryHtml: `
      <p>So sánh đối chiếu toàn diện Cấp số cộng và Cấp số nhân:</p>
      <div class="overflow-x-auto mt-2">
        <table class="w-full text-xs text-left border border-slate-200">
          <thead class="bg-teal-50">
            <tr>
              <th class="p-2 border">Đặc trưng</th>
              <th class="p-2 border">Cấp số cộng (CSC)</th>
              <th class="p-2 border">Cấp số nhân (CSN)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="p-2 border font-medium">Quy luật</td>
              <td class="p-2 border">$u_{n+1} = u_n + d$</td>
              <td class="p-2 border">$u_{n+1} = u_n \\cdot q$</td>
            </tr>
            <tr>
              <td class="p-2 border font-medium">Số hạng thứ $n$</td>
              <td class="p-2 border">$u_n = u_1 + (n-1)d$</td>
              <td class="p-2 border">$u_n = u_1 \\cdot q^{n-1}$</td>
            </tr>
            <tr>
              <td class="p-2 border font-medium">Tổng $n$ số hạng</td>
              <td class="p-2 border">$S_n = \\frac{n(u_1 + u_n)}{2}$</td>
              <td class="p-2 border">$S_n = \\frac{u_1(1-q^n)}{1-q}$</td>
            </tr>
          </tbody>
        </table>
      </div>
    `,
    formulas: [
      'u_k = \\frac{u_{k-1} + u_{k+1}}{2} \\quad (\\text{CSC}), \\quad u_k^2 = u_{k-1} \\cdot u_{k+1} \\quad (\\text{CSN})'
    ],
    keyNotes: [
      'Ba số $a, b, c$ lập thành CSC $\\iff a + c = 2b$; lập thành CSN $\\iff ac = b^2$.'
    ],
    diagramType: 'numberLine',
    sgkRef: '11-CH2-REV',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },

  // --- CHƯƠNG III: SỐ ĐẶC TRƯNG MẪU GHÉP NHÓM LỚP 11 ---
  {
    id: '11-8',
    title: 'Bài 8. Mẫu số liệu ghép nhóm',
    grade: 11,
    chapterIndex: 2,
    chapterTitle: 'Chương III. Các số đặc trưng đo xu thế trung tâm của mẫu số liệu ghép nhóm',
    theoryHtml: `
      <p>Mẫu số liệu ghép nhóm được biểu diễn dưới dạng các khoảng nửa khoảng $[a_i; a_{i+1})$ cùng tần số $n_i$ tương ứng.</p>
      <p>Giá trị đại diện của nhóm $[a_i; a_{i+1})$ là trung điểm: $c_i = \\frac{a_i + a_{i+1}}{2}$. Cỡ mẫu $n = \\sum_{i=1}^k n_i$.</p>
    `,
    formulas: ['c_i = \\frac{a_i + a_{i+1}}{2}, \\quad n = \\sum_{i=1}^k n_i'],
    keyNotes: ['Ghép nhóm giúp thu gọn và xử lý các tập dữ liệu lớn liên tục như chiều cao, cân nặng, điểm thi, thời gian.'],
    diagramType: 'histogram',
    sgkRef: '11-CH3-B8',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-9',
    title: 'Bài 9. Các số đặc trưng đo xu thế trung tâm (Trung bình, Trung vị, Mốt)',
    grade: 11,
    chapterIndex: 2,
    chapterTitle: 'Chương III. Các số đặc trưng đo xu thế trung tâm của mẫu số liệu ghép nhóm',
    theoryHtml: `
      <p>Các công thức tính số đặc trưng đo xu thế trung tâm cho mẫu ghép nhóm:</p>
      <ul class="list-disc list-inside space-y-2 pl-2">
        <li><strong>Số trung bình:</strong> $\\bar{x} = \\frac{1}{n} \\sum_{i=1}^k n_i c_i$.</li>
        <li><strong>Trung vị $M_e$:</strong> $M_e = a_m + \\frac{\\frac{n}{2} - C}{n_m} (a_{m+1} - a_m)$ với $[a_m; a_{m+1})$ là nhóm đầu tiên có tần số tích luỹ $\\ge \\frac{n}{2}$.</li>
        <li><strong>Mốt $M_o$:</strong> $M_o = a_j + \\frac{n_j - n_{j-1}}{(n_j - n_{j-1}) + (n_j - n_{j+1})} (a_{j+1} - a_j)$ với nhóm $j$ có tần số lớn nhất.</li>
      </ul>
    `,
    formulas: [
      '\\bar{x} = \\frac{\\sum n_i c_i}{n}',
      'M_e = a_m + \\frac{\\frac{n}{2} - C}{n_m}(a_{m+1} - a_m)',
      'M_o = a_j + \\frac{n_j - n_{j-1}}{(n_j - n_{j-1}) + (n_j - n_{j+1})}(a_{j+1} - a_j)'
    ],
    keyNotes: [
      'Trung vị chia mẫu số liệu thành 2 phần bằng nhau, không bị ảnh hưởng bởi các giá trị quá lớn hoặc quá nhỏ.',
      'Mốt thể hiện giá trị có tần suất xuất hiện phổ biến nhất trong mẫu số liệu.'
    ],
    diagramType: 'histogram',
    sgkRef: '11-CH3-B9',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },

  // --- CHƯƠNG IV: QUAN HỆ SONG SONG TRONG KHÔNG GIAN ---
  {
    id: '11-10',
    title: 'Bài 10. Đường thẳng và mặt phẳng trong không gian',
    grade: 11,
    chapterIndex: 3,
    chapterTitle: 'Chương IV. Quan hệ song song trong không gian',
    theoryHtml: `
      <p>Các tiên đề và quy tắc xác định mặt phẳng:</p>
      <ul class="list-disc list-inside space-y-1.5 pl-2">
        <li>Mặt phẳng được xác định duy nhất qua 3 điểm không thẳng hàng; hoặc qua 1 điểm và 1 đường thẳng không chứa điểm đó; hoặc qua 2 đường thẳng cắt nhau; hoặc qua 2 đường thẳng song song.</li>
        <li>Giao tuyến của 2 mặt phẳng phân biệt là đường thẳng đi qua tất cả các điểm chung của hai mặt phẳng.</li>
      </ul>
    `,
    formulas: ['(ABC) \\text{ xác định duy nhất khi } A, B, C \\text{ không thẳng hàng}'],
    keyNotes: [
      'Để tìm giao tuyến của 2 mặt phẳng: tìm 2 điểm chung phân biệt, đường thẳng nối 2 điểm đó chính là giao tuyến.'
    ],
    diagramType: 'pyramid',
    sgkRef: '11-CH4-B10',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-12',
    title: 'Bài 12. Đường thẳng và mặt phẳng song song',
    grade: 11,
    chapterIndex: 3,
    chapterTitle: 'Chương IV. Quan hệ song song trong không gian',
    theoryHtml: `
      <p>Đường thẳng $d$ song song với mặt phẳng $(\\alpha)$ nếu chúng không có điểm chung.</p>
      <p><strong>Dấu hiệu nhận biết:</strong> Nếu đường thẳng $d$ không nằm trong $(\\alpha)$ và song song với một đường thẳng $d'$ nằm trong $(\\alpha)$ thì $d \\parallel (\\alpha)$.</p>
      <p><strong>Định lý giao tuyến:</strong> Nếu đường thẳng $d$ song song với mặt phẳng $(\\alpha)$ thì bất kỳ mặt phẳng $(\\beta)$ nào chứa $d$ và cắt $(\\alpha)$ theo giao tuyến $d'$ thì $d \\parallel d'$.</p>
    `,
    formulas: [
      'd \\not\\subset (\\alpha), \\, d \\parallel d\', \\, d\' \\subset (\\alpha) \\implies d \\parallel (\\alpha)',
      'd \\parallel (\\alpha), \\, d \\subset (\\beta), \\, (\\alpha) \\cap (\\beta) = d\' \\implies d \\parallel d\''
    ],
    keyNotes: [
      'Đây là công cụ nền tảng để dựng các thiết diện song song trong hình chóp và hình lăng trụ.'
    ],
    diagramType: 'prism',
    sgkRef: '11-CH4-B12',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-13',
    title: 'Bài 13. Hai mặt phẳng song song',
    grade: 11,
    chapterIndex: 3,
    chapterTitle: 'Chương IV. Quan hệ song song trong không gian',
    theoryHtml: `
      <p><strong>Dấu hiệu nhận biết:</strong> Nếu mặt phẳng $(\\alpha)$ chứa 2 đường thẳng cắt nhau $a, b$ và cả hai cùng song song với mặt phẳng $(\\beta)$ thì $(\\alpha) \\parallel (\\beta)$.</p>
      <p><strong>Định lý Ta-lét trong không gian:</strong> Ba mặt phẳng đôi một song song chắn trên hai cát tuyến bất kỳ các đoạn thẳng tỉ lệ.</p>
    `,
    formulas: [
      'a, b \\subset (\\alpha), \\, a \\cap b = I, \\, a \\parallel (\\beta), \\, b \\parallel (\\beta) \\implies (\\alpha) \\parallel (\\beta)',
      '\\frac{A_1 B_1}{A_2 B_2} = \\frac{B_1 C_1}{B_2 C_2} = \\frac{A_1 C_1}{A_2 C_2} \\quad (\\text{Định lý Thales không gian})'
    ],
    keyNotes: [
      'Qua 1 điểm ngoài mặt phẳng cho trước chỉ có duy nhất 1 mặt phẳng song song với mặt phẳng đó.'
    ],
    diagramType: 'box',
    sgkRef: '11-CH4-B13',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },

  // --- CHƯƠNG V: GIỚI HẠN & HÀM LIÊN TỤC ---
  {
    id: '11-16',
    title: 'Bài 16. Giới hạn của hàm số (Khử các dạng vô định)',
    grade: 11,
    chapterIndex: 4,
    chapterTitle: 'Chương V. Giới hạn & Hàm số liên tục',
    theoryHtml: `
      <p>Bốn dạng vô định kinh điển và phương pháp khử:</p>
      <ul class="list-disc list-inside space-y-1.5 pl-2">
        <li><strong>Dạng $\\frac{0}{0}$:</strong> Phân tích đa thức thành nhân tử để triệt tiêu nhân tử chung $(x - x_0)$, hoặc nhân lượng liên hợp khi có căn thức.</li>
        <li><strong>Dạng $\\frac{\\infty}{\\infty}$:</strong> Chia cả tử và mẫu cho luỹ thừa bậc cao nhất của $x$. Chú ý dấu của $x$ khi đưa vào/ra căn thức khi $x \\to -\\infty$.</li>
        <li><strong>Dạng $\\infty - \\infty$:</strong> Nhân chia lượng liên hợp để chuyển về dạng $\\frac{0}{0}$ hoặc $\\frac{\\infty}{\\infty}$.</li>
        <li><strong>Dạng $0 \\cdot \\infty$:</strong> Chuyển về dạng $\\frac{0}{0}$ hoặc $\\frac{\\infty}{\\infty}$.</li>
      </ul>
    `,
    formulas: [
      '\\lim_{x \\to x_0} \\frac{f(x)}{g(x)} = \\lim_{x \\to x_0} \\frac{(x - x_0)P(x)}{(x - x_0)Q(x)} = \\lim_{x \\to x_0} \\frac{P(x)}{Q(x)}',
      '\\lim_{x \\to +\\infty} \\frac{1}{x^k} = 0 \\quad (k > 0)'
    ],
    keyNotes: [
      'Cực kỳ cẩn thận khi $x \\to -\\infty$: $\\sqrt{x^2} = |x| = -x$. Rất nhiều học sinh mất điểm vì quên dấu trừ.'
    ],
    diagramType: 'rational',
    diagramParams: { a: 1, b: 0, c: 1, d: 0 },
    sgkRef: '11-CH5-B16',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-17',
    title: 'Bài 17. Hàm số liên tục và Định lý giá trị trung gian',
    grade: 11,
    chapterIndex: 4,
    chapterTitle: 'Chương V. Giới hạn & Hàm số liên tục',
    theoryHtml: `
      <p>Hàm số $y = f(x)$ liên tục tại $x_0 \\iff \\lim_{x \\to x_0} f(x) = f(x_0)$.</p>
      <p><strong>Định lý giá trị trung gian (chứng minh phương trình có nghiệm):</strong></p>
      <p>Nếu hàm số $y = f(x)$ liên tục trên đoạn $[a; b]$ và $f(a) \\cdot f(b) < 0$ thì tồn tại ít nhất một số $c \\in (a; b)$ sao cho $f(c) = 0$, nghĩa là phương trình $f(x) = 0$ có ít nhất 1 nghiệm trong khoảng $(a; b)$.</p>
    `,
    formulas: [
      '\\lim_{x \\to x_0} f(x) = f(x_0) \\implies f \\text{ liên tục tại } x_0',
      'f(a) \\cdot f(b) < 0 \\implies \\exists c \\in (a; b): f(c) = 0'
    ],
    keyNotes: [
      'Hàm đa thức, phân thức hữu tỉ, lượng giác liên tục trên từng khoảng xác định của chúng.'
    ],
    diagramType: 'cubic',
    diagramParams: { a: 1, b: 0, c: -3, d: 0 },
    sgkRef: '11-CH5-B17',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },

  // --- CHƯƠNG VI: MŨ & LÔGARIT ---
  {
    id: '11-18',
    title: 'Bài 18. Luỹ thừa với số mũ thực',
    grade: 11,
    chapterIndex: 5,
    chapterTitle: 'Chương VI. Hàm số mũ và hàm số lôgarit',
    theoryHtml: `
      <p>Quy tắc và tính chất luỹ thừa với cơ số dương $a > 0$ và số mũ thực $\\alpha, \\beta$:</p>
      $$a^\\alpha \\cdot a^\\beta = a^{\\alpha+\\beta}, \\quad \\frac{a^\\alpha}{a^\\beta} = a^{\\alpha-\\beta}, \\quad (a^\\alpha)^\\beta = a^{\\alpha\\beta}, \\quad (ab)^\\alpha = a^\\alpha b^\\alpha$$
      <p><strong>So sánh luỹ thừa:</strong></p>
      <p>- Khi $a > 1$: $a^\\alpha > a^\\beta \\iff \\alpha > \\beta$.</p>
      <p>- Khi $0 < a < 1$: $a^\\alpha > a^\\beta \\iff \\alpha < \\beta$ (đảo chiều bất đẳng thức).</p>
    `,
    formulas: [
      'a^\\alpha \\cdot a^\\beta = a^{\\alpha + \\beta}, \\quad (a^\\alpha)^\\beta = a^{\\alpha \\beta}',
      'a > 1: a^\\alpha > a^\\beta \\iff \\alpha > \\beta; \\quad 0 < a < 1: a^\\alpha > a^\\beta \\iff \\alpha < \\beta'
    ],
    keyNotes: [
      'Luỹ thừa với số mũ hữu tỉ $a^{m/n} = \\sqrt[n]{a^m}$ chỉ xác định với cơ số $a > 0$.',
      'Luỹ thừa với số mũ nguyên âm $a^{-n} = \\frac{1}{a^n}$ xác định với cơ số $a \\ne 0$.'
    ],
    diagramType: 'numberLine',
    sgkRef: '11-CH6-B18',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-19',
    title: 'Bài 19. Lôgarit (Công thức đổi cơ số & Biến đổi)',
    grade: 11,
    chapterIndex: 5,
    chapterTitle: 'Chương VI. Hàm số mũ và hàm số lôgarit',
    theoryHtml: `
      <p>Cho $a > 0, a \\ne 1$ và $b > 0$. Lôgarit cơ số $a$ của $b$: $\\log_a b = \\alpha \\iff a^\\alpha = b$.</p>
      <div class="space-y-1.5 mt-2">
        <p><strong>Các công thức trọng tâm:</strong></p>
        <p>$\\log_a(x \\cdot y) = \\log_a x + \\log_a y, \\quad \\log_a\\left(\\frac{x}{y}\\right) = \\log_a x - \\log_a y$</p>
        <p>$\\log_a(x^\\alpha) = \\alpha \\log_a x, \\quad \\log_{a^\\beta} x = \\frac{1}{\\beta} \\log_a x$</p>
        <p><strong>Công thức đổi cơ số:</strong> $\\log_a b = \\frac{\\log_c b}{\\log_c a} \\quad (c > 0, c \\ne 1)$</p>
        <p>Đặc biệt: $\\log_a b = \\frac{1}{\\log_b a}, \\quad a^{\\log_c b} = b^{\\log_c a}$.</p>
      </div>
    `,
    formulas: [
      '\\log_a(xy) = \\log_a x + \\log_a y, \\quad \\log_a\\left(\\frac{x}{y}\\right) = \\log_a x - \\log_a y',
      '\\log_a b = \\frac{\\log_c b}{\\log_c a}, \\quad a^{\\log_a b} = b'
    ],
    keyNotes: [
      'Điều kiện xác định của biểu thức $\\log_a f(x)$: Cơ số $a > 0, a \\ne 1$ và biểu thức dưới dấu logarit $f(x) > 0$.',
      'Ký hiệu: Lôgarit tự nhiên $\\ln x = \\log_e x$; Lôgarit thập phân $\\lg x = \\log_{10} x$.'
    ],
    diagramType: 'numberLine',
    sgkRef: '11-CH6-B19',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-21',
    title: 'Bài 21. Phương trình, bất phương trình mũ và lôgarit',
    grade: 11,
    chapterIndex: 5,
    chapterTitle: 'Chương VI. Hàm số mũ và hàm số lôgarit',
    theoryHtml: `
      <p>Các phương pháp giải kinh điển:</p>
      <ul class="list-disc list-inside space-y-1.5 pl-2">
        <li><strong>Đưa về cùng cơ số:</strong> $a^{f(x)} = a^{g(x)} \\iff f(x) = g(x)$; $\\log_a f(x) = \\log_a g(x) \\iff f(x) = g(x) > 0$.</li>
        <li><strong>Đặt ẩn phụ:</strong> Đặt $t = a^x > 0$ (phương trình bậc hai ẩn $t$); đặt $t = \\log_a x$ ($t \\in \\mathbb{R}$).</li>
        <li><strong>Lôgarit hoá / Mũ hoá:</strong> Áp dụng khi hai vế có các cơ số khác nhau không thể đưa về cùng cơ số.</li>
      </ul>
      <p class="mt-2 font-bold text-red-600">Lưu ý bất phương trình:</p>
      <p>Khi $0 < a < 1$, giải bất phương trình $a^{f(x)} > a^{g(x)} \\iff f(x) < g(x)$ PHẢI ĐỔI CHIỀU BẤT ĐẲNG THỨC.</p>
    `,
    formulas: [
      'a^{f(x)} = b \\iff f(x) = \\log_a b \\quad (b > 0)',
      '\\log_a f(x) > \\log_a g(x) \\iff \\begin{cases} f(x) > g(x) > 0 & (a > 1) \\\\ 0 < f(x) < g(x) & (0 < a < 1) \\end{cases}'
    ],
    keyNotes: [
      'Luôn đặt điều kiện cho biểu thức logarit TRƯỚC KHI thực hiện bất kỳ phép biến đổi nào.',
      'Khi đặt ẩn phụ $t = a^x$, điều kiện bắt buộc là $t > 0$.'
    ],
    diagramType: 'numberLine',
    sgkRef: '11-CH6-B21',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },

  // --- CHƯƠNG VII: QUAN HỆ VUÔNG GÓC KHÔNG GIAN ---
  {
    id: '11-26',
    title: 'Bài 26. Khoảng cách trong không gian (Điểm đến MP, Hai đường chéo nhau)',
    grade: 11,
    chapterIndex: 6,
    chapterTitle: 'Chương VII. Quan hệ vuông góc trong không gian',
    theoryHtml: `
      <p>Hai bài toán khoảng cách cốt lõi:</p>
      <div class="space-y-2 mt-2">
        <p><strong>1. Khoảng cách từ điểm $M$ đến mặt phẳng $(P)$:</strong></p>
        <p>- Dựng $MH \\perp (P)$ tại $H \\implies d(M, (P)) = MH$.</p>
        <p>- <em>Phương pháp đổi điểm:</em> Nếu $AB$ cắt $(P)$ tại $I$ thì $\\frac{d(A, (P))}{d(B, (P))} = \\frac{IA}{IB}$. Luôn đưa về khoảng cách từ chân đường cao.</p>
        <p><strong>2. Khoảng cách giữa hai đường thẳng chéo nhau $a, b$:</strong></p>
        <p>- Dựng mặt phẳng $(P)$ chứa $b$ và song song với $a \\implies d(a, b) = d(a, (P)) = d(M, (P))$ với $M \\in a$.</p>
      </div>
    `,
    formulas: [
      '\\frac{d(A, (P))}{d(B, (P))} = \\frac{IA}{IB} \\quad (AB \\cap (P) = I)',
      'd(a, b) = d(a, (P)) = d(M, (P)) \\quad (b \\subset (P), \\, a \\parallel (P))',
      '\\frac{1}{h^2} = \\frac{1}{a^2} + \\frac{1}{b^2} + \\frac{1}{c^2} \\quad (\\text{Tứ diện vuông đỉnh } O)'
    ],
    keyNotes: [
      'Chân đường cao là "điểm vàng" trong mọi bài toán khoảng cách. Mọi khoảng cách đều nên chuyển về chân đường cao.',
      'Sử dụng công thức thể tích: $d(A, (BCD)) = \\frac{3V_{ABCD}}{S_{\\Delta BCD}}$.'
    ],
    diagramType: 'pyramid',
    sgkRef: '11-CH7-B26',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-27',
    title: 'Bài 27. Thể tích khối đa diện (Chóp, Lăng trụ, Hộp)',
    grade: 11,
    chapterIndex: 6,
    chapterTitle: 'Chương VII. Quan hệ vuông góc trong không gian',
    theoryHtml: `
      <p>Các công thức tính thể tích hình khối đa diện:</p>
      <ul class="list-disc list-inside space-y-1.5 pl-2">
        <li><strong>Khối chóp:</strong> $V = \\frac{1}{3} S_{\\text{đáy}} \\cdot h$.</li>
        <li><strong>Khối lăng trụ:</strong> $V = S_{\\text{đáy}} \\cdot h$.</li>
        <li><strong>Khối hộp chữ nhật:</strong> $V = a \\cdot b \\cdot c$; Khối lập phương: $V = a^3$.</li>
        <li><strong>Tỉ số thể tích khối chóp tam giác (Simson):</strong> $\\frac{V_{S.A\'B\'C\'}}{V_{S.ABC}} = \\frac{SA\'}{SA} \\cdot \\frac{SB\'}{SB} \\cdot \\frac{SC\'}{SC}$.</li>
      </ul>
    `,
    formulas: [
      'V_{\\text{chóp}} = \\frac{1}{3} S \\cdot h, \\quad V_{\\text{lăng trụ}} = S \\cdot h',
      '\\frac{V_{S.A\'B\'C\'}}{V_{S.ABC}} = \\frac{SA\'}{SA} \\cdot \\frac{SB\'}{SB} \\cdot \\frac{SC\'}{SC}'
    ],
    keyNotes: [
      'Công thức tỉ số thể tích Simson CHỈ ÁP DỤNG ĐƯỢC CHO HÌNH CHÓP TAM GIÁC (đáy tam giác). Với đáy tứ giác phải chia thành hai tam giác trước khi tính tỉ số.'
    ],
    diagramType: 'prism',
    sgkRef: '11-CH7-B27',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },

  // --- CHƯƠNG VIII: QUY TẮC XÁC SUẤT LỚP 11 ---
  {
    id: '11-28',
    title: 'Bài 28. Biến cố hợp, biến cố giao và biến cố độc lập',
    grade: 11,
    chapterIndex: 7,
    chapterTitle: 'Chương VIII. Các quy tắc tính xác suất',
    theoryHtml: `
      <p>Các phép toán biến cố:</p>
      <ul class="list-disc list-inside space-y-1.5 pl-2">
        <li><strong>Biến cố hợp $A \\cup B$:</strong> Xảy ra khi có ít nhất một trong hai biến cố $A$ hoặc $B$ xảy ra.</li>
        <li><strong>Biến cố giao $A \\cap B$ (hay $AB$):</strong> Xảy ra khi cả hai biến cố $A$ và $B$ đồng thời xảy ra.</li>
        <li><strong>Biến cố xung khắc:</strong> $A \\cap B = \\emptyset$ (không thể cùng xảy ra).</li>
        <li><strong>Biến cố độc lập:</strong> Biến cố này xảy ra hay không không ảnh hưởng tới xác suất xảy ra biến cố kia: $P(AB) = P(A) \\cdot P(B)$.</li>
      </ul>
    `,
    formulas: [
      'A \\cap B = \\emptyset \\implies A, B \\text{ xung khắc}',
      'P(AB) = P(A) \\cdot P(B) \\iff A, B \\text{ độc lập}'
    ],
    keyNotes: [
      'Phân biệt rõ: Xung khắc là quan hệ về TẬP HỢP ($A \\cap B = \\emptyset$), Độc lập là quan hệ về XÁC SUẤT ($P(AB) = P(A)P(B)$).'
    ],
    diagramType: 'numberLine',
    sgkRef: '11-CH8-B28',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-29',
    title: 'Bài 29. Công thức cộng và Công thức nhân xác suất',
    grade: 11,
    chapterIndex: 7,
    chapterTitle: 'Chương VIII. Các quy tắc tính xác suất',
    theoryHtml: `
      <p>Hệ thống công thức tính xác suất cốt lõi:</p>
      <div class="space-y-2 mt-2">
        <p><strong>1. Công thức cộng tổng quát:</strong></p>
        $$P(A \\cup B) = P(A) + P(B) - P(A \\cap B)$$
        <p>Nếu $A$ và $B$ xung khắc: $P(A \\cup B) = P(A) + P(B)$.</p>
        <p><strong>2. Công thức nhân cho biến cố độc lập:</strong></p>
        $$P(A \\cap B) = P(A) \\cdot P(B)$$
        <p><strong>3. Biến cố đối:</strong> $P(\\overline{A}) = 1 - P(A)$.</p>
      </div>
    `,
    formulas: [
      'P(A \\cup B) = P(A) + P(B) - P(AB)',
      'P(AB) = P(A) \\cdot P(B) \\quad (A, B \\text{ độc lập})',
      'P(\\overline{A}) = 1 - P(A)'
    ],
    keyNotes: [
      'Khi bài toán xuất hiện cụm từ "có ít nhất một...", nên dùng biến cố đối để giải quyết nhanh hơn.'
    ],
    diagramType: 'numberLine',
    sgkRef: '11-CH8-B29',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },

  // --- CHƯƠNG IX: ĐẠO HÀM LỚP 11 ---
  {
    id: '11-31',
    title: 'Bài 31. Định nghĩa và Ý nghĩa của đạo hàm',
    grade: 11,
    chapterIndex: 8,
    chapterTitle: 'Chương IX. Đạo hàm',
    theoryHtml: `
      <p>Đạo hàm của $y = f(x)$ tại điểm $x_0$:</p>
      $$f'(x_0) = \\lim_{x \\to x_0} \\frac{f(x) - f(x_0)}{x - x_0} = \\lim_{\\Delta x \\to 0} \\frac{\\Delta y}{\\Delta x}$$
      <div class="space-y-1.5 mt-2">
        <p><strong>Ý nghĩa hình học:</strong> $f'(x_0)$ là hệ số góc $k$ của tiếp tuyến của đồ thị hàm số tại tiếp điểm $M(x_0; f(x_0))$.</p>
        <p>Phương trình tiếp tuyến: $y = f'(x_0)(x - x_0) + f(x_0)$.</p>
        <p><strong>Ý nghĩa vật lý:</strong> Vận tốc tức thời của chuyển động $s(t)$ tại thời điểm $t_0$ là $v(t_0) = s'(t_0)$.</p>
      </div>
    `,
    formulas: [
      'f\'(x_0) = \\lim_{\\Delta x \\to 0} \\frac{f(x_0 + \\Delta x) - f(x_0)}{\\Delta x}',
      'y = f\'(x_0)(x - x_0) + y_0 \\quad (\\text{Phương trình tiếp tuyến})',
      'v(t) = s\'(t)'
    ],
    keyNotes: [
      "Nếu tiếp tuyến song song với đường thẳng $y = ax + b$ thì hệ số góc $f'(x_0) = a$.",
      "Nếu tiếp tuyến vuông góc với đường thẳng $y = ax + b$ ($a \\ne 0$) thì hệ số góc $f'(x_0) = -\\frac{1}{a}$."
    ],
    diagramType: 'cubic',
    diagramParams: { a: 1, b: 0, c: -3, d: 2 },
    sgkRef: '11-CH9-B31',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  },
  {
    id: '11-32',
    title: 'Bài 32. Các quy tắc tính đạo hàm và Đạo hàm hàm hợp',
    grade: 11,
    chapterIndex: 8,
    chapterTitle: 'Chương IX. Đạo hàm',
    theoryHtml: `
      <p>Bảng đạo hàm các hàm số cơ bản và hàm hợp $u = u(x)$:</p>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs mt-2">
        <div class="p-2 bg-slate-50 rounded border">
          <p class="font-bold text-teal-800">Hàm cơ bản:</p>
          <p>$(x^\\alpha)' = \\alpha x^{\\alpha-1}$</p>
          <p>$(\\sqrt{x})' = \\frac{1}{2\\sqrt{x}}$</p>
          <p>$(\\sin x)' = \\cos x, \\, (\\cos x)' = -\\sin x$</p>
          <p>$(\\tan x)' = \\frac{1}{\\cos^2 x}, \\, (\\cot x)' = -\\frac{1}{\\sin^2 x}$</p>
        </div>
        <div class="p-2 bg-slate-50 rounded border">
          <p class="font-bold text-teal-800">Hàm hợp $u(x)$:</p>
          <p>$(u^\\alpha)' = \\alpha u^{\\alpha-1} \\cdot u'$</p>
          <p>$(\\sqrt{u})' = \\frac{u'}{2\\sqrt{u}}$</p>
          <p>$(\\sin u)' = u' \\cdot \\cos u$</p>
          <p>$(\\cos u)' = -u' \\cdot \\sin u$</p>
        </div>
      </div>
      <p class="mt-2 text-xs font-semibold">Quy tắc tính đạo hàm: $(u \\pm v)' = u' \\pm v'$, $(uv)' = u'v + uv'$, $\\left(\\frac{u}{v}\\right)' = \\frac{u'v - uv'}{v^2}$.</p>
    `,
    formulas: [
      '(uv)\' = u\'v + uv\', \\quad \\left(\\frac{u}{v}\\right)\' = \\frac{u\'v - uv\'}{v^2}',
      '(f(u))\' = f\'(u) \\cdot u\'(x)',
      '\\left(\\frac{ax+b}{cx+d}\\right)\' = \\frac{ad - bc}{(cx+d)^2}'
    ],
    keyNotes: [
      'Công thức tính nhanh đạo hàm phân thức bậc nhất: tử số là định thức $\\begin{vmatrix} a & b \\\\ c & d \\end{vmatrix} = ad - bc$.'
    ],
    diagramType: 'cubic',
    diagramParams: { a: 1, b: 0, c: -3, d: 2 },
    sgkRef: '11-CH9-B32',
    verified: true,
    source: 'Thầy Phạm Bảo Anh',
    addedBatch: 'Batch-11'
  }
];

/**
 * CHUYÊN ĐỀ HỌC TẬP TOÁN 11
 */
export const SPECIAL_TOPIC_CHAPTERS_11: Chapter[] = [
  {
    title: 'Chuyên đề 1. Phép biến hình trong mặt phẳng',
    grade: 11,
    lessons: [
      {
        id: '11-cd1-b1',
        title: 'Bài 1. Phép tịnh tiến, Phép đối xứng trục & Phép quay',
        grade: 11,
        chapterIndex: 9,
        chapterTitle: 'Chuyên đề 1. Phép biến hình trong mặt phẳng',
        theoryHtml: `
          <p>Phép dời hình là phép biến hình bảo toàn khoảng cách giữa hai điểm bất kỳ.</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li><strong>Phép tịnh tiến theo $\\vec{v}(a; b)$:</strong> Biến $M(x; y)$ thành $M'(x'; y')$ thoả mãn: $\\begin{cases} x' = x + a \\\\ y' = y + b \\end{cases}$.</li>
            <li><strong>Phép đối xứng trục $Ox$:</strong> $\\begin{cases} x' = x \\\\ y' = -y \\end{cases}$; qua $Oy$: $\\begin{cases} x' = -x \\\\ y' = y \\end{cases}$.</li>
            <li><strong>Phép quay tâm $O$ góc $90^\\circ$:</strong> $\\begin{cases} x' = -y \\\\ y' = x \\end{cases}$.</li>
          </ul>
        `,
        formulas: [
          'T_{\\vec{v}}(M) = M\' \\iff \\vec{MM\'} = \\vec{v}',
          'Q_{(O, 90^\\circ)}(M) = M\' \\iff \\begin{cases} x\' = -y \\\\ y\' = x \\end{cases}'
        ],
        keyNotes: ['Phép dời hình biến đường thẳng thành đường thẳng song song hoặc trùng, biến tam giác thành tam giác bằng nó, biến đường tròn thành đường tròn có cùng bán kính.'],
        diagramType: 'circle',
        sgkRef: '11-CD1-ALL',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-11'
      }
    ]
  },
  {
    title: 'Chuyên đề 2. Làm quen với Lí thuyết đồ thị',
    grade: 11,
    lessons: [
      {
        id: '11-cd2-b1',
        title: 'Bài 2. Đường đi Euler, Hamilton & Bài toán tìm đường đi tối ưu',
        grade: 11,
        chapterIndex: 10,
        chapterTitle: 'Chuyên đề 2. Lí thuyết đồ thị',
        theoryHtml: `
          <p>Các khái niệm cơ bản về đồ thị $G = (V, E)$ gồm tập đỉnh $V$ và tập cạnh $E$:</p>
          <ul class="list-disc list-inside space-y-1 pl-2">
            <li><strong>Bậc của đỉnh:</strong> Số cạnh nối với đỉnh đó. Định lý bắt tay: Tổng bậc của tất cả các đỉnh bằng hai lần số cạnh.</li>
            <li><strong>Chu trình Euler:</strong> Đi qua mỗi CẠNH của đồ thị đúng một lần. Đồ thị liên thông có chu trình Euler khi và chỉ khi mọi đỉnh đều có bậc chẵn.</li>
            <li><strong>Chu trình Hamilton:</strong> Đi qua mỗi ĐỈNH của đồ thị đúng một lần.</li>
          </ul>
        `,
        formulas: ['\\sum_{v \\in V} \\text{deg}(v) = 2|E|'],
        keyNotes: ['Ứng dụng trong bài toán giao hàng bưu điện, thiết kế mạng viễn thông, bài toán người du lịch.'],
        diagramType: 'numberLine',
        sgkRef: '11-CD2-ALL',
        verified: true,
        source: 'Thầy Phạm Bảo Anh',
        addedBatch: 'Batch-11'
      }
    ]
  }
];
