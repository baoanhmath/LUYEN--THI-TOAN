export type Grade = 10 | 11 | 12;

export interface TrueFalseStatement {
  text: string;
  isTrue: boolean;
  explanation?: string;
}

export interface QuestionGenerated {
  id: string;
  topicTitle: string;
  grade: Grade;
  context: string;
  ask: string;
  // Multiple Choice (4 options)
  correctOption: string;
  distractors: string[];
  // True / False statements (4 items standard for 2025)
  tfStatements: TrueFalseStatement[];
  // Short Answer
  shortAnswer: string;
  shortAnswerPrompt?: string;
  // Detailed step-by-step solution
  solution: string;
  // Optional lesson mapping & source metadata
  lessonId?: string;
  sourceDocument?: string;
  createdAt?: string;
  // Optional SVG diagram type or params
  diagram?: {
    type: 'cubic' | 'quadratic' | 'rational' | 'integral' | 'trig' | 'circle' | 'pyramid' | 'prism' | 'box' | 'numberLine' | 'histogram' | 'appliedMaxMin';
    params?: Record<string, any>;
  };
}

export interface Lesson {
  id: string;
  title: string;
  grade: Grade;
  chapterIndex: number;
  chapterTitle: string;
  theoryHtml: string;
  formulas: string[];
  keyNotes: string[];
  diagramType?: 'cubic' | 'quadratic' | 'rational' | 'integral' | 'trig' | 'circle' | 'pyramid' | 'prism' | 'box' | 'numberLine' | 'histogram' | 'appliedMaxMin';
  diagramParams?: Record<string, any>;
  sgkRef?: string;
  verified?: boolean;
  source?: string;
  addedBatch?: string;
}

export interface Chapter {
  title: string;
  grade: Grade;
  lessons: Lesson[];
}

export interface ExamConfig {
  grade: Grade | 'all';
  type: 'tn' | 'gk1' | 'ck1' | 'gk2' | 'ck2' | 'ch';
  chapterIndex?: number;
  format: 'full' | 'mid' | 'short'; // full: 12 MCQ, 4 TF, 6 Short; mid: 8, 2, 4; short: 6, 1, 2
  schoolName: string;
  studentName?: string;
  studentCode?: string;
}

export interface ExamQuestionMCQ {
  id: string;
  number: number;
  stem: string;
  options: { label: 'A' | 'B' | 'C' | 'D'; content: string }[];
  correctAnswer: 'A' | 'B' | 'C' | 'D';
  solution: string;
  diagram?: any;
}

export interface ExamQuestionTF {
  id: string;
  number: number;
  stem: string;
  subQuestions: {
    id: string;
    label: 'a' | 'b' | 'c' | 'd';
    text: string;
    isCorrect: boolean;
    explanation?: string;
  }[];
  solution: string;
  diagram?: any;
}

export interface ExamQuestionShort {
  id: string;
  number: number;
  stem: string;
  correctAnswer: string;
  solution: string;
  diagram?: any;
}

export interface GeneratedExam {
  id: string;
  code: string;
  config: ExamConfig;
  title: string;
  durationMinutes: number;
  createdAt: string;
  part1: ExamQuestionMCQ[];
  part2: ExamQuestionTF[];
  part3: ExamQuestionShort[];
}

export interface StudentExamAnswers {
  part1: Record<string, 'A' | 'B' | 'C' | 'D'>;
  part2: Record<string, Record<'a' | 'b' | 'c' | 'd', boolean | null>>;
  part3: Record<string, string>;
}

export interface ExamResult {
  score: number;
  maxScore: number;
  timeSpentSeconds: number;
  part1Score: number;
  part2Score: number;
  part3Score: number;
  part1CorrectCount: number;
  part2ScoreBreakdown: { qId: string; correctCount: number; points: number }[];
  part3CorrectCount: number;
  submittedAt: string;
}

export interface WeekProblem {
  id: string;
  weekNumber: number;
  title: string;
  grade: Grade | 'all';
  type: 'short' | 'mcq' | 'essay';
  content: string;
  deadline: string;
  status: 'active' | 'ended';
  options?: string[];
  correctAnswer: string;
  solution: string;
  diagram?: any;
  reward: string;
}

export interface WeekSubmission {
  id: string;
  problemId: string;
  studentName: string;
  studentSchool: string;
  studentClass: string;
  submittedAnswer: string;
  isCorrect?: boolean;
  score?: number;
  feedback?: string;
  submittedAt: string;
}

export interface MathDocument {
  id: string;
  title: string;
  category: 'exam' | 'theory' | 'tf_bank' | 'casio' | 'applied';
  grade: Grade | 'all';
  pages: number;
  fileSize: string;
  downloadCount: number;
  description: string;
  tags: string[];
  downloadUrl?: string;
  previewUrl?: string;
}

export interface TeacherMessage {
  id: string;
  studentName: string;
  studentContact: string;
  question: string;
  grade: Grade | 'other';
  reply?: string;
  createdAt: string;
  status: 'pending' | 'answered';
}
