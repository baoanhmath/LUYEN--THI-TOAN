import katex from 'katex';

/**
 * Comprehensive utility for normalizing mathematical formulas and question content.
 * Single Source of Truth to prevent formula duplication, adjacent repeating strings,
 * broken delimiters, or MathML / HTML double rendering.
 */

/**
 * Normalizes a mathematical formula or text containing formulas:
 * 1. Converts LaTeX delimiters \( ... \) -> $ ... $, \[ ... \] -> $$ ... $$
 * 2. Deduplicates identical adjacent formulas: "$f(x)$$f(x)$" -> "$f(x)$"
 * 3. Deduplicates identical adjacent parenthesized intervals: "(-1; 1)(-1; 1)" -> "(-1; 1)"
 * 4. Deduplicates accidental doubled equation phrases
 * 5. Cleans excess whitespace inside delimiters.
 */
export function normalizeMathContent(input: string | undefined | null): string {
  if (!input) return '';

  let text = String(input);

  // 1. Convert standard LaTeX delimiters to $ and $$ (using function replacers to prevent JS string replace dollar sign bug)
  text = text.replace(/\\\\\[([\s\S]+?)\\\\\]/g, (_, m) => `$$${m}$$`);
  text = text.replace(/\\\\\(([\s\S]+?)\\\\\)/g, (_, m) => `$${m}$`);
  text = text.replace(/\\\[([\s\S]+?)\\\]/g, (_, m) => `$$${m}$$`);
  text = text.replace(/\\\(([\s\S]+?)\\\)/g, (_, m) => `$${m}$`);

  // 2. Remove duplicate adjacent formulas: e.g. "$formula$$formula$" or "$formula$ $formula$"
  text = text.replace(/(\$\$[\s\S]+?\$\$)\s*\1+/g, '$1');
  text = text.replace(/(\$[^$]+\$)\s*\1+/g, '$1');

  // 3. Remove duplicate identical parenthetical intervals: e.g. "(-1; 1)(-1; 1)"
  text = text.replace(/(\([^\)]+\))\s*\1+/g, '$1');

  // 4. Specific fix for accidental equation duplication like:
  // "y = x³ - 3x + 2y = x³ - 3x + 2" or "f(x) = ...f(x) = ..."
  text = text.replace(/((?:y|f\(x\))\s*=\s*[a-zA-Z0-9\^_\+\-\*/\s\u00B2\u00B3]{4,})\s*\1+/g, '$1');
  text = text.replace(/((?:y|f\(x\))\s*=\s*[^,;.\n]+?)\s*(?:y|f\(x\))\s*=\s*\1/g, '$1');

  // 5. Normalize spacing inside $ delimiters
  text = text.replace(/\$\s+/g, '$').replace(/\s+\$/g, '$');

  return text.trim();
}

/**
 * High-performance HTML-aware Math renderer.
 * Tokenizes HTML into tags (<...>) and text content.
 * For text content, converts inline ($...$, \(...\)) and block ($$...$$, \[...\]) math into KaTeX HTML.
 * Ensures:
 * - HTML structure (<p>, <ul>, <li>, <strong>, <h4>, etc.) is 100% preserved.
 * - KaTeX output is strict HTML-only (no MathML dual-render).
 * - Characters like < and > inside formulas (e.g. f'(x) < 0) are handled safely without breaking HTML.
 */
export function renderMathInHtml(html: string | undefined | null): string {
  if (!html) return '';

  const rawHtml = String(html);

  // Regex matches HTML tags OR Math delimiters
  const tokenRegex = /(<[^>]+>)|(\$\$[\s\S]+?\$\$|\\\[[\s\S]+?\\\]|\\\([\s\S]+?\\\)|\$[^$\n]+?\$)/g;

  return rawHtml.replace(tokenRegex, (match, tag, math) => {
    if (tag) return tag;
    if (!math) return match;

    let isBlock = false;
    let formula = '';

    if (math.startsWith('$$') && math.endsWith('$$')) {
      isBlock = true;
      formula = math.slice(2, -2);
    } else if (math.startsWith('\\[') && math.endsWith('\\]')) {
      isBlock = true;
      formula = math.slice(2, -2);
    } else if (math.startsWith('\\(') && math.endsWith('\\)')) {
      isBlock = false;
      formula = math.slice(2, -2);
    } else if (math.startsWith('$') && math.endsWith('$')) {
      isBlock = false;
      formula = math.slice(1, -1);
    } else {
      return match;
    }

    // Unescape HTML entities that might be inside math
    formula = formula.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');

    try {
      let rendered = katex.renderToString(formula.trim(), {
        displayMode: isBlock,
        throwOnError: false,
        strict: false,
        output: 'html',
      });
      // Eliminate any MathML duplication
      rendered = rendered.replace(/<span class="katex-mathml">[\s\S]*?<\/span>/gi, '');
      return rendered;
    } catch {
      return match;
    }
  });
}

/**
 * Normalizes question stem, context, options, and solution strings
 * to eliminate duplicate text or duplicate math tags before rendering.
 */
export function normalizeQuestionContent<T extends {
  context?: string;
  ask?: string;
  stem?: string;
  correctOption?: string;
  distractors?: string[];
  solution?: string;
  shortAnswer?: string;
  shortAnswerPrompt?: string;
}>(question: T): T {
  const context = question.context ? normalizeMathContent(question.context) : question.context;
  const ask = question.ask ? normalizeMathContent(question.ask) : question.ask;
  const stem = question.stem ? normalizeMathContent(question.stem) : question.stem;

  return {
    ...question,
    context,
    ask,
    stem,
    correctOption: question.correctOption ? normalizeMathContent(question.correctOption) : question.correctOption,
    distractors: question.distractors ? question.distractors.map(normalizeMathContent) : question.distractors,
    solution: question.solution ? normalizeMathContent(question.solution) : question.solution,
    shortAnswer: question.shortAnswer ? normalizeMathContent(question.shortAnswer) : question.shortAnswer,
    shortAnswerPrompt: question.shortAnswerPrompt ? normalizeMathContent(question.shortAnswerPrompt) : question.shortAnswerPrompt,
  };
}
