import React, { useState, useMemo, useEffect } from 'react';
import { Grade, Lesson, TrueFalseStatement, QuestionGenerated } from '../types/math';
import { CURRICULUM } from '../data/curriculumData';
import { TOPIC_GENERATORS, getGeneratorForLesson } from '../data/questionGenerators';
import { normalizeQuestionContent } from '../utils/mathNormalize';
import { isShortAnswerEquivalent } from '../utils/mathScoring';
import { MathTex, MathHtml } from './MathTex';
import { MathSvgFigure } from './MathSvgFigures';
import { FunctionPlot } from './FunctionPlot';
import {
  ChevronRight,
  BookOpen,
  Folder,
  RefreshCw,
  Lightbulb,
  CheckCircle2,
  XCircle,
  Sparkles,
  HelpCircle,
  FileCheck2,
  Layers
} from 'lucide-react';

interface GradeTabProps {
  grade: Grade;
}

export const GradeTab: React.FC<GradeTabProps> = ({ grade }) => {
  const chapters = CURRICULUM[grade] || [];

  // Currently selected lesson ID
  const [selectedLessonId, setSelectedLessonId] = useState<string>(() => {
    return chapters[0]?.lessons[0]?.id || '';
  });

  // Active subtab: 'theory' | 'diagram' | 'practice'
  const [subTab, setSubTab] = useState<'theory' | 'diagram' | 'practice'>('theory');

  // Currently selected lesson object
  const currentLesson: Lesson | undefined = useMemo(() => {
    for (const ch of chapters) {
      for (const les of ch.lessons) {
        if (les.id === selectedLessonId) return les;
      }
    }
    return chapters[0]?.lessons[0];
  }, [chapters, selectedLessonId]);

  // Practice state for current lesson generator: check for AI custom bank first
  const loadQuestionForLesson = (lesId: string): QuestionGenerated => {
    try {
      const savedBankStr = localStorage.getItem('pba_ai_generated_bank');
      if (savedBankStr) {
        const bank: QuestionGenerated[] = JSON.parse(savedBankStr);
        // Find matching questions for this lesson or topic
        const matching = bank.filter(
          (q) =>
            q.grade === grade &&
            (q.lessonId === lesId ||
              (q.topicTitle && currentLesson?.title && currentLesson.title.toLowerCase().includes(q.topicTitle.toLowerCase())))
        );
        if (matching.length > 0) {
          const picked = matching[Math.floor(Math.random() * matching.length)];
          return normalizeQuestionContent(picked);
        }
      }
    } catch {
      // Fallback to procedural generator
    }
    const generatorDef = getGeneratorForLesson(lesId, grade);
    return normalizeQuestionContent(generatorDef.generate());
  };

  const [generatedQuestion, setGeneratedQuestion] = useState<QuestionGenerated>(() =>
    loadQuestionForLesson(selectedLessonId)
  );

  // Stable deduplicated MCQ options
  const currentMCQOptions = useMemo(() => {
    const list = [generatedQuestion.correctOption, ...generatedQuestion.distractors];
    return Array.from(new Set(list)).sort();
  }, [generatedQuestion]);

  // Practice modes: 'mcq' | 'tf' | 'short' | 'essay'
  const [practiceMode, setPracticeMode] = useState<'mcq' | 'tf' | 'short' | 'essay'>('mcq');

  // MCQ answer state
  const [selectedMCQ, setSelectedMCQ] = useState<string | null>(null);

  // TF answer state
  const [userTF, setUserTF] = useState<Record<number, boolean | null>>({});

  // Short answer state
  const [userShort, setUserShort] = useState<string>('');

  // Essay / Written answer state
  const [userEssay, setUserEssay] = useState<string>('');
  const [isEssaySubmitted, setIsEssaySubmitted] = useState<boolean>(false);

  // Result check
  const [isChecked, setIsChecked] = useState<boolean>(false);
  const [showSolution, setShowSolution] = useState<boolean>(false);

  // Regenerate problem
  const handleRegenerate = () => {
    setGeneratedQuestion(loadQuestionForLesson(selectedLessonId));
    setSelectedMCQ(null);
    setUserTF({});
    setUserShort('');
    setUserEssay('');
    setIsEssaySubmitted(false);
    setIsChecked(false);
    setShowSolution(false);
  };

  const handleLessonChange = (lesId: string) => {
    setSelectedLessonId(lesId);
    setGeneratedQuestion(loadQuestionForLesson(lesId));
    setSelectedMCQ(null);
    setUserTF({});
    setUserShort('');
    setUserEssay('');
    setIsEssaySubmitted(false);
    setIsChecked(false);
    setShowSolution(false);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      {/* Left Column: Chapters & Lessons Tree Sidebar */}
      <aside className="lg:col-span-4 bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs sticky top-20 max-h-[calc(100vh-100px)] overflow-y-auto">
        <div className="flex items-center gap-2 pb-3 mb-3 border-b border-slate-100">
          <BookOpen className="w-5 h-5 text-teal-700" />
          <h2 className="font-bold text-slate-800 text-base">
            Chương trình Toán {grade}
          </h2>
        </div>

        <div className="space-y-3">
          {chapters.map((ch, chIdx) => (
            <details
              key={chIdx}
              open={currentLesson?.chapterIndex === chIdx}
              className="group border border-slate-100 rounded-xl overflow-hidden"
            >
              <summary className="px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100 font-bold text-xs sm:text-[13px] text-slate-800 cursor-pointer list-none flex items-center justify-between transition-colors">
                <span className="flex items-center gap-2">
                  <Folder className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                  <span className="line-clamp-1">{ch.title}</span>
                </span>
                <ChevronRight className="w-4 h-4 text-slate-400 group-open:rotate-90 transition-transform shrink-0" />
              </summary>

              <div className="p-1 space-y-1 bg-white">
                {ch.lessons.map((les) => {
                  const isSelected = les.id === selectedLessonId;
                  const hasGen = !!TOPIC_GENERATORS[les.id];

                  return (
                    <button
                      key={les.id}
                      onClick={() => handleLessonChange(les.id)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs font-semibold flex items-center justify-between transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-teal-700 text-white shadow-xs'
                          : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                      }`}
                    >
                      <span className="line-clamp-1 pr-2">{les.title}</span>
                      {hasGen && (
                        <span
                          className={`text-[10px] px-1.5 py-0.5 rounded font-mono shrink-0 ${
                            isSelected ? 'bg-white/20 text-white' : 'bg-teal-50 text-teal-700'
                          }`}
                        >
                          Sinh số
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </details>
          ))}
        </div>
      </aside>

      {/* Right Column: Interactive Lesson Sheet */}
      <main className="lg:col-span-8 bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-8 shadow-xs space-y-6">
        {currentLesson ? (
          <>
            {/* Header & Breadcrumb */}
            <div className="space-y-2 pb-4 border-b border-slate-100">
              <div className="text-xs text-slate-500 flex items-center gap-1.5">
                <span>Toán {grade}</span>
                <span>/</span>
                <span>{currentLesson.chapterTitle}</span>
              </div>
              <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 leading-tight">
                {currentLesson.title}
              </h1>

              {/* Subtabs Navigation */}
              <div className="flex items-center gap-1.5 pt-3">
                <button
                  onClick={() => setSubTab('theory')}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                    subTab === 'theory'
                      ? 'bg-teal-700 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  Lý thuyết trọng tâm
                </button>

                {currentLesson.diagramType && (
                  <button
                    onClick={() => setSubTab('diagram')}
                    className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                      subTab === 'diagram'
                        ? 'bg-teal-700 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    Đồ thị & Hình minh họa
                  </button>
                )}

                <button
                  onClick={() => setSubTab('practice')}
                  className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5 ${
                    subTab === 'practice'
                      ? 'bg-teal-700 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>Luyện tập sinh bài</span>
                </button>
              </div>
            </div>

            {/* TAB CONTENT: 1. Theory */}
            {subTab === 'theory' && (
              <div className="space-y-6">
                {/* Theory overview */}
                <MathHtml
                  className="prose prose-slate max-w-none text-sm text-slate-700 leading-relaxed"
                  content={currentLesson.theoryHtml}
                />

                {/* Formulas box */}
                {currentLesson.formulas && currentLesson.formulas.length > 0 && (
                  <div className="p-4 bg-teal-50/70 border-l-4 border-teal-700 rounded-r-xl space-y-2.5">
                    <div className="text-xs font-bold text-teal-900 uppercase tracking-wide">
                      Công thức then chốt cần ghi nhớ:
                    </div>
                    <div className="space-y-2">
                      {currentLesson.formulas.map((form, fIdx) => (
                        <div
                          key={fIdx}
                          className="bg-white/90 p-2.5 rounded-lg border border-teal-200/60 text-slate-800 text-sm font-medium"
                        >
                          <MathTex content={`$${form}$`} block={false} />
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Key notes */}
                {currentLesson.keyNotes && currentLesson.keyNotes.length > 0 && (
                  <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl space-y-2">
                    <div className="text-xs font-bold text-amber-900 uppercase tracking-wide flex items-center gap-1.5">
                      <HelpCircle className="w-4 h-4 text-amber-600" />
                      Lưu ý quan trọng & Tránh bẫy trong phòng thi:
                    </div>
                    <ul className="list-disc list-inside space-y-1.5 text-xs sm:text-sm text-amber-950">
                      {currentLesson.keyNotes.map((note, nIdx) => (
                        <li key={nIdx}>
                          <MathTex content={note} />
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}

            {/* TAB CONTENT: 2. Diagram */}
            {subTab === 'diagram' && currentLesson.diagramType && (
              <div className="space-y-4 flex flex-col items-center">
                {currentLesson.id === '12-4' ? (
                  <div className="w-full max-w-lg p-3 bg-white rounded-xl border border-slate-200/80 shadow-xs flex justify-center">
                    <FunctionPlot
                      f={(x: number) => (2 * x + 1) / (x - 1)}
                      xRange={[-4, 6]}
                      yRange={[-3, 7]}
                      vAsymptotes={[1]}
                      hAsymptotes={[2]}
                      points={[{ x: 1, y: 2, label: 'I(1; 2)' }]}
                      caption="Đồ thị hàm số y = (2x + 1)/(x − 1)"
                    />
                  </div>
                ) : currentLesson.id === '12-1' ? (
                  <div className="w-full max-w-lg p-3 bg-white rounded-xl border border-slate-200/80 shadow-xs flex justify-center">
                    <FunctionPlot
                      f={(x: number) => x * x * x - 3 * x + 2}
                      xRange={[-3.5, 3.5]}
                      yRange={[-3, 7]}
                      points={[
                        { x: -1, y: 4, label: 'CĐ(-1; 4)' },
                        { x: 1, y: 0, label: 'CT(1; 0)' },
                        { x: 0, y: 2, label: 'U(0; 2)' }
                      ]}
                      caption="Đồ thị hàm số y = x³ - 3x + 2"
                    />
                  </div>
                ) : currentLesson.id === '12-2' ? (
                  <div className="w-full max-w-lg p-3 bg-white rounded-xl border border-slate-200/80 shadow-xs flex justify-center">
                    <FunctionPlot
                      f={(x: number) => x * x * x - 3 * x}
                      xRange={[-3.5, 3.5]}
                      yRange={[-4, 4]}
                      points={[
                        { x: -1, y: 2, label: 'CĐ(-1; 2)' },
                        { x: 1, y: -2, label: 'CT(1; -2)' },
                        { x: 0, y: 0, label: 'O(0; 0)' }
                      ]}
                      caption="Đồ thị hàm số y = x³ - 3x"
                    />
                  </div>
                ) : currentLesson.id === '12-7' ? (
                  <div className="w-full max-w-lg p-3 bg-white rounded-xl border border-slate-200/80 shadow-xs flex justify-center">
                    <FunctionPlot
                      f={(x: number) => x * x}
                      xRange={[-3, 3]}
                      yRange={[-1, 9]}
                      points={[
                        { x: 0, y: 0, label: 'O(0; 0)' },
                        { x: 1, y: 1, label: 'A(1; 1)' },
                        { x: 2, y: 4, label: 'B(2; 4)' }
                      ]}
                      caption="Đồ thị hàm số y = x²"
                    />
                  </div>
                ) : (
                  <MathSvgFigure
                    type={currentLesson.diagramType}
                    params={currentLesson.diagramParams}
                    caption={`Hình học và đồ thị minh họa cho: ${currentLesson.title}`}
                  />
                )}
                <p className="text-xs text-slate-500 max-w-md text-center">
                  Quan sát trực quan đồ thị và các điểm đặc biệt để nắm vững mối tương quan giữa đạo hàm, tiếp tuyến, cực trị và hình học không gian.
                </p>
              </div>
            )}

            {/* TAB CONTENT: 3. Dynamic Practice */}
            {subTab === 'practice' && (
              <div className="space-y-6">
                {/* Practice Mode Selector */}
                <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-slate-50 rounded-xl border border-slate-200/80">
                  <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200 shadow-xs">
                    <button
                      onClick={() => setPracticeMode('mcq')}
                      className={`px-3 py-1 rounded-md text-xs font-bold transition-colors cursor-pointer ${
                        practiceMode === 'mcq'
                          ? 'bg-teal-700 text-white'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Trắc nghiệm (4 phương án)
                    </button>
                    <button
                      onClick={() => setPracticeMode('tf')}
                      className={`px-3 py-1 rounded-md text-xs font-bold transition-colors cursor-pointer ${
                        practiceMode === 'tf'
                          ? 'bg-teal-700 text-white'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Đúng / Sai (Format 2025)
                    </button>
                    <button
                      onClick={() => setPracticeMode('short')}
                      className={`px-3 py-1 rounded-md text-xs font-bold transition-colors cursor-pointer ${
                        practiceMode === 'short'
                          ? 'bg-teal-700 text-white'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Trả lời ngắn
                    </button>
                    <button
                      onClick={() => setPracticeMode('essay')}
                      className={`px-3 py-1 rounded-md text-xs font-bold transition-colors cursor-pointer ${
                        practiceMode === 'essay'
                          ? 'bg-teal-700 text-white'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Tự luận (Bài giải chi tiết)
                    </button>
                  </div>

                  <button
                    onClick={handleRegenerate}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-50 hover:bg-teal-100 text-teal-800 text-xs font-bold transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Sinh bài mới</span>
                  </button>
                </div>

                {/* Problem Stem */}
                <div className="p-4 bg-slate-50/70 rounded-xl border border-slate-200/80 space-y-2">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="text-xs font-bold text-teal-800 uppercase">
                      Bài tập rèn luyện dạng toán ({generatedQuestion.topicTitle}):
                    </div>
                    {generatedQuestion.sourceDocument && (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-teal-100 text-teal-800 border border-teal-200">
                        <Sparkles className="w-3 h-3 text-[#F4B942]" />
                        <span>Từ tài liệu: {generatedQuestion.sourceDocument}</span>
                      </span>
                    )}
                  </div>
                  <div className="text-sm sm:text-base text-slate-800 leading-relaxed font-medium">
                    <MathTex content={generatedQuestion.context} />
                  </div>
                  {practiceMode !== 'tf' && (
                    <div className="text-sm sm:text-base font-semibold text-slate-900 pt-1">
                      <MathTex
                        content={
                          practiceMode === 'short'
                            ? generatedQuestion.shortAnswerPrompt || generatedQuestion.ask
                            : generatedQuestion.ask
                        }
                      />
                    </div>
                  )}
                </div>

                {/* MODE 1: MCQ */}
                {practiceMode === 'mcq' && (
                  <div className="space-y-3">
                    <div className="text-xs font-semibold text-slate-500">
                      Chọn đáp án chính xác:
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {currentMCQOptions.map((opt, idx) => {
                        const label = ['A', 'B', 'C', 'D'][idx];
                        const isSelected = selectedMCQ === opt;
                        let borderStyle = 'border-slate-200 bg-white hover:border-slate-300';

                        if (isChecked) {
                          if (opt === generatedQuestion.correctOption) {
                            borderStyle = 'border-emerald-500 bg-emerald-50/70 text-emerald-900 font-semibold';
                          } else if (isSelected) {
                            borderStyle = 'border-rose-400 bg-rose-50/70 text-rose-900';
                          }
                        } else if (isSelected) {
                          borderStyle = 'border-teal-700 bg-teal-50/70 text-teal-900';
                        }

                        return (
                          <button
                            key={idx}
                            onClick={() => !isChecked && setSelectedMCQ(opt)}
                            className={`flex items-start gap-3 p-3 rounded-xl border text-left text-sm transition-all cursor-pointer ${borderStyle}`}
                          >
                            <span className="w-6 h-6 rounded-md bg-slate-100 flex items-center justify-center font-bold text-xs text-slate-700 shrink-0">
                              {label}
                            </span>
                            <span className="pt-0.5 leading-snug">
                              <MathTex content={opt} />
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* MODE 2: TRUE / FALSE */}
                {practiceMode === 'tf' && (
                  <div className="space-y-3">
                    <div className="text-xs font-semibold text-slate-500">
                      Xét tính Đúng / Sai của các khẳng định sau:
                    </div>
                    <div className="space-y-2">
                      {generatedQuestion.tfStatements.map((stmt, sIdx) => {
                        const userChoice = userTF[sIdx];
                        const label = ['a', 'b', 'c', 'd'][sIdx];
                        const isStmtCorrect = isChecked && userChoice === stmt.isTrue;

                        return (
                          <div
                            key={sIdx}
                            className={`p-3.5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                              isChecked
                                ? isStmtCorrect
                                  ? 'border-emerald-200 bg-emerald-50/40'
                                  : 'border-rose-200 bg-rose-50/40'
                                : 'border-slate-200 bg-white'
                            }`}
                          >
                            <div className="text-sm text-slate-800 flex items-start gap-2">
                              <span className="font-bold text-slate-700">{label})</span>
                              <span>
                                <MathTex content={stmt.text} />
                              </span>
                            </div>

                            <div className="flex items-center gap-2 shrink-0">
                              <button
                                onClick={() =>
                                  !isChecked && setUserTF({ ...userTF, [sIdx]: true })
                                }
                                className={`px-3 py-1 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                                  userChoice === true
                                    ? 'bg-teal-700 text-white border-teal-700'
                                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                                }`}
                              >
                                Đúng
                              </button>
                              <button
                                onClick={() =>
                                  !isChecked && setUserTF({ ...userTF, [sIdx]: false })
                                }
                                className={`px-3 py-1 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                                  userChoice === false
                                    ? 'bg-rose-700 text-white border-rose-700'
                                    : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                                }`}
                              >
                                Sai
                              </button>
                              {isChecked && (
                                <span className="text-xs font-bold pl-1">
                                  {stmt.isTrue ? (
                                    <span className="text-emerald-700">(Đúng)</span>
                                  ) : (
                                    <span className="text-rose-700">(Sai)</span>
                                  )}
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* MODE 3: SHORT ANSWER */}
                {practiceMode === 'short' && (
                  <div className="space-y-3">
                    <div className="text-xs font-semibold text-slate-500">
                      Nhập đáp số (số nguyên hoặc số thập phân):
                    </div>
                    <div className="flex flex-wrap items-center gap-3">
                      <input
                        type="text"
                        value={userShort}
                        onChange={(e) => setUserShort(e.target.value)}
                        disabled={isChecked}
                        placeholder="Ví dụ: 5 hoặc 0.5"
                        className="px-4 py-2.5 rounded-xl border border-slate-300 bg-white text-slate-900 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 max-w-xs"
                      />
                      {isChecked && (
                        <div className="flex items-center gap-2">
                          {isShortAnswerEquivalent(userShort, generatedQuestion.shortAnswer) ? (
                            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-bold">
                              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                              Chính xác! Đạt 100% điểm
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-100 text-rose-800 text-xs font-bold">
                              <XCircle className="w-4 h-4 text-rose-600" />
                              Chưa chính xác (Đáp số chuẩn: <strong className="font-mono">{generatedQuestion.shortAnswer}</strong>)
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* MODE 4: WRITTEN / ESSAY RESPONSE */}
                {practiceMode === 'essay' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between text-xs text-slate-500">
                      <span className="font-semibold text-slate-700">Trình bày bài giải tự luận từng bước:</span>
                      <span className="text-[11px] bg-slate-100 px-2 py-0.5 rounded text-slate-600">
                        {isEssaySubmitted ? 'Đã lưu bài nộp' : 'Tự luận tự đánh giá'}
                      </span>
                    </div>

                    {/* Quick Math Symbols Helper */}
                    <div className="flex flex-wrap items-center gap-1.5 p-2 bg-slate-50 rounded-lg border border-slate-200/80 text-xs">
                      <span className="text-[11px] font-semibold text-slate-500 pr-1">Kí hiệu nhanh:</span>
                      {[
                        { label: 'x²', text: 'x^2' },
                        { label: '√x', text: '\\sqrt{x}' },
                        { label: 'a/b', text: '\\frac{a}{b}' },
                        { label: '∫', text: '\\int' },
                        { label: '±', text: '\\pm' },
                        { label: '∈', text: '\\in' },
                        { label: '⇒', text: '\\Rightarrow' },
                        { label: 'Δ', text: '\\Delta' }
                      ].map((sym) => (
                        <button
                          key={sym.label}
                          type="button"
                          onClick={() => setUserEssay((prev) => prev + ` ${sym.text} `)}
                          className="px-2 py-0.5 rounded bg-white hover:bg-teal-50 border border-slate-200 text-slate-700 text-xs font-mono font-bold transition-colors cursor-pointer"
                        >
                          {sym.label}
                        </button>
                      ))}
                    </div>

                    <textarea
                      value={userEssay}
                      onChange={(e) => setUserEssay(e.target.value)}
                      disabled={isEssaySubmitted}
                      placeholder="Bước 1: Tìm tập xác định...\nBước 2: Tính đạo hàm y' = ...\nBước 3: Lập bảng biến thiên và kết luận..."
                      rows={6}
                      className="w-full p-3.5 rounded-xl border border-slate-300 bg-white text-slate-900 text-sm font-sans focus:outline-none focus:ring-2 focus:ring-teal-500 leading-relaxed resize-y"
                    />

                    {/* Action buttons for essay mode */}
                    <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
                      <div className="flex items-center gap-2">
                        {!isEssaySubmitted ? (
                          <button
                            onClick={() => {
                              if (!userEssay.trim()) return;
                              setIsEssaySubmitted(true);
                              setShowSolution(true);
                            }}
                            disabled={!userEssay.trim()}
                            className="px-4 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 disabled:opacity-40 text-white text-xs sm:text-sm font-bold shadow-xs transition-colors cursor-pointer"
                          >
                            Lưu & Nộp bài tự luận
                          </button>
                        ) : (
                          <div className="flex items-center gap-2">
                            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-50 border border-teal-200 text-teal-800 text-xs font-bold">
                              <CheckCircle2 className="w-4 h-4 text-teal-600" />
                              Đã nộp bài giải · Yêu cầu giáo viên chấm điểm / Tự đối chiếu đáp án mẫu
                            </span>
                            <button
                              onClick={() => setIsEssaySubmitted(false)}
                              className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold cursor-pointer"
                            >
                              Chỉnh sửa lại
                            </button>
                          </div>
                        )}
                      </div>

                      <button
                        onClick={() => setShowSolution(!showSolution)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors cursor-pointer"
                      >
                        <Lightbulb className="w-4 h-4 text-amber-600" />
                        <span>{showSolution ? 'Ẩn đáp án mẫu' : 'Xem đáp án mẫu'}</span>
                      </button>
                    </div>

                    {/* Self-Assessment Rubric for Essay */}
                    {isEssaySubmitted && (
                      <div className="p-4 bg-amber-50/70 border border-amber-200 rounded-xl space-y-2 text-xs">
                        <div className="font-bold text-amber-900 uppercase flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-amber-600" />
                          Tiêu chí tự chấm điểm bài làm tự luận (Thang 10 điểm):
                        </div>
                        <ul className="list-disc list-inside space-y-1 text-amber-950 pl-1">
                          <li>Nêu đúng điều kiện xác định / miền giá trị (1.0 điểm).</li>
                          <li>Áp dụng chính xác công thức đạo hàm, tích phân hoặc hình học (3.0 điểm).</li>
                          <li>Lập luận các bước biến đổi trung gian logic, không nhảy cóc (3.0 điểm).</li>
                          <li>Kết luận chính xác nghiệm, khoảng hoặc đại lượng cần tìm (3.0 điểm).</li>
                        </ul>
                      </div>
                    )}
                  </div>
                )}

                {/* Submission & Feedback controls for non-essay modes */}
                {practiceMode !== 'essay' && (
                  <div className="flex flex-wrap items-center gap-3 pt-3 border-t border-slate-100">
                    {!isChecked ? (
                      <button
                        onClick={() => setIsChecked(true)}
                        className="px-5 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-sm font-bold shadow-xs transition-colors cursor-pointer"
                      >
                        Kiểm tra đáp án
                      </button>
                    ) : (
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setShowSolution(!showSolution)}
                          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm font-semibold transition-colors cursor-pointer"
                        >
                          <Lightbulb className="w-4 h-4 text-amber-600" />
                          <span>{showSolution ? 'Ẩn lời giải' : 'Xem lời giải chi tiết'}</span>
                        </button>

                        <button
                          onClick={handleRegenerate}
                          className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-50 hover:bg-teal-100 text-teal-800 text-sm font-bold transition-colors cursor-pointer"
                        >
                          <RefreshCw className="w-4 h-4" />
                          <span>Sinh bài khác</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Solution display */}
                {showSolution && (
                  <div className="p-5 bg-teal-50/50 rounded-xl border border-teal-200 space-y-3 animate-fadeIn">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-teal-900 uppercase">
                      <Lightbulb className="w-4 h-4 text-amber-500" />
                      Lời giải chi tiết từng bước từ Thầy Phạm Bảo Anh:
                    </div>
                    <div className="text-sm text-slate-800 leading-relaxed whitespace-pre-line space-y-2">
                      <MathTex content={generatedQuestion.solution} />
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        ) : (
          <div className="p-8 text-center text-slate-400">
            Vui lòng chọn bài học từ danh mục bên trái.
          </div>
        )}
      </main>
    </div>
  );
};

export default GradeTab;
