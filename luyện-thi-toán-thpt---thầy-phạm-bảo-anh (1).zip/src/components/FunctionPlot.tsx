import React, { useId, useMemo } from 'react';

export interface PlotPoint {
  x: number;
  y: number;
  label?: string;
}

interface SlantAsymptote {
  a: number; // y = a*x + b
  b: number;
  label?: string;
}

interface FunctionPlotProps {
  f: (x: number) => number;
  xRange?: [number, number];
  yRange?: [number, number];
  vAsymptotes?: number[]; // tiệm cận đứng: x = v
  hAsymptotes?: number[]; // tiệm cận ngang: y = h
  slantAsymptotes?: SlantAsymptote[]; // tiệm cận xiên
  points?: PlotPoint[];
  width?: number;
  caption?: string;
  curveColor?: string;
}

const fmt = (n: number) => n.toFixed(2);

/**
 * Vẽ đồ thị hàm số bằng SVG.
 * - Tự tách nhánh tại mỗi tiệm cận đứng (mỗi nhánh là một path "M" riêng, không nối nhau).
 * - Lấy mẫu dày, đặc biệt dày khi tiến sát tiệm cận đứng.
 * - Tỉ lệ hai trục bằng nhau (1 đơn vị Ox = 1 đơn vị Oy).
 * - Màu dùng currentColor nên hiển thị tốt ở cả chế độ sáng và tối.
 */
export default function FunctionPlot({
  f,
  xRange = [-4, 6],
  yRange = [-3, 7],
  vAsymptotes = [],
  hAsymptotes = [],
  slantAsymptotes = [],
  points = [],
  width = 420,
  caption,
  curveColor = '#0f766e',
}: FunctionPlotProps) {
  const uid = useId().replace(/:/g, '');
  const [x0, x1] = xRange;
  const [y0, y1] = yRange;
  const xs = x1 - x0;
  const ys = y1 - y0;
  const W = width;
  const H = Math.round((width * ys) / xs); // giữ tỉ lệ 1:1

  const sx = (x: number) => ((x - x0) / xs) * W;
  const sy = (y: number) => H - ((y - y0) / ys) * H;

  // Mỗi phần tử là một nhánh liên tục của đồ thị
  const branches = useMemo(() => {
    const vas = vAsymptotes
      .filter((v) => v > x0 && v < x1)
      .sort((a, b) => a - b);
    const cuts = [x0, ...vas, x1];
    const BIG = ys * 3; // đẩy điểm ra ngoài khung, clipPath sẽ cắt
    const result: string[] = [];

    for (let i = 0; i < cuts.length - 1; i++) {
      const a = cuts[i];
      const b = cuts[i + 1];
      const aIsVA = i > 0;
      const bIsVA = i < cuts.length - 2;

      const xsList: number[] = [];
      const N = 400;
      for (let k = 0; k <= N; k++) xsList.push(a + ((b - a) * k) / N);
      // Lấy mẫu dày sát tiệm cận đứng
      for (let k = 0; k < 80; k++) {
        const d = 0.5 * Math.pow(0.85, k);
        if (aIsVA) xsList.push(a + d);
        if (bIsVA) xsList.push(b - d);
      }

      const pts = xsList
        .filter(
          (x) =>
            x >= a &&
            x <= b &&
            (aIsVA ? x > a : true) &&
            (bIsVA ? x < b : true)
        )
        .sort((p, q) => p - q);

      let d = '';
      for (const x of pts) {
        let y = f(x);
        if (!Number.isFinite(y)) continue;
        y = Math.max(y0 - BIG, Math.min(y1 + BIG, y));
        d += `${d ? 'L' : 'M'}${fmt(sx(x))} ${fmt(sy(y))}`;
      }
      if (d) result.push(d);
    }
    return result;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [f, x0, x1, y0, y1, W, H, vAsymptotes.join(',')]);

  const gridX: number[] = [];
  for (let i = Math.ceil(x0); i <= Math.floor(x1); i++) gridX.push(i);
  const gridY: number[] = [];
  for (let i = Math.ceil(y0); i <= Math.floor(y1); i++) gridY.push(i);

  const showTicks = xs <= 14 && ys <= 14;
  const axisX = y0 <= 0 && y1 >= 0 ? sy(0) : null;
  const axisY = x0 <= 0 && x1 >= 0 ? sx(0) : null;

  return (
    <figure style={{ margin: 0, textAlign: 'center' }}>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        style={{ width: '100%', maxWidth: W, height: 'auto', color: 'inherit' }}
        role="img"
        aria-label={caption || 'Đồ thị hàm số'}
      >
        <defs>
          <clipPath id={`clip-${uid}`}>
            <rect x={0} y={0} width={W} height={H} />
          </clipPath>
          <marker
            id={`arrow-${uid}`}
            viewBox="0 0 10 10"
            refX="9"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
          >
            <path d="M0 0L10 5L0 10z" fill="currentColor" />
          </marker>
        </defs>

        {/* Lưới */}
        <g stroke="currentColor" strokeOpacity={0.12} strokeWidth={1}>
          {gridX.map((g) => (
            <line key={`gx${g}`} x1={sx(g)} y1={0} x2={sx(g)} y2={H} />
          ))}
          {gridY.map((g) => (
            <line key={`gy${g}`} x1={0} y1={sy(g)} x2={W} y2={sy(g)} />
          ))}
        </g>

        {/* Trục tọa độ */}
        {axisX !== null && (
          <line
            x1={0}
            y1={axisX}
            x2={W - 2}
            y2={axisX}
            stroke="currentColor"
            strokeWidth={1.5}
            markerEnd={`url(#arrow-${uid})`}
          />
        )}
        {axisY !== null && (
          <line
            x1={axisY}
            y1={H}
            x2={axisY}
            y2={2}
            stroke="currentColor"
            strokeWidth={1.5}
            markerEnd={`url(#arrow-${uid})`}
          />
        )}
        {axisX !== null && axisY !== null && (
          <g fontSize={13} fill="currentColor" fontStyle="italic">
            <text x={W - 14} y={axisX + 18}>x</text>
            <text x={axisY + 8} y={14}>y</text>
            <text x={axisY - 14} y={axisX + 16} fontStyle="normal">O</text>
          </g>
        )}
        {showTicks && axisX !== null && axisY !== null && (
          <g fontSize={10} fill="currentColor" fillOpacity={0.65}>
            {gridX
              .filter((g) => g !== 0)
              .map((g) => (
                <text key={`tx${g}`} x={sx(g)} y={axisX + 13} textAnchor="middle">
                  {g}
                </text>
              ))}
            {gridY
              .filter((g) => g !== 0)
              .map((g) => (
                <text key={`ty${g}`} x={axisY - 5} y={sy(g) + 3} textAnchor="end">
                  {g}
                </text>
              ))}
          </g>
        )}

        {/* Tiệm cận (nét đứt) */}
        <g strokeDasharray="6 4" strokeWidth={1.5} fill="none">
          {vAsymptotes.map((v) => (
            <g key={`va${v}`}>
              <line x1={sx(v)} y1={0} x2={sx(v)} y2={H} stroke="#dc2626" />
              <text x={sx(v) + 6} y={16} fontSize={12} fill="#dc2626" stroke="none">
                {`TCĐ: x = ${v}`}
              </text>
            </g>
          ))}
          {hAsymptotes.map((h) => (
            <g key={`ha${h}`}>
              <line x1={0} y1={sy(h)} x2={W} y2={sy(h)} stroke="#2563eb" />
              <text
                x={W - 6}
                y={sy(h) - 6}
                fontSize={12}
                fill="#2563eb"
                stroke="none"
                textAnchor="end"
              >
                {`TCN: y = ${h}`}
              </text>
            </g>
          ))}
          {slantAsymptotes.map((s, i) => (
            <g key={`sa${i}`}>
              <line
                x1={sx(x0)}
                y1={sy(s.a * x0 + s.b)}
                x2={sx(x1)}
                y2={sy(s.a * x1 + s.b)}
                stroke="#9333ea"
                clipPath={`url(#clip-${uid})`}
              />
              <text x={W - 6} y={16} fontSize={12} fill="#9333ea" stroke="none" textAnchor="end">
                {s.label ??
                  `TCX: y = ${s.a}x ${s.b >= 0 ? '+' : '−'} ${Math.abs(s.b)}`}
              </text>
            </g>
          ))}
        </g>

        {/* Đường cong: mỗi nhánh một path riêng */}
        <g clipPath={`url(#clip-${uid})`}>
          {branches.map((d, i) => (
            <path
              key={i}
              d={d}
              fill="none"
              stroke={curveColor}
              strokeWidth={2.5}
              strokeLinejoin="round"
              strokeLinecap="round"
            />
          ))}
        </g>

        {/* Điểm đặc biệt, ví dụ tâm đối xứng */}
        {points.map((p, i) => (
          <g key={`pt${i}`}>
            <circle cx={sx(p.x)} cy={sy(p.y)} r={4} fill="currentColor" />
            {p.label && (
              <text x={sx(p.x) + 8} y={sy(p.y) + 16} fontSize={12} fill="currentColor">
                {p.label}
              </text>
            )}
          </g>
        ))}
      </svg>
      {caption && (
        <figcaption style={{ fontSize: 13, opacity: 0.7, marginTop: 8, fontStyle: 'italic' }}>
          {caption}
        </figcaption>
      )}
    </figure>
  );
}

export { FunctionPlot };
