import React, { useMemo } from 'react';
import katex from 'katex';
import { normalizeMathContent, renderMathInHtml } from '../utils/mathNormalize';

export { renderMathInHtml };

interface MathTexProps {
  children?: React.ReactNode;
  content?: string;
  math?: string;
  block?: boolean;
  className?: string;
}

/**
 * Single Source of Truth for Mathematical Formula Rendering.
 * Guarantees that:
 * - Each formula is parsed and rendered EXACTLY ONCE.
 * - KaTeX produces only HTML output (no MathML dual-render).
 * - Any stray MathML or duplicate tokens are stripped out.
 * - Supports inline ($...$, \(...\)) and display ($$...$$, \[...\]) math seamlessly.
 */
export const MathTex: React.FC<MathTexProps> = ({ content, math, children, block = false, className = '' }) => {
  const initialText = content !== undefined ? content : math !== undefined ? math : typeof children === 'string' ? children : '';

  const renderedHtml = useMemo(() => {
    if (!initialText) return '';

    // Step 1: Normalize text to remove duplicate adjacent math tokens or duplicated equation strings
    const rawText = normalizeMathContent(initialText);

    // If whole string is requested as a block formula without $ markers
    if (block && !rawText.includes('$') && !rawText.includes('\\(') && !rawText.includes('\\[')) {
      try {
        let res = katex.renderToString(rawText, {
          displayMode: true,
          throwOnError: false,
          strict: false,
          output: 'html', // Strict HTML-only
        });
        // Defensive strip of any MathML tag
        res = res.replace(/<span class="katex-mathml">[\s\S]*?<\/span>/gi, '');
        return res;
      } catch {
        return `<span class="font-mono text-sm">${escapeHtml(rawText)}</span>`;
      }
    }

    // Split text by $$...$$, \[...\], $...$, \(...\)
    const parts: string[] = [];
    let lastIndex = 0;
    const regex = /\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]|\\\((\s*[\s\S]+?\s*)\\\)|\$([^$\n]+?)\$/g;
    let match: RegExpExecArray | null;

    while ((match = regex.exec(rawText)) !== null) {
      // Text before formula
      if (match.index > lastIndex) {
        const textSegment = rawText.substring(lastIndex, match.index);
        parts.push(escapeHtml(textSegment).replace(/\n/g, '<br/>'));
      }

      const isBlock = match[1] !== undefined || match[2] !== undefined;
      const formula = match[1] ?? match[2] ?? match[3] ?? match[4];

      try {
        let rendered = katex.renderToString((formula || '').trim(), {
          displayMode: isBlock,
          throwOnError: false,
          strict: false,
          output: 'html', // Strict HTML-only to eliminate duplicate MathML text
        });
        // Defensive strip of any MathML element
        rendered = rendered.replace(/<span class="katex-mathml">[\s\S]*?<\/span>/gi, '');
        parts.push(rendered);
      } catch {
        parts.push(`<span class="font-mono text-red-600">${escapeHtml(match[0])}</span>`);
      }

      lastIndex = match.index + match[0].length;
    }

    if (lastIndex < rawText.length) {
      parts.push(escapeHtml(rawText.substring(lastIndex)).replace(/\n/g, '<br/>'));
    }

    return parts.join('');
  }, [initialText, block]);

  return (
    <span
      className={`inline-math ${block ? 'block text-center my-2' : 'inline'} ${className}`}
      dangerouslySetInnerHTML={{ __html: renderedHtml }}
    />
  );
};

interface MathHtmlProps {
  content: string;
  className?: string;
}

/**
 * Component for rendering rich HTML blocks (like lesson theory notes)
 * that contain HTML markup along with embedded math formulas.
 */
export const MathHtml: React.FC<MathHtmlProps> = ({ content, className = '' }) => {
  const rendered = useMemo(() => renderMathInHtml(content), [content]);

  return (
    <div
      className={className}
      dangerouslySetInnerHTML={{ __html: rendered }}
    />
  );
};

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export default MathTex;
