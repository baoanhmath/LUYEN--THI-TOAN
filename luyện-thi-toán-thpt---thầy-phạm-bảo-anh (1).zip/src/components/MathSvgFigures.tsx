import React from 'react';
import FunctionPlot, { PlotPoint } from './FunctionPlot';
import {
  analyzeCubicFunction,
  analyzeRationalFunction,
  analyzeQuadraticFunction
} from '../utils/graphEngine';

interface DiagramProps {
  type: string;
  params?: Record<string, any>;
  className?: string;
  caption?: string;
}

export const MathSvgFigure: React.FC<DiagramProps> = ({ type, params = {}, className = '', caption }) => {
  return (
    <div className={`flex flex-col items-center justify-center p-3 bg-white rounded-xl border border-slate-200/80 shadow-xs max-w-md mx-auto ${className}`}>
      <div className="w-full flex justify-center overflow-x-auto py-1">
        {renderFigure(type, params)}
      </div>
      {caption && (
        <span className="text-xs text-slate-500 font-medium mt-2 text-center italic">
          {caption}
        </span>
      )}
    </div>
  );
};

function renderFigure(type: string, params: Record<string, any>) {
  switch (type) {
    case 'cubic':
      return renderCubicGraph(params);
    case 'rational':
      return renderRationalGraph(params);
    case 'quadratic':
      return renderQuadraticGraph(params);
    case 'integral':
      return renderIntegralGraph(params);
    case 'circle':
    case 'trig':
      return renderUnitCircle(params);
    case 'pyramid':
      return renderPyramid(params);
    case 'prism':
      return renderPrism(params);
    case 'box':
      return renderBox(params);
    case 'numberLine':
      return renderNumberLine(params);
    case 'histogram':
      return renderHistogram(params);
    case 'appliedMaxMin':
      return renderAppliedMaxMin(params);
    default:
      return renderCubicGraph(params);
  }
}

// 1. Đồ thị hàm bậc 3: Dùng component FunctionPlot
function renderCubicGraph(params: Record<string, any>) {
  const a = Number(params.a ?? 1);
  const b = Number(params.b ?? 0);
  const c = Number(params.c ?? -3);
  const d = Number(params.d ?? 2);
  const analysis = analyzeCubicFunction(a, b, c, d);
  const { viewport, hasExtrema, cd, ct, inflection } = analysis;

  const pts: PlotPoint[] = [];
  if (hasExtrema && cd && ct) {
    pts.push({ x: cd.x, y: cd.y, label: `CĐ(${cd.x}; ${cd.y})` });
    pts.push({ x: ct.x, y: ct.y, label: `CT(${ct.x}; ${ct.y})` });
  }
  if (inflection) {
    pts.push({ x: inflection.x, y: inflection.y, label: `U(${inflection.x.toFixed(1)}; ${inflection.y.toFixed(1)})` });
  }

  return (
    <FunctionPlot
      f={(x) => a * x * x * x + b * x * x + c * x + d}
      xRange={params.xRange || [viewport.xMin, viewport.xMax]}
      yRange={params.yRange || [viewport.yMin, viewport.yMax]}
      points={pts}
      caption={params.caption}
      width={params.width || 340}
    />
  );
}

// 2. Đồ thị hàm phân thức bậc nhất y = (ax+b)/(cx+d): Dùng component FunctionPlot
function renderRationalGraph(params: Record<string, any>) {
  const x0Param = params.x0 !== undefined ? Number(params.x0) : undefined;
  const a = Number(params.a ?? 2);
  const b = Number(params.b ?? 1);
  const c = Number(params.c ?? 1);
  const d = x0Param !== undefined ? -x0Param : Number(params.d ?? -1);
  const xVa = -d / c;
  const yHa = a / c;

  return (
    <FunctionPlot
      f={(x) => (a * x + b) / (c * x + d)}
      xRange={params.xRange || [-4, 6]}
      yRange={params.yRange || [-3, 7]}
      vAsymptotes={[xVa]}
      hAsymptotes={[yHa]}
      points={[{ x: xVa, y: yHa, label: `I(${xVa}; ${yHa})` }]}
      caption={params.caption}
      width={params.width || 340}
    />
  );
}

// 3. Đồ thị Parabol y = ax^2 + bx + c: Dùng component FunctionPlot
function renderQuadraticGraph(params: Record<string, any>) {
  const a = Number(params.a ?? 1);
  const b = Number(params.b ?? 0);
  const c = Number(params.c ?? 0);
  const xv = -b / (2 * a);
  const yv = a * xv * xv + b * xv + c;

  return (
    <FunctionPlot
      f={(x) => a * x * x + b * x + c}
      xRange={params.xRange || [xv - 3, xv + 3]}
      yRange={params.yRange || (a > 0 ? [yv - 1, yv + 8] : [yv - 8, yv + 1])}
      points={[{ x: xv, y: yv, label: `Đỉnh I(${xv.toFixed(1)}; ${yv.toFixed(1)})` }]}
      caption={params.caption}
      width={params.width || 340}
    />
  );
}

// 4. Tích phân & diện tích hình phẳng: Dùng component FunctionPlot
function renderIntegralGraph(params: Record<string, any>) {
  return (
    <FunctionPlot
      f={(x) => x * x}
      xRange={[-2.5, 2.5]}
      yRange={[-0.5, 5]}
      points={[
        { x: 0, y: 0, label: 'O(0; 0)' },
        { x: 1, y: 1, label: 'A(1; 1)' },
        { x: 2, y: 4, label: 'B(2; 4)' }
      ]}
      caption={params.caption || 'Đồ thị hàm số y = x²'}
      width={params.width || 340}
    />
  );
}

// 5. Đường tròn lượng giác
function renderUnitCircle(params: Record<string, any>) {
  return (
    <svg viewBox="0 0 240 220" className="w-[240px] h-[220px] select-none">
      {/* Axes */}
      <line x1="20" y1="110" x2="220" y2="110" stroke="#334155" strokeWidth="1.5" />
      <polygon points="220,110 212,106 212,114" fill="#334155" />
      <text x="224" y="114" fontSize="11" fill="#334155" fontWeight="600">cos α</text>

      <line x1="120" y1="205" x2="120" y2="15" stroke="#334155" strokeWidth="1.5" />
      <polygon points="120,15 116,23 124,23" fill="#334155" />
      <text x="110" y="12" fontSize="11" fill="#334155" fontWeight="600">sin α</text>
      <text x="124" y="124" fontSize="10" fill="#64748B">O</text>

      {/* Circle R = 75px */}
      <circle cx="120" cy="110" r="75" fill="none" stroke="#0F766E" strokeWidth="2" />

      {/* Angle alpha = 45 deg */}
      {/* cos 45 = 0.707 -> 120 + 53 = 173, sin 45 = 0.707 -> 110 - 53 = 57 */}
      <line x1="120" y1="110" x2="173" y2="57" stroke="#EF4444" strokeWidth="2" />
      <circle cx="173" cy="57" r="3.5" fill="#EF4444" />
      <text x="178" y="55" fontSize="11" fill="#EF4444" fontWeight="600">M(cos α; sin α)</text>

      {/* Projections */}
      <line x1="173" y1="57" x2="173" y2="110" stroke="#94A3B8" strokeDasharray="3 3" />
      <line x1="173" y1="57" x2="120" y2="57" stroke="#94A3B8" strokeDasharray="3 3" />

      <path d="M 140,110 A 20 20 0 0 0 134,96" fill="none" stroke="#EF4444" strokeWidth="1.5" />
      <text x="142" y="102" fontSize="10" fill="#EF4444">α</text>

      <text x="195" y="124" fontSize="10" fill="#64748B">1</text>
      <text x="105" y="40" fontSize="10" fill="#64748B">1</text>
    </svg>
  );
}

// 6. Hình chóp S.ABCD
function renderPyramid(params: Record<string, any>) {
  return (
    <svg viewBox="0 0 280 210" className="w-[280px] h-[210px] select-none">
      {/* S at (140, 25) */}
      {/* Base: A(60, 140), B(110, 180), C(220, 180), D(190, 140) */}
      {/* Dashed lines inside: AD, DC */}
      <line x1="60" y1="140" x2="190" y2="140" stroke="#94A3B8" strokeDasharray="4 3" strokeWidth="1.4" />
      <line x1="190" y1="140" x2="220" y2="180" stroke="#334155" strokeWidth="1.6" />
      <line x1="60" y1="140" x2="110" y2="180" stroke="#334155" strokeWidth="1.6" />
      <line x1="110" y1="180" x2="220" y2="180" stroke="#334155" strokeWidth="1.6" />

      {/* Edges from S */}
      <line x1="140" y1="25" x2="60" y2="140" stroke="#0F766E" strokeWidth="2" />
      <line x1="140" y1="25" x2="110" y2="180" stroke="#0F766E" strokeWidth="2" />
      <line x1="140" y1="25" x2="220" y2="180" stroke="#0F766E" strokeWidth="2" />
      <line x1="140" y1="25" x2="190" y2="140" stroke="#0F766E" strokeDasharray="4 3" strokeWidth="1.4" />

      {/* Height SO to center O */}
      <line x1="140" y1="25" x2="145" y2="160" stroke="#EF4444" strokeDasharray="4 3" strokeWidth="1.6" />
      <circle cx="145" cy="160" r="2.5" fill="#EF4444" />
      <text x="148" y="166" fontSize="10" fill="#EF4444" fontWeight="600">O</text>

      {/* Labels */}
      <text x="136" y="18" fontSize="12" fill="#0F766E" fontWeight="700">S</text>
      <text x="44" y="142" fontSize="11" fill="#334155" fontWeight="600">A</text>
      <text x="104" y="196" fontSize="11" fill="#334155" fontWeight="600">B</text>
      <text x="226" y="185" fontSize="11" fill="#334155" fontWeight="600">C</text>
      <text x="195" y="138" fontSize="11" fill="#334155" fontWeight="600">D</text>
    </svg>
  );
}

// 7. Hình lăng trụ tam giác ABC.A'B'C'
function renderPrism(params: Record<string, any>) {
  return (
    <svg viewBox="0 0 280 210" className="w-[280px] h-[210px] select-none">
      {/* Top base: A'(80, 40), B'(150, 65), C'(210, 35) */}
      <polygon points="80,40 150,65 210,35" fill="none" stroke="#0F766E" strokeWidth="2" />

      {/* Bottom base: A(80, 150), B(150, 175), C(210, 145) */}
      <line x1="80" y1="150" x2="150" y2="175" stroke="#334155" strokeWidth="1.8" />
      <line x1="150" y1="175" x2="210" y2="145" stroke="#334155" strokeWidth="1.8" />
      <line x1="80" y1="150" x2="210" y2="145" stroke="#94A3B8" strokeDasharray="4 3" strokeWidth="1.4" />

      {/* Side edges */}
      <line x1="80" y1="40" x2="80" y2="150" stroke="#0F766E" strokeWidth="2" />
      <line x1="150" y1="65" x2="150" y2="175" stroke="#0F766E" strokeWidth="2" />
      <line x1="210" y1="35" x2="210" y2="145" stroke="#0F766E" strokeWidth="2" />

      {/* Labels */}
      <text x="68" y="38" fontSize="11" fill="#0F766E" fontWeight="700">A'</text>
      <text x="148" y="80" fontSize="11" fill="#0F766E" fontWeight="700">B'</text>
      <text x="216" y="36" fontSize="11" fill="#0F766E" fontWeight="700">C'</text>

      <text x="68" y="155" fontSize="11" fill="#334155" fontWeight="700">A</text>
      <text x="148" y="192" fontSize="11" fill="#334155" fontWeight="700">B</text>
      <text x="216" y="152" fontSize="11" fill="#334155" fontWeight="700">C</text>
    </svg>
  );
}

// 8. Hình hộp chữ nhật / Hệ tọa độ Oxyz
function renderBox(params: Record<string, any>) {
  return (
    <svg viewBox="0 0 280 200" className="w-[280px] h-[200px] select-none">
      {/* Coordinate axes at vertex O */}
      <line x1="70" y1="140" x2="30" y2="180" stroke="#DC2626" strokeWidth="1.8" />
      <polygon points="30,180 34,172 40,178" fill="#DC2626" />
      <text x="20" y="190" fontSize="11" fill="#DC2626" fontStyle="italic" fontWeight="700">x</text>

      <line x1="70" y1="140" x2="225" y2="140" stroke="#16A34A" strokeWidth="1.8" />
      <polygon points="225,140 217,136 217,144" fill="#16A34A" />
      <text x="232" y="144" fontSize="11" fill="#16A34A" fontStyle="italic" fontWeight="700">y</text>

      <line x1="70" y1="140" x2="70" y2="25" stroke="#2563EB" strokeWidth="1.8" />
      <polygon points="70,25 66,33 74,33" fill="#2563EB" />
      <text x="65" y="18" fontSize="11" fill="#2563EB" fontStyle="italic" fontWeight="700">z</text>

      {/* Hidden edges from O(70, 140) */}
      <line x1="70" y1="140" x2="190" y2="140" stroke="#94A3B8" strokeDasharray="3 3" strokeWidth="1.4" />
      <line x1="70" y1="140" x2="105" y2="170" stroke="#94A3B8" strokeDasharray="3 3" strokeWidth="1.4" />
      <line x1="70" y1="140" x2="70" y2="50" stroke="#94A3B8" strokeDasharray="3 3" strokeWidth="1.4" />

      {/* Visible box edges */}
      <polygon points="105,80 225,80 225,170 105,170" fill="none" stroke="#0F766E" strokeWidth="1.8" />
      <polygon points="70,50 190,50 225,80 105,80" fill="#0F766E" fillOpacity="0.05" stroke="#0F766E" strokeWidth="1.8" />
      <line x1="190" y1="50" x2="190" y2="140" stroke="#0F766E" strokeWidth="1.8" />
      <line x1="190" y1="140" x2="225" y2="170" stroke="#0F766E" strokeWidth="1.8" />

      {/* Origin label */}
      <text x="56" y="136" fontSize="11" fill="#334155" fontWeight="700">O(0;0;0)</text>
      <circle cx="225" cy="80" r="3" fill="#0F766E" />
      <text x="210" y="74" fontSize="10" fill="#0F766E" fontWeight="700">M(a;b;c)</text>
    </svg>
  );
}

// 9. Trục số biểu diễn khoảng đoạn
function renderNumberLine(params: Record<string, any>) {
  return (
    <svg viewBox="0 0 280 80" className="w-[280px] h-[80px] select-none">
      <line x1="20" y1="40" x2="260" y2="40" stroke="#334155" strokeWidth="2" />
      <polygon points="260,40 252,36 252,44" fill="#334155" />

      {/* Interval [-2; 3] */}
      {/* Hash lines outside [-2; 3] */}
      <line x1="30" y1="30" x2="40" y2="50" stroke="#CBD5E1" strokeWidth="1.5" />
      <line x1="45" y1="30" x2="55" y2="50" stroke="#CBD5E1" strokeWidth="1.5" />
      <line x1="60" y1="30" x2="70" y2="50" stroke="#CBD5E1" strokeWidth="1.5" />

      <text x="80" y="44" fontSize="16" fill="#0F766E" fontWeight="800">[</text>
      <text x="76" y="60" fontSize="11" fill="#0F766E" fontWeight="700">-2</text>

      <line x1="88" y1="40" x2="192" y2="40" stroke="#0F766E" strokeWidth="4" />

      <text x="195" y="44" fontSize="16" fill="#0F766E" fontWeight="800">]</text>
      <text x="194" y="60" fontSize="11" fill="#0F766E" fontWeight="700">3</text>

      <line x1="210" y1="30" x2="220" y2="50" stroke="#CBD5E1" strokeWidth="1.5" />
      <line x1="225" y1="30" x2="235" y2="50" stroke="#CBD5E1" strokeWidth="1.5" />
      <line x1="240" y1="30" x2="250" y2="50" stroke="#CBD5E1" strokeWidth="1.5" />
    </svg>
  );
}

// 10. Biểu đồ tần số ghép nhóm (Histogram)
function renderHistogram(params: Record<string, any>) {
  return (
    <svg viewBox="0 0 280 160" className="w-[280px] h-[160px] select-none">
      <line x1="30" y1="130" x2="260" y2="130" stroke="#334155" strokeWidth="1.5" />
      <line x1="30" y1="130" x2="30" y2="20" stroke="#334155" strokeWidth="1.5" />

      {/* Bars: [40; 50), [50; 60), [60; 70), [70; 80), [80; 90) */}
      <rect x="40" y="100" width="35" height="30" fill="#0F766E" fillOpacity="0.4" stroke="#0F766E" strokeWidth="1.2" />
      <text x="52" y="94" fontSize="10" fill="#0F766E">3</text>

      <rect x="75" y="60" width="35" height="70" fill="#0F766E" fillOpacity="0.6" stroke="#0F766E" strokeWidth="1.2" />
      <text x="87" y="54" fontSize="10" fill="#0F766E">7</text>

      <rect x="110" y="30" width="35" height="100" fill="#0F766E" fillOpacity="0.8" stroke="#0F766E" strokeWidth="1.2" />
      <text x="120" y="24" fontSize="10" fill="#0F766E" fontWeight="700">12</text>

      <rect x="145" y="50" width="35" height="80" fill="#0F766E" fillOpacity="0.6" stroke="#0F766E" strokeWidth="1.2" />
      <text x="157" y="44" fontSize="10" fill="#0F766E">8</text>

      <rect x="180" y="80" width="35" height="50" fill="#0F766E" fillOpacity="0.4" stroke="#0F766E" strokeWidth="1.2" />
      <text x="192" y="74" fontSize="10" fill="#0F766E">5</text>

      {/* Ticks */}
      <text x="35" y="144" fontSize="9" fill="#64748B">40</text>
      <text x="70" y="144" fontSize="9" fill="#64748B">50</text>
      <text x="105" y="144" fontSize="9" fill="#64748B">60</text>
      <text x="140" y="144" fontSize="9" fill="#64748B">70</text>
      <text x="175" y="144" fontSize="9" fill="#64748B">80</text>
      <text x="210" y="144" fontSize="9" fill="#64748B">90</text>
    </svg>
  );
}

// 11. Bài toán tối ưu hộp không nắp / chi phí
function renderAppliedMaxMin(params: Record<string, any>) {
  return (
    <svg viewBox="0 0 280 160" className="w-[280px] h-[160px] select-none">
      {/* Square sheet of metal */}
      <rect x="50" y="20" width="120" height="120" fill="#E2E8F0" stroke="#334155" strokeWidth="1.5" />

      {/* 4 cut corners size x */}
      <rect x="50" y="20" width="25" height="25" fill="#EF4444" fillOpacity="0.3" stroke="#DC2626" strokeDasharray="2 2" />
      <rect x="145" y="20" width="25" height="25" fill="#EF4444" fillOpacity="0.3" stroke="#DC2626" strokeDasharray="2 2" />
      <rect x="50" y="115" width="25" height="25" fill="#EF4444" fillOpacity="0.3" stroke="#DC2626" strokeDasharray="2 2" />
      <rect x="145" y="115" width="25" height="25" fill="#EF4444" fillOpacity="0.3" stroke="#DC2626" strokeDasharray="2 2" />

      <text x="58" y="37" fontSize="11" fill="#DC2626" fontWeight="700">x</text>
      <text x="100" y="85" fontSize="11" fill="#0F766E" fontWeight="700">a - 2x</text>
      <text x="100" y="15" fontSize="11" fill="#334155" fontWeight="600">Cạnh a</text>

      {/* Folded 3D box arrow */}
      <path d="M 180,80 L 205,80" stroke="#0F766E" strokeWidth="2" markerEnd="url(#arrow)" />
      <polygon points="205,80 197,76 197,84" fill="#0F766E" />

      {/* 3D Box sketch */}
      <polygon points="215,70 255,70 255,105 215,105" fill="#CCFBF1" stroke="#0F766E" strokeWidth="1.5" />
      <polygon points="215,70 230,55 270,55 255,70" fill="#99F6E4" stroke="#0F766E" strokeWidth="1.5" />
      <polygon points="255,70 270,55 270,90 255,105" fill="#5EEAD4" stroke="#0F766E" strokeWidth="1.5" />
      <text x="220" y="122" fontSize="10" fill="#0F766E" fontWeight="600">V = x(a-2x)²</text>
    </svg>
  );
}

export default MathSvgFigure;
