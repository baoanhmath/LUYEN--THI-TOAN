import React, { useState, useRef } from 'react';
import {
  Upload,
  FileText,
  FileCode,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  BookOpen,
  ArrowRight,
  Layers,
  Save,
  Trash2,
  RefreshCw,
  Eye,
  Sliders,
  HelpCircle,
  FileCheck2,
  ListOrdered
} from 'lucide-react';
import { Grade, QuestionGenerated } from '../types/math';
import { CURRICULUM } from '../data/curriculumData';
import { MathTex, MathHtml } from './MathTex';
import { MathSvgFigure } from './MathSvgFigures';
import { normalizeQuestionContent } from '../utils/mathNormalize';

interface DocumentAnalysisResult {
  detectedGrade: Grade;
  topicTitle: string;
  chapterName: string;
  summary: string;
  keyTheorems: string[];
  identifiedTopics: { id: string; name: string; level: string }[];
  readinessAssessment: {
    isSufficient: boolean;
    notes: string;
  };
}

interface AiQuestionGeneratorSectionProps {
  onAddQuestionsToBank: (questions: QuestionGenerated[]) => void;
}

export const AiQuestionGeneratorSection: React.FC<AiQuestionGeneratorSectionProps> = ({
  onAddQuestionsToBank,
}) => {
  // File upload state
  const [file, setFile] = useState<File | null>(null);
  const [fileName, setFileName] = useState<string>('');
  const [fileSize, setFileSize] = useState<string>('');
  const [fileBase64, setFileBase64] = useState<string>('');
  const [fileMimeType, setFileMimeType] = useState<string>('');
  const [manualText, setManualText] = useState<string>('');
  const [useTextMode, setUseTextMode] = useState<boolean>(false);

  // AI Pipeline Steps: 'upload' | 'analyzing' | 'analyzed' | 'generating' | 'review'
  const [step, setStep] = useState<'upload' | 'analyzing' | 'analyzed' | 'generating' | 'review'>('upload');

  // Analysis result
  const [analysis, setAnalysis] = useState<DocumentAnalysisResult | null>(null);
  const [errorMsg, setErrorMsg] = useState<string>('');

  // Generation options
  const [selectedGrade, setSelectedGrade] = useState<Grade>(12);
  const [selectedLessonId, setSelectedLessonId] = useState<string>('');
  const [topicTitle, setTopicTitle] = useState<string>('');
  const [questionCount, setQuestionCount] = useState<number>(3);
  const [selectedLevels, setSelectedLevels] = useState<string[]>(['Nhận biết', 'Thông hiểu', 'Vận dụng']);
  const [teacherNotes, setTeacherNotes] = useState<string>('');

  // Generated questions preview
  const [generatedQuestions, setGeneratedQuestions] = useState<QuestionGenerated[]>([]);
  const [activePreviewIndex, setActivePreviewIndex] = useState<number>(0);
  const [activeTabFormat, setActiveTabFormat] = useState<'mcq' | 'tf' | 'short' | 'solution'>('mcq');
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // File selection handler
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (!selected) return;

    setFile(selected);
    setFileName(selected.name);
    setFileSize((selected.size / (1024 * 1024)).toFixed(2) + ' MB');
    setErrorMsg('');

    // Check type: PDF or docx or txt
    const mime = selected.type || (selected.name.endsWith('.pdf') ? 'application/pdf' : 'application/octet-stream');
    setFileMimeType(mime);

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Strip data url prefix (e.g. data:application/pdf;base64,...)
      const base64Index = result.indexOf(';base64,');
      if (base64Index !== -1) {
        setFileBase64(result.substring(base64Index + 8));
      } else {
        setFileBase64(result);
      }
    };
    reader.readAsDataURL(selected);
  };

  // Trigger Document Analysis via AI
  const handleAnalyzeDocument = async () => {
    if (!fileBase64 && !manualText.trim()) {
      setErrorMsg('Vui lòng chọn file PDF/DOCX hoặc dán nội dung văn bản tài liệu.');
      return;
    }

    setStep('analyzing');
    setErrorMsg('');

    try {
      const res = await fetch('/api/ai/analyze-document', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileBase64: fileBase64 || undefined,
          mimeType: fileMimeType || undefined,
          fileName,
          textContent: manualText || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Phân tích tài liệu thất bại.');
      }

      const resData = data.data as DocumentAnalysisResult;
      setAnalysis(resData);
      const gradeTarget = resData.detectedGrade || 12;
      setSelectedGrade(gradeTarget);
      const docTopic = resData.topicTitle || resData.chapterName || 'Chuyên đề Toán THPT';
      setTopicTitle(docTopic);

      // Attempt to auto-match lesson in curriculum
      const gradeChapters = CURRICULUM[gradeTarget] || [];
      let matchedLessonId = '';
      for (const ch of gradeChapters) {
        for (const les of ch.lessons) {
          if (
            docTopic.toLowerCase().includes(les.title.toLowerCase()) ||
            les.title.toLowerCase().includes(docTopic.toLowerCase()) ||
            (resData.chapterName && ch.title.toLowerCase().includes(resData.chapterName.toLowerCase()))
          ) {
            matchedLessonId = les.id;
            break;
          }
        }
        if (matchedLessonId) break;
      }
      setSelectedLessonId(matchedLessonId || gradeChapters[0]?.lessons[0]?.id || '');
      setStep('analyzed');
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Lỗi kết nối khi phân tích tài liệu.');
      setStep('upload');
    }
  };

  // Trigger Question Generation via AI
  const handleGenerateQuestions = async () => {
    setStep('generating');
    setErrorMsg('');

    try {
      const res = await fetch('/api/ai/generate-questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileBase64: fileBase64 || undefined,
          mimeType: fileMimeType || undefined,
          fileName,
          textContent: manualText || undefined,
          grade: selectedGrade,
          topicTitle,
          count: questionCount,
          levels: selectedLevels,
          customInstructions: teacherNotes,
          lessonId: selectedLessonId || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Sinh câu hỏi thất bại.');
      }

      const normalized = (data.data as QuestionGenerated[]).map((q) =>
        normalizeQuestionContent({
          ...q,
          grade: selectedGrade,
          topicTitle: q.topicTitle || topicTitle,
          lessonId: selectedLessonId || q.lessonId,
          sourceDocument: fileName || 'Tài liệu giáo viên',
          createdAt: new Date().toLocaleDateString('vi-VN'),
        })
      );
      setGeneratedQuestions(normalized);
      setActivePreviewIndex(0);
      setStep('review');
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Lỗi kết nối khi tạo câu hỏi từ AI.');
      setStep('analyzed');
    }
  };

  // Save selected questions to question bank
  const handleSaveToBank = () => {
    if (generatedQuestions.length === 0) return;
    onAddQuestionsToBank(generatedQuestions);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const currentQ = generatedQuestions[activePreviewIndex];

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-7 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-800">
            <Sparkles className="w-5 h-5 text-teal-700" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
              <span>AI Sinh Bài Tập Từ Tài Liệu Nguồn</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-teal-100 text-teal-800">
                Chuẩn Bộ GD&ĐT 2025
              </span>
            </h2>
            <p className="text-xs text-slate-500">
              Tải giáo án, đề thi (PDF, DOCX) → Phân tích cấu trúc chương bài → AI sinh câu hỏi Trắc nghiệm 4 lựa chọn, Đúng/Sai, Trả lời ngắn có lời giải chuẩn.
            </p>
          </div>
        </div>

        {step !== 'upload' && (
          <button
            onClick={() => {
              setStep('upload');
              setAnalysis(null);
              setGeneratedQuestions([]);
            }}
            className="text-xs font-semibold text-slate-600 hover:text-slate-900 px-3 py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Tải tài liệu mới</span>
          </button>
        )}
      </div>

      {/* STEP 1: UPLOAD & INPUT */}
      {step === 'upload' && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Box 1: File Dropzone */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-all ${
                file
                  ? 'border-teal-500 bg-teal-50/40'
                  : 'border-slate-300 hover:border-teal-500 hover:bg-slate-50/60'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.docx,.doc,.txt"
                className="hidden"
                onChange={handleFileChange}
              />
              <div className="w-12 h-12 rounded-full bg-teal-100/70 text-teal-800 flex items-center justify-center mb-3">
                <Upload className="w-6 h-6 text-teal-700" />
              </div>
              <div className="text-sm font-bold text-slate-800 mb-1">
                {file ? fileName : 'Chọn hoặc kéo thả tài liệu vào đây'}
              </div>
              <div className="text-xs text-slate-500 max-w-xs mb-3">
                Hỗ trợ định dạng tài liệu Giáo trình, Đề thi, Chuyên đề: <strong>PDF, DOCX</strong> (Tối đa 30MB)
              </div>
              {file && (
                <div className="inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full bg-teal-200/60 text-teal-900">
                  <CheckCircle2 className="w-3.5 h-3.5 text-teal-700" />
                  <span>Đã chọn ({fileSize})</span>
                </div>
              )}
            </div>

            {/* Box 2: Manual Text Fallback / Paste */}
            <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/40 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-teal-700" />
                    <span>Hoặc dán nội dung bài học / đề bài</span>
                  </label>
                  <span className="text-[10px] text-slate-400">Tùy chọn bổ trợ</span>
                </div>
                <textarea
                  value={manualText}
                  onChange={(e) => setManualText(e.target.value)}
                  placeholder="Ví dụ: Định lý Lagrange, bảng biến thiên f'(x), các bài toán thực tiễn tối ưu hóa thể tích hình chóp, công thức Oxyz..."
                  rows={4}
                  className="w-full text-xs p-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-2">
                * Có thể tải file kèm dán thêm ghi chú để AI hiểu sâu ngữ cảnh đề thi của thầy cô.
              </p>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="flex justify-end pt-2">
            <button
              onClick={handleAnalyzeDocument}
              disabled={!file && !manualText.trim()}
              className="px-5 py-2.5 rounded-xl font-bold text-xs sm:text-sm bg-teal-800 text-white hover:bg-teal-900 transition-colors shadow-xs flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-[#F4B942]" />
              <span>Phân Tích Cấu Trúc Tài Liệu</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: ANALYZING SPINNER */}
      {step === 'analyzing' && (
        <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
          <div className="w-12 h-12 rounded-full border-4 border-teal-200 border-t-teal-700 animate-spin" />
          <h3 className="font-bold text-slate-900 text-sm">
            AI đang đọc và phân tích cấu trúc tài liệu...
          </h3>
          <p className="text-xs text-slate-500 max-w-sm">
            Hệ thống đang trích xuất các chủ đề, định lý trọng tâm, mức độ nhận thức và kiểm tra tính đầy đủ của dữ liệu nguồn.
          </p>
        </div>
      )}

      {/* STEP 3: ANALYZED RESULT & CONFIGURATION */}
      {(step === 'analyzed' || step === 'generating') && analysis && (
        <div className="space-y-6">
          {/* Analysis Summary Box */}
          <div className="bg-teal-50/60 border border-teal-200/80 rounded-2xl p-4 sm:p-5 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-teal-200/60 pb-2.5">
              <div className="flex items-center gap-2">
                <FileCheck2 className="w-4 h-4 text-teal-800" />
                <span className="font-bold text-xs sm:text-sm text-teal-900">
                  Kết quả phân tích tài liệu: {fileName || 'Văn bản đã nhập'}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-800 text-white">
                  Toán {analysis.detectedGrade}
                </span>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800 border border-emerald-300">
                  {analysis.readinessAssessment.isSufficient ? 'Dữ liệu đầy đủ' : 'Cần bổ trợ'}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-700 leading-relaxed">
              <strong>Tóm tắt nội dung:</strong> {analysis.summary}
            </p>

            {analysis.keyTheorems && analysis.keyTheorems.length > 0 && (
              <div className="space-y-1">
                <div className="text-xs font-bold text-teal-950">Định lý & Công thức then chốt:</div>
                <div className="flex flex-wrap gap-1.5">
                  {analysis.keyTheorems.map((thm, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 rounded-lg bg-white border border-teal-200 text-xs font-mono text-slate-800"
                    >
                      <MathTex math={thm} />
                    </span>
                  ))}
                </div>
              </div>
            )}

            {analysis.identifiedTopics && analysis.identifiedTopics.length > 0 && (
              <div className="space-y-1">
                <div className="text-xs font-bold text-teal-950">Các dạng bài nhận diện được:</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {analysis.identifiedTopics.map((top, i) => (
                    <div
                      key={i}
                      className="p-2 rounded-xl bg-white/80 border border-slate-200/70 flex items-center justify-between"
                    >
                      <span className="font-medium text-slate-800 truncate mr-2">{top.name}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 shrink-0">
                        {top.level}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Configuration Form */}
          <div className="border border-slate-200 rounded-2xl p-5 bg-slate-50/50 space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-200/70 pb-2">
              <Sliders className="w-4 h-4 text-teal-700" />
              <h3 className="font-bold text-xs sm:text-sm text-slate-800">
                Tùy chọn yêu cầu tạo bài tập từ tài liệu
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Khối lớp mục tiêu
                </label>
                <select
                  value={selectedGrade}
                  onChange={(e) => {
                    const g = parseInt(e.target.value) as Grade;
                    setSelectedGrade(g);
                    const chs = CURRICULUM[g] || [];
                    if (chs[0]?.lessons[0]) {
                      setSelectedLessonId(chs[0].lessons[0].id);
                    }
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs sm:text-sm font-medium focus:ring-2 focus:ring-teal-500"
                >
                  <option value={10}>Toán 10 (GDPT 2018)</option>
                  <option value={11}>Toán 11 (GDPT 2018)</option>
                  <option value={12}>Toán 12 (GDPT 2018)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Gắn vào bài học trong SGK
                </label>
                <select
                  value={selectedLessonId}
                  onChange={(e) => {
                    setSelectedLessonId(e.target.value);
                    const chs = CURRICULUM[selectedGrade] || [];
                    for (const ch of chs) {
                      for (const l of ch.lessons) {
                        if (l.id === e.target.value) {
                          setTopicTitle(l.title.replace(/^Bài \d+\.\s*/, ''));
                        }
                      }
                    }
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs sm:text-sm font-medium focus:ring-2 focus:ring-teal-500 truncate"
                >
                  {(CURRICULUM[selectedGrade] || []).map((ch) => (
                    <optgroup key={ch.title} label={ch.title}>
                      {ch.lessons.map((les) => (
                        <option key={les.id} value={les.id}>
                          {les.title}
                        </option>
                      ))}
                    </optgroup>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Số lượng câu hỏi sinh ra
                </label>
                <select
                  value={questionCount}
                  onChange={(e) => setQuestionCount(parseInt(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs sm:text-sm font-medium focus:ring-2 focus:ring-teal-500"
                >
                  <option value={1}>1 Bộ câu hỏi (Đầy đủ 3 dạng)</option>
                  <option value={2}>2 Bộ câu hỏi</option>
                  <option value={3}>3 Bộ câu hỏi (Khuyến nghị)</option>
                  <option value={5}>5 Bộ câu hỏi</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Chủ đề cụ thể cần sinh (từ tài liệu nguồn)
              </label>
              <input
                type="text"
                value={topicTitle}
                onChange={(e) => setTopicTitle(e.target.value)}
                placeholder="Ví dụ: Đơn điệu hàm số, Oxyz, Cấp số cộng..."
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs sm:text-sm focus:ring-2 focus:ring-teal-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                Mức độ nhận thức cần phủ
              </label>
              <div className="flex flex-wrap gap-2">
                {['Nhận biết', 'Thông hiểu', 'Vận dụng', 'Vận dụng cao'].map((lvl) => {
                  const active = selectedLevels.includes(lvl);
                  return (
                    <button
                      key={lvl}
                      type="button"
                      onClick={() => {
                        if (active) {
                          setSelectedLevels(selectedLevels.filter((x) => x !== lvl));
                        } else {
                          setSelectedLevels([...selectedLevels, lvl]);
                        }
                      }}
                      className={`px-3 py-1 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                        active
                          ? 'bg-teal-700 text-white'
                          : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {lvl}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">
                Ghi chú / Yêu cầu sư phạm bổ sung của giáo viên (tùy chọn)
              </label>
              <input
                type="text"
                value={teacherNotes}
                onChange={(e) => setTeacherNotes(e.target.value)}
                placeholder="Ví dụ: Ưu tiên dạng toán thực tế kinh tế hoặc vật lý; câu đúng/sai gài bẫy dấu âm..."
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-xs sm:text-sm focus:ring-2 focus:ring-teal-500"
              />
            </div>
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-2">
            <button
              onClick={handleGenerateQuestions}
              disabled={step === 'generating'}
              className="px-6 py-2.5 rounded-xl font-bold text-xs sm:text-sm bg-teal-800 text-white hover:bg-teal-900 transition-colors shadow-xs flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {step === 'generating' ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>AI đang sinh đề & kiểm tra nghiệm...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-[#F4B942]" />
                  <span>Tiến Hành Sinh Câu Hỏi (Đầy đủ 3 Dạng)</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: REVIEW & VERIFICATION */}
      {step === 'review' && generatedQuestions.length > 0 && (
        <div className="space-y-5">
          {/* Success banner */}
          <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <div>
                <div className="text-xs sm:text-sm font-bold text-emerald-900">
                  Đã sinh thành công {generatedQuestions.length} bộ câu hỏi hoàn chỉnh từ tài liệu nguồn!
                </div>
                <div className="text-[11px] text-emerald-700">
                  Mỗi câu hỏi đã được tạo đầy đủ: Phần I (Trắc nghiệm 4 lựa chọn), Phần II (Đúng/Sai 4 khẳng định), Phần III (Trả lời ngắn) và Lời giải chi tiết.
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleSaveToBank}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-700 text-white hover:bg-emerald-800 transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Lưu Vào Ngân Hàng Câu Hỏi</span>
              </button>
            </div>
          </div>

          {savedSuccess && (
            <div className="p-3 rounded-xl bg-teal-100 border border-teal-300 text-xs font-bold text-teal-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-teal-700" />
              <span>Đã lưu thành công bộ câu hỏi vào hệ thống! Học sinh có thể luyện tập ngay.</span>
            </div>
          )}

          {/* Navigation between generated questions */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            <span className="text-xs font-semibold text-slate-500 shrink-0 mr-1">Bộ câu hỏi:</span>
            {generatedQuestions.map((q, idx) => (
              <button
                key={q.id || idx}
                onClick={() => setActivePreviewIndex(idx)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-colors cursor-pointer ${
                  activePreviewIndex === idx
                    ? 'bg-teal-800 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                Câu {idx + 1}: {q.topicTitle}
              </button>
            ))}
          </div>

          {/* Active Question Preview Box */}
          {currentQ && (
            <div className="border border-slate-200 rounded-2xl p-5 space-y-4 bg-slate-50/30">
              {/* Question metadata badge */}
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-3">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-teal-100 text-teal-800">
                    Toán {currentQ.grade}
                  </span>
                  <span className="text-xs font-bold text-slate-800">
                    Chủ đề: {currentQ.topicTitle}
                  </span>
                </div>
                <div className="flex items-center gap-1 bg-slate-200/70 p-1 rounded-xl">
                  <button
                    onClick={() => setActiveTabFormat('mcq')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      activeTabFormat === 'mcq'
                        ? 'bg-white text-teal-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Phần I: 4 Lựa chọn
                  </button>
                  <button
                    onClick={() => setActiveTabFormat('tf')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      activeTabFormat === 'tf'
                        ? 'bg-white text-teal-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Phần II: Đúng / Sai
                  </button>
                  <button
                    onClick={() => setActiveTabFormat('short')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      activeTabFormat === 'short'
                        ? 'bg-white text-teal-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Phần III: Trả lời ngắn
                  </button>
                  <button
                    onClick={() => setActiveTabFormat('solution')}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      activeTabFormat === 'solution'
                        ? 'bg-amber-100 text-amber-900 shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Lời giải chi tiết
                  </button>
                </div>
              </div>

              {/* Context / Hypothesis */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs space-y-2">
                <div className="text-xs font-bold text-slate-500 uppercase tracking-wide">
                  Bối cảnh & Giả thiết bài toán:
                </div>
                <div className="text-xs sm:text-sm text-slate-800 leading-relaxed font-serif">
                  <MathTex math={currentQ.context} />
                </div>
              </div>

              {/* Format-specific view */}
              {activeTabFormat === 'mcq' && (
                <div className="space-y-3 bg-white p-4 rounded-xl border border-slate-200">
                  <div className="text-xs font-bold text-teal-800">
                    Câu hỏi trắc nghiệm 4 phương án:
                  </div>
                  <div className="text-xs sm:text-sm text-slate-900 font-medium">
                    <MathTex math={currentQ.ask} />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
                    <div className="p-2.5 rounded-xl border border-emerald-300 bg-emerald-50/50 flex items-start gap-2">
                      <span className="font-bold text-emerald-800 text-xs font-mono">A (ĐÚNG):</span>
                      <span className="text-xs font-serif text-slate-900">
                        <MathTex math={currentQ.correctOption} />
                      </span>
                    </div>
                    {currentQ.distractors.map((dis, i) => (
                      <div key={i} className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 flex items-start gap-2">
                        <span className="font-bold text-slate-600 text-xs font-mono">
                          {String.fromCharCode(66 + i)} (Nhiễu):
                        </span>
                        <span className="text-xs font-serif text-slate-700">
                          <MathTex math={dis} />
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTabFormat === 'tf' && (
                <div className="space-y-3 bg-white p-4 rounded-xl border border-slate-200">
                  <div className="text-xs font-bold text-teal-800">
                    Câu hỏi trắc nghiệm Đúng / Sai (Bộ 4 mệnh đề):
                  </div>
                  <div className="space-y-2">
                    {currentQ.tfStatements.map((stmt, i) => (
                      <div
                        key={i}
                        className={`p-3 rounded-xl border flex items-start justify-between gap-3 ${
                          stmt.isTrue ? 'border-emerald-200 bg-emerald-50/40' : 'border-red-200 bg-red-50/40'
                        }`}
                      >
                        <div className="flex items-start gap-2 text-xs sm:text-sm text-slate-800 font-serif">
                          <span className="font-bold font-mono">
                            {['a)', 'b)', 'c)', 'd)'][i]}
                          </span>
                          <span>
                            <MathTex math={stmt.text} />
                          </span>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase shrink-0 ${
                            stmt.isTrue ? 'bg-emerald-200 text-emerald-900' : 'bg-red-200 text-red-900'
                          }`}
                        >
                          {stmt.isTrue ? 'Đúng' : 'Sai'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTabFormat === 'short' && (
                <div className="space-y-3 bg-white p-4 rounded-xl border border-slate-200">
                  <div className="text-xs font-bold text-teal-800">
                    Câu hỏi trả lời ngắn (Phần III):
                  </div>
                  <div className="text-xs sm:text-sm text-slate-800 font-serif">
                    <MathTex math={currentQ.shortAnswerPrompt || currentQ.ask} />
                  </div>
                  <div className="p-3 rounded-xl bg-teal-50 border border-teal-200 flex items-center justify-between">
                    <span className="text-xs font-semibold text-teal-900">Đáp án chính xác:</span>
                    <span className="font-bold text-sm text-teal-950 font-mono">
                      <MathTex math={currentQ.shortAnswer} />
                    </span>
                  </div>
                </div>
              )}

              {activeTabFormat === 'solution' && (
                <div className="space-y-2 bg-amber-50/50 p-4 rounded-xl border border-amber-200">
                  <div className="text-xs font-bold text-amber-900">
                    Hướng dẫn giải chi tiết từng bước:
                  </div>
                  <div className="text-xs sm:text-sm text-slate-800 leading-relaxed font-serif whitespace-pre-wrap">
                    <MathTex math={currentQ.solution} />
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
