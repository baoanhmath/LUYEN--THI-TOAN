import React, { useState, useEffect } from 'react';
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ReferenceLine
} from 'recharts';
import {
  TrendingUp,
  Award,
  CheckCircle2,
  Calendar,
  Clock,
  ArrowUpRight,
  RotateCcw,
  PlusCircle,
  FileCheck2,
  Zap,
  History,
  Search,
  ChevronDown,
  ChevronUp,
  ExternalLink
} from 'lucide-react';
import { TabKey } from './Navbar';

export interface ExamRecord {
  id: string;
  name: string;
  code: string;
  date: string;
  score: number;
  maxScore: number;
  timeSpentMinutes: number;
  format?: string;
}

const DEFAULT_EXAM_HISTORY: ExamRecord[] = [
  {
    id: 'rec-1',
    name: 'Đề 01',
    code: '102',
    date: '10/09',
    score: 6.75,
    maxScore: 10,
    timeSpentMinutes: 85,
    format: 'Chuẩn 2025'
  },
  {
    id: 'rec-2',
    name: 'Đề 02',
    code: '115',
    date: '16/09',
    score: 7.25,
    maxScore: 10,
    timeSpentMinutes: 82,
    format: 'Chuẩn 2025'
  },
  {
    id: 'rec-3',
    name: 'Đề 03',
    code: '204',
    date: '22/09',
    score: 7.75,
    maxScore: 10,
    timeSpentMinutes: 78,
    format: 'Chuẩn 2025'
  },
  {
    id: 'rec-4',
    name: 'Đề 04',
    code: '318',
    date: '28/09',
    score: 8.25,
    maxScore: 10,
    timeSpentMinutes: 75,
    format: 'Chuẩn 2025'
  },
  {
    id: 'rec-5',
    name: 'Đề 05',
    code: '421',
    date: '02/10',
    score: 8.50,
    maxScore: 10,
    timeSpentMinutes: 72,
    format: 'Chuẩn 2025'
  },
  {
    id: 'rec-6',
    name: 'Đề 06',
    code: '509',
    date: '05/10',
    score: 8.75,
    maxScore: 10,
    timeSpentMinutes: 70,
    format: 'Chuẩn 2025'
  },
  {
    id: 'rec-7',
    name: 'Đề 07',
    code: '612',
    date: 'Hôm nay',
    score: 9.25,
    maxScore: 10,
    timeSpentMinutes: 68,
    format: 'Chuẩn 2025'
  }
];

interface StudentProgressChartProps {
  onNavigateToExam: () => void;
}

export const StudentProgressChart: React.FC<StudentProgressChartProps> = ({
  onNavigateToExam
}) => {
  const [examRecords, setExamRecords] = useState<ExamRecord[]>(() => {
    try {
      const saved = localStorage.getItem('pba_student_exam_history');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {}
    return DEFAULT_EXAM_HISTORY;
  });

  const [chartType, setChartType] = useState<'area' | 'bar'>('area');
  const [filterCount, setFilterCount] = useState<'all' | 'recent5'>('all');
  const [tableSearch, setTableSearch] = useState('');
  const [showAllRows, setShowAllRows] = useState(false);

  // Compute running average and format data for Recharts
  const chartData = React.useMemo(() => {
    let runningSum = 0;
    const formatted = examRecords.map((item, index) => {
      runningSum += item.score;
      const runningAvg = Math.round((runningSum / (index + 1)) * 100) / 100;
      return {
        ...item,
        avgScore: runningAvg
      };
    });

    if (filterCount === 'recent5' && formatted.length > 5) {
      return formatted.slice(formatted.length - 5);
    }
    return formatted;
  }, [examRecords, filterCount]);

  // Overall Statistics
  const totalExams = examRecords.length;
  const avgScore =
    totalExams > 0
      ? (
          Math.round(
            (examRecords.reduce((acc, curr) => acc + curr.score, 0) / totalExams) * 100
          ) / 100
        ).toFixed(2)
      : '0.00';
  const maxScore =
    totalExams > 0
      ? Math.max(...examRecords.map((r) => r.score)).toFixed(2)
      : '0.00';
  const latestScore =
    totalExams > 0 ? examRecords[examRecords.length - 1].score.toFixed(2) : '0.00';
  const highScorersCount = examRecords.filter((r) => r.score >= 8.0).length;
  const targetRate =
    totalExams > 0
      ? Math.round((highScorersCount / totalExams) * 100)
      : 0;

  const handleResetHistory = () => {
    if (window.confirm('Khôi phục lại dữ liệu lịch sử thi mẫu của Thầy PBA?')) {
      setExamRecords(DEFAULT_EXAM_HISTORY);
      localStorage.setItem('pba_student_exam_history', JSON.stringify(DEFAULT_EXAM_HISTORY));
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-7 shadow-xs space-y-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-teal-700 mb-1">
            <TrendingUp className="w-3.5 h-3.5" />
            Theo dõi học tập cá nhân hóa
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
            Tiến Độ Hoàn Thành & Phong Độ Luyện Thi
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Biểu đồ thống kê số lượng đề đã luyện và sự thay đổi điểm trung bình hướng tới mục tiêu điểm 9+
          </p>
        </div>

        {/* View toggles */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Chart visual toggle */}
          <div className="flex items-center bg-slate-100 p-1 rounded-lg text-xs font-semibold">
            <button
              onClick={() => setChartType('area')}
              className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                chartType === 'area'
                  ? 'bg-white text-teal-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Đường xu hướng
            </button>
            <button
              onClick={() => setChartType('bar')}
              className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                chartType === 'bar'
                  ? 'bg-white text-teal-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Cột phân tích
            </button>
          </div>

          {/* Filter count toggle */}
          <div className="flex items-center bg-slate-100 p-1 rounded-lg text-xs font-semibold">
            <button
              onClick={() => setFilterCount('all')}
              className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                filterCount === 'all'
                  ? 'bg-white text-teal-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Tất cả ({totalExams})
            </button>
            <button
              onClick={() => setFilterCount('recent5')}
              className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                filterCount === 'recent5'
                  ? 'bg-white text-teal-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              5 đề gần nhất
            </button>
          </div>

          <button
            onClick={handleResetHistory}
            title="Khôi phục dữ liệu mẫu"
            className="p-1.5 rounded-lg border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-50 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 4 Summary Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Metric 1: Total Exams Completed */}
        <div className="p-4 rounded-xl bg-teal-50/60 border border-teal-200/70 space-y-1">
          <div className="flex items-center justify-between text-xs text-teal-800 font-semibold">
            <span>Số đề đã hoàn thành</span>
            <FileCheck2 className="w-4 h-4 text-teal-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-teal-950">
            {totalExams} <span className="text-xs font-normal text-teal-700">đề thi</span>
          </div>
          <div className="text-[11px] text-teal-700">
            Đã chấm điểm tự động
          </div>
        </div>

        {/* Metric 2: Average Score */}
        <div className="p-4 rounded-xl bg-amber-50/60 border border-amber-200/70 space-y-1">
          <div className="flex items-center justify-between text-xs text-amber-800 font-semibold">
            <span>Điểm trung bình (ĐTB)</span>
            <Award className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-amber-950">
            {avgScore} <span className="text-xs font-normal text-amber-700">/ 10.0</span>
          </div>
          <div className="text-[11px] text-amber-700 font-medium">
            {parseFloat(avgScore) >= 8.0 ? 'Xếp loại: Giỏi / Xuất sắc' : 'Đang tiến bộ ổn định'}
          </div>
        </div>

        {/* Metric 3: Highest Score */}
        <div className="p-4 rounded-xl bg-emerald-50/60 border border-emerald-200/70 space-y-1">
          <div className="flex items-center justify-between text-xs text-emerald-800 font-semibold">
            <span>Điểm cao nhất</span>
            <Zap className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-950">
            {maxScore} <span className="text-xs font-normal text-emerald-700">/ 10.0</span>
          </div>
          <div className="text-[11px] text-emerald-700">
            Gần nhất: {latestScore} điểm
          </div>
        </div>

        {/* Metric 4: Target 8+ / 9+ rate */}
        <div className="p-4 rounded-xl bg-blue-50/60 border border-blue-200/70 space-y-1">
          <div className="flex items-center justify-between text-xs text-blue-800 font-semibold">
            <span>Tỉ lệ đạt điểm giỏi (&ge; 8.0)</span>
            <CheckCircle2 className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-blue-950">
            {targetRate}%
          </div>
          <div className="text-[11px] text-blue-700">
            {highScorersCount}/{totalExams} đề đạt &ge; 8.0
          </div>
        </div>
      </div>

      {/* Main Recharts Container */}
      <div className="w-full pt-2">
        <div className="h-[320px] w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart
              data={chartData}
              margin={{ top: 20, right: 20, left: -10, bottom: 5 }}
            >
              <defs>
                <linearGradient id="scoreColor" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0F766E" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#0F766E" stopOpacity={0.02} />
                </linearGradient>
              </defs>

              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" />

              <XAxis
                dataKey="name"
                tick={{ fontSize: 12, fill: '#475569', fontWeight: 600 }}
                tickLine={false}
                stroke="#CBD5E1"
              />

              <YAxis
                domain={[0, 10]}
                ticks={[0, 2, 4, 6, 8, 9, 10]}
                tick={{ fontSize: 11, fill: '#64748B' }}
                tickLine={false}
                stroke="#CBD5E1"
              />

              {/* Reference line for 9+ Target */}
              <ReferenceLine
                y={9.0}
                stroke="#DC2626"
                strokeDasharray="4 3"
                strokeWidth={1.5}
                label={{
                  value: 'Mục tiêu 9+ THPT',
                  fill: '#DC2626',
                  fontSize: 11,
                  fontWeight: 700,
                  position: 'insideTopRight'
                }}
              />

              {/* Reference line for 8.0 Good Mark */}
              <ReferenceLine
                y={8.0}
                stroke="#0284C7"
                strokeDasharray="3 3"
                strokeWidth={1}
                label={{
                  value: 'Mốc 8.0',
                  fill: '#0284C7',
                  fontSize: 10,
                  position: 'insideBottomRight'
                }}
              />

              <Tooltip content={<CustomTooltip />} />
              <Legend
                verticalAlign="bottom"
                height={36}
                iconType="circle"
                wrapperStyle={{ fontSize: 12, paddingTop: 12 }}
              />

              {chartType === 'area' ? (
                <Area
                  type="monotone"
                  dataKey="score"
                  stroke="#0F766E"
                  strokeWidth={3}
                  fillOpacity={1}
                  fill="url(#scoreColor)"
                  name="Điểm bài thi"
                  activeDot={{ r: 6, fill: '#0F766E', stroke: '#FFFFFF', strokeWidth: 2 }}
                />
              ) : (
                <Bar
                  dataKey="score"
                  fill="#0F766E"
                  radius={[6, 6, 0, 0]}
                  name="Điểm bài thi"
                  maxBarSize={45}
                />
              )}

              {/* Continuous running average line */}
              <Line
                type="monotone"
                dataKey="avgScore"
                stroke="#D97706"
                strokeWidth={2.5}
                strokeDasharray="4 3"
                dot={{ r: 4, fill: '#D97706', stroke: '#FFFFFF', strokeWidth: 1.5 }}
                name="Điểm TB tích lũy"
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Motivational Advice & Call to Action */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-xl bg-slate-50 border border-slate-200/80">
        <div className="space-y-1 text-center sm:text-left">
          <div className="text-xs font-bold text-slate-800 flex items-center justify-center sm:justify-start gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Đánh giá từ Thầy Phạm Bảo Anh:</span>
          </div>
          <p className="text-xs text-slate-600 leading-relaxed max-w-xl">
            Điểm số của em đang cải thiện rất rõ rệt qua từng đề (tăng từ{' '}
            <strong className="text-slate-800">{examRecords[0]?.score || '6.75'}</strong> lên{' '}
            <strong className="text-teal-700">{latestScore}</strong>). Tiếp tục rèn luyện Phần II (Đúng/Sai) và tối ưu thời gian dưới 75 phút để tự tin giành điểm 9+ trong kì thi THPT chính thức!
          </p>
        </div>

        <button
          onClick={onNavigateToExam}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs sm:text-sm shadow-xs transition-colors shrink-0 cursor-pointer"
        >
          <span>Làm đề kiểm tra mới</span>
          <ArrowUpRight className="w-4 h-4" />
        </button>
      </div>

      {/* Bảng Lịch Sử Các Đề Thi Đã Làm Gần Đây */}
      <div className="pt-4 border-t border-slate-100 space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-teal-700" />
            <h3 className="font-bold text-slate-900 text-sm sm:text-base">
              Lịch sử các đề thi đã làm gần đây ({totalExams})
            </h3>
          </div>

          <div className="flex items-center gap-2">
            {/* Search filter for exams */}
            <div className="relative min-w-[180px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={tableSearch}
                onChange={(e) => setTableSearch(e.target.value)}
                placeholder="Tìm mã đề, tên đề..."
                className="w-full pl-8 pr-2.5 py-1.5 rounded-lg border border-slate-200 text-xs bg-slate-50 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>

            {totalExams > 5 && (
              <button
                onClick={() => setShowAllRows(!showAllRows)}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
              >
                <span>{showAllRows ? 'Thu gọn' : `Xem tất cả (${totalExams})`}</span>
                {showAllRows ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>
            )}
          </div>
        </div>

        {/* Table Container */}
        <div className="overflow-x-auto rounded-xl border border-slate-200/90 shadow-2xs">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 border-b border-slate-200 font-bold text-slate-600 text-[11px] uppercase tracking-wider">
              <tr>
                <th scope="col" className="px-4 py-3">STT</th>
                <th scope="col" className="px-4 py-3">Tên đề thi & Mã đề</th>
                <th scope="col" className="px-4 py-3">Thời gian hoàn thành</th>
                <th scope="col" className="px-4 py-3">Điểm số</th>
                <th scope="col" className="px-4 py-3">Xếp loại</th>
                <th scope="col" className="px-4 py-3 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 bg-white">
              {(() => {
                // Reverse to show newest on top
                const reversed = [...examRecords].reverse();
                const filtered = reversed.filter(
                  (r) =>
                    !tableSearch ||
                    r.name.toLowerCase().includes(tableSearch.toLowerCase()) ||
                    r.code.toLowerCase().includes(tableSearch.toLowerCase()) ||
                    (r.format && r.format.toLowerCase().includes(tableSearch.toLowerCase()))
                );

                const displayed = showAllRows ? filtered : filtered.slice(0, 5);

                if (displayed.length === 0) {
                  return (
                    <tr>
                      <td colSpan={6} className="px-4 py-6 text-center text-slate-400">
                        {tableSearch
                          ? `Không tìm thấy đề thi phù hợp với "${tableSearch}".`
                          : 'Chưa có đề thi nào trong lịch sử.'}
                      </td>
                    </tr>
                  );
                }

                return displayed.map((record, idx) => {
                  const score = record.score;
                  const isTopScore = score >= 9.0;
                  const isGoodScore = score >= 8.0 && score < 9.0;
                  const isFairScore = score >= 6.5 && score < 8.0;

                  const ratingLabel = isTopScore
                    ? 'Xuất sắc'
                    : isGoodScore
                    ? 'Giỏi'
                    : isFairScore
                    ? 'Khá'
                    : 'Trung bình';

                  const ratingColor = isTopScore
                    ? 'text-teal-800'
                    : isGoodScore
                    ? 'text-blue-700'
                    : isFairScore
                    ? 'text-amber-700'
                    : 'text-slate-600';

                  return (
                    <tr
                      key={record.id || idx}
                      className="hover:bg-slate-50/70 transition-colors"
                    >
                      {/* Index */}
                      <td className="px-4 py-3 font-mono text-slate-400 font-semibold">
                        {String(idx + 1).padStart(2, '0')}
                      </td>

                      {/* Name & Code */}
                      <td className="px-4 py-3">
                        <div className="font-bold text-slate-900 flex items-center gap-2">
                          <span>{record.name}</span>
                          <span className="font-mono text-[11px] text-slate-500 font-normal">
                            (Mã #{record.code})
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                          <span>{record.format || 'Chuẩn 2025'}</span>
                          <span>·</span>
                          <span>Ngày {record.date}</span>
                        </div>
                      </td>

                      {/* Time spent */}
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1.5 font-medium text-slate-700">
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>{record.timeSpentMinutes} phút</span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5">
                          Hoàn thành: {record.date}
                        </div>
                      </td>

                      {/* Score with miniature progress indicator */}
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <span
                            className={`font-mono text-sm font-extrabold ${
                              isTopScore
                                ? 'text-teal-700'
                                : isGoodScore
                                ? 'text-blue-700'
                                : isFairScore
                                ? 'text-amber-700'
                                : 'text-slate-700'
                            }`}
                          >
                            {score.toFixed(2)}
                          </span>
                          <span className="text-slate-400 text-[11px]">/ 10.0</span>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-24 bg-slate-100 rounded-full h-1.5 mt-1 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              isTopScore
                                ? 'bg-teal-600'
                                : isGoodScore
                                ? 'bg-blue-600'
                                : isFairScore
                                ? 'bg-amber-500'
                                : 'bg-slate-400'
                            }`}
                            style={{ width: `${Math.min(100, (score / 10) * 100)}%` }}
                          />
                        </div>
                      </td>

                      {/* Rating */}
                      <td className="px-4 py-3">
                        <span className={`font-semibold ${ratingColor}`}>
                          {ratingLabel}
                        </span>
                      </td>

                      {/* Action */}
                      <td className="px-4 py-3 text-right">
                        <button
                          onClick={onNavigateToExam}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold text-teal-700 hover:text-teal-800 hover:bg-teal-50 transition-colors cursor-pointer"
                          title="Làm đề mới hoặc luyện lại dạng bài này"
                        >
                          <span>Làm lại</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  );
                });
              })()}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

interface TooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
}

const CustomTooltip: React.FC<TooltipProps> = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const score = data.score;
    const avgScore = data.avgScore;

    return (
      <div className="bg-white/95 backdrop-blur-xs p-3.5 rounded-xl shadow-xl border border-slate-200 text-xs space-y-2 min-w-[190px]">
        <div className="flex items-center justify-between border-b border-slate-100 pb-1.5">
          <span className="font-bold text-slate-900">{data.name} (Mã {data.code})</span>
          <span className="text-[11px] text-slate-400">{data.date}</span>
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <span className="text-slate-600 flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-teal-700 inline-block"></span>
              Điểm bài thi:
            </span>
            <span className="font-extrabold text-sm text-teal-900 font-mono">
              {score.toFixed(2)} / 10.0
            </span>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-slate-600 flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 inline-block"></span>
              Điểm TB tích lũy:
            </span>
            <span className="font-bold text-amber-900 font-mono">
              {avgScore.toFixed(2)}
            </span>
          </div>

          {data.timeSpentMinutes && (
            <div className="flex items-center justify-between text-slate-500 text-[11px] pt-1 border-t border-slate-50">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-slate-400" />
                Thời gian làm:
              </span>
              <span>{data.timeSpentMinutes} phút</span>
            </div>
          )}
        </div>
      </div>
    );
  }

  return null;
};

export default StudentProgressChart;
