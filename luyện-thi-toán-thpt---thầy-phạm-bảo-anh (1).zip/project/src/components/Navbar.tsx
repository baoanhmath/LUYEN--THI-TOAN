import React from 'react';
import {
  Home,
  BookOpen,
  Activity,
  Box,
  Zap,
  FileCheck2,
  Trophy,
  FolderDown,
  Lock,
  Unlock,
  MessageSquare,
  Menu,
  X,
  Sun,
  Moon
} from 'lucide-react';

export type TabKey = 'home' | 'g10' | 'g11' | 'g12' | 'tt' | 'exam' | 'week' | 'docs' | 'admin';

interface NavbarProps {
  currentTab: TabKey;
  onSelectTab: (tab: TabKey) => void;
  isAdmin: boolean;
  onToggleAdmin: () => void;
  onOpenAskModal: () => void;
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onSelectTab,
  isAdmin,
  onToggleAdmin,
  onOpenAskModal,
  isDarkMode,
  onToggleDarkMode
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navItems = [
    { key: 'home' as TabKey, label: 'Trang chủ', icon: Home },
    { key: 'g10' as TabKey, label: 'Toán 10', icon: BookOpen },
    { key: 'g11' as TabKey, label: 'Toán 11', icon: Activity },
    { key: 'g12' as TabKey, label: 'Toán 12', icon: Box },
    { key: 'tt' as TabKey, label: 'Toán thực tiễn', icon: Zap },
    { key: 'exam' as TabKey, label: 'Đề kiểm tra', icon: FileCheck2 },
    { key: 'week' as TabKey, label: 'Bài toán tuần', icon: Trophy },
    { key: 'docs' as TabKey, label: 'Tài liệu', icon: FolderDown },
  ];

  const handleNavClick = (tab: TabKey) => {
    onSelectTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0B5563] text-white shadow-md border-b border-[#0E7C86]/40">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 h-15 flex items-center justify-between gap-3">
        {/* Brand */}
        <button
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-2.5 text-left group cursor-pointer"
        >
          <div className="w-9 h-9 rounded-lg bg-white/10 group-hover:bg-white/20 transition-colors flex items-center justify-center font-extrabold tracking-wider text-base text-[#F4B942] border border-white/20 shadow-xs">
            PBA
          </div>
          <div className="leading-tight">
            <div className="text-[15px] font-bold tracking-tight text-white flex items-center gap-1.5">
              <span>Dạy học Toán PBA</span>
            </div>
            <div className="text-[11px] text-[#A2D9D9] font-medium hidden sm:block">
              Thầy Phạm Bảo Anh · THPT Quốc Gia
            </div>
          </div>
        </button>

        {/* Desktop Nav Items */}
        <nav className="hidden lg:flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.key;
            return (
              <button
                key={item.key}
                onClick={() => handleNavClick(item.key)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[13.5px] font-semibold transition-all cursor-pointer ${
                  isActive
                    ? 'bg-white text-[#0B5563] shadow-xs'
                    : 'text-white/85 hover:bg-white/10 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 opacity-90" />
                <span>{item.label}</span>
              </button>
            );
          })}
          {isAdmin && (
            <button
              onClick={() => handleNavClick('admin')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[13.5px] font-semibold transition-all cursor-pointer ${
                currentTab === 'admin'
                  ? 'bg-[#EF4444] text-white shadow-xs'
                  : 'bg-[#EF4444]/20 text-red-200 hover:bg-[#EF4444]/30'
              }`}
            >
              <Lock className="w-4 h-4" />
              <span>Quản trị</span>
            </button>
          )}
        </nav>

        {/* Right Action buttons */}
        <div className="flex items-center gap-2">
          {/* Dark / Light mode toggle button */}
          <button
            onClick={onToggleDarkMode}
            title={isDarkMode ? 'Chuyển sang giao diện Sáng' : 'Chuyển sang giao diện Tối (Học ban đêm)'}
            className="p-1.5 sm:px-2.5 sm:py-1.5 rounded-lg text-xs font-semibold bg-white/10 hover:bg-white/20 text-white border border-white/20 transition-all flex items-center gap-1.5 cursor-pointer"
            aria-label={isDarkMode ? 'Bật chế độ sáng' : 'Bật chế độ tối'}
          >
            {isDarkMode ? (
              <Sun className="w-4 h-4 text-[#F4B942]" />
            ) : (
              <Moon className="w-4 h-4 text-[#A2D9D9]" />
            )}
            <span className="hidden sm:inline">{isDarkMode ? 'Sáng' : 'Tối'}</span>
          </button>

          {/* Ask Teacher CTA */}
          <button
            onClick={onOpenAskModal}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-xs sm:text-[13px] font-semibold bg-[#F4B942] text-[#0B2A3C] hover:bg-[#FFCB5C] transition-colors cursor-pointer shadow-xs"
          >
            <MessageSquare className="w-3.5 h-3.5 text-[#0B2A3C]" />
            <span className="hidden xs:inline">Hỏi thầy PBA</span>
            <span className="xs:hidden">Hỏi</span>
          </button>

          {/* Admin toggle */}
          <button
            onClick={onToggleAdmin}
            title={isAdmin ? 'Thoát quyền quản trị' : 'Chế độ Quản trị của Thầy'}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold border transition-colors cursor-pointer ${
              isAdmin
                ? 'bg-red-500/20 border-red-400 text-white hover:bg-red-500/30'
                : 'bg-white/5 border-white/20 text-white/80 hover:bg-white/15'
            }`}
          >
            {isAdmin ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{isAdmin ? 'Thoát' : 'Quản trị'}</span>
          </button>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-[#08424D] border-t border-white/10 px-4 py-3 space-y-1 animate-fadeIn">
          {/* Mobile dark mode toggle */}
          <button
            onClick={() => {
              onToggleDarkMode();
            }}
            className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm font-semibold text-white/90 hover:bg-white/10 mb-2 border-b border-white/10 pb-2.5"
          >
            <span className="flex items-center gap-2">
              {isDarkMode ? <Sun className="w-4 h-4 text-[#F4B942]" /> : <Moon className="w-4 h-4 text-[#A2D9D9]" />}
              <span>Giao diện {isDarkMode ? 'Sáng' : 'Tối (Học ban đêm)'}</span>
            </span>
            <span className="text-xs font-mono bg-white/10 px-2 py-0.5 rounded">
              {isDarkMode ? 'Đang bật Tối' : 'Đang bật Sáng'}
            </span>
          </button>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.key;
            return (
              <button
                key={item.key}
                onClick={() => handleNavClick(item.key)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-semibold transition-colors ${
                  isActive
                    ? 'bg-white text-[#0B5563]'
                    : 'text-white/90 hover:bg-white/10'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}
          {isAdmin && (
            <button
              onClick={() => handleNavClick('admin')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-semibold ${
                currentTab === 'admin'
                  ? 'bg-red-500 text-white'
                  : 'bg-red-500/20 text-red-100'
              }`}
            >
              <Lock className="w-4 h-4" />
              <span>Quản trị hệ thống</span>
            </button>
          )}
        </div>
      )}
    </header>
  );
};

export default Navbar;
