import React, { useState } from 'react';
import { REAL_WORLD_PROBLEMS, RealWorldProblem } from '../data/realWorldData';
import { MathTex } from './MathTex';
import { MathSvgFigure } from './MathSvgFigures';
import {
  Compass,
  Sliders,
  CheckCircle2,
  RefreshCw,
  Lightbulb,
  ArrowRight,
  TrendingUp,
  Boxes
} from 'lucide-react';

export const RealWorldTab: React.FC = () => {
  const [selectedProblemId, setSelectedProblemId] = useState<string>(REAL_WORLD_PROBLEMS[0].id);
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const currentProblem =
    REAL_WORLD_PROBLEMS.find((p) => p.id === selectedProblemId) || REAL_WORLD_PROBLEMS[0];

  // Dynamic parameters state
  const [params, setParams] = useState<Record<string, number>>(
    currentProblem.defaultParams || {}
  );

  const handleSelectProblem = (id: string) => {
    setSelectedProblemId(id);
    const prob = REAL_WORLD_PROBLEMS.find((p) => p.id === id);
    if (prob && prob.defaultParams) {
      setParams(prob.defaultParams);
    } else {
      setParams({});
    }
  };

  const handleParamChange = (key: string, val: number) => {
    setParams((prev) => ({ ...prev, [key]: val }));
  };

  const filteredProblems =
    activeCategory === 'all'
      ? REAL_WORLD_PROBLEMS
      : REAL_WORLD_PROBLEMS.filter((p) => p.category === activeCategory);

  const dynamicResult = currentProblem.calculateResult
    ? currentProblem.calculateResult(params)
    : null;

  return (
    <div className="space-y-8">
      {/* Title & Introduction Banner */}
      <div className="bg-gradient-to-r from-[#0B5563] to-[#0E7C86] rounded-2xl p-6 sm:p-8 text-white shadow-md space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-xs font-semibold text-[#F4B942]">
          <Compass className="w-3.5 h-3.5" />
          <span>Toán học gắn liền với đời sống & Kĩ thuật</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          Toán Ứng Dụng Thực Tiễn
        </h1>
        <p className="text-xs sm:text-sm text-teal-100 max-w-2xl leading-relaxed">
          Đổi mới theo xu hướng thi THPT của Bộ GD&ĐT: Vận dụng kiến thức đạo hàm, hình học không gian, hàm số mũ - logarit và xác suất thống kê để giải quyết các bài toán tối ưu kinh tế, kiến trúc xây dựng và kĩ thuật số.
        </p>
      </div>

      {/* Filter and Problem Selection Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 p-4 bg-white rounded-2xl border border-slate-200/90 shadow-xs">
        {/* Category Filter Chips */}
        <div className="flex flex-wrap items-center gap-1.5">
          {['all', 'Kinh tế & Tối ưu', 'Kĩ thuật & Hình học'].map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                activeCategory === cat
                  ? 'bg-teal-700 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat === 'all' ? 'Tất cả chủ đề' : cat}
            </button>
          ))}
        </div>

        {/* Dropdown selector */}
        <div className="flex items-center gap-2">
          <select
            value={selectedProblemId}
            onChange={(e) => handleSelectProblem(e.target.value)}
            className="w-full md:w-auto px-3.5 py-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 text-xs sm:text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-teal-500"
          >
            {filteredProblems.map((prob) => (
              <option key={prob.id} value={prob.id}>
                {prob.title}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Main Problem Sheet */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Problem context, Dynamic parameters, and Mathematical Solution */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-800">
                {currentProblem.category}
              </span>
              <span className="text-xs text-slate-400">Mã bài: {currentProblem.id}</span>
            </div>

            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 leading-tight">
              {currentProblem.title}
            </h2>

            <p className="text-xs text-slate-500 italic">
              {currentProblem.summary}
            </p>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/70 space-y-2 text-sm text-slate-800 leading-relaxed">
              <div className="font-bold text-slate-900 text-xs uppercase text-teal-800">
                Bối cảnh thực tế:
              </div>
              <MathTex content={currentProblem.context} />
              <div className="font-semibold text-slate-900 pt-1">
                <MathTex content={currentProblem.question} />
              </div>
            </div>

            {/* Interactive Parameter Control Box if supported */}
            {currentProblem.defaultParams && (
              <div className="p-4 bg-teal-50/60 rounded-xl border border-teal-200 space-y-3">
                <div className="flex items-center gap-1.5 text-xs font-bold text-teal-900 uppercase">
                  <Sliders className="w-3.5 h-3.5 text-teal-700" />
                  Mô phỏng thay đổi số liệu thực nghiệm:
                </div>

                <div className="space-y-3">
                  {Object.entries(currentProblem.defaultParams).map(([key, defaultVal]) => (
                    <div key={key} className="space-y-1">
                      <div className="flex justify-between text-xs text-slate-700 font-medium">
                        <span>{currentProblem.paramLabels?.[key] || key}:</span>
                        <span className="font-mono font-bold text-teal-800">
                          {params[key] ?? defaultVal}
                        </span>
                      </div>
                      <input
                        type="range"
                        min={defaultVal > 50 ? 30 : 2}
                        max={defaultVal > 50 ? 120 : 15}
                        step={defaultVal > 50 ? 6 : 0.5}
                        value={params[key] ?? defaultVal}
                        onChange={(e) => handleParamChange(key, parseFloat(e.target.value))}
                        className="w-full accent-teal-700 cursor-pointer"
                      />
                    </div>
                  ))}
                </div>

                {dynamicResult && (
                  <div className="p-2.5 bg-white rounded-lg border border-teal-200 text-xs text-teal-950 font-semibold space-y-1">
                    <div>
                      Kết quả với số liệu mới:{' '}
                      <span className="font-mono text-teal-800 font-bold">
                        {dynamicResult.value}
                      </span>
                    </div>
                    <div className="text-slate-600 font-normal">
                      <MathTex content={dynamicResult.explanation} />
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Mathematical Modeling Steps */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-4">
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <Lightbulb className="w-4 h-4 text-amber-500" />
              Lời giải chi tiết theo các bước mô hình hóa Toán học:
            </h3>

            <div className="space-y-4">
              {currentProblem.steps.map((step, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl border border-slate-100 bg-slate-50/60 space-y-2"
                >
                  <div className="text-xs font-bold text-teal-800 flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-teal-100 text-teal-800 flex items-center justify-center text-[11px] font-bold">
                      {idx + 1}
                    </span>
                    <span>{step.title}</span>
                  </div>
                  <div className="text-xs sm:text-sm text-slate-700 leading-relaxed pl-6">
                    <MathTex content={step.description} />
                  </div>
                  {step.formula && (
                    <div className="pl-6 pt-1">
                      <div className="p-2 bg-white rounded-lg border border-slate-200 text-slate-900 font-medium text-xs sm:text-sm">
                        <MathTex content={`$${step.formula}$`} block={false} />
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Final Answer Banner */}
            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <div className="text-sm font-bold text-emerald-950">
                Kết luận thực tế:{' '}
                <span className="font-medium">
                  <MathTex content={currentProblem.finalAnswer} />
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Visual Diagram & Practical Notes */}
        <div className="lg:col-span-5 space-y-6 sticky top-20">
          {currentProblem.diagramType && (
            <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-3">
              <div className="text-xs font-bold text-slate-500 uppercase tracking-wide">
                Mô hình trực quan:
              </div>
              <MathSvgFigure
                type={currentProblem.diagramType}
                caption={currentProblem.title}
              />
            </div>
          )}

          <div className="bg-gradient-to-br from-slate-50 to-teal-50/40 rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-3">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Boxes className="w-4 h-4 text-teal-700" />
              Bí quyết làm bài thi dạng Toán thực tiễn:
            </h4>
            <ul className="space-y-2 text-xs text-slate-700 leading-relaxed list-disc list-inside">
              <li>
                <strong>Đặt ẩn số rõ ràng:</strong> Luôn kèm theo đơn vị đo (cm, m, lít, triệu đồng) và điều kiện thực tế của biến.
              </li>
              <li>
                <strong>Hàm mục tiêu:</strong> Đưa bài toán về khảo sát hàm 1 biến $f(x)$. Nếu có 2 biến, dùng quan hệ hình học/kinh tế để triệt tiêu còn 1 biến.
              </li>
              <li>
                <strong>Khảo sát đạo hàm:</strong> Tìm điểm dừng $f'(x) = 0$ và lập bảng biến thiên hoặc dùng định lí Fermat để khẳng định cực trị.
              </li>
              <li>
                <strong>Đối chiếu thực tế:</strong> Kiểm tra xem nghiệm tìm được có phù hợp với thực tiễn hay không trước khi kết luận.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RealWorldTab;
