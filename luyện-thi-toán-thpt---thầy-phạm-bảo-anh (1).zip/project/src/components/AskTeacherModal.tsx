import React, { useState } from 'react';
import {
  MessageSquare,
  X,
  Send,
  CheckCircle2,
  HelpCircle,
  Mail,
  Phone,
  Sparkles
} from 'lucide-react';
import { TeacherMessage } from '../types/math';

interface AskTeacherModalProps {
  isOpen: boolean;
  onClose: () => void;
  onMessageSent: (msg: TeacherMessage) => void;
}

export const AskTeacherModal: React.FC<AskTeacherModalProps> = ({
  isOpen,
  onClose,
  onMessageSent
}) => {
  const [studentName, setStudentName] = useState('');
  const [studentContact, setStudentContact] = useState('');
  const [grade, setGrade] = useState<'10' | '11' | '12' | 'other'>('12');
  const [question, setQuestion] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [formError, setFormError] = useState('');

  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  const faqs = [
    {
      q: 'Làm thế nào để không bị mất điểm oan ở Phần II (Câu hỏi Đúng / Sai)?',
      a: 'Phần Đúng/Sai có barem điểm tăng tiến (0.1đ -> 0.25đ -> 0.5đ -> 1.0đ). Để đạt trọn 1.0 điểm, em phải xét độc lập từng khẳng định a, b, c, d; không được suy diễn chủ quan từ ý trước sang ý sau. Hãy luôn vẽ bảng biến thiên hoặc phác thảo hình học ra nháp trước khi quyết định.'
    },
    {
      q: 'Có nên phụ thuộc vào máy tính Casio để giải trắc nghiệm không?',
      a: 'Casio là công cụ hỗ trợ tuyệt vời để kiểm tra nghiệm, tính tích phân phức tạp hoặc nhân tích có hướng vectơ Oxyz. Tuy nhiên, đề thi 2025 của Bộ GD&ĐT tăng cường câu hỏi bản chất và tham số m để chống bấm máy mò mẫm. Do đó, nắm chắc bản chất toán học vẫn là gốc rễ để đạt 9+.'
    },
    {
      q: 'Phần trả lời ngắn (Phần III) cần lưu ý gì về định dạng điền số?',
      a: 'Chỉ điền số nguyên hoặc số thập phân. Nếu đề bài yêu cầu làm tròn đến hàng phần mười hay phần trăm, hãy tuân thủ chính xác quy tắc làm tròn. Tránh gõ thêm chữ cái hay đơn vị vào ô kết quả.'
    }
  ];

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentName.trim() || !question.trim()) {
      setFormError('Vui lòng nhập họ tên và nội dung câu hỏi.');
      return;
    }
    setFormError('');

    const newMsg: TeacherMessage = {
      id: `msg-${Date.now()}`,
      studentName: studentName.trim(),
      studentContact: studentContact.trim() || 'Học sinh',
      grade: grade === 'other' ? 'other' : (parseInt(grade) as 10 | 11 | 12),
      question: question.trim(),
      createdAt: new Date().toLocaleTimeString('vi-VN') + ' ' + new Date().toLocaleDateString('vi-VN'),
      status: 'pending'
    };

    onMessageSent(newMsg);
    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      setQuestion('');
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div className="bg-white rounded-2xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl relative max-h-[90vh] overflow-y-auto space-y-6">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 border-b border-slate-100 pb-4">
          <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-800 flex items-center justify-center font-bold text-lg">
            PBA
          </div>
          <div>
            <div className="text-xs font-bold text-[#F4B942] uppercase tracking-wide">
              Hỗ trợ học tập 24/7
            </div>
            <h2 className="text-xl font-bold text-slate-900">
              Nhắn tin hỏi Thầy Phạm Bảo Anh
            </h2>
            <div className="text-xs text-slate-500">
              Thầy sẽ giải đáp chi tiết bài toán và phương pháp học cho em
            </div>
          </div>
        </div>

        {/* FAQ Accordion */}
        <div className="space-y-2">
          <div className="text-xs font-bold text-slate-700 uppercase tracking-wide flex items-center gap-1.5">
            <HelpCircle className="w-3.5 h-3.5 text-teal-700" />
            Các câu hỏi thường gặp (FAQ) được Thầy giải đáp sẵn:
          </div>

          <div className="space-y-2">
            {faqs.map((faq, idx) => {
              const isOpenFaq = activeFaq === idx;
              return (
                <div
                  key={idx}
                  className="rounded-xl border border-slate-200 overflow-hidden text-xs"
                >
                  <button
                    onClick={() => setActiveFaq(isOpenFaq ? null : idx)}
                    className="w-full text-left p-3 font-semibold text-slate-800 bg-slate-50 hover:bg-slate-100 flex items-center justify-between gap-2 cursor-pointer"
                  >
                    <span>{faq.q}</span>
                    <span className="text-slate-400 font-bold">{isOpenFaq ? '−' : '+'}</span>
                  </button>
                  {isOpenFaq && (
                    <div className="p-3 bg-white text-slate-600 leading-relaxed border-t border-slate-100">
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Ask Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5 pt-2 border-t border-slate-100">
          <div className="text-xs font-bold text-slate-800 uppercase tracking-wide">
            Gửi câu hỏi bài toán mới cho thầy:
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div>
              <label className="block font-semibold text-slate-600 mb-1">
                Họ và tên *
              </label>
              <input
                type="text"
                required
                value={studentName}
                onChange={(e) => setStudentName(e.target.value)}
                placeholder="Em Nguyễn Văn B"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-600 mb-1">
                Email hoặc SĐT để thầy hồi âm *
              </label>
              <input
                type="text"
                required
                value={studentContact}
                onChange={(e) => setStudentContact(e.target.value)}
                placeholder="email@gmail.com hoặc SĐT"
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>
            <div>
              <label className="block font-semibold text-slate-600 mb-1">
                Khối lớp
              </label>
              <select
                value={grade}
                onChange={(e) => setGrade(e.target.value as any)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-500"
              >
                <option value="12">Lớp 12 (Ôn thi THPT)</option>
                <option value="11">Lớp 11</option>
                <option value="10">Lớp 10</option>
                <option value="other">Học sinh tự do</option>
              </select>
            </div>
          </div>

          <div className="text-xs">
            <label className="block font-semibold text-slate-600 mb-1">
              Nội dung câu hỏi hoặc bài toán thắc mắc *
            </label>
            <textarea
              required
              rows={4}
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Thầy ơi, cho em hỏi bài toán này: Cho hình chóp S.ABCD có đáy là hình vuông..."
              className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 text-slate-900 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>

          {formError && (
            <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-800 font-semibold">
              {formError}
            </div>
          )}

          <div className="flex items-center justify-between gap-3 pt-2">
            <div className="text-[11px] text-slate-500">
              Liên hệ trực tiếp: <a href="mailto:baoanh.math@gmail.com" className="text-teal-700 underline font-semibold">baoanh.math@gmail.com</a>
            </div>

            <button
              type="submit"
              disabled={isSuccess}
              className="px-5 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Gửi câu hỏi</span>
            </button>
          </div>

          {isSuccess && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Câu hỏi của em đã được gửi thành công đến Thầy Phạm Bảo Anh! Thầy sẽ phản hồi sớm nhất.</span>
            </div>
          )}
        </form>
      </div>
    </div>
  );
};

export default AskTeacherModal;
