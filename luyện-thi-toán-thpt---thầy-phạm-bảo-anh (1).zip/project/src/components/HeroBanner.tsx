import React from 'react';
import { Sparkles, FileText, Compass, Award, ArrowRight } from 'lucide-react';
import { TabKey } from './Navbar';
import { CubicGraphInteractive } from './CubicGraphInteractive';

interface HeroBannerProps {
  onNavigate: (tab: TabKey) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ onNavigate }) => {
  return (
    <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#0B2A3C] via-[#0B5563] to-[#0E7C86] text-white p-6 sm:p-10 shadow-lg border border-teal-800/40">
      {/* Decorative math formula background accents */}
      <div className="absolute -right-8 -top-8 text-white/5 font-mono text-9xl font-bold select-none pointer-events-none">
        ∫dx
      </div>
      <div className="absolute right-1/3 -bottom-10 text-white/5 font-mono text-8xl font-bold select-none pointer-events-none">
        lim
      </div>

      <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left Column: Brief and Headline */}
        <div className="lg:col-span-7 space-y-5">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-xs border border-white/20 text-xs font-semibold text-[#F4B942]">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Chương trình GDPT 2018 · Đề thi Chuẩn 2025</span>
          </div>

          <div className="space-y-2">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
              Luyện Thi Toán THPT <br className="hidden sm:inline" />
              <span className="text-[#F4B942]">Thầy Phạm Bảo Anh</span>
            </h1>
            <p className="text-sm sm:text-base text-teal-100 max-w-xl leading-relaxed">
              Hệ thống rèn luyện Toán 10 - 11 - 12 với công nghệ sinh đề ngẫu nhiên, bài toán thực tiễn gắn liền đời sống và cấu trúc đề thi 3 phần chuẩn Bộ GD&ĐT: Trắc nghiệm 4 lựa chọn, Đúng/Sai và Trả lời ngắn.
            </p>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-wrap gap-2.5 pt-2">
            <button
              onClick={() => onNavigate('exam')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-bold text-sm bg-[#F4B942] text-[#0B2A3C] hover:bg-[#FFCB5C] transition-all shadow-md hover:scale-[1.02] cursor-pointer"
            >
              <FileText className="w-4 h-4" />
              <span>Tạo đề thi Chuẩn 2025</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onNavigate('g12')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm bg-white/10 hover:bg-white/20 text-white transition-all border border-white/20 cursor-pointer"
            >
              <span>Ôn tập Toán 12</span>
            </button>

            <button
              onClick={() => onNavigate('tt')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm bg-white/10 hover:bg-white/20 text-white transition-all border border-white/20 cursor-pointer"
            >
              <Compass className="w-4 h-4" />
              <span>Toán thực tiễn</span>
            </button>

            <button
              onClick={() => onNavigate('week')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl font-semibold text-sm bg-white/10 hover:bg-white/20 text-white transition-all border border-white/20 cursor-pointer"
            >
              <Award className="w-4 h-4" />
              <span>Bài toán tuần</span>
            </button>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-white/15">
            <div>
              <div className="text-xl sm:text-2xl font-bold text-white">48+</div>
              <div className="text-xs text-teal-200">Dạng toán sinh số</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-bold text-[#F4B942]">3 Phần</div>
              <div className="text-xs text-teal-200">Chuẩn thi 2025</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-bold text-white">100%</div>
              <div className="text-xs text-teal-200">Có giải chi tiết</div>
            </div>
            <div>
              <div className="text-xl sm:text-2xl font-bold text-emerald-300">Miễn phí</div>
              <div className="text-xs text-teal-200">Luyện tập trực tuyến</div>
            </div>
          </div>
        </div>

        {/* Right Column: High-Precision Interactive Cubic Graph */}
        <div className="lg:col-span-5">
          <CubicGraphInteractive initialPreset="benchmark" />
        </div>
      </div>
    </div>
  );
};

export default HeroBanner;
