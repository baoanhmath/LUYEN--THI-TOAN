import React, { useState } from 'react';
import {
  FolderDown,
  Search,
  FileText,
  Download,
  BookOpen,
  CheckCircle2,
  ExternalLink,
  Eye,
  X
} from 'lucide-react';
import { MATH_DOCUMENTS } from '../data/documentsData';
import { MathDocument } from '../types/math';

export const DocumentsTab: React.FC = () => {
  const [documents, setDocuments] = useState<MathDocument[]>(MATH_DOCUMENTS);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [previewDoc, setPreviewDoc] = useState<MathDocument | null>(null);
  const [downloadSuccessToast, setDownloadSuccessToast] = useState<string | null>(null);

  const categories = [
    { key: 'all', label: 'Tất cả tài liệu' },
    { key: 'exam', label: 'Đề thi thử 2025' },
    { key: 'theory', label: 'Sổ tay lý thuyết & Oxyz' },
    { key: 'tf_bank', label: 'Ngân hàng Đúng / Sai' },
    { key: 'applied', label: 'Toán thực tế' },
    { key: 'casio', label: 'Thủ thuật Casio' }
  ];

  const filteredDocs = documents.filter((doc) => {
    const matchCat = selectedCategory === 'all' || doc.category === selectedCategory;
    const matchQuery =
      searchQuery === '' ||
      doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase())) ||
      doc.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCat && matchQuery;
  });

  const handleDownload = (doc: MathDocument) => {
    // Increment download counter
    setDocuments((prev) =>
      prev.map((d) => (d.id === doc.id ? { ...d, downloadCount: d.downloadCount + 1 } : d))
    );

    setDownloadSuccessToast(`Đang tải xuống: "${doc.title}" (${doc.fileSize})...`);
    setTimeout(() => {
      setDownloadSuccessToast(null);
    }, 3500);
  };

  return (
    <div className="space-y-8">
      {/* Banner */}
      <div className="bg-gradient-to-r from-[#0B5563] to-[#0E7C86] rounded-2xl p-6 sm:p-8 text-white shadow-md space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-xs font-semibold text-[#F4B942]">
          <FolderDown className="w-3.5 h-3.5" />
          <span>Thư viện học liệu Thầy Phạm Bảo Anh</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          Kho Tài Liệu & Đề Thi Thử Môn Toán
        </h1>
        <p className="text-xs sm:text-sm text-teal-100 max-w-2xl leading-relaxed">
          Tổng hợp toàn bộ các bộ đề thi thử THPT Quốc Gia có lời giải chi tiết, sổ tay công thức giải nhanh, chuyên đề trắc nghiệm Đúng/Sai và hướng dẫn bấm máy Casio FX-580VNX / 880BTG.
        </p>
      </div>

      {/* Toast Notification */}
      {downloadSuccessToast && (
        <div className="p-3.5 bg-teal-800 text-white rounded-xl text-xs sm:text-sm font-semibold flex items-center justify-between shadow-lg animate-fadeIn">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#F4B942]" />
            <span>{downloadSuccessToast}</span>
          </div>
          <button onClick={() => setDownloadSuccessToast(null)} className="text-white/80 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 p-4 bg-white rounded-2xl border border-slate-200/90 shadow-xs">
        {/* Category Tabs */}
        <div className="flex flex-wrap items-center gap-1.5">
          {categories.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setSelectedCategory(cat.key)}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                selectedCategory === cat.key
                  ? 'bg-teal-700 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Tìm kiếm tài liệu, chuyên đề..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm bg-slate-50 focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>
      </div>

      {/* Document Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredDocs.map((doc) => (
          <div
            key={doc.id}
            className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between space-y-4 hover:border-teal-500/50 hover:shadow-md transition-all group"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span className="font-semibold text-teal-800 bg-teal-50 px-2 py-0.5 rounded">
                  {doc.grade === 'all' ? 'Toán 10-11-12' : `Toán ${doc.grade}`}
                </span>
                <span>{doc.pages} trang · {doc.fileSize}</span>
              </div>

              <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug group-hover:text-teal-700 transition-colors">
                {doc.title}
              </h3>

              <p className="text-xs text-slate-500 leading-relaxed line-clamp-3">
                {doc.description}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {doc.tags.map((tag, tIdx) => (
                  <span
                    key={tIdx}
                    className="text-[11px] px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-medium"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
              <span className="text-[11px] text-slate-400">
                {doc.downloadCount.toLocaleString('vi-VN')} lượt tải
              </span>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setPreviewDoc(doc)}
                  className="px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Xem</span>
                </button>

                <button
                  onClick={() => handleDownload(doc)}
                  className="px-3 py-1.5 rounded-lg bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Tải PDF</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredDocs.length === 0 && (
        <div className="p-12 text-center text-slate-400 bg-white rounded-2xl border border-slate-200">
          Không tìm thấy tài liệu phù hợp với từ khóa &ldquo;{searchQuery}&rdquo;.
        </div>
      )}

      {/* Preview Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-2xl max-w-xl w-full p-6 space-y-4 shadow-2xl relative">
            <button
              onClick={() => setPreviewDoc(null)}
              className="absolute right-4 top-4 p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2 text-xs font-bold text-teal-800 uppercase">
              <BookOpen className="w-4 h-4" />
              Xem trước tài liệu học tập
            </div>

            <h3 className="text-lg font-bold text-slate-900 leading-snug">
              {previewDoc.title}
            </h3>

            <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs sm:text-sm text-slate-700 leading-relaxed">
              <div className="font-semibold text-slate-900">Nội dung tóm lược:</div>
              <p>{previewDoc.description}</p>
              <div className="pt-2 text-slate-500 font-mono text-xs">
                Định dạng: PDF chất lượng cao (in ấn sắc nét) · Dung lượng: {previewDoc.fileSize} · {previewDoc.pages} trang · Biên soạn: Thầy Phạm Bảo Anh.
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setPreviewDoc(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                Đóng
              </button>
              <button
                onClick={() => {
                  handleDownload(previewDoc);
                  setPreviewDoc(null);
                }}
                className="px-4 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 text-white text-xs font-bold flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>Tải tài liệu ngay</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DocumentsTab;
