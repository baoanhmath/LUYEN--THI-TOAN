import React, { useState, useEffect } from 'react';
import {
  Trophy,
  Award,
  Clock,
  Send,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  BookOpen,
  History,
  Lightbulb
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { INITIAL_WEEK_PROBLEMS, INITIAL_LEADERBOARD } from '../data/weekProblemsData';
import { WeekProblem, WeekSubmission } from '../types/math';
import { MathTex } from './MathTex';
import { isShortAnswerEquivalent } from '../utils/mathScoring';

export const WeekProblemTab: React.FC = () => {
  // Problems state with localStorage support
  const [problems, setProblems] = useState<WeekProblem[]>(() => {
    const saved = localStorage.getItem('pba_week_problems');
    return saved ? JSON.parse(saved) : INITIAL_WEEK_PROBLEMS;
  });

  const [leaderboard, setLeaderboard] = useState<WeekSubmission[]>(() => {
    const saved = localStorage.getItem('pba_week_leaderboard');
    return saved ? JSON.parse(saved) : INITIAL_LEADERBOARD;
  });

  const currentProblem = problems.find((p) => p.status === 'active') || problems[0];

  // Submission Form
  const [studentName, setStudentName] = useState('');
  const [studentSchool, setStudentSchool] = useState('');
  const [studentClass, setStudentClass] = useState('');
  const [submittedAnswer, setSubmittedAnswer] = useState('');
  const [submissionStatus, setSubmissionStatus] = useState<string | null>(null);
  const [formError, setFormError] = useState('');

  // Past problems view
  const [viewPastSolutionId, setViewPastSolutionId] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentName.trim() || !submittedAnswer.trim()) {
      setFormError('Vui lòng điền đầy đủ Họ tên và Đáp số của bạn.');
      return;
    }
    setFormError('');

    const isMatch = isShortAnswerEquivalent(submittedAnswer, currentProblem.correctAnswer);

    const newSubmission: WeekSubmission = {
      id: `sub-${Date.now()}`,
      problemId: currentProblem.id,
      studentName: studentName.trim(),
      studentSchool: studentSchool.trim() || 'Học sinh tự do',
      studentClass: studentClass.trim() || '12',
      submittedAnswer: submittedAnswer.trim(),
      isCorrect: isMatch,
      score: isMatch ? 10 : 8,
      feedback: isMatch
        ? 'Chính xác! Chúc mừng em đã xuất sắc tìm ra đáp số chuẩn.'
        : 'Cảm ơn em đã nộp bài. Thầy PBA đã ghi nhận lời giải của em.',
      submittedAt: 'Vừa xong'
    };

    const updatedLeaderboard = [newSubmission, ...leaderboard];
    setLeaderboard(updatedLeaderboard);
    localStorage.setItem('pba_week_leaderboard', JSON.stringify(updatedLeaderboard));

    setSubmissionStatus(
      isMatch
        ? 'Chúc mừng em! Đáp án chính xác tuyệt đối. Em đã được vinh danh trên Bảng Vàng!'
        : 'Bài làm đã được gửi thành công đến Thầy Phạm Bảo Anh để chấm điểm.'
    );

    if (isMatch) {
      try {
        confetti({ particleCount: 70, spread: 60 });
      } catch {}
    }
  };

  const pastProblems = problems.filter((p) => p.id !== currentProblem.id);

  return (
    <div className="space-y-8">
      {/* Banner */}
      <div className="bg-gradient-to-r from-[#0B2A3C] via-[#0B5563] to-[#0E7C86] rounded-2xl p-6 sm:p-8 text-white shadow-md space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-xs font-semibold text-[#F4B942]">
          <Trophy className="w-3.5 h-3.5" />
          <span>Thử thách Toán học Thầy PBA</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          Bài Toán Tuần & Bảng Vàng Vinh Danh
        </h1>
        <p className="text-xs sm:text-sm text-teal-100 max-w-2xl leading-relaxed">
          Mỗi tuần một bài toán tư duy vận dụng cao môn Toán. Thử sức khả năng giải quyết vấn đề, tranh tài cùng các bạn học sinh toàn quốc và nhận những phần quà ý nghĩa từ Thầy Phạm Bảo Anh.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Active Problem & Submission Form */}
        <div className="lg:col-span-7 space-y-6">
          {/* Active Problem Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-5">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-teal-50 text-teal-800 text-xs font-bold">
                <Trophy className="w-3.5 h-3.5 text-teal-600" />
                Tuần thứ {currentProblem.weekNumber}
              </span>
              <div className="flex items-center gap-1 text-xs text-rose-600 font-semibold">
                <Clock className="w-3.5 h-3.5" />
                <span>Hạn nộp: {currentProblem.deadline}</span>
              </div>
            </div>

            <div className="space-y-2">
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 leading-snug">
                {currentProblem.title}
              </h2>
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 text-slate-800 text-sm leading-relaxed font-medium">
                <MathTex content={currentProblem.content} />
              </div>
            </div>

            {/* Reward Box */}
            <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl flex items-center gap-3 text-xs sm:text-sm text-amber-950">
              <Award className="w-5 h-5 text-amber-600 shrink-0" />
              <div>
                <span className="font-bold">Phần thưởng tuần này: </span>
                <span>{currentProblem.reward}</span>
              </div>
            </div>

            {/* Submission Form */}
            <form onSubmit={handleSubmit} className="space-y-4 pt-2">
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                Nộp bài giải của bạn:
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Họ và tên *
                  </label>
                  <input
                    type="text"
                    required
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    placeholder="Nguyễn Văn A"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Trường THPT
                  </label>
                  <input
                    type="text"
                    value={studentSchool}
                    onChange={(e) => setStudentSchool(e.target.value)}
                    placeholder="THPT Chuyên..."
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">
                    Lớp
                  </label>
                  <input
                    type="text"
                    value={studentClass}
                    onChange={(e) => setStudentClass(e.target.value)}
                    placeholder="12A1"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Đáp số / Lời giải tóm tắt *
                </label>
                <textarea
                  required
                  rows={3}
                  value={submittedAnswer}
                  onChange={(e) => setSubmittedAnswer(e.target.value)}
                  placeholder="Điền đáp số hoặc tóm tắt các bước giải chính..."
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-sm shadow-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Nộp bài thử thách</span>
              </button>

              {submissionStatus && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-900 font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{submissionStatus}</span>
                </div>
              )}
            </form>
          </div>

          {/* Past Weeks Archive */}
          {pastProblems.length > 0 && (
            <div className="bg-white rounded-2xl border border-slate-200/90 p-6 shadow-xs space-y-4">
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <History className="w-4 h-4 text-slate-600" />
                Kho bài toán các tuần trước
              </h3>

              <div className="space-y-3">
                {pastProblems.map((prob) => {
                  const isViewing = viewPastSolutionId === prob.id;

                  return (
                    <div
                      key={prob.id}
                      className="p-4 rounded-xl border border-slate-100 bg-slate-50/60 space-y-2"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-xs text-slate-700">
                          Tuần {prob.weekNumber}: {prob.title}
                        </span>
                        <button
                          onClick={() => setViewPastSolutionId(isViewing ? null : prob.id)}
                          className="text-xs text-teal-700 font-semibold hover:underline cursor-pointer"
                        >
                          {isViewing ? 'Ẩn lời giải' : 'Xem lời giải'}
                        </button>
                      </div>

                      <div className="text-xs text-slate-600">
                        <MathTex content={prob.content} />
                      </div>

                      {isViewing && (
                        <div className="p-3 bg-white rounded-lg border border-slate-200 text-xs text-slate-800 space-y-1 mt-2">
                          <div className="font-bold text-teal-900 flex items-center gap-1">
                            <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
                            Đáp án: {prob.correctAnswer} · Lời giải mẫu của Thầy PBA:
                          </div>
                          <div className="whitespace-pre-line text-slate-700">
                            <MathTex content={prob.solution} />
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Leaderboard (Bảng Vàng) */}
        <div className="lg:col-span-5 space-y-6 sticky top-20">
          <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-500" />
                <h3 className="font-extrabold text-slate-900 text-base">
                  Bảng Vàng Thủ Khoa
                </h3>
              </div>
              <span className="text-xs text-slate-400">
                {leaderboard.length} bài nộp
              </span>
            </div>

            <div className="space-y-3">
              {leaderboard.slice(0, 8).map((sub, idx) => (
                <div
                  key={sub.id}
                  className="p-3 rounded-xl border border-slate-100 bg-slate-50/50 flex items-start gap-3"
                >
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs shrink-0 ${
                      idx === 0
                        ? 'bg-amber-100 text-amber-800 border border-amber-300'
                        : idx === 1
                        ? 'bg-slate-200 text-slate-700'
                        : idx === 2
                        ? 'bg-amber-700/10 text-amber-900'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {idx + 1}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <div className="font-bold text-xs sm:text-sm text-slate-900 truncate">
                        {sub.studentName}
                      </div>
                      <span className="font-bold text-xs text-teal-800 shrink-0">
                        {sub.score || 10}đ
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-500 truncate">
                      {sub.studentSchool} · {sub.studentClass}
                    </div>

                    {sub.feedback && (
                      <div className="text-[11px] text-teal-700 italic mt-1 line-clamp-1">
                        &ldquo;{sub.feedback}&rdquo;
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WeekProblemTab;
