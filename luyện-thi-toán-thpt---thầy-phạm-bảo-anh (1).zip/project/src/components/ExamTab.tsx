import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import {
  FileCheck2,
  Clock,
  Printer,
  Eye,
  RefreshCw,
  Send,
  AlertCircle,
  Award,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ChevronDown
} from 'lucide-react';
import { generateFullExam2025 } from '../data/questionGenerators';
import { GeneratedExam, StudentExamAnswers, ExamResult } from '../types/math';
import { evaluateExam } from '../utils/mathScoring';
import { MathTex } from './MathTex';
import { MathSvgFigure } from './MathSvgFigures';

export const ExamTab: React.FC = () => {
  // Exam generation config
  const [schoolName, setSchoolName] = useState<string>('TRƯỜNG THPT CHUYÊN TOÁN - THẦY PHẠM BẢO ANH');
  const [studentName, setStudentName] = useState<string>('Phạm Văn Minh');
  const [studentCode, setStudentCode] = useState<string>('SBD: 250186');

  // Generated exam state
  const [exam, setExam] = useState<GeneratedExam | null>(null);

  // Student answers
  const [answers, setAnswers] = useState<StudentExamAnswers>({
    part1: {},
    part2: {},
    part3: {}
  });

  // Timer state
  const [timeLeft, setTimeLeft] = useState<number>(90 * 60);
  const [timerActive, setTimerActive] = useState<boolean>(false);

  // Submission & Scoring state
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [result, setResult] = useState<ExamResult | null>(null);
  const [showSolutions, setShowSolutions] = useState<boolean>(false);

  // Initial exam generation on mount
  useEffect(() => {
    handleCreateExam();
  }, []);

  // Timer interval - strictly separated from state side-effects
  useEffect(() => {
    let interval: any = null;
    if (timerActive && timeLeft > 0 && !isSubmitted) {
      interval = setInterval(() => {
        setTimeLeft((prev) => Math.max(0, prev - 1));
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [timerActive, timeLeft, isSubmitted]);

  // Automatic submission when timer reaches 0
  useEffect(() => {
    if (timerActive && timeLeft === 0 && !isSubmitted && exam) {
      handleSubmitExam();
    }
  }, [timerActive, timeLeft, isSubmitted, exam]);

  const handleCreateExam = () => {
    const newExam = generateFullExam2025(schoolName);
    setExam(newExam);
    setAnswers({
      part1: {},
      part2: {},
      part3: {}
    });
    setTimeLeft(newExam.durationMinutes * 60);
    setTimerActive(true);
    setIsSubmitted(false);
    setResult(null);
    setShowSolutions(false);
  };

  const handleSelectMCQ = (qId: string, label: 'A' | 'B' | 'C' | 'D') => {
    if (isSubmitted) return;
    setAnswers((prev) => ({
      ...prev,
      part1: { ...prev.part1, [qId]: label }
    }));
  };

  const handleSelectTF = (qId: string, subLabel: 'a' | 'b' | 'c' | 'd', value: boolean) => {
    if (isSubmitted) return;
    setAnswers((prev) => {
      const currentQ = prev.part2[qId] || { a: null, b: null, c: null, d: null };
      return {
        ...prev,
        part2: {
          ...prev.part2,
          [qId]: { ...currentQ, [subLabel]: value }
        }
      };
    });
  };

  const handleShortAnswerChange = (qId: string, val: string) => {
    if (isSubmitted) return;
    setAnswers((prev) => ({
      ...prev,
      part3: { ...prev.part3, [qId]: val }
    }));
  };

  const handleSubmitExam = () => {
    if (!exam || isSubmitted) return;

    const timeSpent = Math.max(0, exam.durationMinutes * 60 - timeLeft);
    const examResult = evaluateExam(exam, answers, timeSpent);

    setResult(examResult);
    setIsSubmitted(true);
    setTimerActive(false);

    // Save exam record to student history for progress chart
    try {
      const existing = localStorage.getItem('pba_student_exam_history');
      const list = existing ? JSON.parse(existing) : [];
      const newRecord = {
        id: exam.id,
        name: `Đề ${list.length + 1}`,
        code: exam.code,
        date: new Date().toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' }),
        score: examResult.score,
        maxScore: 10,
        timeSpentMinutes: Math.max(1, Math.round(timeSpent / 60)),
        format: 'Chuẩn 2025'
      };
      list.push(newRecord);
      localStorage.setItem('pba_student_exam_history', JSON.stringify(list));
    } catch {}

    try {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch {
      // ignore
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (!exam) {
    return (
      <div className="p-12 text-center text-slate-500">
        Đang khởi tạo đề thi mô phỏng...
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 1. Exam Configuration Header (Hidden during print) */}
      <div className="print:hidden bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-3 border-b border-slate-100">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-teal-800">
              <FileCheck2 className="w-4 h-4" />
              Chuẩn cấu trúc Bộ Giáo dục & Đào tạo 2025
            </div>
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900">
              Phòng Luyện Thi Trực Tuyến & In Đề
            </h1>
          </div>

          {/* Timer Display */}
          <div className="flex items-center gap-3">
            <div
              className={`flex items-center gap-2 px-4 py-2 rounded-xl border font-mono font-bold text-base shadow-xs ${
                timeLeft < 300
                  ? 'bg-rose-50 border-rose-300 text-rose-700 animate-pulse'
                  : 'bg-slate-50 border-slate-200 text-slate-800'
              }`}
            >
              <Clock className="w-4 h-4 text-teal-700" />
              <span>{formatTimer(timeLeft)}</span>
            </div>

            {!isSubmitted ? (
              <button
                onClick={handleSubmitExam}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs sm:text-sm shadow-xs transition-colors cursor-pointer"
              >
                <Send className="w-4 h-4" />
                <span>Nộp bài & Chấm</span>
              </button>
            ) : (
              <button
                onClick={() => setShowSolutions(!showSolutions)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 font-bold text-xs sm:text-sm transition-colors cursor-pointer"
              >
                <Eye className="w-4 h-4 text-amber-700" />
                <span>{showSolutions ? 'Ẩn lời giải' : 'Xem đáp án chi tiết'}</span>
              </button>
            )}

            <button
              onClick={handleCreateExam}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
              title="Tạo đề thi mới với bộ câu hỏi và số liệu ngẫu nhiên"
            >
              <RefreshCw className="w-4 h-4" />
              <span className="hidden sm:inline">Tạo đề mới</span>
            </button>

            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
              title="In đề thi chuẩn trang giấy"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">In đề</span>
            </button>
          </div>
        </div>

        {/* Inputs for school name and candidate info */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div>
            <label className="text-slate-500 font-medium block mb-1">
              Đơn vị / Trường in trên đề:
            </label>
            <input
              type="text"
              value={schoolName}
              onChange={(e) => setSchoolName(e.target.value)}
              className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 font-medium focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>
          <div>
            <label className="text-slate-500 font-medium block mb-1">
              Họ và tên thí sinh:
            </label>
            <input
              type="text"
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
              className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 font-medium focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>
          <div>
            <label className="text-slate-500 font-medium block mb-1">
              Số báo danh (SBD):
            </label>
            <input
              type="text"
              value={studentCode}
              onChange={(e) => setStudentCode(e.target.value)}
              className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 text-slate-800 font-medium focus:outline-none focus:ring-1 focus:ring-teal-500"
            />
          </div>
        </div>
      </div>

      {/* 2. Result Summary Banner (if submitted) */}
      {isSubmitted && result && (
        <div className="bg-gradient-to-r from-teal-900 to-[#0B5563] text-white rounded-2xl p-6 shadow-md space-y-4 animate-fadeIn">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/20 pb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-[#F4B942]">
                <Award className="w-7 h-7" />
              </div>
              <div>
                <div className="text-xs text-teal-200 uppercase font-semibold">
                  Kết quả bài thi tốt nghiệp
                </div>
                <div className="text-2xl sm:text-3xl font-black text-white">
                  {result.score.toFixed(2)} / 10.00 điểm
                </div>
              </div>
            </div>

            <div className="flex items-center gap-6 text-xs text-teal-100">
              <div>
                <span className="block text-slate-300">Thời gian làm bài:</span>
                <span className="font-bold text-white text-sm">
                  {Math.floor(result.timeSpentSeconds / 60)} phút {result.timeSpentSeconds % 60} giây
                </span>
              </div>
              <div>
                <span className="block text-slate-300">Nộp lúc:</span>
                <span className="font-bold text-white text-sm">{result.submittedAt}</span>
              </div>
            </div>
          </div>

          {/* Breakdown by 3 Parts */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-white/10 border border-white/15">
              <div className="text-slate-300 font-medium">Phần I (Trắc nghiệm):</div>
              <div className="text-base font-bold text-white mt-1">
                {result.part1Score.toFixed(2)} / 3.00 điểm
              </div>
              <div className="text-teal-200 mt-0.5">
                Đúng {result.part1CorrectCount} / 12 câu
              </div>
            </div>

            <div className="p-3 rounded-xl bg-white/10 border border-white/15">
              <div className="text-slate-300 font-medium">Phần II (Đúng / Sai):</div>
              <div className="text-base font-bold text-white mt-1">
                {result.part2Score.toFixed(2)} / 4.00 điểm
              </div>
              <div className="text-teal-200 mt-0.5">
                Barem Bộ GD&ĐT (1 ý: 0.1đ, 4 ý: 1.0đ)
              </div>
            </div>

            <div className="p-3 rounded-xl bg-white/10 border border-white/15">
              <div className="text-slate-300 font-medium">Phần III (Trả lời ngắn):</div>
              <div className="text-base font-bold text-white mt-1">
                {result.part3Score.toFixed(2)} / 3.00 điểm
              </div>
              <div className="text-teal-200 mt-0.5">
                Đúng {result.part3CorrectCount} / 6 câu
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. The Exam Paper (Print layout + Online Interactive) */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-10 shadow-xs space-y-8 print:p-0 print:border-none print:shadow-none">
        {/* Official Paper Header */}
        <div className="border-b-2 border-slate-900 pb-5 grid grid-cols-2 gap-4 text-xs sm:text-sm">
          <div>
            <div className="font-bold uppercase tracking-tight text-slate-900">
              {schoolName}
            </div>
            <div className="font-semibold text-slate-700">TỔ TOÁN - TIN</div>
            <div className="italic text-slate-500 mt-1">
              (Đề thi gồm 3 phần: 12 TN · 4 Đ/S · 6 TLN)
            </div>
            <div className="mt-3 text-slate-800">
              <span>Họ và tên thí sinh: </span>
              <strong className="underline underline-offset-4">{studentName}</strong>
            </div>
            <div className="text-slate-800">
              <span>Số báo danh: </span>
              <strong className="underline underline-offset-4">{studentCode}</strong>
            </div>
          </div>

          <div className="text-right">
            <div className="font-extrabold uppercase text-slate-900">
              KÌ THI TỐT NGHIỆP TRUNG HỌC PHỔ THÔNG
            </div>
            <div className="font-bold text-teal-800">Môn: TOÁN</div>
            <div className="text-slate-600 mt-0.5">
              Thời gian làm bài: 90 phút (không kể thời gian phát đề)
            </div>
            <div className="mt-3 font-mono font-bold text-slate-900">
              Mã đề thi: <span className="px-2 py-0.5 border border-slate-800 rounded">{exam.code}</span>
            </div>
          </div>
        </div>

        {/* ========================================================
            PHẦN I: CÂU TRẮC NGHIỆM NHIỀU PHƯƠNG ÁN LỰA CHỌN (12 câu)
            ======================================================== */}
        <section className="space-y-6">
          <div className="bg-slate-100/80 p-3 rounded-xl border border-slate-200">
            <h2 className="font-bold text-slate-900 text-sm sm:text-base">
              PHẦN I. Câu trắc nghiệm nhiều phương án lựa chọn (Thí sinh trả lời từ câu 1 đến câu 12. Mỗi câu hỏi thí sinh chỉ chọn một phương án).
            </h2>
            <div className="text-xs text-slate-500 mt-0.5">
              Mỗi câu trả lời đúng thí sinh được 0,25 điểm.
            </div>
          </div>

          <div className="space-y-6">
            {exam.part1.map((q) => {
              const userSelected = answers.part1[q.id];
              const isCorrect = isSubmitted && userSelected === q.correctAnswer;

              return (
                <div key={q.id} className="space-y-3 pt-2 border-b border-slate-100 pb-5">
                  <div className="text-sm font-semibold text-slate-900 leading-relaxed flex items-start gap-2">
                    <span className="text-teal-800 shrink-0 font-bold">
                      Câu {q.number}.
                    </span>
                    <div className="flex-1">
                      <MathTex content={q.stem} />
                    </div>
                  </div>

                  {q.diagram && (
                    <div className="py-2 flex justify-center">
                      <MathSvgFigure type={q.diagram.type} params={q.diagram.params} />
                    </div>
                  )}

                  {/* 4 Options */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 pt-1">
                    {q.options.map((opt) => {
                      const isSelected = userSelected === opt.label;
                      let optionClass =
                        'border-slate-200 bg-white hover:border-slate-300 text-slate-800';

                      if (isSubmitted) {
                        if (opt.label === q.correctAnswer) {
                          optionClass = 'border-emerald-500 bg-emerald-50 font-bold text-emerald-900';
                        } else if (isSelected) {
                          optionClass = 'border-rose-400 bg-rose-50 text-rose-900 line-through';
                        }
                      } else if (isSelected) {
                        optionClass = 'border-teal-700 bg-teal-50/70 text-teal-900 font-semibold';
                      }

                      return (
                        <button
                          key={opt.label}
                          onClick={() => handleSelectMCQ(q.id, opt.label)}
                          disabled={isSubmitted}
                          className={`flex items-start gap-2 p-2.5 rounded-xl border text-xs sm:text-sm text-left transition-all cursor-pointer ${optionClass}`}
                        >
                          <span className="font-bold text-slate-700 shrink-0">
                            {opt.label}.
                          </span>
                          <span className="flex-1">
                            <MathTex content={opt.content} />
                          </span>
                        </button>
                      );
                    })}
                  </div>

                  {/* Solution display if requested */}
                  {showSolutions && (
                    <div className="p-3 bg-teal-50/40 rounded-xl border border-teal-200 text-xs text-slate-700 space-y-1">
                      <div className="font-bold text-teal-900">
                        Đáp án: {q.correctAnswer} · Hướng dẫn giải:
                      </div>
                      <div className="whitespace-pre-line">
                        <MathTex content={q.solution} />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* ========================================================
            PHẦN II: CÂU TRẮC NGHIỆM ĐÚNG SAI (4 câu)
            ======================================================== */}
        <section className="space-y-6 pt-4">
          <div className="bg-slate-100/80 p-3 rounded-xl border border-slate-200">
            <h2 className="font-bold text-slate-900 text-sm sm:text-base">
              PHẦN II. Câu trắc nghiệm đúng sai (Thí sinh trả lời từ câu 1 đến câu 4. Trong mỗi ý a), b), c), d) ở mỗi câu, thí sinh chọn đúng hoặc sai).
            </h2>
            <div className="text-xs text-slate-500 mt-0.5">
              Thang điểm Bộ GD&ĐT: Đúng 1 ý: 0,1đ · Đúng 2 ý: 0,25đ · Đúng 3 ý: 0,5đ · Đúng 4 ý: 1,0đ.
            </div>
          </div>

          <div className="space-y-8">
            {exam.part2.map((q) => {
              const qAns = answers.part2[q.id] || { a: null, b: null, c: null, d: null };

              return (
                <div key={q.id} className="space-y-4 pt-2 border-b border-slate-100 pb-6">
                  <div className="text-sm font-semibold text-slate-900 leading-relaxed flex items-start gap-2">
                    <span className="text-teal-800 shrink-0 font-bold">
                      Câu {q.number}.
                    </span>
                    <div className="flex-1">
                      <MathTex content={q.stem} />
                    </div>
                  </div>

                  {q.diagram && (
                    <div className="py-2 flex justify-center">
                      <MathSvgFigure type={q.diagram.type} params={q.diagram.params} />
                    </div>
                  )}

                  {/* 4 statements a, b, c, d */}
                  <div className="space-y-2.5">
                    {q.subQuestions.map((sq) => {
                      const userChoice = qAns[sq.label];
                      const isCorrectChoice = isSubmitted && userChoice === sq.isCorrect;

                      return (
                        <div
                          key={sq.id}
                          className={`p-3 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs sm:text-sm ${
                            isSubmitted
                              ? isCorrectChoice
                                ? 'border-emerald-200 bg-emerald-50/40'
                                : 'border-rose-200 bg-rose-50/40'
                              : 'border-slate-200 bg-white'
                          }`}
                        >
                          <div className="flex items-start gap-2 flex-1">
                            <span className="font-bold text-slate-800">{sq.label})</span>
                            <span className="text-slate-800">
                              <MathTex content={sq.text} />
                            </span>
                          </div>

                          <div className="flex items-center gap-2 shrink-0">
                            <button
                              onClick={() => handleSelectTF(q.id, sq.label, true)}
                              disabled={isSubmitted}
                              className={`px-3 py-1 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                                userChoice === true
                                  ? 'bg-teal-700 text-white border-teal-700'
                                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                              }`}
                            >
                              Đúng
                            </button>
                            <button
                              onClick={() => handleSelectTF(q.id, sq.label, false)}
                              disabled={isSubmitted}
                              className={`px-3 py-1 rounded-lg text-xs font-bold border transition-colors cursor-pointer ${
                                userChoice === false
                                  ? 'bg-rose-700 text-white border-rose-700'
                                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                              }`}
                            >
                              Sai
                            </button>

                            {isSubmitted && (
                              <span className="text-xs font-bold pl-1">
                                {sq.isCorrect ? (
                                  <span className="text-emerald-700">(Đúng)</span>
                                ) : (
                                  <span className="text-rose-700">(Sai)</span>
                                )}
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {showSolutions && (
                    <div className="p-3 bg-teal-50/40 rounded-xl border border-teal-200 text-xs text-slate-700 space-y-1">
                      <div className="font-bold text-teal-900">Lời giải chi tiết:</div>
                      <div className="whitespace-pre-line">
                        <MathTex content={q.solution} />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* ========================================================
            PHẦN III: CÂU TRẮC NGHIỆM TRẢ LỜI NGẮN (6 câu)
            ======================================================== */}
        <section className="space-y-6 pt-4">
          <div className="bg-slate-100/80 p-3 rounded-xl border border-slate-200">
            <h2 className="font-bold text-slate-900 text-sm sm:text-base">
              PHẦN III. Câu trắc nghiệm trả lời ngắn (Thí sinh trả lời từ câu 1 đến câu 6. Điền số nguyên hoặc số thập phân vào ô trả lời).
            </h2>
            <div className="text-xs text-slate-500 mt-0.5">
              Mỗi câu trả lời đúng thí sinh được 0,5 điểm.
            </div>
          </div>

          <div className="space-y-6">
            {exam.part3.map((q) => {
              const userVal = answers.part3[q.id] || '';

              return (
                <div key={q.id} className="space-y-3 pt-2 border-b border-slate-100 pb-5">
                  <div className="text-sm font-semibold text-slate-900 leading-relaxed flex items-start gap-2">
                    <span className="text-teal-800 shrink-0 font-bold">
                      Câu {q.number}.
                    </span>
                    <div className="flex-1">
                      <MathTex content={q.stem} />
                    </div>
                  </div>

                  {q.diagram && (
                    <div className="py-2 flex justify-center">
                      <MathSvgFigure type={q.diagram.type} params={q.diagram.params} />
                    </div>
                  )}

                  {/* Input form */}
                  <div className="flex flex-wrap items-center gap-3 pt-1">
                    <span className="text-xs font-semibold text-slate-600">
                      Đáp số của bạn:
                    </span>
                    <input
                      type="text"
                      value={userVal}
                      onChange={(e) => handleShortAnswerChange(q.id, e.target.value)}
                      disabled={isSubmitted}
                      placeholder="Nhập số..."
                      className="px-3 py-1.5 rounded-lg border border-slate-300 font-mono text-sm max-w-[140px] focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />

                    {isSubmitted && (
                      <span className="text-xs font-semibold">
                        Đáp án chuẩn:{' '}
                        <span className="font-mono text-teal-800 bg-teal-50 px-2 py-0.5 rounded font-bold">
                          {q.correctAnswer}
                        </span>
                      </span>
                    )}
                  </div>

                  {showSolutions && (
                    <div className="p-3 bg-teal-50/40 rounded-xl border border-teal-200 text-xs text-slate-700 space-y-1">
                      <div className="font-bold text-teal-900">
                        Đáp số: {q.correctAnswer} · Lời giải:
                      </div>
                      <div className="whitespace-pre-line">
                        <MathTex content={q.solution} />
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* Paper End marker */}
        <div className="text-center pt-8 border-t border-slate-200 text-xs font-bold text-slate-400 uppercase tracking-widest">
          --------- HẾT ---------
          <div className="text-[11px] text-slate-400 font-normal lowercase mt-1">
            (Cán bộ coi thi không giải thích gì thêm)
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExamTab;
