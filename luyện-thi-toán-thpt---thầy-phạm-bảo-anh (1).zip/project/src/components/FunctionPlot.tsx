import React, { useId, useMemo } from 'react';

export interface PlotPoint {
  x: number;
  y: number;
  label?: string;
}

interface SlantAsymptote {
  a: number; // y = a*x + b
  b: number;
  label?: string;
}

interface FunctionPlotProps {
  f: (x: number) => number;
  xRange?: [number, number];
  yRange?: [number, number];
  vAsymptotes?: number[]; // tiệm cận đứng: x = v
  hAsymptotes?: number[]; // tiệm cận ngang: y = h
  slantAsymptotes?: SlantAsymptote[]; // tiệm cận xiên
  points?: PlotPoint[];
  width?: number;
  caption?: string;
  curveColor?: string;
}

const fmt = (n: number) => n.toFixed(2);

/** Format số hiển thị trên nhãn tiệm cận / điểm (ưu tiên số nguyên) */
const fmtLabel = (n: number): string => {
  const c = Math.abs(n) < 1e-9 ? 0 : n;
  if (Number.isInteger(c) || Math.abs(c - Math.round(c)) < 1e-6) return String(Math.round(c));
  const s = c.toFixed(2).replace(/\.?0+$/, '');
  return s;
};

/**
 * Vẽ đồ thị hàm số bằng SVG.
 * - Tự tách nhánh tại mỗi tiệm cận đứng (mỗi nhánh là một path "M" riêng, không nối nhau).
 * - Lấy mẫu dày, đặc biệt dày khi tiến sát tiệm cận đứng.
 * - Tỉ lệ hai trục bằng nhau (1 đơn vị Ox = 1 đơn vị Oy).
 * - Màu dùng currentColor nên hiển thị tốt ở cả chế độ sáng và tối.
 */
export default function FunctionPlot({
  f,
  xRange = [-4, 6],
  yRange = [-3, 7],
  vAsymptotes = [],
  hAsymptotes = [],
  slantAsymptotes = [],
  points = [],
  width = 420,
  caption,
  curveColor = '#0f766e',
}: FunctionPlotProps) {
  const uid = useId().replace(/:/g, '');
  const [x0, x1] = xRange;
  const [y0, y1] = yRange;
  const xs = x1 - x0;
  const ys = y1 - y0;
  const W = width;
  const H = Math.round((width * ys) / xs); // giữ tỉ lệ 1:1

  const sx = (x: number) => ((x - x0) / xs) * W;
  const sy = (y: number) => H - ((y - y0) / ys) * H;

  // Mỗi phần tử là một nhánh liên tục của đồ thị
  // Tách nhánh tại mỗi tiệm cận đứng; không nối điểm có |Δy| quá lớn (tránh đường "gãy")
  const branches = useMemo(() => {
    const vas = vAsymptotes
      .filter((v) => v > x0 && v < x1)
      .sort((a, b) => a - b);
    const cuts = [x0, ...vas, x1];
    // Cho phép đường cong vượt nhẹ khung rồi clipPath cắt — đủ để tiệm cận nhìn mượt
    const yPad = ys * 0.35;
    const yLo = y0 - yPad;
    const yHi = y1 + yPad;
    // Ngưỡng nhảy: nếu |Δy| lớn hơn ~1.2 khung → coi là đứt đoạn (không nối)
    const jumpThresh = ys * 1.2;
    const result: string[] = [];

    for (let i = 0; i < cuts.length - 1; i++) {
      const a = cuts[i];
      const b = cuts[i + 1];
      const aIsVA = i > 0;
      const bIsVA = i < cuts.length - 2;
      const span = b - a;
      if (span <= 1e-12) continue;

      // Lấy mẫu đều + dày dần về phía tiệm cận đứng
      const xsList: number[] = [];
      const N = 480;
      for (let k = 0; k <= N; k++) {
        xsList.push(a + (span * k) / N);
      }
      // Cluster gần tiệm cận (không vượt quá biên nhánh)
      for (let k = 0; k < 100; k++) {
        const d = Math.min(span * 0.45, 0.6 * Math.pow(0.88, k));
        if (d < 1e-8) break;
        if (aIsVA) xsList.push(a + d);
        if (bIsVA) xsList.push(b - d);
      }

      const pts = xsList
        .filter(
          (x) =>
            x >= a - 1e-12 &&
            x <= b + 1e-12 &&
            (aIsVA ? x > a + 1e-10 : true) &&
            (bIsVA ? x < b - 1e-10 : true)
        )
        .sort((p, q) => p - q);

      // Loại bỏ điểm trùng x gần nhau
      const unique: number[] = [];
      for (const x of pts) {
        if (unique.length === 0 || Math.abs(x - unique[unique.length - 1]) > 1e-9) {
          unique.push(x);
        }
      }

      let d = '';
      let prevY: number | null = null;
      for (const x of unique) {
        const rawY = f(x);
        if (!Number.isFinite(rawY)) {
          // Gặp điểm bất định → kết thúc nhánh hiện tại
          if (d) {
            result.push(d);
            d = '';
          }
          prevY = null;
          continue;
        }
        // Chỉ lấy điểm còn trong vùng hiển thị mở rộng (không kéo đường dọc mép khung)
        if (rawY < yLo || rawY > yHi) {
          // Vẫn thêm 1 điểm biên nếu đang trong nhánh để đường tiến sát tiệm cận
          if (prevY !== null && d) {
            const edgeY = rawY < yLo ? yLo : yHi;
            // Chỉ nối nếu không nhảy quá lớn so với điểm trước
            if (Math.abs(edgeY - prevY) <= jumpThresh) {
              d += `L${fmt(sx(x))} ${fmt(sy(edgeY))}`;
            }
            result.push(d);
            d = '';
          }
          prevY = null;
          continue;
        }

        if (prevY !== null && Math.abs(rawY - prevY) > jumpThresh) {
          // Nhảy lớn → bắt đầu path mới (tránh đường gãy ngang)
          if (d) result.push(d);
          d = `M${fmt(sx(x))} ${fmt(sy(rawY))}`;
        } else {
          d += `${d ? 'L' : 'M'}${fmt(sx(x))} ${fmt(sy(rawY))}`;
        }
        prevY = rawY;
      }
      if (d) result.push(d);
    }
    return result;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [f, x0, x1, y0, y1, W, H, vAsymptotes.join(',')]);

  const gridX: number[] = [];
  for (let i = Math.ceil(x0); i <= Math.floor(x1); i++) gridX.push(i);
  const gridY: number[] = [];
  for (let i = Math.ceil(y0); i <= Math.floor(y1); i++) gridY.push(i);

  const showTicks = xs <= 14 && ys <= 14;
  const axisX = y0 <= 0 && y1 >= 0 ? sy(0) : null;
  const axisY = x0 <= 0 && x1 >= 0 ? sx(0) : null;

  return (
    <figure style={{ margin: 0, textAlign: 'center' }}>
      <svg
        viewBox={`0 0 ${W} ${H}`}
        style={{ width: '100%', maxWidth: W, height: 'auto', color: 'inherit' }}
        role="img"
        aria-label={caption || 'Đồ thị hàm số'}
      >
        <defs>
          <clipPath id={`clip-${uid}`}>
            <rect x={0} y={0} width={W} height={H} />
          </clipPath>
          <marker
            id={`arrow-${uid}`}
            viewBox="0 0 10 10"
            refX="9"
            refY="5"
            markerWidth="7"
            markerHeight="7"
            orient="auto-start-reverse"
          >
            <path d="M0 0L10 5L0 10z" fill="currentColor" />
          </marker>
        </defs>

        {/* Lưới */}
        <g stroke="currentColor" strokeOpacity={0.12} strokeWidth={1}>
          {gridX.map((g) => (
            <line key={`gx${g}`} x1={sx(g)} y1={0} x2={sx(g)} y2={H} />
          ))}
          {gridY.map((g) => (
            <line key={`gy${g}`} x1={0} y1={sy(g)} x2={W} y2={sy(g)} />
          ))}
        </g>

        {/* Trục tọa độ */}
        {axisX !== null && (
          <line
            x1={0}
            y1={axisX}
            x2={W - 2}
            y2={axisX}
            stroke="currentColor"
            strokeWidth={1.5}
            markerEnd={`url(#arrow-${uid})`}
          />
        )}
        {axisY !== null && (
          <line
            x1={axisY}
            y1={H}
            x2={axisY}
            y2={2}
            stroke="currentColor"
            strokeWidth={1.5}
            markerEnd={`url(#arrow-${uid})`}
          />
        )}
        {axisX !== null && axisY !== null && (
          <g fontSize={13} fill="currentColor" fontStyle="italic">
            <text x={W - 14} y={axisX + 18}>x</text>
            <text x={axisY + 8} y={14}>y</text>
            <text x={axisY - 14} y={axisX + 16} fontStyle="normal">O</text>
          </g>
        )}
        {showTicks && axisX !== null && axisY !== null && (
          <g fontSize={10} fill="currentColor" fillOpacity={0.65}>
            {gridX
              .filter((g) => g !== 0)
              .map((g) => (
                <text key={`tx${g}`} x={sx(g)} y={axisX + 13} textAnchor="middle">
                  {g}
                </text>
              ))}
            {gridY
              .filter((g) => g !== 0)
              .map((g) => (
                <text key={`ty${g}`} x={axisY - 5} y={sy(g) + 3} textAnchor="end">
                  {g}
                </text>
              ))}
          </g>
        )}

        {/* Tiệm cận (nét đứt) — chỉ vẽ khi nằm trong khung nhìn */}
        <g strokeDasharray="6 4" strokeWidth={1.5} fill="none">
          {vAsymptotes
            .filter((v) => v >= x0 - 1e-9 && v <= x1 + 1e-9)
            .map((v) => (
              <g key={`va${v}`}>
                <line x1={sx(v)} y1={0} x2={sx(v)} y2={H} stroke="#dc2626" />
                <text x={sx(v) + 6} y={16} fontSize={12} fill="#dc2626" stroke="none">
                  {`TCĐ: x = ${fmtLabel(v)}`}
                </text>
              </g>
            ))}
          {hAsymptotes
            .filter((h) => h >= y0 - 1e-9 && h <= y1 + 1e-9)
            .map((h) => (
              <g key={`ha${h}`}>
                <line x1={0} y1={sy(h)} x2={W} y2={sy(h)} stroke="#2563eb" />
                <text
                  x={W - 6}
                  y={sy(h) - 6}
                  fontSize={12}
                  fill="#2563eb"
                  stroke="none"
                  textAnchor="end"
                >
                  {`TCN: y = ${fmtLabel(h)}`}
                </text>
              </g>
            ))}
          {slantAsymptotes.map((s, i) => (
            <g key={`sa${i}`}>
              <line
                x1={sx(x0)}
                y1={sy(s.a * x0 + s.b)}
                x2={sx(x1)}
                y2={sy(s.a * x1 + s.b)}
                stroke="#9333ea"
                clipPath={`url(#clip-${uid})`}
              />
              <text x={W - 6} y={16} fontSize={12} fill="#9333ea" stroke="none" textAnchor="end">
                {s.label ??
                  `TCX: y = ${fmtLabel(s.a)}x ${s.b >= 0 ? '+' : '−'} ${fmtLabel(Math.abs(s.b))}`}
              </text>
            </g>
          ))}
        </g>

        {/* Đường cong: mỗi nhánh một path riêng */}
        <g clipPath={`url(#clip-${uid})`}>
          {branches.map((d, i) => (
            <path
              key={i}
              d={d}
              fill="none"
              stroke={curveColor}
              strokeWidth={2.5}
              strokeLinejoin="round"
              strokeLinecap="round"
            />
          ))}
        </g>

        {/* Điểm đặc biệt, ví dụ tâm đối xứng */}
        {points.map((p, i) => (
          <g key={`pt${i}`}>
            <circle cx={sx(p.x)} cy={sy(p.y)} r={4} fill="currentColor" />
            {p.label && (
              <text x={sx(p.x) + 8} y={sy(p.y) + 16} fontSize={12} fill="currentColor">
                {p.label}
              </text>
            )}
          </g>
        ))}
      </svg>
      {caption && (
        <figcaption style={{ fontSize: 13, opacity: 0.7, marginTop: 8, fontStyle: 'italic' }}>
          {caption}
        </figcaption>
      )}
    </figure>
  );
}

export { FunctionPlot };
