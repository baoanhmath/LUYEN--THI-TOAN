import React, { useState, useMemo, useCallback, useRef } from 'react';
import {
  Play,
  Sliders,
  Maximize2,
  TrendingUp,
  TrendingDown,
  Minus,
  CheckCircle2,
  Layers,
  Sparkles,
  Settings2
} from 'lucide-react';
import { analyzeCubicFunction, sampleCubicCurve } from '../utils/graphEngine';

interface QuickJump {
  val: number;
  label: string;
  desc: string;
}

interface CubicPreset {
  a: number;
  b: number;
  c: number;
  d: number;
  name: string;
  desc: string;
  initialX0: number;
  quickJumps: QuickJump[];
}

const PRESET_FUNCTIONS: Record<string, CubicPreset> = {
  benchmark: {
    a: 1,
    b: 0,
    c: -27,
    d: 2,
    name: 'f(x) = x³ - 27x + 2',
    desc: 'Hàm kiểm thử trọng tâm: CĐ(-3; 56), CT(3; -52), U(0; 2)',
    initialX0: 0.0,
    quickJumps: [
      { val: -3.0, label: 'x₀ = -3', desc: 'Cực đại' },
      { val: -1.5, label: 'x₀ = -1.5', desc: 'Nghịch biến' },
      { val: 0.0, label: 'x₀ = 0', desc: 'Điểm uốn' },
      { val: 1.5, label: 'x₀ = 1.5', desc: 'Nghịch biến' },
      { val: 3.0, label: 'x₀ = 3', desc: 'Cực tiểu' }
    ]
  },
  std: {
    a: 1,
    b: 0,
    c: -3,
    d: 2,
    name: 'f(x) = x³ - 3x + 2',
    desc: 'Hàm chuẩn SGK: CĐ(-1; 4), CT(1; 0), U(0; 2)',
    initialX0: 0.6,
    quickJumps: [
      { val: -1.0, label: 'x₀ = -1', desc: 'Cực đại' },
      { val: -0.5, label: 'x₀ = -0.5', desc: 'Nghịch biến' },
      { val: 0.0, label: 'x₀ = 0', desc: 'Điểm uốn' },
      { val: 0.6, label: 'x₀ = 0.6', desc: 'Thử nghiệm' },
      { val: 1.0, label: 'x₀ = 1', desc: 'Cực tiểu' }
    ]
  },
  origin: {
    a: 1,
    b: 0,
    c: -3,
    d: 0,
    name: 'f(x) = x³ - 3x',
    desc: 'Đối xứng qua gốc O: CĐ(-1; 2), CT(1; -2), U(0; 0)',
    initialX0: 0.0,
    quickJumps: [
      { val: -1.0, label: 'x₀ = -1', desc: 'Cực đại' },
      { val: -0.5, label: 'x₀ = -0.5', desc: 'Nghịch biến' },
      { val: 0.0, label: 'x₀ = 0', desc: 'Gốc tọa độ' },
      { val: 0.5, label: 'x₀ = 0.5', desc: 'Nghịch biến' },
      { val: 1.0, label: 'x₀ = 1', desc: 'Cực tiểu' }
    ]
  },
  shifted: {
    a: 1,
    b: -3,
    c: 0,
    d: 2,
    name: 'f(x) = x³ - 3x² + 2',
    desc: 'Hàm lệch trục: CĐ(0; 2), CT(2; -2), U(1; 0)',
    initialX0: 1.0,
    quickJumps: [
      { val: 0.0, label: 'x₀ = 0', desc: 'Cực đại' },
      { val: 0.5, label: 'x₀ = 0.5', desc: 'Nghịch biến' },
      { val: 1.0, label: 'x₀ = 1', desc: 'Điểm uốn' },
      { val: 1.5, label: 'x₀ = 1.5', desc: 'Nghịch biến' },
      { val: 2.0, label: 'x₀ = 2', desc: 'Cực tiểu' }
    ]
  },
  negA: {
    a: -1,
    b: 0,
    c: 3,
    d: 2,
    name: 'f(x) = -x³ + 3x + 2',
    desc: 'Hệ số a < 0: CT(-1; 0), CĐ(1; 4), U(0; 2)',
    initialX0: 0.0,
    quickJumps: [
      { val: -1.0, label: 'x₀ = -1', desc: 'Cực tiểu' },
      { val: 0.0, label: 'x₀ = 0', desc: 'Điểm uốn' },
      { val: 0.5, label: 'x₀ = 0.5', desc: 'Đồng biến' },
      { val: 1.0, label: 'x₀ = 1', desc: 'Cực đại' },
      { val: 1.8, label: 'x₀ = 1.8', desc: 'Nghịch biến' }
    ]
  }
};

interface CubicGraphInteractiveProps {
  initialPreset?: 'benchmark' | 'std' | 'origin' | 'shifted' | 'negA';
  className?: string;
}

export const CubicGraphInteractive: React.FC<CubicGraphInteractiveProps> = ({
  initialPreset = 'benchmark',
  className = ''
}) => {
  const [activePresetKey, setActivePresetKey] = useState<string>(initialPreset);
  const [params, setParams] = useState<CubicPreset>(PRESET_FUNCTIONS[initialPreset] || PRESET_FUNCTIONS.benchmark);
  const [x0, setX0] = useState<number>(PRESET_FUNCTIONS[initialPreset]?.initialX0 ?? 0.0);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [showCustomSliders, setShowCustomSliders] = useState<boolean>(false);

  const svgRef = useRef<SVGSVGElement | null>(null);
  const rafRef = useRef<number | null>(null);

  const { a, b, c, d } = params;

  // Mathematical functions
  const f = useCallback((x: number) => a * x * x * x + b * x * x + c * x + d, [a, b, c, d]);
  const fPrime = useCallback((x: number) => 3 * a * x * x + 2 * b * x + c, [a, b, c]);

  // Viewport determination dynamically from calculus landmarks via graphEngine
  const analysis = useMemo(() => {
    return analyzeCubicFunction(a, b, c, d);
  }, [a, b, c, d]);

  const { viewport, hasExtrema, cd, ct, inflection, xTicks, yTicks } = analysis;
  const { xMin, xMax, yMin, yMax } = viewport;

  const width = 540;
  const height = 370;
  const padLeft = 48;
  const padRight = 28;
  const padTop = 26;
  const padBottom = 36;

  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  const mapX = useCallback(
    (x: number) => padLeft + ((x - xMin) / (xMax - xMin)) * plotW,
    [padLeft, xMin, xMax, plotW]
  );

  const mapY = useCallback(
    (y: number) => height - padBottom - ((y - yMin) / (yMax - yMin)) * plotH,
    [height, padBottom, yMin, yMax, plotH]
  );

  const unmapX = useCallback(
    (pixelX: number) => {
      const clampedPixel = Math.max(padLeft, Math.min(width - padRight, pixelX));
      return xMin + ((clampedPixel - padLeft) / plotW) * (xMax - xMin);
    },
    [padLeft, width, padRight, xMin, xMax, plotW]
  );

  // High-Density Smooth Mathematical Curve Path (600 points)
  const curvePath = useMemo(() => {
    return sampleCubicCurve(a, b, c, d, xMin, xMax, yMin, yMax, mapX, mapY, 600);
  }, [a, b, c, d, xMin, xMax, yMin, yMax, mapX, mapY]);

  // Values at current x0
  const y0 = useMemo(() => Math.round(f(x0) * 1000) / 1000, [f, x0]);
  const slope = useMemo(() => Math.round(fPrime(x0) * 1000) / 1000, [fPrime, x0]);
  const intercept = useMemo(() => Math.round((y0 - slope * x0) * 1000) / 1000, [y0, slope, x0]);

  // Tangent line bounded cleanly to plot rectangle
  const tangentLine = useMemo(() => {
    const pts: [number, number][] = [];

    // Intersections with bounding box [xMin, xMax] x [yMin, yMax]
    const yAtMinX = slope * xMin + intercept;
    if (yAtMinX >= yMin && yAtMinX <= yMax) {
      pts.push([xMin, yAtMinX]);
    }

    const yAtMaxX = slope * xMax + intercept;
    if (yAtMaxX >= yMin && yAtMaxX <= yMax) {
      pts.push([xMax, yAtMaxX]);
    }

    if (slope !== 0) {
      const xAtMinY = (yMin - intercept) / slope;
      if (xAtMinY >= xMin && xAtMinY <= xMax) {
        pts.push([xAtMinY, yMin]);
      }

      const xAtMaxY = (yMax - intercept) / slope;
      if (xAtMaxY >= xMin && xAtMaxY <= xMax) {
        pts.push([xAtMaxY, yMax]);
      }
    }

    // Deduplicate
    const unique: [number, number][] = [];
    pts.forEach(([px, py]) => {
      if (!unique.some(([ux, uy]) => Math.abs(ux - px) < 0.01 && Math.abs(uy - py) < 0.01)) {
        unique.push([px, py]);
      }
    });

    if (unique.length >= 2) {
      return {
        x1: mapX(unique[0][0]),
        y1: mapY(unique[0][1]),
        x2: mapX(unique[1][0]),
        y2: mapY(unique[1][1])
      };
    }

    // Fallback span around x0
    const span = (xMax - xMin) * 0.25;
    return {
      x1: mapX(Math.max(xMin, x0 - span)),
      y1: mapY(slope * Math.max(xMin, x0 - span) + intercept),
      x2: mapX(Math.min(xMax, x0 + span)),
      y2: mapY(slope * Math.min(xMax, x0 + span) + intercept)
    };
  }, [x0, slope, intercept, xMin, xMax, yMin, yMax, mapX, mapY]);

  // Tangent equation string
  const signIntercept = intercept >= 0 ? `+ ${intercept.toFixed(2)}` : `- ${Math.abs(intercept).toFixed(2)}`;
  const tangentEqStr =
    slope === 0
      ? `y = ${intercept.toFixed(2)}`
      : intercept === 0
      ? `y = ${slope.toFixed(2)}x`
      : `y = ${slope.toFixed(2)}x ${signIntercept}`;

  // Pixel coordinates for axes
  const oxY = Math.max(padTop, Math.min(height - padBottom, mapY(0)));
  const oyX = Math.max(padLeft, Math.min(width - padRight, mapX(0)));

  // Landmark pixel coordinates
  const pM = { x: mapX(x0), y: mapY(y0) };
  const pU = { x: mapX(inflection.x), y: mapY(inflection.y) };

  // Pointer drag handling for 60fps silky smooth interaction
  const handlePointerDown = (e: React.PointerEvent<SVGSVGElement>) => {
    setIsDragging(true);
    e.currentTarget.setPointerCapture(e.pointerId);
    handlePointerMove(e);
  };

  const handlePointerMove = (e: React.PointerEvent<SVGSVGElement>) => {
    if (!isDragging && e.buttons !== 1) return;
    if (!svgRef.current) return;

    const rect = svgRef.current.getBoundingClientRect();
    const clientX = e.clientX - rect.left;
    const scaleX = width / rect.width;
    const svgPixelX = clientX * scaleX;

    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    rafRef.current = requestAnimationFrame(() => {
      const newX0 = Math.max(xMin + 0.1, Math.min(xMax - 0.1, unmapX(svgPixelX)));
      setX0(Math.round(newX0 * 100) / 100);
    });
  };

  const handlePointerUp = (e: React.PointerEvent<SVGSVGElement>) => {
    setIsDragging(false);
    try {
      e.currentTarget.releasePointerCapture(e.pointerId);
    } catch {}
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
  };

  // Change preset function
  const handlePresetChange = (key: string) => {
    setActivePresetKey(key);
    const newPreset = PRESET_FUNCTIONS[key];
    setParams(newPreset);
    setX0(newPreset.initialX0);
  };

  // Monotonicity state at x0
  const isIncreasingAtX0 = slope > 0.001;
  const isDecreasingAtX0 = slope < -0.001;
  const isStationaryAtX0 = Math.abs(slope) <= 0.001;

  return (
    <div className={`bg-[#082230]/95 backdrop-blur-md rounded-2xl p-4 sm:p-5 border border-white/20 shadow-xl space-y-4 text-white ${className}`}>
      {/* Title & Preset Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/10 pb-3">
        <div className="flex items-center gap-2">
          <Play className="w-4 h-4 text-[#F4B942]" />
          <span className="font-bold text-sm text-teal-100">
            Khảo sát & Đồ thị Hàm số Bậc ba: f(x)
          </span>
          <button
            onClick={() => setShowCustomSliders(!showCustomSliders)}
            className="ml-2 text-xs bg-white/10 hover:bg-white/20 text-teal-300 px-2 py-0.5 rounded flex items-center gap-1 cursor-pointer transition-colors"
            title="Tùy chỉnh hệ số a, b, c, d"
          >
            <Settings2 className="w-3 h-3 text-[#F4B942]" />
            <span>Hệ số</span>
          </button>
        </div>

        {/* Function selector tabs */}
        <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
          {Object.entries(PRESET_FUNCTIONS).map(([key, p]) => (
            <button
              key={key}
              onClick={() => handlePresetChange(key)}
              className={`px-2.5 py-1 rounded text-[11px] font-mono font-bold transition-all cursor-pointer whitespace-nowrap ${
                activePresetKey === key
                  ? 'bg-[#F4B942] text-[#082230] shadow-xs ring-1 ring-white/30'
                  : 'bg-white/10 text-teal-200 hover:bg-white/20'
              }`}
            >
              {p.name.replace('f(x) = ', '')}
            </button>
          ))}
        </div>
      </div>

      {/* Optional Custom Coefficient Sliders */}
      {showCustomSliders && (
        <div className="bg-[#051722]/80 p-3 rounded-xl border border-white/10 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <div className="flex justify-between text-teal-300 font-mono">
              <span>a: {a}</span>
            </div>
            <input
              type="range"
              min="-3"
              max="3"
              step="1"
              value={a}
              onChange={(e) => {
                const val = parseInt(e.target.value) || 1;
                setParams((prev) => ({ ...prev, a: val === 0 ? 1 : val }));
              }}
              className="w-full accent-[#F4B942]"
            />
          </div>
          <div>
            <div className="flex justify-between text-teal-300 font-mono">
              <span>b: {b}</span>
            </div>
            <input
              type="range"
              min="-6"
              max="6"
              step="1"
              value={b}
              onChange={(e) => {
                setParams((prev) => ({ ...prev, b: parseInt(e.target.value) || 0 }));
              }}
              className="w-full accent-[#F4B942]"
            />
          </div>
          <div>
            <div className="flex justify-between text-teal-300 font-mono">
              <span>c: {c}</span>
            </div>
            <input
              type="range"
              min="-30"
              max="15"
              step="3"
              value={c}
              onChange={(e) => {
                setParams((prev) => ({ ...prev, c: parseInt(e.target.value) || 0 }));
              }}
              className="w-full accent-[#F4B942]"
            />
          </div>
          <div>
            <div className="flex justify-between text-teal-300 font-mono">
              <span>d: {d}</span>
            </div>
            <input
              type="range"
              min="-10"
              max="10"
              step="1"
              value={d}
              onChange={(e) => {
                setParams((prev) => ({ ...prev, d: parseInt(e.target.value) || 0 }));
              }}
              className="w-full accent-[#F4B942]"
            />
          </div>
        </div>
      )}

      {/* Active Function Description Badge */}
      <div className="flex items-center justify-between text-xs px-2 py-1 bg-white/5 rounded-lg border border-white/10">
        <span className="text-teal-200">
          <span className="font-bold text-[#F4B942] font-mono mr-2">{params.name}:</span>
          {params.desc}
        </span>
        <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">
          Miền hiển thị tự động: x ∈ [{xMin.toFixed(1)}; {xMax.toFixed(1)}], y ∈ [{yMin.toFixed(0)}; {yMax.toFixed(0)}]
        </span>
      </div>

      {/* SVG Canvas with Mathematical Precision & Hardware Acceleration */}
      <div className="bg-[#051722] rounded-xl p-2 border border-white/10 flex flex-col items-center overflow-hidden relative group">
        <div className="absolute top-3 left-3 z-10 text-[10px] text-teal-300 bg-black/60 backdrop-blur-xs px-2.5 py-1 rounded border border-white/10 select-none pointer-events-none flex items-center gap-1">
          <Maximize2 className="w-3 h-3 text-[#F4B942]" />
          <span>Kéo chuột/chạm trực tiếp trên đồ thị để trượt tiếp điểm M</span>
        </div>

        <svg
          ref={svgRef}
          viewBox={`0 0 ${width} ${height}`}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className="w-full max-w-[520px] h-auto select-none overflow-visible cursor-ew-resize touch-none"
        >
          <defs>
            <pattern id="grid-cubic" width="30" height="30" patternUnits="userSpaceOnUse">
              <path d="M 30 0 L 0 0 0 30" fill="none" stroke="#132B3C" strokeWidth="0.8" />
            </pattern>
            {/* Soft glow for function curve */}
            <filter id="curve-glow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="2" floodColor="#14B8A6" floodOpacity="0.4" />
            </filter>
            <clipPath id="interactive-plot-clip">
              <rect x={padLeft} y={padTop} width={plotW} height={plotH} />
            </clipPath>
          </defs>

          {/* Background grid */}
          <rect width={width} height={height} fill="url(#grid-cubic)" rx="8" />

          {/* Grid lines based on dynamic Nice Ticks */}
          {xTicks.map((t) => {
            if (t.value === 0) return null;
            const px = mapX(t.value);
            if (px < padLeft || px > width - padRight) return null;
            return (
              <line
                key={`gx-${t.value}`}
                x1={px}
                y1={padTop}
                x2={px}
                y2={height - padBottom}
                stroke="#1A3B52"
                strokeDasharray="2 3"
                strokeWidth="0.8"
              />
            );
          })}
          {yTicks.map((t) => {
            if (t.value === 0) return null;
            const py = mapY(t.value);
            if (py < padTop || py > height - padBottom) return null;
            return (
              <line
                key={`gy-${t.value}`}
                x1={padLeft}
                y1={py}
                x2={width - padRight}
                y2={py}
                stroke="#1A3B52"
                strokeDasharray="2 3"
                strokeWidth="0.8"
              />
            );
          })}

          {/* Axes: Ox (y = 0) */}
          <line
            x1={padLeft - 10}
            y1={oxY}
            x2={width - padRight + 12}
            y2={oxY}
            stroke="#94A3B8"
            strokeWidth="1.5"
          />
          <polygon
            points={`${width - padRight + 14},${oxY} ${width - padRight + 7},${oxY - 4} ${width - padRight + 7},${oxY + 4}`}
            fill="#94A3B8"
          />
          <text
            x={width - padRight + 16}
            y={oxY + 4}
            fill="#CBD5E1"
            fontSize="12"
            fontStyle="italic"
            fontWeight="bold"
          >
            x
          </text>

          {/* Axes: Oy (x = 0) */}
          <line
            x1={oyX}
            y1={height - padBottom + 10}
            x2={oyX}
            y2={padTop - 12}
            stroke="#94A3B8"
            strokeWidth="1.5"
          />
          <polygon
            points={`${oyX},${padTop - 14} ${oyX - 4},${padTop - 7} ${oyX + 4},${padTop - 7}`}
            fill="#94A3B8"
          />
          <text
            x={oyX - 4}
            y={padTop - 16}
            fill="#CBD5E1"
            fontSize="12"
            fontStyle="italic"
            fontWeight="bold"
          >
            y
          </text>
          <text x={oyX - 14} y={oxY + 14} fill="#64748B" fontSize="11" fontWeight="bold">
            O
          </text>

          {/* Axis number labels (Nice Ticks) */}
          {xTicks.map((t) => {
            if (t.value === 0) return null;
            const px = mapX(t.value);
            if (px < padLeft + 6 || px > width - padRight - 10) return null;
            return (
              <text
                key={`x-lbl-${t.value}`}
                x={px}
                y={oxY + 14}
                textAnchor="middle"
                fill="#64748B"
                fontSize="10"
              >
                {t.formatted}
              </text>
            );
          })}
          {yTicks.map((t) => {
            if (t.value === 0) return null;
            const py = mapY(t.value);
            if (py < padTop + 8 || py > height - padBottom - 6) return null;
            return (
              <text
                key={`y-lbl-${t.value}`}
                x={oyX - 8}
                y={py + 3}
                textAnchor="end"
                fill="#64748B"
                fontSize="10"
              >
                {t.formatted}
              </text>
            );
          })}

          {/* Dashed projections for Extreme Points */}
          {hasExtrema && cd && ct && (
            <>
              {/* Cực đại */}
              <line
                x1={mapX(cd.x)}
                y1={oxY}
                x2={mapX(cd.x)}
                y2={mapY(cd.y)}
                stroke="#EF4444"
                strokeDasharray="3 3"
                strokeWidth="1"
                opacity="0.8"
              />
              <line
                x1={oyX}
                y1={mapY(cd.y)}
                x2={mapX(cd.x)}
                y2={mapY(cd.y)}
                stroke="#EF4444"
                strokeDasharray="3 3"
                strokeWidth="1"
                opacity="0.8"
              />

              {/* Cực tiểu */}
              <line
                x1={mapX(ct.x)}
                y1={oxY}
                x2={mapX(ct.x)}
                y2={mapY(ct.y)}
                stroke="#38BDF8"
                strokeDasharray="3 3"
                strokeWidth="1"
                opacity="0.8"
              />
              <line
                x1={oyX}
                y1={mapY(ct.y)}
                x2={mapX(ct.x)}
                y2={mapY(ct.y)}
                stroke="#38BDF8"
                strokeDasharray="3 3"
                strokeWidth="1"
                opacity="0.8"
              />
            </>
          )}

          {/* Smooth Continuous Mathematical Curve & Tangent Line clipped to plot area */}
          <g clipPath="url(#interactive-plot-clip)">
            <path
              d={curvePath}
              fill="none"
              stroke="#14B8A6"
              strokeWidth="3.0"
              strokeLinecap="round"
              strokeLinejoin="round"
              filter="url(#curve-glow)"
              shapeRendering="geometricPrecision"
            />

            {/* Tangent line at (x0; y0) */}
            <line
              x1={tangentLine.x1}
              y1={tangentLine.y1}
              x2={tangentLine.x2}
              y2={tangentLine.y2}
              stroke="#F4B942"
              strokeWidth="2.4"
              strokeDasharray="6 3"
              shapeRendering="geometricPrecision"
            />
          </g>

          {/* Landmark Extremum 1: Cực đại */}
          {hasExtrema && cd && (
            <g>
              <circle
                cx={mapX(cd.x)}
                cy={mapY(cd.y)}
                r="4.2"
                fill="#EF4444"
                stroke="#FFFFFF"
                strokeWidth="1.2"
              />
              <text
                x={mapX(cd.x)}
                y={mapY(cd.y) - 8}
                fill="#EF4444"
                fontSize="10"
                fontWeight="bold"
                textAnchor="middle"
                filter="drop-shadow(0px 1px 2px rgba(0,0,0,0.9))"
              >
                CĐ({cd.x.toFixed(0)}; {cd.y.toFixed(0)})
              </text>
            </g>
          )}

          {/* Landmark Extremum 2: Cực tiểu */}
          {hasExtrema && ct && (
            <g>
              <circle
                cx={mapX(ct.x)}
                cy={mapY(ct.y)}
                r="4.2"
                fill="#38BDF8"
                stroke="#FFFFFF"
                strokeWidth="1.2"
              />
              <text
                x={mapX(ct.x)}
                y={mapY(ct.y) + 14}
                fill="#38BDF8"
                fontSize="10"
                fontWeight="bold"
                textAnchor="middle"
                filter="drop-shadow(0px 1px 2px rgba(0,0,0,0.9))"
              >
                CT({ct.x.toFixed(0)}; {ct.y.toFixed(0)})
              </text>
            </g>
          )}

          {/* Landmark Inflection Point: U */}
          {inflection && (
            <g>
              <circle
                cx={pU.x}
                cy={pU.y}
                r="3.5"
                fill="#A855F7"
                stroke="#FFFFFF"
                strokeWidth="1"
              />
              <text
                x={pU.x + 6}
                y={pU.y + 3}
                fill="#C084FC"
                fontSize="9"
                fontWeight="bold"
                filter="drop-shadow(0px 1px 2px rgba(0,0,0,0.9))"
              >
                U({inflection.x.toFixed(0)}; {inflection.y.toFixed(0)})
              </text>
            </g>
          )}

          {/* Interactive Tangent point M(x0; y0) */}
          <line
            x1={pM.x}
            y1={oxY}
            x2={pM.x}
            y2={pM.y}
            stroke="#F59E0B"
            strokeDasharray="2 2"
            strokeWidth="1.2"
            opacity="0.9"
          />
          <line
            x1={oyX}
            y1={pM.y}
            x2={pM.x}
            y2={pM.y}
            stroke="#F59E0B"
            strokeDasharray="2 2"
            strokeWidth="1.2"
            opacity="0.9"
          />

          {/* Large Interactive Touch/Hover Target */}
          <circle
            cx={pM.x}
            cy={pM.y}
            r="16"
            fill="transparent"
            className="cursor-ew-resize"
          />

          <circle
            cx={pM.x}
            cy={pM.y}
            r="6"
            fill="#F59E0B"
            stroke="#FFFFFF"
            strokeWidth="2.5"
            className="filter drop-shadow"
          />

          <text
            x={pM.x + 9}
            y={pM.y - 9}
            fill="#F4B942"
            fontSize="11"
            fontWeight="bold"
            filter="drop-shadow(0px 1px 3px rgba(0,0,0,0.95))"
          >
            M({x0.toFixed(2)}; {y0.toFixed(2)})
          </text>
        </svg>
      </div>

      {/* Preset quick-jump buttons and continuous hardware slider */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-teal-200">
          <span className="flex items-center gap-1">
            <Sliders className="w-3.5 h-3.5 text-[#F4B942]" />
            Chọn nhanh điểm tiếp xúc x₀:
          </span>
          <span className="font-mono font-bold text-white bg-white/10 px-2 py-0.5 rounded">
            x₀ = {x0.toFixed(2)}
          </span>
        </div>

        <div className="grid grid-cols-5 gap-1.5 text-xs">
          {params.quickJumps.map((item) => (
            <button
              key={item.val}
              onClick={() => setX0(item.val)}
              className={`p-1.5 rounded-lg border text-center transition-all cursor-pointer ${
                Math.abs(x0 - item.val) < 0.04
                  ? 'bg-[#F4B942] text-[#0B2A3C] border-[#F4B942] font-bold shadow-xs'
                  : 'bg-white/5 text-slate-200 border-white/15 hover:bg-white/10'
              }`}
            >
              <div className="font-bold text-[11px]">{item.label}</div>
              <div className="text-[9px] opacity-80">{item.desc}</div>
            </button>
          ))}
        </div>

        {/* Continuous Slider */}
        <div className="pt-1">
          <input
            type="range"
            min={xMin + 0.1}
            max={xMax - 0.1}
            step={(xMax - xMin) / 250}
            value={x0}
            onChange={(e) => setX0(parseFloat(e.target.value))}
            className="w-full accent-[#F4B942] cursor-pointer h-2 bg-slate-700 rounded-lg appearance-none"
          />
        </div>
      </div>

      {/* Synchronized Mathematical Analysis Display */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs bg-black/35 p-3 rounded-xl border border-white/10">
        <div className="space-y-1">
          <div className="text-teal-300">
            Tọa độ tiếp điểm: <span className="font-mono text-white font-bold">M({x0.toFixed(2)}; {y0.toFixed(2)})</span>
          </div>
          <div className="text-teal-300 flex items-center gap-1">
            <span>Hệ số góc tiếp tuyến:</span>
            <span className="font-mono text-[#F4B942] font-bold">
              k = f'({x0.toFixed(2)}) = {slope.toFixed(2)}
            </span>
          </div>
          <div className="text-slate-300 flex items-center gap-1 pt-0.5">
            <span>Trạng thái:</span>
            {isIncreasingAtX0 ? (
              <span className="text-emerald-400 font-bold flex items-center gap-0.5">
                <TrendingUp className="w-3.5 h-3.5" /> Đồng biến (k &gt; 0)
              </span>
            ) : isDecreasingAtX0 ? (
              <span className="text-rose-400 font-bold flex items-center gap-0.5">
                <TrendingDown className="w-3.5 h-3.5" /> Nghịch biến (k &lt; 0)
              </span>
            ) : (
              <span className="text-amber-400 font-bold flex items-center gap-0.5">
                <Minus className="w-3.5 h-3.5" /> Tiếp tuyến ngang (k = 0)
              </span>
            )}
          </div>
        </div>

        <div className="space-y-1 sm:text-right">
          <div className="text-slate-300">
            Phương trình tiếp tuyến tại M:
          </div>
          <div className="font-mono font-bold text-[#F4B942] text-sm">
            {tangentEqStr}
          </div>
          {hasExtrema && cd && ct && (
            <div className="text-[11px] text-teal-200/90 pt-0.5">
              Cực đại: ({cd.x.toFixed(0)}; {cd.y.toFixed(0)}) · Cực tiểu: ({ct.x.toFixed(0)}; {ct.y.toFixed(0)})
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CubicGraphInteractive;
