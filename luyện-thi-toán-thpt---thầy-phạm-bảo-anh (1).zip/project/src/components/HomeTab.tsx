import React, { useState, useMemo } from 'react';
import {
  GraduationCap,
  Sparkles,
  BookCheck,
  Compass,
  Award,
  RefreshCw,
  Mail,
  Phone,
  HelpCircle,
  Lightbulb,
  CheckCircle2,
  XCircle,
  ChevronRight
} from 'lucide-react';
import { HeroBanner } from './HeroBanner';
import { MathTex } from './MathTex';
import { MathSvgFigure } from './MathSvgFigures';
import { StudentProgressChart } from './StudentProgressChart';
import { TOPIC_GENERATORS } from '../data/questionGenerators';
import { normalizeQuestionContent } from '../utils/mathNormalize';
import { TabKey } from './Navbar';

interface HomeTabProps {
  onNavigate: (tab: TabKey) => void;
  onOpenAskModal: () => void;
}

export const HomeTab: React.FC<HomeTabProps> = ({ onNavigate, onOpenAskModal }) => {
  // Quick dynamic problem drill
  const [drillTopic, setDrillTopic] = useState<string>('12-1');
  const [currentQuestion, setCurrentQuestion] = useState(() =>
    normalizeQuestionContent(TOPIC_GENERATORS['12-1'].generate())
  );
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showSolution, setShowSolution] = useState<boolean>(false);
  const [isAnswerChecked, setIsAnswerChecked] = useState<boolean>(false);

  const handleGenerateNew = (topicKey: string = drillTopic) => {
    setDrillTopic(topicKey);
    setCurrentQuestion(normalizeQuestionContent(TOPIC_GENERATORS[topicKey].generate()));
    setSelectedOption(null);
    setShowSolution(false);
    setIsAnswerChecked(false);
  };

  const handleSelectOption = (opt: string) => {
    if (isAnswerChecked) return;
    setSelectedOption(opt);
  };

  const handleCheckAnswer = () => {
    if (!selectedOption) return;
    setIsAnswerChecked(true);
  };

  const isCorrect = selectedOption === currentQuestion.correctOption;

  const currentOptions = useMemo(() => {
    const list = [currentQuestion.correctOption, ...currentQuestion.distractors];
    return Array.from(new Set(list)).sort();
  }, [currentQuestion]);

  return (
    <div className="space-y-10">
      {/* 1. Hero Banner */}
      <HeroBanner onNavigate={onNavigate} />

      {/* 2. Highlights / Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div
          onClick={() => onNavigate('exam')}
          className="group p-5 bg-white rounded-xl border border-slate-200/80 hover:border-teal-500/50 hover:shadow-md transition-all cursor-pointer space-y-2.5"
        >
          <div className="w-10 h-10 rounded-lg bg-teal-50 text-teal-700 flex items-center justify-center group-hover:scale-105 transition-transform">
            <BookCheck className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-800 text-base group-hover:text-teal-700 transition-colors">
            Đề thi Chuẩn 2025
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Mô phỏng trọn vẹn cấu trúc thi Tốt nghiệp THPT 2025: 12 trắc nghiệm, 4 đúng/sai và 6 trả lời ngắn. Tự động chấm điểm.
          </p>
          <div className="pt-1 flex items-center gap-1 text-xs font-semibold text-teal-700">
            <span>Làm bài ngay</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        <div
          onClick={() => onNavigate('g12')}
          className="group p-5 bg-white rounded-xl border border-slate-200/80 hover:border-teal-500/50 hover:shadow-md transition-all cursor-pointer space-y-2.5"
        >
          <div className="w-10 h-10 rounded-lg bg-blue-50 text-blue-700 flex items-center justify-center group-hover:scale-105 transition-transform">
            <GraduationCap className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-800 text-base group-hover:text-blue-700 transition-colors">
            Khóa Toán 10 - 11 - 12
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Hệ thống hóa toàn bộ lý thuyết, công thức trọng tâm và các dạng bài tập theo chương trình GDPT 2018 mới nhất.
          </p>
          <div className="pt-1 flex items-center gap-1 text-xs font-semibold text-blue-700">
            <span>Khám phá bài học</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        <div
          onClick={() => onNavigate('tt')}
          className="group p-5 bg-white rounded-xl border border-slate-200/80 hover:border-teal-500/50 hover:shadow-md transition-all cursor-pointer space-y-2.5"
        >
          <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-700 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Compass className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-800 text-base group-hover:text-amber-700 transition-colors">
            Toán ứng dụng thực tiễn
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Tuyển chọn các bài toán tối ưu chi phí, vòm cầu Parabol, lãi kép, mô hình vệ tinh GPS bám sát đề thi Bộ GD&ĐT.
          </p>
          <div className="pt-1 flex items-center gap-1 text-xs font-semibold text-amber-700">
            <span>Xem bài toán</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>

        <div
          onClick={() => onNavigate('week')}
          className="group p-5 bg-white rounded-xl border border-slate-200/80 hover:border-teal-500/50 hover:shadow-md transition-all cursor-pointer space-y-2.5"
        >
          <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:scale-105 transition-transform">
            <Award className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-slate-800 text-base group-hover:text-emerald-700 transition-colors">
            Bài toán tuần & Vinh danh
          </h3>
          <p className="text-xs text-slate-600 leading-relaxed">
            Thử thách toán học hàng tuần với các bài toán vận dụng cao, bảng xếp hạng thủ khoa và nhận sách giải chi tiết.
          </p>
          <div className="pt-1 flex items-center gap-1 text-xs font-semibold text-emerald-700">
            <span>Tham gia thử thách</span>
            <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </div>
        </div>
      </div>

      {/* 3. Recharts: Student Learning Progress & Exam Analytics */}
      <StudentProgressChart onNavigateToExam={() => onNavigate('exam')} />

      {/* 4. Interactive Quick Practice Drill Box */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-6 sm:p-8 shadow-xs space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-teal-700 mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              Rèn luyện phản xạ nhanh
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              Thực hành giải bài tập tự động sinh số
            </h2>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={drillTopic}
              onChange={(e) => handleGenerateNew(e.target.value)}
              className="text-xs font-semibold px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-slate-700 focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
              <option value="12-1">Toán 12: Đơn điệu hàm bậc ba</option>
              <option value="12-2">Toán 12: Tiệm cận hàm phân thức</option>
              <option value="12-6">Toán 12: Vectơ & Tọa độ Oxyz</option>
              <option value="12-11">Toán 12: Tích phân xác định</option>
              <option value="12-14">Toán 12: Phương trình mặt cầu Oxyz</option>
              <option value="12-18">Toán 12: Xác suất y khoa Bayes</option>
              <option value="11-1">Toán 11: Góc nhân đôi lượng giác</option>
              <option value="11-6">Toán 11: Cấp số cộng</option>
              <option value="10-1">Toán 10: Phủ định mệnh đề</option>
              <option value="10-2">Toán 10: Giao hợp khoảng đoạn</option>
            </select>

            <button
              onClick={() => handleGenerateNew()}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-teal-50 hover:bg-teal-100 text-teal-800 rounded-lg text-xs font-bold transition-colors cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Sinh bài mới</span>
            </button>
          </div>
        </div>

        {/* Problem Stem & Diagram */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className={`${currentQuestion.diagram ? 'lg:col-span-7' : 'lg:col-span-12'} space-y-4`}>
            <div className="p-4 bg-slate-50/80 rounded-xl border border-slate-200/60 space-y-2">
              <div className="text-xs font-semibold text-slate-500 uppercase tracking-wide">
                Đề bài ({currentQuestion.topicTitle}):
              </div>
              <div className="text-base text-slate-800 leading-relaxed font-medium">
                <MathTex content={currentQuestion.context} />
              </div>
              <div className="text-base font-semibold text-slate-900 pt-1">
                <MathTex content={currentQuestion.ask} />
              </div>
            </div>

            {/* MCQ Options */}
            <div className="space-y-2.5">
              <div className="text-xs font-semibold text-slate-500">Chọn 1 phương án đúng:</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {currentOptions.map((opt, idx) => {
                  const label = ['A', 'B', 'C', 'D'][idx];
                  const isSelected = selectedOption === opt;
                  let borderStyle = 'border-slate-200 bg-white hover:border-slate-300';

                  if (isAnswerChecked) {
                    if (opt === currentQuestion.correctOption) {
                      borderStyle = 'border-emerald-500 bg-emerald-50/60 text-emerald-900 font-semibold';
                    } else if (isSelected) {
                      borderStyle = 'border-rose-400 bg-rose-50/60 text-rose-900';
                    }
                  } else if (isSelected) {
                    borderStyle = 'border-teal-600 bg-teal-50/60 text-teal-900';
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleSelectOption(opt)}
                      disabled={isAnswerChecked}
                      className={`flex items-start gap-3 p-3 rounded-xl border text-left text-sm transition-all cursor-pointer ${borderStyle}`}
                    >
                      <span className="w-6 h-6 rounded-md bg-slate-100 flex items-center justify-center font-bold text-xs text-slate-700 shrink-0">
                        {label}
                      </span>
                      <span className="pt-0.5 leading-snug">
                        <MathTex content={opt} />
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Check Button & Feedback */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              {!isAnswerChecked ? (
                <button
                  onClick={handleCheckAnswer}
                  disabled={!selectedOption}
                  className="px-5 py-2.5 rounded-xl bg-teal-700 hover:bg-teal-800 disabled:opacity-40 disabled:cursor-not-allowed text-white text-sm font-bold shadow-xs transition-colors cursor-pointer"
                >
                  Kiểm tra đáp án
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  {isCorrect ? (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-100 text-emerald-800 font-bold text-sm">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      Chính xác! Xuất sắc!
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-100 text-rose-800 font-bold text-sm">
                      <XCircle className="w-4 h-4 text-rose-600" />
                      Chưa chính xác! Xem lời giải bên dưới.
                    </span>
                  )}

                  <button
                    onClick={() => setShowSolution(!showSolution)}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-sm font-semibold transition-colors cursor-pointer"
                  >
                    <Lightbulb className="w-4 h-4 text-amber-600" />
                    <span>{showSolution ? 'Ẩn lời giải' : 'Xem lời giải chi tiết'}</span>
                  </button>

                  <button
                    onClick={() => handleGenerateNew()}
                    className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-teal-50 hover:bg-teal-100 text-teal-800 text-sm font-semibold transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>Bài tiếp theo</span>
                  </button>
                </div>
              )}
            </div>

            {/* Step-by-step Solution Box */}
            {showSolution && (
              <div className="p-4 bg-teal-50/50 rounded-xl border border-teal-200 space-y-2 animate-fadeIn">
                <div className="flex items-center gap-1.5 text-xs font-bold text-teal-900 uppercase">
                  <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
                  Hướng dẫn giải chi tiết từng bước:
                </div>
                <div className="text-sm text-slate-800 leading-relaxed space-y-2 whitespace-pre-line">
                  <MathTex content={currentQuestion.solution} />
                </div>
              </div>
            )}
          </div>

          {/* Diagram column if exists */}
          {currentQuestion.diagram && (
            <div className="lg:col-span-5 flex flex-col items-center">
              <MathSvgFigure
                type={currentQuestion.diagram.type}
                params={currentQuestion.diagram.params}
                caption="Hình vẽ minh họa dạng toán"
              />
            </div>
          )}
        </div>
      </div>

      {/* 4. Teacher Profile Card: Thầy Phạm Bảo Anh */}
      <div className="rounded-2xl bg-gradient-to-r from-[#0B2A3C] to-[#0B5563] text-white p-6 sm:p-8 shadow-md border border-teal-800/50">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6">
          {/* Avatar badge */}
          <div className="w-20 h-20 rounded-2xl bg-white text-[#0B5563] flex items-center justify-center font-black text-2xl shadow-lg shrink-0 border-2 border-[#F4B942]">
            PBA
          </div>

          {/* Info */}
          <div className="space-y-3 flex-1 text-center sm:text-left">
            <div>
              <div className="text-xs uppercase tracking-wider text-[#F4B942] font-bold">
                Giáo viên phụ trách chuyên môn
              </div>
              <h3 className="text-2xl font-extrabold text-white">Thầy Phạm Bảo Anh</h3>
              <p className="text-sm text-teal-100 mt-1">
                Giáo viên Toán THPT · Chuyên gia Luyện thi Tốt nghiệp THPT Quốc Gia
              </p>
            </div>

            <p className="text-xs sm:text-sm text-slate-200 max-w-2xl leading-relaxed">
              &ldquo;Phương châm giảng dạy: Vững bản chất hình học và giải tích, tối ưu hóa tốc độ làm bài với cấu trúc đề thi 2025. Hỗ trợ giải đáp tận tình mọi thắc mắc của học sinh trong quá trình ôn luyện.&rdquo;
            </p>

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 pt-1 text-xs text-teal-200">
              <span className="inline-flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-[#F4B942]" />
                <a href="mailto:baoanh.math@gmail.com" className="hover:underline text-white font-medium">
                  baoanh.math@gmail.com
                </a>
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-[#F4B942]" />
                <span className="text-white font-medium">0988 567 890</span>
              </span>
            </div>
          </div>

          {/* CTA on Teacher Card */}
          <div className="shrink-0 pt-2 sm:pt-0">
            <button
              onClick={onOpenAskModal}
              className="px-4 py-2.5 rounded-xl bg-[#F4B942] hover:bg-[#FFCB5C] text-[#0B2A3C] font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer"
            >
              Nhắn tin hỏi thầy
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomeTab;
