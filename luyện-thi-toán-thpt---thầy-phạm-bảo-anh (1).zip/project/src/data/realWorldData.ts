export interface RealWorldProblem {
  id: string;
  title: string;
  category: 'Kinh tế & Tối ưu' | 'Kĩ thuật & Hình học' | 'Vật lí & Quỹ đạo' | 'Đời sống & Sinh học';
  summary: string;
  context: string;
  question: string;
  steps: {
    title: string;
    description: string;
    formula?: string;
  }[];
  finalAnswer: string;
  diagramType?: string;
  defaultParams?: Record<string, number>;
  paramLabels?: Record<string, string>;
  calculateResult?: (params: Record<string, number>) => { value: string; explanation: string };
}

export const REAL_WORLD_PROBLEMS: RealWorldProblem[] = [
  {
    id: 'rw-box',
    title: 'Tối ưu hóa hộp không nắp từ tấm tôn hình vuông',
    category: 'Kinh tế & Tối ưu',
    summary: 'Bài toán kinh điển ứng dụng đạo hàm tìm thể tích cực đại khi cắt bốn góc tấm tôn.',
    context: 'Một xưởng cơ khí cần làm một thùng chứa hình hộp chữ nhật không nắp từ một tấm tôn hình vuông cạnh $a = 60\\text{ cm}$. Người thợ cắt bỏ ở bốn góc bốn hình vuông bằng nhau có cạnh là $x\\text{ cm}$ rồi gập mép lại hàn thành hộp.',
    question: 'Hãy tìm kích thước cạnh cắt $x$ để thùng tạo thành có thể tích $V$ lớn nhất, và tính thể tích lớn nhất đó.',
    steps: [
      {
        title: 'Bước 1: Xác định biến số và điều kiện',
        description: 'Gọi $x\\text{ (cm)}$ là độ dài cạnh của hình vuông bị cắt ở mỗi góc. Vì tấm tôn cạnh $60\\text{ cm}$ và cắt 2 đầu nên điều kiện là:',
        formula: '0 < x < \\frac{60}{2} = 30'
      },
      {
        title: 'Bước 2: Thiết lập hàm thể tích mục tiêu',
        description: 'Đáy của thùng là hình vuông có cạnh là $60 - 2x\\text{ (cm)}$, chiều cao của thùng là $x\\text{ (cm)}$. Thể tích thùng là:',
        formula: 'V(x) = x(60 - 2x)^2 = 4x(30 - x)^2 = 4x^3 - 240x^2 + 3600x'
      },
      {
        title: 'Bước 3: Lấy đạo hàm tìm điểm cực trị',
        description: 'Đạo hàm của $V(x)$ theo $x$ là:',
        formula: 'V\'(x) = 12x^2 - 480x + 3600 = 12(x^2 - 40x + 300) = 12(x - 10)(x - 30)'
      },
      {
        title: 'Bước 4: Khảo sát và kết luận',
        description: 'Trên khoảng $(0; 30)$, nghiệm duy nhất của $V\'(x) = 0$ là $x = 10\\text{ cm}$. Đạo hàm đổi dấu từ dương sang âm khi qua $x = 10$, vậy hàm số đạt cực đại tại $x = 10\\text{ cm}$.',
        formula: 'V_{\\max} = V(10) = 10 \\cdot (60 - 20)^2 = 16\\,000\\text{ cm}^3 = 16\\text{ lít}'
      }
    ],
    finalAnswer: '$x = 10\\text{ cm}$ và thể tích cực đại $V_{\\max} = 16\\,000\\text{ cm}^3$ (16 lít)',
    diagramType: 'appliedMaxMin',
    defaultParams: { a: 60 },
    paramLabels: { a: 'Độ dài cạnh tấm tôn (cm)' },
    calculateResult: (params) => {
      const a = params.a || 60;
      const x = Math.round((a / 6) * 100) / 100;
      const V = Math.round(x * Math.pow(a - 2 * x, 2));
      return {
        value: `x = ${x} cm, V_max = ${V.toLocaleString('vi-VN')} cm³`,
        explanation: `Theo công thức tổng quát $x = a / 6 = ${a} / 6 = ${x} \\text{ cm}$. Thể tích đạt được là $V = ${V.toLocaleString('vi-VN')} \\text{ cm}^3$.`
      };
    }
  },
  {
    id: 'rw-parabol-tunnel',
    title: 'Độ cao an toàn của xe tải khi đi qua hầm vòm Parabol',
    category: 'Kĩ thuật & Hình học',
    summary: 'Ứng dụng phương trình Parabol vào thiết kế cầu vòm giao thông và trần hầm xe cơ giới.',
    context: 'Một cổng hầm có mặt cắt là một đường Parabol với chiều rộng mặt đường $AB = 8\\text{ m}$ và chiều cao đỉnh vòm so với mặt đường là $h = 6\\text{ m}$. Một chiếc xe tải chở hàng có chiều rộng $w = 3\\text{ m}$ muốn đi qua hầm sao cho xe đi chính giữa tim đường.',
    question: 'Xác định chiều cao tối đa của thùng xe tải để xe có thể đi qua hầm mà trần xe vẫn cách vòm hầm ít nhất $0{,}5\\text{ m}$ an toàn.',
    steps: [
      {
        title: 'Bước 1: Chọn hệ trục tọa độ thích hợp',
        description: 'Chọn hệ trục tọa độ $Oxy$ sao cho gốc $O$ là trung điểm đáy $AB$, trục tung $Oy$ đi qua đỉnh vòm $I(0; 6)$. Hai mút đáy nằm tại $A(-4; 0)$ và $B(4; 0)$.',
        formula: '(P): y = -ax^2 + 6'
      },
      {
        title: 'Bước 2: Tìm phương trình Parabol',
        description: 'Vì Parabol đi qua điểm $B(4; 0)$, ta thay tọa độ vào phương trình:',
        formula: '0 = -a(4^2) + 6 \\Rightarrow 16a = 6 \\Rightarrow a = \\frac{3}{8} = 0{,}375 \\Rightarrow y = -\\frac{3}{8}x^2 + 6'
      },
      {
        title: 'Bước 3: Tính chiều cao vòm tại mép thùng xe',
        description: 'Chiếc xe rộng $3\\text{ m}$ đi giữa tim đường nên hai mép xe có hoành độ $x = \\pm 1{,}5\\text{ m}$. Độ cao vòm hầm tại vị trí mép xe là:',
        formula: 'y(1{,}5) = -\\frac{3}{8}(1{,}5)^2 + 6 = -0{,}375 \\times 2{,}25 + 6 = 5{,}15625\\text{ m}'
      },
      {
        title: 'Bước 4: Trừ khoảng cách an toàn',
        description: 'Để đảm bảo khoảng cách an toàn tối thiểu $0{,}5\\text{ m}$, chiều cao tối đa của xe là:',
        formula: 'H_{\\max} = 5{,}15625 - 0{,}5 = 4{,}65625\\text{ m} \\approx 4{,}65\\text{ m}'
      }
    ],
    finalAnswer: 'Chiều cao tối đa của xe tải là khoảng $4{,}65\\text{ m}$',
    diagramType: 'quadratic'
  },
  {
    id: 'rw-interest',
    title: 'Quy hoạch tài chính: Lãi kép và thời gian nhân đôi tài sản (Quy tắc 72)',
    category: 'Kinh tế & Tối ưu',
    summary: 'Ứng dụng hàm số mũ và phương trình lôgarit trong ngân hàng và đầu tư sinh lời.',
    context: 'Một gia đình gửi tiết kiệm vào ngân hàng số tiền gốc $P = 200\\text{ triệu đồng}$ với lãi suất $r = 6{,}5\\%/\\text{năm}$, tiền lãi được nhập gốc hàng năm (lãi kép liên tục).',
    question: 'Sau bao nhiêu năm thì số tiền trong tài khoản của gia đình sẽ tăng gấp đôi (đạt 400 triệu đồng)?',
    steps: [
      {
        title: 'Bước 1: Công thức lãi kép hàng năm',
        description: 'Số tiền tích lũy sau $n$ năm với lãi suất kép $r$ là:',
        formula: 'A_n = P(1 + r)^n'
      },
      {
        title: 'Bước 2: Thiết lập phương trình lôgarit',
        description: 'Để tài sản nhân đôi, ta cần $A_n = 2P \\Leftrightarrow (1 + r)^n = 2$:',
        formula: '(1 + 0{,}065)^n = 2 \\Leftrightarrow 1{,}065^n = 2'
      },
      {
        title: 'Bước 3: Lấy lôgarit hai vế',
        description: 'Áp dụng công thức lôgarit tự nhiên hoặc lôgarit cơ số 10:',
        formula: 'n = \\log_{1{,}065} 2 = \\frac{\\ln 2}{\\ln 1{,}065} \\approx \\frac{0{,}6931}{0{,}0630} \\approx 11\\text{ năm}'
      }
    ],
    finalAnswer: 'Cần khoảng $11$ năm (chính xác $11{,}01$ năm) để số tiền tăng gấp đôi.',
    defaultParams: { P: 200, r: 6.5 },
    paramLabels: { P: 'Số tiền gửi ban đầu (triệu)', r: 'Lãi suất hàng năm (%)' },
    calculateResult: (params) => {
      const r = (params.r || 6.5) / 100;
      const years = Math.round((Math.log(2) / Math.log(1 + r)) * 10) / 10;
      return {
        value: `Sau khoảng ${years} năm`,
        explanation: `Công thức n = ln(2) / ln(1 + ${r}) = ${years} năm.`
      };
    }
  },
  {
    id: 'rw-gps',
    title: 'Hệ thống vệ tinh định vị toàn cầu GPS trong không gian Oxyz',
    category: 'Kĩ thuật & Hình học',
    summary: 'Mô hình giao của ba mặt cầu định vị vị trí máy bay hoặc điện thoại thông minh trên Trái Đất.',
    context: 'Một thiết bị bay không người lái (drone) nhận tín hiệu từ 3 trạm phát sóng mặt đất tại các tọa độ $A(0; 0; 0)$, $B(4; 0; 0)$, $C(0; 6; 0)$ (đơn vị: km). Khoảng cách đo được từ drone tới trạm $A$ là $5\\text{ km}$, tới trạm $B$ là $5\\text{ km}$, và drone đang bay ở độ cao $z > 0$.',
    question: 'Hãy xác định tọa độ không gian $(x; y; z)$ và độ cao của drone.',
    steps: [
      {
        title: 'Bước 1: Viết phương trình các mặt cầu khoảng cách',
        description: 'Gọi tọa độ của drone là $M(x; y; z)$. Khoảng cách $MA = 5$ và $MB = 5$ tương ứng với hai mặt cầu:',
        formula: 'x^2 + y^2 + z^2 = 25 \\quad (1)'
      },
      {
        title: 'Bước 2: Khoảng cách tới trạm B',
        description: 'Trạm $B(4; 0; 0)$ có phương trình:',
        formula: '(x - 4)^2 + y^2 + z^2 = 25 \\quad (2)'
      },
      {
        title: 'Bước 3: Giải hệ phương trình',
        description: 'Lấy (1) trừ (2) ta được $x^2 - (x - 4)^2 = 0 \\Leftrightarrow 8x - 16 = 0 \\Rightarrow x = 2\\text{ km}$. Thay vào (1) với điểm nằm trên đường nối:',
        formula: '2^2 + 0^2 + z^2 = 25 \\Rightarrow z^2 = 21 \\Rightarrow z = \\sqrt{21} \\approx 4{,}58\\text{ km}'
      }
    ],
    finalAnswer: 'Tọa độ drone là $(2; 0; \\sqrt{21})$, độ cao bay là khoảng $4{,}58\\text{ km}$',
    diagramType: 'box'
  }
];
