import { Chapter, Grade, Lesson } from '../types/math';

/**
 * Chương trình Toán THPT (CT 2018) — Lớp 10, 11, 12
 * Bao gồm: các chương chính, bài học, hoạt động trải nghiệm, chuyên đề
 */

function L(
  id: string,
  title: string,
  grade: Grade,
  chapterIndex: number,
  chapterTitle: string,
  theoryHtml: string,
  formulas: string[] = [],
  keyNotes: string[] = [],
  diagramType?: Lesson['diagramType'],
  diagramParams?: Record<string, any>
): Lesson {
  return {
    id,
    title,
    grade,
    chapterIndex,
    chapterTitle,
    theoryHtml,
    formulas,
    keyNotes,
    ...(diagramType ? { diagramType } : {}),
    ...(diagramParams ? { diagramParams } : {})
  };
}

export const CURRICULUM: Record<Grade, Chapter[]> = {
  // =====================================================================
  // LỚP 10
  // =====================================================================
  10: [
    {
      title: 'Chương I. Mệnh đề và tập hợp',
      grade: 10,
      lessons: [
        L(
          '10-1',
          'Bài 1. Mệnh đề',
          10,
          0,
          'Chương I. Mệnh đề và tập hợp',
          `<p>Mệnh đề là một khẳng định đúng hoặc sai. Không có mệnh đề vừa đúng vừa sai.</p>
           <p>Phủ định của mệnh đề $P$ ký hiệu $\\overline{P}$. Mệnh đề kéo theo $P \\Rightarrow Q$ sai khi và chỉ khi $P$ đúng và $Q$ sai.</p>`,
          [
            '\\overline{\\forall x \\in X, P(x)} \\Leftrightarrow \\exists x \\in X, \\overline{P(x)}',
            '\\overline{\\exists x \\in X, P(x)} \\Leftrightarrow \\forall x \\in X, \\overline{P(x)}',
            'P \\Rightarrow Q \\text{ sai } \\Leftrightarrow P \\text{ đúng và } Q \\text{ sai}'
          ],
          [
            'Phủ định $\\forall$ thành $\\exists$ và ngược lại.',
            'Dấu $>$ phủ định thành $\\le$; dấu $\\ge$ phủ định thành $<$.',
            'Định lí đảo: nếu $P \\Rightarrow Q$ đúng thì $Q \\Rightarrow P$ chưa chắc đúng.'
          ],
          'numberLine'
        ),
        L(
          '10-2',
          'Bài 2. Tập hợp và các phép toán trên tập hợp',
          10,
          0,
          'Chương I. Mệnh đề và tập hợp',
          `<p>Tập hợp gồm các phần tử xác định. Ba phép toán cơ bản: giao, hợp và hiệu.</p>
           <p>Khoảng $(a;b)$, đoạn $[a;b]$, nửa khoảng $[a;b)$ hoặc $(a;b]$.</p>`,
          [
            'A \\cap B = \\{x \\mid x \\in A \\text{ và } x \\in B\\}',
            'A \\cup B = \\{x \\mid x \\in A \\text{ hoặc } x \\in B\\}',
            'A \\setminus B = \\{x \\mid x \\in A \\text{ và } x \\notin B\\}',
            'C_E A = E \\setminus A \\quad (A \\subset E)'
          ],
          [
            'Khi biểu diễn trên trục số, phần không thuộc tập hợp ta gạch bỏ.',
            'Số phần tử của $A \\cup B$: $|A \\cup B| = |A| + |B| - |A \\cap B|$.'
          ],
          'numberLine'
        ),
        L(
          '10-1-bt',
          'Bài tập cuối chương I',
          10,
          0,
          'Chương I. Mệnh đề và tập hợp',
          `<p>Ôn tập mệnh đề, phủ định, kéo theo, tập hợp và các phép toán trên tập hợp.</p>`,
          [],
          ['Luyện tập xác định tính đúng/sai của mệnh đề và biểu diễn tập hợp trên trục số.']
        )
      ]
    },
    {
      title: 'Chương II. Bất phương trình và hệ bất phương trình bậc nhất hai ẩn',
      grade: 10,
      lessons: [
        L(
          '10-3',
          'Bài 3. Bất phương trình bậc nhất hai ẩn',
          10,
          1,
          'Chương II. Bất phương trình và hệ bất phương trình bậc nhất hai ẩn',
          `<p>BPT dạng $ax + by \\le c$ (hoặc $<,>,\\ge$) với $a^2+b^2 \\ne 0$. Đường thẳng $ax+by=c$ chia mặt phẳng thành hai nửa mặt phẳng.</p>`,
          [
            'ax + by \\le c',
            '\\text{Thử điểm } O(0;0) \\text{ để xác định nửa mặt phẳng nghiệm}'
          ],
          [
            'Miền nghiệm của hệ BPT là giao các miền nghiệm thành phần, thường là đa giác lồi.',
            'GTLN/GTNN của $F(x;y)=ax+by$ đạt tại một trong các đỉnh của miền nghiệm.'
          ]
        ),
        L(
          '10-4',
          'Bài 4. Hệ bất phương trình bậc nhất hai ẩn',
          10,
          1,
          'Chương II. Bất phương trình và hệ bất phương trình bậc nhất hai ẩn',
          `<p>Hệ BPT bậc nhất hai ẩn: tìm cặp $(x;y)$ thỏa đồng thời mọi BPT trong hệ. Miền nghiệm là giao các nửa mặt phẳng.</p>`,
          [
            '\\begin{cases} a_1 x + b_1 y \\le c_1 \\\\ a_2 x + b_2 y \\le c_2 \\end{cases}',
            'F(x;y) = ax + by \\text{ đạt cực trị tại đỉnh miền nghiệm}'
          ],
          [
            'Vẽ từng đường thẳng biên, thử điểm để xác định nửa mặt phẳng, lấy giao.',
            'Ứng dụng: bài toán quy hoạch tuyến tính đơn giản.'
          ]
        ),
        L(
          '10-2-bt',
          'Bài tập cuối chương II',
          10,
          1,
          'Chương II. Bất phương trình và hệ bất phương trình bậc nhất hai ẩn',
          `<p>Ôn tập biểu diễn miền nghiệm và tìm GTLN/GTNN của biểu thức tuyến tính trên miền đa giác.</p>`,
          [],
          ['Chú ý điều kiện biên (dấu $=$, $<$, $\\le$).']
        )
      ]
    },
    {
      title: 'Chương III. Hệ thức lượng trong tam giác',
      grade: 10,
      lessons: [
        L(
          '10-5',
          'Bài 5. Giá trị lượng giác của một góc từ 0° đến 180°',
          10,
          2,
          'Chương III. Hệ thức lượng trong tam giác',
          `<p>Với góc $\\alpha \\in [0^\\circ; 180^\\circ]$: $\\sin\\alpha \\ge 0$, $\\cos\\alpha$ có thể âm khi $\\alpha > 90^\\circ$.</p>`,
          [
            '\\sin(180^\\circ - \\alpha) = \\sin\\alpha',
            '\\cos(180^\\circ - \\alpha) = -\\cos\\alpha',
            '\\tan(180^\\circ - \\alpha) = -\\tan\\alpha'
          ],
          [
            'Trong tam giác $ABC$: $A+B+C=180^\\circ$ nên $\\sin C = \\sin(A+B)$, $\\cos C = -\\cos(A+B)$.'
          ],
          'trig'
        ),
        L(
          '10-6',
          'Bài 6. Hệ thức lượng trong tam giác',
          10,
          2,
          'Chương III. Hệ thức lượng trong tam giác',
          `<p>Định lí côsin, định lí sin và các công thức diện tích hỗ trợ giải tam giác và đo đạc thực địa.</p>`,
          [
            'a^2 = b^2 + c^2 - 2bc\\cos A',
            '\\frac{a}{\\sin A} = \\frac{b}{\\sin B} = \\frac{c}{\\sin C} = 2R',
            'S = \\frac{1}{2}ab\\sin C = \\frac{abc}{4R} = pr = \\sqrt{p(p-a)(p-b)(p-c)}'
          ],
          [
            'Biết 2 cạnh và góc xen giữa → dùng định lí côsin.',
            'Biết 1 cạnh và 2 góc kề → dùng định lí sin.'
          ]
        ),
        L(
          '10-3-bt',
          'Bài tập cuối chương III',
          10,
          2,
          'Chương III. Hệ thức lượng trong tam giác',
          `<p>Ôn tập giá trị lượng giác góc từ $0^\\circ$ đến $180^\\circ$ và hệ thức lượng trong tam giác.</p>`,
          [],
          ['Phân biệt trường hợp tam giác nhọn / tù khi dùng định lí côsin.']
        )
      ]
    },
    {
      title: 'Chương IV. Vectơ',
      grade: 10,
      lessons: [
        L(
          '10-7',
          'Bài 7. Các khái niệm mở đầu',
          10,
          3,
          'Chương IV. Vectơ',
          `<p>Vectơ là đoạn thẳng có hướng. Hai vectơ bằng nhau khi cùng hướng và cùng độ dài.</p>`,
          [
            '\\vec{AB} = \\vec{CD} \\Leftrightarrow A,B,C,D \\text{ tạo thành hình bình hành (theo thứ tự)}',
            '|\\vec{AB}| = AB'
          ],
          ['Vectơ không: $\\vec{0}$, điểm đầu trùng điểm cuối.']
        ),
        L(
          '10-8',
          'Bài 8. Tổng và hiệu của hai vectơ',
          10,
          3,
          'Chương IV. Vectơ',
          `<p>Quy tắc ba điểm: $\\vec{AB}+\\vec{BC}=\\vec{AC}$. Quy tắc hình bình hành: $\\vec{AB}+\\vec{AD}=\\vec{AC}$.</p>`,
          [
            '\\vec{u} + \\vec{v} = \\vec{v} + \\vec{u}',
            '\\vec{AB} - \\vec{CD} = \\vec{AB} + (-\\vec{CD})'
          ],
          [
            'Trung điểm $M$ của $AB$: $\\vec{MA}+\\vec{MB}=\\vec{0}$.',
            'Trọng tâm $G$ của $\\triangle ABC$: $\\vec{GA}+\\vec{GB}+\\vec{GC}=\\vec{0}$.'
          ]
        ),
        L(
          '10-9',
          'Bài 9. Tích của một vectơ với một số',
          10,
          3,
          'Chương IV. Vectơ',
          `<p>$k\\vec{u}$ cùng hướng $\\vec{u}$ nếu $k>0$, ngược hướng nếu $k<0$; $|k\\vec{u}|=|k|\\,|\\vec{u}|$.</p>`,
          [
            'k(\\vec{u}+\\vec{v}) = k\\vec{u} + k\\vec{v}',
            '(k+m)\\vec{u} = k\\vec{u} + m\\vec{u}'
          ],
          ['Hai vectơ cùng phương $\\Leftrightarrow$ tồn tại $k$ sao cho $\\vec{u}=k\\vec{v}$.']
        ),
        L(
          '10-10',
          'Bài 10. Vectơ trong mặt phẳng tọa độ',
          10,
          3,
          'Chương IV. Vectơ',
          `<p>Trong hệ $Oxy$: $\\vec{u}=(u_1;u_2)$, $\\vec{AB}=(x_B-x_A; y_B-y_A)$.</p>`,
          [
            '|\\vec{u}| = \\sqrt{u_1^2 + u_2^2}',
            '\\vec{u} + \\vec{v} = (u_1+v_1; u_2+v_2)',
            'k\\vec{u} = (ku_1; ku_2)'
          ],
          ['Tọa độ trung điểm $M$ của $AB$: $M\\big(\\frac{x_A+x_B}{2}; \\frac{y_A+y_B}{2}\\)$.']
        ),
        L(
          '10-11',
          'Bài 11. Tích vô hướng của hai vectơ',
          10,
          3,
          'Chương IV. Vectơ',
          `<p>Tích vô hướng: $\\vec{u}\\cdot\\vec{v}=|\\vec{u}|\\,|\\vec{v}|\\cos(\\vec{u},\\vec{v})$.</p>`,
          [
            '\\vec{u} \\cdot \\vec{v} = u_1 v_1 + u_2 v_2',
            '\\vec{u} \\perp \\vec{v} \\Leftrightarrow \\vec{u} \\cdot \\vec{v} = 0',
            '\\cos(\\vec{u},\\vec{v}) = \\frac{\\vec{u}\\cdot\\vec{v}}{|\\vec{u}|\\,|\\vec{v}|}'
          ],
          [
            'Hai vectơ vuông góc $\\Leftrightarrow$ tích vô hướng bằng 0.',
            'Ứng dụng: chứng minh vuông góc, tính góc, độ dài.'
          ]
        ),
        L(
          '10-4-bt',
          'Bài tập cuối chương IV',
          10,
          3,
          'Chương IV. Vectơ',
          `<p>Ôn tập các phép toán vectơ, tọa độ và tích vô hướng.</p>`,
          [],
          ['Kết hợp hình học thuần túy với tọa độ để giải bài tập.']
        )
      ]
    },
    {
      title: 'Chương V. Các số đặc trưng của mẫu số liệu không ghép nhóm',
      grade: 10,
      lessons: [
        L(
          '10-12',
          'Bài 12. Số gần đúng và sai số',
          10,
          4,
          'Chương V. Các số đặc trưng của mẫu số liệu không ghép nhóm',
          `<p>Số gần đúng $a$ của số đúng $A$: sai số tuyệt đối $\\Delta a = |A-a|$; sai số tương đối $\\delta_a = \\frac{\\Delta a}{|A|}$.</p>`,
          [
            '\\Delta a = |A - a|',
            '\\delta_a = \\frac{\\Delta a}{|A|} \\quad (A \\ne 0)'
          ],
          ['Quy tắc làm tròn: số $\\ge 5$ thì làm tròn lên.']
        ),
        L(
          '10-13',
          'Bài 13. Các số đặc trưng đo xu thế trung tâm',
          10,
          4,
          'Chương V. Các số đặc trưng của mẫu số liệu không ghép nhóm',
          `<p>Số trung bình, trung vị, mốt mô tả xu thế trung tâm của mẫu số liệu.</p>`,
          [
            '\\bar{x} = \\frac{x_1+x_2+\\dots+x_n}{n}',
            '\\text{Trung vị } M_e: \\text{ giá trị giữa dãy đã sắp xếp}',
            '\\text{Mốt } M_o: \\text{ giá trị xuất hiện nhiều nhất}'
          ],
          [
            'Trung bình nhạy với giá trị ngoại lai; trung vị ổn định hơn.',
            'Mẫu có thể có nhiều mốt hoặc không có mốt.'
          ],
          'histogram'
        ),
        L(
          '10-14',
          'Bài 14. Các số đặc trưng đo độ phân tán',
          10,
          4,
          'Chương V. Các số đặc trưng của mẫu số liệu không ghép nhóm',
          `<p>Khoảng biến thiên, khoảng tứ phân vị, phương sai và độ lệch chuẩn đo mức độ phân tán.</p>`,
          [
            'R = x_{\\max} - x_{\\min}',
            'Q = Q_3 - Q_1',
            's^2 = \\frac{1}{n}\\sum_{i=1}^{n}(x_i-\\bar{x})^2, \\quad s = \\sqrt{s^2}'
          ],
          ['Độ lệch chuẩn càng lớn → số liệu càng phân tán.']
        ),
        L(
          '10-5-bt',
          'Bài tập cuối chương V',
          10,
          4,
          'Chương V. Các số đặc trưng của mẫu số liệu không ghép nhóm',
          `<p>Ôn tập số gần đúng, xu thế trung tâm và độ phân tán.</p>`,
          [],
          ['Phân biệt khi nào dùng trung bình, trung vị hay mốt.']
        )
      ]
    },
    {
      title: 'Hoạt động thực hành trải nghiệm (Lớp 10 – Học kì 1)',
      grade: 10,
      lessons: [
        L(
          '10-tn1',
          'Tìm hiểu một số kiến thức về tài chính',
          10,
          5,
          'Hoạt động thực hành trải nghiệm (Lớp 10 – Học kì 1)',
          `<p>Lãi suất đơn, lãi suất kép; chiết khấu; đọc và phân tích hóa đơn, bảng lương đơn giản.</p>`,
          [
            'A = P(1 + r)^n \\quad (\\text{lãi kép})',
            'A = P(1 + nr) \\quad (\\text{lãi đơn})'
          ],
          ['So sánh lãi đơn và lãi kép trong cùng thời gian gửi.']
        ),
        L(
          '10-tn2',
          'Mạng xã hội: Lợi và hại',
          10,
          5,
          'Hoạt động thực hành trải nghiệm (Lớp 10 – Học kì 1)',
          `<p>Thu thập và phân tích dữ liệu về thời gian sử dụng mạng xã hội; biểu đồ và số đặc trưng.</p>`,
          [],
          ['Kết hợp thống kê mô tả với kỹ năng phản biện thông tin.']
        )
      ]
    },
    {
      title: 'Chương VI. Hàm số, đồ thị và ứng dụng',
      grade: 10,
      lessons: [
        L(
          '10-15',
          'Bài 15. Hàm số',
          10,
          6,
          'Chương VI. Hàm số, đồ thị và ứng dụng',
          `<p>Hàm số $y=f(x)$: mỗi $x$ thuộc tập xác định ứng với duy nhất một $y$. Tập giá trị, đồ thị hàm số.</p>`,
          [
            'D = \\{x \\in \\mathbb{R} \\mid f(x) \\text{ xác định}\\}',
            'y = f(x) \\text{ đồng biến trên } K \\Leftrightarrow x_1 < x_2 \\Rightarrow f(x_1) < f(x_2)'
          ],
          ['Hàm số chẵn: $f(-x)=f(x)$; hàm lẻ: $f(-x)=-f(x)$.']
        ),
        L(
          '10-16',
          'Bài 16. Hàm số bậc hai',
          10,
          6,
          'Chương VI. Hàm số, đồ thị và ứng dụng',
          `<p>Hàm số $y=ax^2+bx+c$ ($a\\ne 0$). Đồ thị là parabol, đỉnh $I\\big(-\\frac{b}{2a}; -\\frac{\\Delta}{4a}\\)$.</p>`,
          [
            'y = ax^2 + bx + c',
            'x_I = -\\frac{b}{2a}, \\quad y_I = -\\frac{\\Delta}{4a}',
            '\\Delta = b^2 - 4ac'
          ],
          [
            '$a>0$: parabol hướng lên; $a<0$: hướng xuống.',
            'Trục đối xứng: $x=-\\frac{b}{2a}$.'
          ],
          'quadratic'
        ),
        L(
          '10-17',
          'Bài 17. Dấu của tam thức bậc hai',
          10,
          6,
          'Chương VI. Hàm số, đồ thị và ứng dụng',
          `<p>Tam thức $f(x)=ax^2+bx+c$. Xét dấu theo biệt thức $\\Delta$ và hệ số $a$.</p>`,
          [
            '\\Delta > 0: f(x) \\text{ cùng dấu } a \\text{ ngoài } (x_1;x_2), \\text{ trái dấu } a \\text{ trong } (x_1;x_2)',
            '\\Delta = 0: f(x) \\text{ cùng dấu } a \\text{ (trừ tại } x=-b/2a\\text{)}',
            '\\Delta < 0: f(x) \\text{ luôn cùng dấu } a'
          ],
          ['Bảng xét dấu tam thức là công cụ giải BPT bậc hai.']
        ),
        L(
          '10-18',
          'Bài 18. Phương trình quy về phương trình bậc hai',
          10,
          6,
          'Chương VI. Hàm số, đồ thị và ứng dụng',
          `<p>Phương trình trùng phương $ax^4+bx^2+c=0$; đặt $t=x^2$ ($t\\ge 0$). Phương trình chứa căn, phương trình tích.</p>`,
          [
            'ax^4 + bx^2 + c = 0 \\xrightarrow{t=x^2} at^2 + bt + c = 0 \\ (t \\ge 0)',
            '\\sqrt{A} = B \\Leftrightarrow \\begin{cases} B \\ge 0 \\\\ A = B^2 \\end{cases}'
          ],
          ['Luôn đặt điều kiện cho ẩn phụ và kiểm tra nghiệm.']
        ),
        L(
          '10-6-bt',
          'Bài tập cuối chương VI',
          10,
          6,
          'Chương VI. Hàm số, đồ thị và ứng dụng',
          `<p>Ôn tập hàm số bậc hai, xét dấu tam thức và phương trình quy về bậc hai.</p>`,
          [],
          ['Kết hợp đồ thị parabol với bảng xét dấu.']
        )
      ]
    },
    {
      title: 'Chương VII. Phương pháp tọa độ trong mặt phẳng',
      grade: 10,
      lessons: [
        L(
          '10-19',
          'Bài 19. Phương trình đường thẳng',
          10,
          7,
          'Chương VII. Phương pháp tọa độ trong mặt phẳng',
          `<p>Đường thẳng qua $M(x_0;y_0)$ có VTPT $\\vec{n}=(a;b)$: $a(x-x_0)+b(y-y_0)=0$.</p>`,
          [
            '\\Delta: ax + by + c = 0',
            'd(M,\\Delta) = \\frac{|ax_0+by_0+c|}{\\sqrt{a^2+b^2}}',
            '\\vec{u}=(u_1;u_2) \\Rightarrow \\vec{n}=(-u_2;u_1)'
          ],
          ['Hai đường thẳng song song / vuông góc / trùng dựa vào hệ số $a,b$.']
        ),
        L(
          '10-20',
          'Bài 20. Đường thẳng trong mặt phẳng tọa độ',
          10,
          7,
          'Chương VII. Phương pháp tọa độ trong mặt phẳng',
          `<p>Phương trình tham số, chính tắc; vị trí tương đối của hai đường thẳng; chùm đường thẳng.</p>`,
          [
            '\\frac{x-x_0}{u_1} = \\frac{y-y_0}{u_2}',
            'x = x_0 + tu_1,\\quad y = y_0 + tu_2'
          ],
          ['VTCP và VTPT vuông góc: $\\vec{u}\\cdot\\vec{n}=0$.']
        ),
        L(
          '10-21',
          'Bài 21. Đường tròn trong mặt phẳng tọa độ',
          10,
          7,
          'Chương VII. Phương pháp tọa độ trong mặt phẳng',
          `<p>Đường tròn tâm $I(a;b)$ bán kính $R$: $(x-a)^2+(y-b)^2=R^2$.</p>`,
          [
            '(x-a)^2 + (y-b)^2 = R^2',
            'x^2 + y^2 + Dx + Ey + F = 0 \\ (D^2+E^2-4F > 0)'
          ],
          [
            '$d(I,\\Delta)<R$: cắt tại 2 điểm; $=R$: tiếp xúc; $>R$: không giao.',
            'Tiếp tuyến tại $M_0$ trên đường tròn: $(x-a)(x_0-a)+(y-b)(y_0-b)=R^2$.'
          ],
          'circle'
        ),
        L(
          '10-22',
          'Bài 22. Ba đường conic',
          10,
          7,
          'Chương VII. Phương pháp tọa độ trong mặt phẳng',
          `<p>Elip, hypebol, parabol — định nghĩa qua tiêu điểm và đường chuẩn (hoặc tổng/hiệu khoảng cách).</p>`,
          [
            '\\text{Elip: } \\frac{x^2}{a^2} + \\frac{y^2}{b^2} = 1 \\ (a>b>0)',
            '\\text{Hypebol: } \\frac{x^2}{a^2} - \\frac{y^2}{b^2} = 1',
            '\\text{Parabol: } y^2 = 2px'
          ],
          ['Elip: $MF_1+MF_2=2a$; Hypebol: $|MF_1-MF_2|=2a$; Parabol: $MF=d(M,d)$.']
        ),
        L(
          '10-7-bt',
          'Bài tập cuối chương VII',
          10,
          7,
          'Chương VII. Phương pháp tọa độ trong mặt phẳng',
          `<p>Ôn tập phương trình đường thẳng, đường tròn và ba đường conic.</p>`,
          [],
          ['Xác định đúng tâm, bán kính, tiêu điểm trước khi lập phương trình.']
        )
      ]
    },
    {
      title: 'Chương VIII. Đại số tổ hợp',
      grade: 10,
      lessons: [
        L(
          '10-23',
          'Bài 23. Quy tắc đếm',
          10,
          8,
          'Chương VIII. Đại số tổ hợp',
          `<p>Quy tắc cộng và quy tắc nhân — nền tảng đếm số cách thực hiện một công việc.</p>`,
          [
            '\\text{Quy tắc cộng: } m + n',
            '\\text{Quy tắc nhân: } m \\cdot n'
          ],
          ['Phân biệt “hoặc” (cộng) và “và” (nhân) trong đề bài.']
        ),
        L(
          '10-24',
          'Bài 24. Hoán vị, chỉnh hợp và tổ hợp',
          10,
          8,
          'Chương VIII. Đại số tổ hợp',
          `<p>Hoán vị, chỉnh hợp, tổ hợp của $n$ phần tử lấy $k$ phần tử.</p>`,
          [
            'P_n = n!',
            'A_n^k = \\frac{n!}{(n-k)!}',
            'C_n^k = \\frac{n!}{k!(n-k)!}'
          ],
          [
            'Hoán vị: sắp xếp $n$ phần tử khác nhau.',
            'Chỉnh hợp: chọn $k$ và sắp xếp; Tổ hợp: chỉ chọn $k$, không sắp xếp.'
          ]
        ),
        L(
          '10-25',
          'Bài 25. Nhị thức Newton',
          10,
          8,
          'Chương VIII. Đại số tổ hợp',
          `<p>Khai triển $(a+b)^n = \\sum_{k=0}^{n} C_n^k a^{n-k} b^k$.</p>`,
          [
            '(a+b)^n = \\sum_{k=0}^{n} C_n^k a^{n-k} b^k',
            'T_{k+1} = C_n^k a^{n-k} b^k'
          ],
          ['Hệ số đối xứng: $C_n^k = C_n^{n-k}$.']
        ),
        L(
          '10-8-bt',
          'Bài tập cuối chương VIII',
          10,
          8,
          'Chương VIII. Đại số tổ hợp',
          `<p>Ôn tập quy tắc đếm, hoán vị — chỉnh hợp — tổ hợp và nhị thức Newton.</p>`,
          [],
          ['Đọc kỹ đề: có xét thứ tự hay không?']
        )
      ]
    },
    {
      title: 'Chương IX. Tính xác suất theo định nghĩa cổ điển',
      grade: 10,
      lessons: [
        L(
          '10-26',
          'Bài 26. Biến cố và định nghĩa cổ điển của xác suất',
          10,
          9,
          'Chương IX. Tính xác suất theo định nghĩa cổ điển',
          `<p>Không gian mẫu $\\Omega$ hữu hạn, các kết quả đồng khả năng. $P(A)=\\frac{|A|}{|\\Omega|}$.</p>`,
          [
            '0 \\le P(A) \\le 1',
            'P(\\Omega) = 1,\\quad P(\\emptyset) = 0',
            'P(\\overline{A}) = 1 - P(A)'
          ],
          ['Biến cố đối: $\\overline{A}$; biến cố hợp, giao.']
        ),
        L(
          '10-27',
          'Bài 27. Thực hành tính xác suất theo định nghĩa cổ điển',
          10,
          9,
          'Chương IX. Tính xác suất theo định nghĩa cổ điển',
          `<p>Áp dụng đếm tổ hợp / chỉnh hợp để tính $|A|$ và $|\\Omega|$ trong các bài toán thực tế.</p>`,
          [
            'P(A \\cup B) = P(A) + P(B) - P(A \\cap B)',
            'A \\cap B = \\emptyset \\Rightarrow P(A \\cup B) = P(A) + P(B)'
          ],
          ['Xác định rõ không gian mẫu trước khi đếm.']
        ),
        L(
          '10-9-bt',
          'Bài tập cuối chương IX',
          10,
          9,
          'Chương IX. Tính xác suất theo định nghĩa cổ điển',
          `<p>Ôn tập biến cố và tính xác suất cổ điển.</p>`,
          [],
          ['Kết hợp tổ hợp với xác suất.']
        )
      ]
    },
    {
      title: 'Hoạt động thực hành trải nghiệm (Lớp 10 – Học kì 2)',
      grade: 10,
      lessons: [
        L(
          '10-tn3',
          'Một số nội dung cho hoạt động trải nghiệm hình học',
          10,
          10,
          'Hoạt động thực hành trải nghiệm (Lớp 10 – Học kì 2)',
          `<p>Đo đạc thực tế, vẽ hình, sử dụng phần mềm hình học động (GeoGebra) để khám phá tính chất.</p>`,
          [],
          ['Kết nối hệ thức lượng, vectơ với đo đạc thực địa.']
        ),
        L(
          '10-tn4',
          'Ước tính số cá thể trong một quần thể',
          10,
          10,
          'Hoạt động thực hành trải nghiệm (Lớp 10 – Học kì 2)',
          `<p>Phương pháp bắt–đánh dấu–thả lại: ước lượng quy mô quần thể từ mẫu.</p>`,
          [
            'N \\approx \\frac{n_1 \\cdot n_2}{m}'
          ],
          ['$n_1$: số bắt lần 1; $n_2$: số bắt lần 2; $m$: số cá thể đánh dấu bắt lại.']
        )
      ]
    },
    {
      title: 'Chuyên đề 1. Hệ phương trình bậc nhất ba ẩn',
      grade: 10,
      lessons: [
        L(
          '10-cd1-1',
          'Bài 1. Hệ phương trình bậc nhất ba ẩn',
          10,
          11,
          'Chuyên đề 1. Hệ phương trình bậc nhất ba ẩn',
          `<p>Hệ 3 phương trình bậc nhất 3 ẩn. Phương pháp thế, cộng đại số; ma trận và định thức (giới thiệu).</p>`,
          [
            '\\begin{cases} a_1x+b_1y+c_1z=d_1 \\\\ a_2x+b_2y+c_2z=d_2 \\\\ a_3x+b_3y+c_3z=d_3 \\end{cases}'
          ],
          ['Hệ có thể có nghiệm duy nhất, vô số nghiệm hoặc vô nghiệm.']
        ),
        L(
          '10-cd1-2',
          'Bài 2. Ứng dụng của hệ phương trình bậc nhất ba ẩn',
          10,
          11,
          'Chuyên đề 1. Hệ phương trình bậc nhất ba ẩn',
          `<p>Mô hình hóa bài toán thực tế (hỗn hợp, kinh tế, hình học) bằng hệ 3 ẩn.</p>`,
          [],
          ['Đặt ẩn hợp lý, lập hệ, giải và kiểm tra điều kiện thực tế.']
        ),
        L(
          '10-cd1-bt',
          'Bài tập cuối chuyên đề 1',
          10,
          11,
          'Chuyên đề 1. Hệ phương trình bậc nhất ba ẩn',
          `<p>Ôn tập giải và ứng dụng hệ phương trình bậc nhất ba ẩn.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chuyên đề 2. Phương pháp quy nạp toán học, nhị thức Newton',
      grade: 10,
      lessons: [
        L(
          '10-cd2-1',
          'Bài 3. Phương pháp quy nạp toán học',
          10,
          12,
          'Chuyên đề 2. Phương pháp quy nạp toán học, nhị thức Newton',
          `<p>Quy nạp: (1) Kiểm tra $n=n_0$; (2) Giả sử đúng với $n=k$; (3) Chứng minh đúng với $n=k+1$.</p>`,
          [],
          ['Chỉ áp dụng cho mệnh đề phụ thuộc số tự nhiên $n$.']
        ),
        L(
          '10-cd2-2',
          'Bài 4. Nhị thức Newton',
          10,
          12,
          'Chuyên đề 2. Phương pháp quy nạp toán học, nhị thức Newton',
          `<p>Mở rộng khai triển nhị thức Newton và ứng dụng tìm hệ số, số hạng.</p>`,
          [
            '(a+b)^n = \\sum_{k=0}^{n} C_n^k a^{n-k} b^k'
          ],
          ['Dùng quy nạp để chứng minh công thức nhị thức Newton.']
        ),
        L(
          '10-cd2-bt',
          'Bài tập cuối chuyên đề 2',
          10,
          12,
          'Chuyên đề 2. Phương pháp quy nạp toán học, nhị thức Newton',
          `<p>Ôn tập quy nạp và nhị thức Newton.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chuyên đề 3. Ba đường conic và ứng dụng',
      grade: 10,
      lessons: [
        L(
          '10-cd3-1',
          'Bài 5. Elip',
          10,
          13,
          'Chuyên đề 3. Ba đường conic và ứng dụng',
          `<p>Elip: tập hợp điểm $M$ sao cho $MF_1+MF_2=2a$ ($2a>F_1F_2$).</p>`,
          [
            '\\frac{x^2}{a^2}+\\frac{y^2}{b^2}=1,\\quad b^2=a^2-c^2,\\quad e=\\frac{c}{a}<1'
          ],
          ['Tiêu điểm $F(\\pm c;0)$; độ lệch tâm $e<1$.']
        ),
        L(
          '10-cd3-2',
          'Bài 6. Hypebol',
          10,
          13,
          'Chuyên đề 3. Ba đường conic và ứng dụng',
          `<p>Hypebol: $|MF_1-MF_2|=2a$ ($2a<F_1F_2$).</p>`,
          [
            '\\frac{x^2}{a^2}-\\frac{y^2}{b^2}=1,\\quad b^2=c^2-a^2,\\quad e=\\frac{c}{a}>1'
          ],
          ['Hai nhánh; tiệm cận $y=\\pm\\frac{b}{a}x$.']
        ),
        L(
          '10-cd3-3',
          'Bài 7. Parabol',
          10,
          13,
          'Chuyên đề 3. Ba đường conic và ứng dụng',
          `<p>Parabol: $MF=d(M,\\Delta)$ (tiêu điểm và đường chuẩn).</p>`,
          [
            'y^2 = 2px \\quad (\\text{hoặc } x^2 = 2py)'
          ],
          ['Tiêu điểm $F(\\frac{p}{2};0)$; đường chuẩn $x=-\\frac{p}{2}$.']
        ),
        L(
          '10-cd3-4',
          'Bài 8. Sự thống nhất giữa ba đường conic',
          10,
          13,
          'Chuyên đề 3. Ba đường conic và ứng dụng',
          `<p>Ba đường conic đều là quỹ tích điểm có tỉ số khoảng cách tới tiêu điểm và đường chuẩn bằng $e$ (độ lệch tâm).</p>`,
          [
            '\\frac{MF}{d(M,\\Delta)} = e'
          ],
          ['$e<1$: elip; $e=1$: parabol; $e>1$: hypebol.']
        ),
        L(
          '10-cd3-bt',
          'Bài tập cuối chuyên đề 3',
          10,
          13,
          'Chuyên đề 3. Ba đường conic và ứng dụng',
          `<p>Ôn tập elip, hypebol, parabol và mối liên hệ giữa chúng.</p>`,
          [],
          []
        )
      ]
    }
  ],

  // =====================================================================
  // LỚP 11
  // =====================================================================
  11: [
    {
      title: 'Chương I. Hàm số lượng giác và phương trình lượng giác',
      grade: 11,
      lessons: [
        L(
          '11-1',
          'Bài 1. Giá trị lượng giác của góc lượng giác',
          11,
          0,
          'Chương I. Hàm số lượng giác và phương trình lượng giác',
          `<p>Góc lượng giác: $\\pi$ rad $= 180^\\circ$. Giá trị lượng giác của góc bất kì qua đường tròn lượng giác.</p>`,
          [
            '\\sin^2 x + \\cos^2 x = 1',
            '1 + \\tan^2 x = \\frac{1}{\\cos^2 x}',
            '\\sin(-x)=-\\sin x,\\quad \\cos(-x)=\\cos x'
          ],
          ['Dấu sin, cos theo góc phần tư trên đường tròn lượng giác.'],
          'trig'
        ),
        L(
          '11-2',
          'Bài 2. Công thức lượng giác',
          11,
          0,
          'Chương I. Hàm số lượng giác và phương trình lượng giác',
          `<p>Công thức cộng, nhân đôi, hạ bậc, biến đổi tích thành tổng và ngược lại.</p>`,
          [
            '\\sin(a\\pm b)=\\sin a\\cos b \\pm \\cos a\\sin b',
            '\\cos(a\\pm b)=\\cos a\\cos b \\mp \\sin a\\sin b',
            '\\sin 2a = 2\\sin a\\cos a',
            '\\cos 2a = \\cos^2 a - \\sin^2 a = 2\\cos^2 a - 1 = 1 - 2\\sin^2 a'
          ],
          ['Hạ bậc: $\\sin^2 a = \\frac{1-\\cos 2a}{2}$, $\\cos^2 a = \\frac{1+\\cos 2a}{2}$.']
        ),
        L(
          '11-3',
          'Bài 3. Hàm số lượng giác',
          11,
          0,
          'Chương I. Hàm số lượng giác và phương trình lượng giác',
          `<p>Hàm số $y=\\sin x$, $y=\\cos x$, $y=\\tan x$, $y=\\cot x$: tập xác định, chu kì, tính chẵn/lẻ, đồ thị.</p>`,
          [
            'y=\\sin x:\\ T=2\\pi,\\ \\text{hàm lẻ}',
            'y=\\cos x:\\ T=2\\pi,\\ \\text{hàm chẵn}',
            'y=\\tan x:\\ T=\\pi,\\ x\\ne\\frac{\\pi}{2}+k\\pi'
          ],
          ['Đồ thị sin và cos lệch pha $\\frac{\\pi}{2}$.'],
          'trig'
        ),
        L(
          '11-4',
          'Bài 4. Phương trình lượng giác cơ bản',
          11,
          0,
          'Chương I. Hàm số lượng giác và phương trình lượng giác',
          `<p>Phương trình cơ bản: $\\sin x = a$, $\\cos x = a$, $\\tan x = a$.</p>`,
          [
            '\\sin x = \\sin\\alpha \\Leftrightarrow x = \\alpha + k2\\pi \\text{ hoặc } x = \\pi-\\alpha + k2\\pi',
            '\\cos x = \\cos\\alpha \\Leftrightarrow x = \\pm\\alpha + k2\\pi',
            '\\tan x = \\tan\\alpha \\Leftrightarrow x = \\alpha + k\\pi'
          ],
          ['Điều kiện $|a|\\le 1$ với $\\sin$ và $\\cos$; luôn có nghiệm với $\\tan$.']
        ),
        L(
          '11-1-bt',
          'Bài tập cuối chương I',
          11,
          0,
          'Chương I. Hàm số lượng giác và phương trình lượng giác',
          `<p>Ôn tập giá trị lượng giác, công thức, hàm số và phương trình lượng giác cơ bản.</p>`,
          [],
          ['Biến đổi về phương trình cơ bản trước khi giải.']
        )
      ]
    },
    {
      title: 'Chương II. Dãy số. Cấp số cộng và cấp số nhân',
      grade: 11,
      lessons: [
        L(
          '11-5',
          'Bài 5. Dãy số',
          11,
          1,
          'Chương II. Dãy số. Cấp số cộng và cấp số nhân',
          `<p>Dãy số $(u_n)$: công thức số hạng tổng quát hoặc hệ thức truy hồi. Dãy tăng, giảm, bị chặn.</p>`,
          [
            'u_{n+1} = f(u_n)',
            'u_n = f(n)'
          ],
          ['Dãy tăng: $u_{n+1}>u_n$; dãy bị chặn trên nếu tồn tại $M$ sao cho $u_n\\le M$.']
        ),
        L(
          '11-6',
          'Bài 6. Cấp số cộng',
          11,
          1,
          'Chương II. Dãy số. Cấp số cộng và cấp số nhân',
          `<p>Cấp số cộng: $u_{n+1}=u_n+d$ (công sai $d$).</p>`,
          [
            'u_n = u_1 + (n-1)d',
            'S_n = \\frac{n(u_1+u_n)}{2} = \\frac{n[2u_1+(n-1)d]}{2}'
          ],
          ['Ba số $a,b,c$ lập CSC $\\Leftrightarrow a+c=2b$.']
        ),
        L(
          '11-7',
          'Bài 7. Cấp số nhân',
          11,
          1,
          'Chương II. Dãy số. Cấp số cộng và cấp số nhân',
          `<p>Cấp số nhân: $u_{n+1}=u_n\\cdot q$ (công bội $q$).</p>`,
          [
            'u_n = u_1 \\cdot q^{n-1}',
            'S_n = u_1\\frac{1-q^n}{1-q}\\ (q\\ne 1)',
            '|q|<1:\\ S = \\frac{u_1}{1-q}\\ (\\text{CSN lùi vô hạn})'
          ],
          ['Ba số $a,b,c$ lập CSN $\\Leftrightarrow ac=b^2$ (nếu $b\\ne 0$).']
        ),
        L(
          '11-2-bt',
          'Bài tập cuối chương II',
          11,
          1,
          'Chương II. Dãy số. Cấp số cộng và cấp số nhân',
          `<p>Ôn tập dãy số, cấp số cộng và cấp số nhân.</p>`,
          [],
          ['Phân biệt CSC và CSN qua công sai / công bội.']
        )
      ]
    },
    {
      title: 'Chương III. Các số đặc trưng đo xu thế trung tâm của mẫu số liệu ghép nhóm',
      grade: 11,
      lessons: [
        L(
          '11-8',
          'Bài 8. Mẫu số liệu ghép nhóm',
          11,
          2,
          'Chương III. Các số đặc trưng đo xu thế trung tâm của mẫu số liệu ghép nhóm',
          `<p>Bảng tần số ghép nhóm: chia số liệu thành các khoảng (nhóm), ghi tần số / tần suất.</p>`,
          [
            '\\text{Tần suất } f_i = \\frac{n_i}{n}',
            '\\sum f_i = 1'
          ],
          ['Đại diện nhóm thường lấy trung điểm khoảng.'],
          'histogram'
        ),
        L(
          '11-9',
          'Bài 9. Các số đặc trưng đo xu thế trung tâm',
          11,
          2,
          'Chương III. Các số đặc trưng đo xu thế trung tâm của mẫu số liệu ghép nhóm',
          `<p>Số trung bình, trung vị, mốt của mẫu ghép nhóm.</p>`,
          [
            '\\bar{x} = \\frac{\\sum n_i x_i}{n}',
            'M_e \\approx a + \\frac{\\frac{n}{2}-n_{t}}{n_{me}}\\cdot h',
            'M_o \\approx a + \\frac{n_{mo}-n_{tr}}{(n_{mo}-n_{tr})+(n_{mo}-n_{s})}\\cdot h'
          ],
          ['Công thức xấp xỉ trung vị và mốt dựa trên nhóm chứa chúng.']
        ),
        L(
          '11-3-bt',
          'Bài tập cuối chương III',
          11,
          2,
          'Chương III. Các số đặc trưng đo xu thế trung tâm của mẫu số liệu ghép nhóm',
          `<p>Ôn tập mẫu ghép nhóm và các số đặc trưng xu thế trung tâm.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chương IV. Quan hệ song song trong không gian',
      grade: 11,
      lessons: [
        L(
          '11-10',
          'Bài 10. Đường thẳng và mặt phẳng trong không gian',
          11,
          3,
          'Chương IV. Quan hệ song song trong không gian',
          `<p>Định nghĩa đường thẳng, mặt phẳng; các cách xác định mặt phẳng; vị trí tương đối đường thẳng và mặt phẳng.</p>`,
          [],
          ['Ba điểm không thẳng hàng xác định duy nhất một mặt phẳng.']
        ),
        L(
          '11-11',
          'Bài 11. Hai đường thẳng song song',
          11,
          3,
          'Chương IV. Quan hệ song song trong không gian',
          `<p>Hai đường thẳng song song trong không gian: đồng phẳng và không có điểm chung.</p>`,
          [],
          ['Định lí về giao tuyến của hai mặt phẳng song song với một đường thẳng.']
        ),
        L(
          '11-12',
          'Bài 12. Đường thẳng và mặt phẳng song song',
          11,
          3,
          'Chương IV. Quan hệ song song trong không gian',
          `<p>$d \\parallel (\\alpha)$ khi $d$ không nằm trên $(\\alpha)$ và không cắt $(\\alpha)$.</p>`,
          [],
          ['Nếu $d \\parallel d\' \\subset (\\alpha)$ và $d \\not\\subset (\\alpha)$ thì $d \\parallel (\\alpha)$.']
        ),
        L(
          '11-13',
          'Bài 13. Hai mặt phẳng song song',
          11,
          3,
          'Chương IV. Quan hệ song song trong không gian',
          `<p>Hai mặt phẳng song song khi không có điểm chung. Định lí đường thẳng và mặt phẳng song song.</p>`,
          [],
          ['Hai mặt phẳng song song chắn trên hai cát tuyến song song các đoạn bằng nhau.']
        ),
        L(
          '11-14',
          'Bài 14. Phép chiếu song song',
          11,
          3,
          'Chương IV. Quan hệ song song trong không gian',
          `<p>Phép chiếu song song lên một mặt phẳng theo phương cho trước. Tính chất bảo toàn tỉ số trên đường thẳng song song với phương chiếu.</p>`,
          [],
          ['Hình chiếu của đường thẳng là đường thẳng hoặc điểm.']
        ),
        L(
          '11-4-bt',
          'Bài tập cuối chương IV',
          11,
          3,
          'Chương IV. Quan hệ song song trong không gian',
          `<p>Ôn tập quan hệ song song đường thẳng — mặt phẳng trong không gian.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chương V. Giới hạn. Hàm số liên tục',
      grade: 11,
      lessons: [
        L(
          '11-15',
          'Bài 15. Giới hạn của dãy số',
          11,
          4,
          'Chương V. Giới hạn. Hàm số liên tục',
          `<p>$\\lim_{n\\to\\infty} u_n = L$ khi $u_n$ tiến tới $L$ khi $n$ đủ lớn. Giới hạn hữu hạn và vô cùng.</p>`,
          [
            '\\lim_{n\\to\\infty} \\frac{1}{n} = 0',
            '\\lim_{n\\to\\infty} q^n = 0 \\quad (|q|<1)',
            '\\lim_{n\\to\\infty} \\frac{a_k n^k + \\cdots}{b_k n^k + \\cdots} = \\frac{a_k}{b_k}'
          ],
          ['Dãy hội tụ bị chặn; dãy đơn điệu và bị chặn thì hội tụ.']
        ),
        L(
          '11-16',
          'Bài 16. Giới hạn của hàm số',
          11,
          4,
          'Chương V. Giới hạn. Hàm số liên tục',
          `<p>Giới hạn tại một điểm và tại vô cùng. Khử dạng vô định $\\frac{0}{0}$, $\\frac{\\infty}{\\infty}$, $\\infty-\\infty$.</p>`,
          [
            '\\lim_{x\\to x_0} f(x) = L',
            '\\lim_{x\\to\\infty} \\frac{a_m x^m+\\cdots}{b_n x^n+\\cdots}'
          ],
          [
            'Phương pháp: phân tích nhân tử, nhân lượng liên hợp, chia bậc cao nhất.',
            'Giới hạn một phía: $x\\to x_0^+$ và $x\\to x_0^-$.'
          ]
        ),
        L(
          '11-17',
          'Bài 17. Hàm số liên tục',
          11,
          4,
          'Chương V. Giới hạn. Hàm số liên tục',
          `<p>$f$ liên tục tại $x_0$ khi $\\lim_{x\\to x_0} f(x) = f(x_0)$. Liên tục trên khoảng, đoạn.</p>`,
          [
            'f \\text{ liên tục tại } x_0 \\Leftrightarrow \\lim_{x\\to x_0} f(x) = f(x_0)'
          ],
          [
            'Tổng, hiệu, tích, thương (mẫu $\\ne 0$) của các hàm liên tục là liên tục.',
            'Hàm đa thức, lượng giác, mũ, lôgarit liên tục trên TXĐ.'
          ]
        ),
        L(
          '11-5-bt',
          'Bài tập cuối chương V',
          11,
          4,
          'Chương V. Giới hạn. Hàm số liên tục',
          `<p>Ôn tập giới hạn dãy số, giới hạn hàm số và tính liên tục.</p>`,
          [],
          ['Xác định đúng dạng vô định trước khi khử.']
        )
      ]
    },
    {
      title: 'Hoạt động thực hành trải nghiệm (Lớp 11 – Học kì 1)',
      grade: 11,
      lessons: [
        L(
          '11-tn1',
          'Một vài áp dụng của Toán học trong tài chính',
          11,
          5,
          'Hoạt động thực hành trải nghiệm (Lớp 11 – Học kì 1)',
          `<p>Lãi suất, khấu hao, trả góp; mô hình tăng trưởng với dãy số và hàm mũ.</p>`,
          [
            'A = P(1+r)^n'
          ],
          ['So sánh các phương án vay / gửi tiết kiệm.']
        ),
        L(
          '11-tn2',
          'Lực căng mặt ngoài của nước',
          11,
          5,
          'Hoạt động thực hành trải nghiệm (Lớp 11 – Học kì 1)',
          `<p>Mô hình hóa hiện tượng vật lý bằng công thức lượng giác / hình học không gian đơn giản.</p>`,
          [],
          ['Liên hệ góc, lực và cân bằng.']
        )
      ]
    },
    {
      title: 'Chương VI. Hàm số mũ và hàm số lôgarit',
      grade: 11,
      lessons: [
        L(
          '11-18',
          'Bài 18. Lũy thừa với số mũ thực',
          11,
          6,
          'Chương VI. Hàm số mũ và hàm số lôgarit',
          `<p>Lũy thừa với số mũ nguyên, hữu tỉ, thực. Các tính chất của lũy thừa.</p>`,
          [
            'a^m \\cdot a^n = a^{m+n}',
            '(a^m)^n = a^{mn}',
            '(ab)^n = a^n b^n'
          ],
          ['Điều kiện $a>0$ khi mũ thực tùy ý.']
        ),
        L(
          '11-19',
          'Bài 19. Lôgarit',
          11,
          6,
          'Chương VI. Hàm số mũ và hàm số lôgarit',
          `<p>$\\log_a b = \\alpha \\Leftrightarrow a^\\alpha = b$ ($a>0, a\\ne 1, b>0$).</p>`,
          [
            '\\log_a (xy) = \\log_a x + \\log_a y',
            '\\log_a \\frac{x}{y} = \\log_a x - \\log_a y',
            '\\log_a x^n = n\\log_a x',
            '\\log_a b = \\frac{\\log_c b}{\\log_c a}'
          ],
          ['Đổi cơ số; $\\ln x = \\log_e x$; $\\lg x = \\log_{10} x$.']
        ),
        L(
          '11-20',
          'Bài 20. Hàm số mũ và hàm số lôgarit',
          11,
          6,
          'Chương VI. Hàm số mũ và hàm số lôgarit',
          `<p>Hàm số $y=a^x$ và $y=\\log_a x$: TXĐ, tập giá trị, tính đơn điệu, đồ thị.</p>`,
          [
            'y=a^x \\ (a>0,a\\ne 1): D=\\mathbb{R},\\ T=(0;+\\infty)',
            'y=\\log_a x: D=(0;+\\infty),\\ T=\\mathbb{R}'
          ],
          [
            '$a>1$: cả hai hàm đồng biến; $0<a<1$: nghịch biến.',
            'Đồ thị $y=a^x$ và $y=\\log_a x$ đối xứng qua $y=x$.'
          ]
        ),
        L(
          '11-21',
          'Bài 21. Phương trình, bất phương trình mũ và lôgarit',
          11,
          6,
          'Chương VI. Hàm số mũ và hàm số lôgarit',
          `<p>Phương trình / BPT mũ và lôgarit cơ bản; đặt ẩn phụ; đưa về cùng cơ số.</p>`,
          [
            'a^{f(x)} = a^{g(x)} \\Leftrightarrow f(x)=g(x)\\ (a>0,a\\ne 1)',
            '\\log_a f(x) = \\log_a g(x) \\Leftrightarrow f(x)=g(x)>0'
          ],
          ['Luôn đặt điều kiện cho biểu thức trong lôgarit và cơ số.']
        ),
        L(
          '11-6-bt',
          'Bài tập cuối chương VI',
          11,
          6,
          'Chương VI. Hàm số mũ và hàm số lôgarit',
          `<p>Ôn tập lũy thừa, lôgarit, hàm số và phương trình mũ — lôgarit.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chương VII. Quan hệ vuông góc trong không gian',
      grade: 11,
      lessons: [
        L(
          '11-22',
          'Bài 22. Hai đường thẳng vuông góc',
          11,
          7,
          'Chương VII. Quan hệ vuông góc trong không gian',
          `<p>Hai đường thẳng vuông góc khi góc giữa chúng bằng $90^\\circ$ (kể cả chéo nhau).</p>`,
          [],
          ['Góc giữa hai đường thẳng chéo nhau = góc giữa hai đường thẳng cắt nhau cùng phương với chúng.']
        ),
        L(
          '11-23',
          'Bài 23. Đường thẳng vuông góc với mặt phẳng',
          11,
          7,
          'Chương VII. Quan hệ vuông góc trong không gian',
          `<p>$d \\perp (\\alpha)$ khi $d$ vuông góc với mọi đường thẳng nằm trên $(\\alpha)$.</p>`,
          [],
          ['$d \\perp (\\alpha)$ nếu $d$ vuông góc với hai đường thẳng cắt nhau trên $(\\alpha)$.'],
          'pyramid'
        ),
        L(
          '11-24',
          'Bài 24. Phép chiếu vuông góc. Góc giữa đường thẳng và mặt phẳng',
          11,
          7,
          'Chương VII. Quan hệ vuông góc trong không gian',
          `<p>Góc giữa đường thẳng và mặt phẳng: góc giữa đường thẳng và hình chiếu vuông góc của nó trên mặt phẳng.</p>`,
          [
            '\\sin\\varphi = |\\cos\\theta|\\ (\\theta:\\text{ góc giữa } d \\text{ và pháp tuyến})'
          ],
          ['Nếu $d \\perp (\\alpha)$ thì góc bằng $90^\\circ$; nếu $d \\parallel (\\alpha)$ thì góc bằng $0^\\circ$.']
        ),
        L(
          '11-25',
          'Bài 25. Hai mặt phẳng vuông góc',
          11,
          7,
          'Chương VII. Quan hệ vuông góc trong không gian',
          `<p>Hai mặt phẳng vuông góc khi góc giữa chúng bằng $90^\\circ$.</p>`,
          [],
          ['$(\\alpha)\\perp(\\beta)$ nếu $(\\alpha)$ chứa một đường thẳng vuông góc với $(\\beta)$.']
        ),
        L(
          '11-26',
          'Bài 26. Khoảng cách',
          11,
          7,
          'Chương VII. Quan hệ vuông góc trong không gian',
          `<p>Khoảng cách từ điểm đến đường thẳng / mặt phẳng; khoảng cách giữa hai đường thẳng chéo nhau.</p>`,
          [
            'd(M,(\\alpha)) = |\\overrightarrow{HM}|\\ (H=\\text{ hình chiếu vuông góc})'
          ],
          ['Khoảng cách giữa hai đường chéo = độ dài đoạn vuông góc chung.']
        ),
        L(
          '11-27',
          'Bài 27. Thể tích',
          11,
          7,
          'Chương VII. Quan hệ vuông góc trong không gian',
          `<p>Thể tích khối lăng trụ, hình hộp, hình chóp, hình chóp cụt.</p>`,
          [
            'V_{\\text{lăng trụ}} = S_\\text{đáy} \\cdot h',
            'V_{\\text{chóp}} = \\frac{1}{3} S_\\text{đáy} \\cdot h',
            'V_{\\text{chóp cụt}} = \\frac{h}{3}(S + S\' + \\sqrt{SS\'})'
          ],
          ['Chiều cao phải vuông góc với mặt đáy.'],
          'pyramid'
        ),
        L(
          '11-7-bt',
          'Bài tập cuối chương VII',
          11,
          7,
          'Chương VII. Quan hệ vuông góc trong không gian',
          `<p>Ôn tập quan hệ vuông góc, khoảng cách và thể tích.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chương VIII. Các quy tắc tính xác suất',
      grade: 11,
      lessons: [
        L(
          '11-28',
          'Bài 28. Biến cố hợp, biến cố giao, biến cố độc lập',
          11,
          8,
          'Chương VIII. Các quy tắc tính xác suất',
          `<p>Biến cố hợp $A\\cup B$, giao $A\\cap B$; hai biến cố độc lập khi $P(A\\cap B)=P(A)P(B)$.</p>`,
          [
            'P(A\\cup B)=P(A)+P(B)-P(A\\cap B)',
            'A,B \\text{ độc lập } \\Leftrightarrow P(A\\cap B)=P(A)P(B)'
          ],
          ['Độc lập khác với xung khắc ($A\\cap B=\\emptyset$).']
        ),
        L(
          '11-29',
          'Bài 29. Công thức cộng xác suất',
          11,
          8,
          'Chương VIII. Các quy tắc tính xác suất',
          `<p>Công thức cộng cho hai hoặc nhiều biến cố; trường hợp xung khắc.</p>`,
          [
            'A\\cap B=\\emptyset \\Rightarrow P(A\\cup B)=P(A)+P(B)'
          ],
          ['Mở rộng cho $n$ biến cố xung khắc từng đôi.']
        ),
        L(
          '11-30',
          'Bài 30. Công thức nhân xác suất cho hai biến cố độc lập',
          11,
          8,
          'Chương VIII. Các quy tắc tính xác suất',
          `<p>Với hai biến cố độc lập: $P(A\\cap B)=P(A)P(B)$. Mở rộng cho nhiều biến cố độc lập.</p>`,
          [
            'P(A\\cap B)=P(A)P(B)\\ (\\text{độc lập})'
          ],
          ['Kiểm tra tính độc lập trước khi nhân xác suất.']
        ),
        L(
          '11-8-bt',
          'Bài tập cuối chương VIII',
          11,
          8,
          'Chương VIII. Các quy tắc tính xác suất',
          `<p>Ôn tập biến cố hợp/giao, công thức cộng và nhân xác suất.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chương IX. Đạo hàm',
      grade: 11,
      lessons: [
        L(
          '11-31',
          'Bài 31. Định nghĩa và ý nghĩa của đạo hàm',
          11,
          9,
          'Chương IX. Đạo hàm',
          `<p>$f'(x_0)=\\lim_{x\\to x_0}\\frac{f(x)-f(x_0)}{x-x_0}$. Ý nghĩa hình học: hệ số góc tiếp tuyến; ý nghĩa vật lý: vận tốc tức thời.</p>`,
          [
            'f\'(x_0) = \\lim_{h\\to 0}\\frac{f(x_0+h)-f(x_0)}{h}',
            'y - y_0 = f\'(x_0)(x - x_0)\\ (\\text{tiếp tuyến})'
          ],
          ['Nếu $f$ có đạo hàm tại $x_0$ thì $f$ liên tục tại $x_0$ (điều ngược lại không luôn đúng).']
        ),
        L(
          '11-32',
          'Bài 32. Các quy tắc tính đạo hàm',
          11,
          9,
          'Chương IX. Đạo hàm',
          `<p>Đạo hàm tổng, hiệu, tích, thương; đạo hàm hàm hợp; đạo hàm các hàm sơ cấp.</p>`,
          [
            '(u\\pm v)\' = u\'\\pm v\'',
            '(uv)\' = u\'v + uv\'',
            '\\left(\\frac{u}{v}\\right)\' = \\frac{u\'v-uv\'}{v^2}',
            '(u^n)\' = n u^{n-1} u\''
          ],
          [
            '(\\sin x)\'=\\cos x;\\ (\\cos x)\'=-\\sin x;\\ (\\tan x)\'=\\frac{1}{\\cos^2 x}',
            '(e^x)\'=e^x;\\ (\\ln x)\'=\\frac{1}{x};\\ (a^x)\'=a^x\\ln a'
          ]
        ),
        L(
          '11-33',
          'Bài 33. Đạo hàm cấp hai',
          11,
          9,
          'Chương IX. Đạo hàm',
          `<p>$f''(x)=(f'(x))'$. Ý nghĩa: gia tốc; liên hệ với tính lồi/lõm của đồ thị.</p>`,
          [
            'f\'\'(x) = (f\'(x))\''
          ],
          ['$f\'\'(x)>0$: đồ thị lõm lên; $f\'\'(x)<0$: lõm xuống (trên khoảng).']
        ),
        L(
          '11-9-bt',
          'Bài tập cuối chương IX',
          11,
          9,
          'Chương IX. Đạo hàm',
          `<p>Ôn tập định nghĩa, quy tắc tính đạo hàm và đạo hàm cấp hai.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Hoạt động thực hành trải nghiệm (Lớp 11 – Học kì 2)',
      grade: 11,
      lessons: [
        L(
          '11-tn3',
          'Một vài mô hình toán học sử dụng hàm số mũ và hàm số lôgarit',
          11,
          10,
          'Hoạt động thực hành trải nghiệm (Lớp 11 – Học kì 2)',
          `<p>Tăng trưởng dân số, phân rã phóng xạ, lãi kép — mô hình $y=y_0 a^{kt}$ hoặc $\\log$.</p>`,
          [
            'N(t) = N_0 e^{kt}'
          ],
          ['Xác định tham số từ dữ liệu thực tế.']
        ),
        L(
          '11-tn4',
          'Hoạt động thực hành trải nghiệm Hình học',
          11,
          10,
          'Hoạt động thực hành trải nghiệm (Lớp 11 – Học kì 2)',
          `<p>Vẽ hình không gian, tính khoảng cách và thể tích với phần mềm hoặc mô hình vật lý.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chuyên đề 1. Phép biến hình trong mặt phẳng',
      grade: 11,
      lessons: [
        L('11-cd1-1', 'Bài 1. Phép biến hình', 11, 11, 'Chuyên đề 1. Phép biến hình trong mặt phẳng',
          `<p>Phép biến hình là quy tắc đặt tương ứng mỗi điểm $M$ với duy nhất một điểm $M'$.</p>`, [], []),
        L('11-cd1-2', 'Bài 2. Phép tịnh tiến', 11, 11, 'Chuyên đề 1. Phép biến hình trong mặt phẳng',
          `<p>Phép tịnh tiến theo vectơ $\\vec{v}$: $\\overrightarrow{MM'}=\\vec{v}$.</p>`,
          ['M\'(x+a; y+b)\\ \\text{nếu } \\vec{v}=(a;b)'], []),
        L('11-cd1-3', 'Bài 3. Phép đối xứng trục', 11, 11, 'Chuyên đề 1. Phép biến hình trong mặt phẳng',
          `<p>Phép đối xứng qua trục $\\Delta$: $\\Delta$ là đường trung trực của $MM'$.</p>`, [], []),
        L('11-cd1-4', 'Bài 4. Phép quay và phép đối xứng tâm', 11, 11, 'Chuyên đề 1. Phép biến hình trong mặt phẳng',
          `<p>Phép quay tâm $O$ góc $\\varphi$; phép đối xứng tâm $O$ (quay $180^\\circ$).</p>`, [], []),
        L('11-cd1-5', 'Bài 5. Phép dời hình', 11, 11, 'Chuyên đề 1. Phép biến hình trong mặt phẳng',
          `<p>Phép dời hình bảo toàn khoảng cách giữa mọi cặp điểm.</p>`, [],
          ['Tịnh tiến, đối xứng trục, quay, đối xứng tâm đều là phép dời hình.']),
        L('11-cd1-6', 'Bài 6. Phép vị tự', 11, 11, 'Chuyên đề 1. Phép biến hình trong mặt phẳng',
          `<p>Phép vị tự tâm $O$ tỉ số $k$: $\\overrightarrow{OM'}=k\\overrightarrow{OM}$.</p>`,
          ['|k| \\ne 1:\\ \\text{ không phải phép dời hình}'], []),
        L('11-cd1-7', 'Bài 7. Phép đồng dạng', 11, 11, 'Chuyên đề 1. Phép biến hình trong mặt phẳng',
          `<p>Phép đồng dạng = phép vị tự kết hợp phép dời hình; bảo toàn tỉ số khoảng cách.</p>`, [], []),
        L('11-cd1-bt', 'Bài tập cuối chuyên đề 1', 11, 11, 'Chuyên đề 1. Phép biến hình trong mặt phẳng',
          `<p>Ôn tập các phép biến hình trong mặt phẳng.</p>`, [], [])
      ]
    },
    {
      title: 'Chuyên đề 2. Làm quen với một vài khái niệm của lí thuyết đồ thị',
      grade: 11,
      lessons: [
        L('11-cd2-1', 'Bài 8. Một số khái niệm cơ bản', 11, 12, 'Chuyên đề 2. Làm quen với một vài khái niệm của lí thuyết đồ thị',
          `<p>Đỉnh, cạnh, đường đi, chu trình; đồ thị vô hướng / có hướng; bậc của đỉnh.</p>`, [], []),
        L('11-cd2-2', 'Bài 9. Đường đi Euler và đường đi Hamilton', 11, 12, 'Chuyên đề 2. Làm quen với một vài khái niệm của lí thuyết đồ thị',
          `<p>Đường Euler: đi qua mỗi cạnh đúng một lần. Đường Hamilton: đi qua mỗi đỉnh đúng một lần.</p>`, [],
          ['Đồ thị liên thông có đường Euler đóng $\\Leftrightarrow$ mọi đỉnh bậc chẵn.']),
        L('11-cd2-3', 'Bài 10. Bài toán tìm đường đi tối ưu trong một vài trường hợp đơn giản', 11, 12, 'Chuyên đề 2. Làm quen với một vài khái niệm của lí thuyết đồ thị',
          `<p>Thuật toán đơn giản tìm đường đi ngắn nhất trên đồ thị có trọng số nhỏ.</p>`, [], []),
        L('11-cd2-bt', 'Bài tập cuối chuyên đề 2', 11, 12, 'Chuyên đề 2. Làm quen với một vài khái niệm của lí thuyết đồ thị',
          `<p>Ôn tập khái niệm đồ thị, Euler, Hamilton và đường đi tối ưu.</p>`, [], [])
      ]
    },
    {
      title: 'Chuyên đề 3. Một số yếu tố vẽ kĩ thuật',
      grade: 11,
      lessons: [
        L('11-cd3-1', 'Bài 11. Hình chiếu vuông góc và hình chiếu trục đo', 11, 13, 'Chuyên đề 3. Một số yếu tố vẽ kĩ thuật',
          `<p>Hình chiếu vuông góc (các mặt); hình chiếu trục đo (isometric, dimetric).</p>`, [], []),
        L('11-cd3-2', 'Bài 12. Bản vẽ kĩ thuật', 11, 13, 'Chuyên đề 3. Một số yếu tố vẽ kĩ thuật',
          `<p>Đọc và vẽ bản vẽ kĩ thuật đơn giản: kích thước, tỉ lệ, ký hiệu.</p>`, [], []),
        L('11-cd3-bt', 'Bài tập cuối chuyên đề 3', 11, 13, 'Chuyên đề 3. Một số yếu tố vẽ kĩ thuật',
          `<p>Ôn tập hình chiếu và bản vẽ kĩ thuật.</p>`, [], [])
      ]
    }
  ],

  // =====================================================================
  // LỚP 12
  // =====================================================================
  12: [
    {
      title: 'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị hàm số',
      grade: 12,
      lessons: [
        L(
          '12-1',
          'Bài 1. Tính đơn điệu và cực trị của hàm số',
          12,
          0,
          'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị hàm số',
          `<p>Cho hàm số $y=f(x)$ có đạo hàm trên khoảng $K$. Nếu $f'(x)\\ge 0$ với mọi $x\\in K$ (bằng 0 tại hữu hạn điểm) thì $f$ đồng biến trên $K$.</p>
           <p>Điểm $x_0$ là điểm cực trị nếu $f'(x)$ đổi dấu khi $x$ đi qua $x_0$.</p>`,
          [
            'f\'(x)>0\\ (\\forall x\\in K)\\Rightarrow f\\text{ đồng biến trên }K',
            'f\'(x)<0\\ (\\forall x\\in K)\\Rightarrow f\\text{ nghịch biến trên }K',
            'f\'(x_0)=0,\\ f\'\'(x_0)<0\\Rightarrow x_0\\text{ cực đại}',
            'f\'(x_0)=0,\\ f\'\'(x_0)>0\\Rightarrow x_0\\text{ cực tiểu}'
          ],
          [
            'Hàm phân thức $y=\\frac{ax+b}{cx+d}$ có $y\'=\\frac{ad-bc}{(cx+d)^2}$, luôn đơn điệu trên từng khoảng xác định.',
            'Phân biệt: điểm cực trị $x_0$, giá trị cực trị $y_0$, điểm cực trị trên đồ thị $M(x_0;y_0)$.'
          ],
          'cubic',
          { a: 1, b: 0, c: -3, d: 2 }
        ),
        L(
          '12-2',
          'Bài 2. Giá trị lớn nhất và giá trị nhỏ nhất của hàm số',
          12,
          0,
          'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị hàm số',
          `<p>Trên đoạn $[a;b]$: tính $f(a), f(b)$ và $f(x_i)$ tại các nghiệm $x_i\\in[a;b]$ của $f'(x)=0$; so sánh.</p>`,
          [
            '\\max_{[a;b]} f = \\max\\{f(a),f(b),f(x_1),\\dots\\}',
            '\\min_{[a;b]} f = \\min\\{f(a),f(b),f(x_1),\\dots\\}'
          ],
          [
            'Trên khoảng mở hoặc $\\mathbb{R}$: xét giới hạn tại biên và cực trị.',
            'Ứng dụng thực tế: thiết lập hàm mục tiêu, tìm điều kiện biến.'
          ],
          'appliedMaxMin'
        ),
        L(
          '12-3',
          'Bài 3. Đường tiệm cận của đồ thị hàm số',
          12,
          0,
          'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị hàm số',
          `<p>Tiệm cận đứng: $\\lim_{x\\to x_0^\\pm} y=\\pm\\infty \\Rightarrow x=x_0$ là TCĐ.</p>
           <p>Tiệm cận ngang: $\\lim_{x\\to\\pm\\infty} y=y_0 \\Rightarrow y=y_0$ là TCN.</p>
           <p>Tiệm cận xiên: $y=ax+b$ khi $\\lim_{x\\to\\pm\\infty}[f(x)-(ax+b)]=0$.</p>`,
          [
            'y=\\frac{ax+b}{cx+d}\\Rightarrow\\text{TCĐ: }x=-\\frac{d}{c},\\ \\text{TCN: }y=\\frac{a}{c}',
            'y=\\frac{ax^2+bx+c}{px+q}=mx+n+\\frac{r}{px+q}\\Rightarrow\\text{TCX: }y=mx+n'
          ],
          [
            'Tâm đối xứng của đồ thị hàm phân thức bậc nhất: $I\\big(-\\frac{d}{c};\\frac{a}{c}\\)$.'
          ],
          'rational',
          { a: 2, b: 1, c: 1, d: -1, caption: 'Đồ thị hàm số y = (2x + 1)/(x − 1)' }
        ),
        L(
          '12-4',
          'Bài 4. Khảo sát sự biến thiên và vẽ đồ thị của hàm số',
          12,
          0,
          'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị hàm số',
          `<p>Quy trình khảo sát: TXĐ → chiều biến thiên (bảng biến thiên) → cực trị → tiệm cận → đồ thị.</p>
           <p>Các dạng: bậc ba, bậc bốn trùng phương, phân thức bậc nhất/bậc hai.</p>`,
          [
            'y=ax^3+bx^2+cx+d',
            'y=ax^4+bx^2+c',
            'y=\\frac{ax+b}{cx+d}'
          ],
          [
            'Vẽ đúng tiệm cận trước, rồi các điểm đặc biệt, sau đó nối nhánh.'
          ],
          'cubic'
        ),
        L(
          '12-5',
          'Bài 5. Ứng dụng đạo hàm để giải quyết một số vấn đề liên quan đến thực tiễn',
          12,
          0,
          'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị hàm số',
          `<p>Bài toán tối ưu: thể tích, diện tích, chi phí, khoảng cách — thiết lập hàm số rồi tìm GTLN/GTNN.</p>`,
          [],
          [
            'Xác định biến, hàm mục tiêu, điều kiện ràng buộc (tập xác định thực tế).'
          ],
          'appliedMaxMin'
        ),
        L(
          '12-1-bt',
          'Bài tập cuối chương I',
          12,
          0,
          'Chương I. Ứng dụng đạo hàm để khảo sát và vẽ đồ thị hàm số',
          `<p>Ôn tập đơn điệu, cực trị, GTLN/GTNN, tiệm cận và khảo sát hàm số.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chương II. Vectơ và hệ trục tọa độ trong không gian',
      grade: 12,
      lessons: [
        L(
          '12-6',
          'Bài 6. Vectơ trong không gian',
          12,
          1,
          'Chương II. Vectơ và hệ trục tọa độ trong không gian',
          `<p>Vectơ trong không gian: tổng, hiệu, tích với số; tích vô hướng.</p>`,
          [
            '\\vec{u}\\cdot\\vec{v}=|\\vec{u}|\\,|\\vec{v}|\\cos(\\vec{u},\\vec{v})',
            '\\vec{u}\\perp\\vec{v}\\Leftrightarrow\\vec{u}\\cdot\\vec{v}=0'
          ],
          ['Quy tắc hình hộp: $\\vec{AB}+\\vec{AD}+\\vec{AA\'}=\\vec{AC\'}$.']
        ),
        L(
          '12-7',
          'Bài 7. Hệ trục tọa độ trong không gian',
          12,
          1,
          'Chương II. Vectơ và hệ trục tọa độ trong không gian',
          `<p>Hệ $Oxyz$: $M(x;y;z)\\Leftrightarrow\\vec{OM}=x\\vec{i}+y\\vec{j}+z\\vec{k}$.</p>`,
          [
            '|\\vec{u}|=\\sqrt{u_1^2+u_2^2+u_3^2}',
            '\\vec{u}\\cdot\\vec{v}=u_1v_1+u_2v_2+u_3v_3',
            'd(A,B)=\\sqrt{(x_B-x_A)^2+(y_B-y_A)^2+(z_B-z_A)^2}'
          ],
          ['Tọa độ trung điểm, trọng tâm tương tự mặt phẳng.']
        ),
        L(
          '12-8',
          'Bài 8. Biểu thức tọa độ của các phép toán vectơ',
          12,
          1,
          'Chương II. Vectơ và hệ trục tọa độ trong không gian',
          `<p>Biểu thức tọa độ của tổng, hiệu, tích vô hướng; điều kiện đồng phẳng, vuông góc, song song.</p>`,
          [
            '\\vec{u}=k\\vec{v}\\Leftrightarrow\\frac{u_1}{v_1}=\\frac{u_2}{v_2}=\\frac{u_3}{v_3}',
            '[\\vec{u},\\vec{v},\\vec{w}]=0\\Leftrightarrow\\text{ đồng phẳng}'
          ],
          ['Tích có hướng (vector product) dùng khi cần pháp tuyến.']
        ),
        L(
          '12-2-bt',
          'Bài tập cuối chương II',
          12,
          1,
          'Chương II. Vectơ và hệ trục tọa độ trong không gian',
          `<p>Ôn tập vectơ và tọa độ trong không gian.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chương III. Các số đặc trưng đo mức độ phân tán của mẫu số liệu ghép nhóm',
      grade: 12,
      lessons: [
        L(
          '12-9',
          'Bài 9. Khoảng biến thiên và khoảng tứ phân vị',
          12,
          2,
          'Chương III. Các số đặc trưng đo mức độ phân tán của mẫu số liệu ghép nhóm',
          `<p>Khoảng biến thiên $R=x_{\\max}-x_{\\min}$; khoảng tứ phân vị $Q=Q_3-Q_1$ của mẫu ghép nhóm.</p>`,
          [
            'R = x_{\\max}-x_{\\min}',
            'Q = Q_3 - Q_1'
          ],
          ['$Q$ ít bị ảnh hưởng bởi giá trị ngoại lai hơn $R$.'],
          'histogram'
        ),
        L(
          '12-10',
          'Bài 10. Phương sai và độ lệch chuẩn',
          12,
          2,
          'Chương III. Các số đặc trưng đo mức độ phân tán của mẫu số liệu ghép nhóm',
          `<p>Phương sai và độ lệch chuẩn của mẫu ghép nhóm.</p>`,
          [
            's^2 = \\frac{1}{n}\\sum n_i(x_i-\\bar{x})^2',
            's = \\sqrt{s^2}'
          ],
          ['Độ lệch chuẩn cùng đơn vị với số liệu gốc.']
        ),
        L(
          '12-3-bt',
          'Bài tập cuối chương III',
          12,
          2,
          'Chương III. Các số đặc trưng đo mức độ phân tán của mẫu số liệu ghép nhóm',
          `<p>Ôn tập khoảng biến thiên, tứ phân vị, phương sai và độ lệch chuẩn.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Hoạt động thực hành trải nghiệm (Lớp 12 – Học kì 1)',
      grade: 12,
      lessons: [
        L(
          '12-tn1',
          'Khảo sát và vẽ đồ thị hàm số với phần mềm GeoGebra',
          12,
          3,
          'Hoạt động thực hành trải nghiệm (Lớp 12 – Học kì 1)',
          `<p>Dùng GeoGebra khảo sát chiều biến thiên, cực trị, tiệm cận và vẽ đồ thị các hàm số thường gặp.</p>`,
          [],
          ['Đối chiếu kết quả phần mềm với bảng biến thiên thủ công.']
        ),
        L(
          '12-tn2',
          'Vẽ vectơ tổng của ba vectơ trong không gian bằng phần mềm GeoGebra',
          12,
          3,
          'Hoạt động thực hành trải nghiệm (Lớp 12 – Học kì 1)',
          `<p>Biểu diễn và tính tổng ba vectơ trong không gian 3D với GeoGebra.</p>`,
          [],
          []
        ),
        L(
          '12-tn3',
          'Độ dài gang tay (gang tay của bạn dài bao nhiêu?)',
          12,
          3,
          'Hoạt động thực hành trải nghiệm (Lớp 12 – Học kì 1)',
          `<p>Thu thập số liệu độ dài gang tay lớp học; tính các số đặc trưng và vẽ biểu đồ.</p>`,
          [],
          ['Áp dụng thống kê mô tả đã học.']
        )
      ]
    },
    {
      title: 'Chương IV. Nguyên hàm và tích phân',
      grade: 12,
      lessons: [
        L(
          '12-11',
          'Bài 11. Nguyên hàm',
          12,
          4,
          'Chương IV. Nguyên hàm và tích phân',
          `<p>$F$ là nguyên hàm của $f$ trên $K$ nếu $F'(x)=f(x)$ với mọi $x\\in K$. Ký hiệu $\\int f(x)\\,dx=F(x)+C$.</p>`,
          [
            '\\int x^\\alpha dx = \\frac{x^{\\alpha+1}}{\\alpha+1}+C\\ (\\alpha\\ne -1)',
            '\\int \\frac{1}{x}dx = \\ln|x|+C',
            '\\int e^x dx = e^x+C',
            '\\int \\sin x\\,dx = -\\cos x+C'
          ],
          [
            'Nguyên hàm của tổng = tổng nguyên hàm; $\\int kf = k\\int f$.',
            'Phương pháp đổi biến và tích phân từng phần.'
          ]
        ),
        L(
          '12-12',
          'Bài 12. Tích phân',
          12,
          4,
          'Chương IV. Nguyên hàm và tích phân',
          `<p>Tích phân xác định: $\\int_a^b f(x)\\,dx = F(b)-F(a)$ (công thức Newton–Leibniz).</p>`,
          [
            '\\int_a^b f(x)\\,dx = F(b)-F(a)',
            '\\int_a^b f = -\\int_b^a f',
            '\\int_a^b f + \\int_b^c f = \\int_a^c f'
          ],
          ['Tính chất tuyến tính; đổi cận khi đổi biến.']
        ),
        L(
          '12-13',
          'Bài 13. Ứng dụng hình học của tích phân',
          12,
          4,
          'Chương IV. Nguyên hàm và tích phân',
          `<p>Diện tích hình phẳng: $S=\\int_a^b |f(x)-g(x)|\\,dx$. Thể tích khối tròn xoay: $V=\\pi\\int_a^b [f(x)]^2 dx$.</p>`,
          [
            'S = \\int_a^b |f(x)|\\,dx',
            'V = \\pi\\int_a^b [f(x)]^2 dx'
          ],
          ['Xác định đúng cận và hàm dưới dấu tích phân theo hình.'],
          'integral'
        ),
        L(
          '12-4-bt',
          'Bài tập cuối chương IV',
          12,
          4,
          'Chương IV. Nguyên hàm và tích phân',
          `<p>Ôn tập nguyên hàm, tích phân và ứng dụng hình học.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chương V. Phương pháp tọa độ trong không gian',
      grade: 12,
      lessons: [
        L(
          '12-14',
          'Bài 14. Phương trình mặt phẳng',
          12,
          5,
          'Chương V. Phương pháp tọa độ trong không gian',
          `<p>Mặt phẳng qua $M_0(x_0;y_0;z_0)$ có VTPT $\\vec{n}=(a;b;c)$: $a(x-x_0)+b(y-y_0)+c(z-z_0)=0$.</p>`,
          [
            'ax+by+cz+d=0',
            'd(M_0,(\\alpha))=\\frac{|ax_0+by_0+cz_0+d|}{\\sqrt{a^2+b^2+c^2}}'
          ],
          ['Hai mặt phẳng song song / vuông góc theo $\\vec{n}_1,\\vec{n}_2$.']
        ),
        L(
          '12-15',
          'Bài 15. Phương trình đường thẳng trong không gian',
          12,
          5,
          'Chương V. Phương pháp tọa độ trong không gian',
          `<p>Đường thẳng qua $M_0$ có VTCP $\\vec{u}=(a;b;c)$: phương trình tham số / chính tắc.</p>`,
          [
            '\\frac{x-x_0}{a}=\\frac{y-y_0}{b}=\\frac{z-z_0}{c}',
            'x=x_0+at,\\ y=y_0+bt,\\ z=z_0+ct'
          ],
          ['Vị trí tương đối hai đường thẳng: song song, cắt, chéo, trùng.']
        ),
        L(
          '12-16',
          'Bài 16. Công thức tính góc trong không gian',
          12,
          5,
          'Chương V. Phương pháp tọa độ trong không gian',
          `<p>Góc giữa hai đường thẳng, giữa đường thẳng và mặt phẳng, giữa hai mặt phẳng.</p>`,
          [
            '\\cos\\varphi = \\frac{|\\vec{u}\\cdot\\vec{v}|}{|\\vec{u}|\\,|\\vec{v}|}',
            '\\sin\\varphi = \\frac{|\\vec{u}\\cdot\\vec{n}|}{|\\vec{u}|\\,|\\vec{n}|}\\ (d\\text{ và }(\\alpha))',
            '\\cos\\varphi = \\frac{|\\vec{n}_1\\cdot\\vec{n}_2|}{|\\vec{n}_1|\\,|\\vec{n}_2|}'
          ],
          ['Lấy trị tuyệt đối khi góc hình học $\\in[0;90^\\circ]$.']
        ),
        L(
          '12-17',
          'Bài 17. Phương trình mặt cầu',
          12,
          5,
          'Chương V. Phương pháp tọa độ trong không gian',
          `<p>Mặt cầu tâm $I(a;b;c)$ bán kính $R$: $(x-a)^2+(y-b)^2+(z-c)^2=R^2$.</p>`,
          [
            '(x-a)^2+(y-b)^2+(z-c)^2=R^2',
            'x^2+y^2+z^2+Dx+Ey+Fz+G=0'
          ],
          [
            'Vị trí tương đối mặt cầu và mặt phẳng / đường thẳng theo $d(I,\\cdot)$ so với $R$.'
          ]
        ),
        L(
          '12-5-bt',
          'Bài tập cuối chương V',
          12,
          5,
          'Chương V. Phương pháp tọa độ trong không gian',
          `<p>Ôn tập phương trình mặt phẳng, đường thẳng, góc và mặt cầu.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chương VI. Xác suất có điều kiện',
      grade: 12,
      lessons: [
        L(
          '12-18',
          'Bài 18. Xác suất có điều kiện',
          12,
          6,
          'Chương VI. Xác suất có điều kiện',
          `<p>$P(A|B)=\\frac{P(A\\cap B)}{P(B)}$ ($P(B)>0$). Công thức nhân tổng quát.</p>`,
          [
            'P(A|B)=\\frac{P(A\\cap B)}{P(B)}',
            'P(A\\cap B)=P(B)\\cdot P(A|B)=P(A)\\cdot P(B|A)'
          ],
          ['Nếu $A,B$ độc lập thì $P(A|B)=P(A)$.']
        ),
        L(
          '12-19',
          'Bài 19. Công thức xác suất toàn phần và công thức Bayes',
          12,
          6,
          'Chương VI. Xác suất có điều kiện',
          `<p>Hệ đầy đủ biến cố $\\{B_i\\}$: $P(A)=\\sum P(B_i)P(A|B_i)$. Công thức Bayes cập nhật xác suất.</p>`,
          [
            'P(A)=\\sum_i P(B_i)P(A|B_i)',
            'P(B_k|A)=\\frac{P(B_k)P(A|B_k)}{\\sum_i P(B_i)P(A|B_i)}'
          ],
          ['Bayes: từ “kết quả quan sát được” suy ngược xác suất nguyên nhân.']
        ),
        L(
          '12-6-bt',
          'Bài tập cuối chương VI',
          12,
          6,
          'Chương VI. Xác suất có điều kiện',
          `<p>Ôn tập xác suất có điều kiện, công thức toàn phần và Bayes.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Hoạt động thực hành trải nghiệm (Lớp 12 – Học kì 2)',
      grade: 12,
      lessons: [
        L(
          '12-tn4',
          'Tính nguyên hàm và tích phân với phần mềm GeoGebra',
          12,
          7,
          'Hoạt động thực hành trải nghiệm (Lớp 12 – Học kì 2)',
          `<p>Dùng GeoGebra / CAS tính nguyên hàm, tích phân xác định và kiểm tra kết quả thủ công.</p>`,
          [],
          []
        ),
        L(
          '12-tn5',
          'Tính gần đúng tích phân bằng phương pháp hình thang',
          12,
          7,
          'Hoạt động thực hành trải nghiệm (Lớp 12 – Học kì 2)',
          `<p>Công thức hình thang: chia đoạn $[a;b]$ thành $n$ phần bằng nhau.</p>`,
          [
            '\\int_a^b f(x)\\,dx \\approx \\frac{h}{2}\\big(y_0+2y_1+\\cdots+2y_{n-1}+y_n\\big),\\ h=\\frac{b-a}{n}'
          ],
          ['Sai số giảm khi $n$ tăng.']
        ),
        L(
          '12-tn6',
          'Vẽ đồ họa 3D với phần mềm GeoGebra',
          12,
          7,
          'Hoạt động thực hành trải nghiệm (Lớp 12 – Học kì 2)',
          `<p>Vẽ mặt phẳng, đường thẳng, mặt cầu trong không gian 3D; quan sát góc và khoảng cách.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chuyên đề 1. Biến ngẫu nhiên rời rạc. Các số đặc trưng của biến ngẫu nhiên rời rạc',
      grade: 12,
      lessons: [
        L(
          '12-cd1-1',
          'Bài 1. Biến ngẫu nhiên rời rạc và các số đặc trưng',
          12,
          8,
          'Chuyên đề 1. Biến ngẫu nhiên rời rạc. Các số đặc trưng của biến ngẫu nhiên rời rạc',
          `<p>Biến ngẫu nhiên rời rạc $X$: bảng phân phối xác suất; kỳ vọng $E(X)$, phương sai $V(X)$.</p>`,
          [
            'E(X)=\\sum x_i p_i',
            'V(X)=E(X^2)-[E(X)]^2',
            '\\sigma(X)=\\sqrt{V(X)}'
          ],
          ['$\\sum p_i=1$; $0\\le p_i\\le 1$.']
        ),
        L(
          '12-cd1-2',
          'Bài 2. Biến ngẫu nhiên có phân bố nhị thức và áp dụng',
          12,
          8,
          'Chuyên đề 1. Biến ngẫu nhiên rời rạc. Các số đặc trưng của biến ngẫu nhiên rời rạc',
          `<p>$X\\sim B(n,p)$: $P(X=k)=C_n^k p^k(1-p)^{n-k}$. $E(X)=np$, $V(X)=np(1-p)$.</p>`,
          [
            'P(X=k)=C_n^k p^k (1-p)^{n-k}',
            'E(X)=np,\\quad V(X)=np(1-p)'
          ],
          ['Mô hình: $n$ phép thử Bernoulli độc lập, xác suất thành công $p$.']
        ),
        L(
          '12-cd1-bt',
          'Bài tập cuối chuyên đề 1',
          12,
          8,
          'Chuyên đề 1. Biến ngẫu nhiên rời rạc. Các số đặc trưng của biến ngẫu nhiên rời rạc',
          `<p>Ôn tập biến ngẫu nhiên rời rạc và phân bố nhị thức.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chuyên đề 2. Ứng dụng toán học để giải quyết một số bài toán tối ưu',
      grade: 12,
      lessons: [
        L(
          '12-cd2-1',
          'Bài 3. Vận dụng hệ bất phương trình bậc nhất hai ẩn để giải quyết một số bài toán quy hoạch tuyến tính',
          12,
          9,
          'Chuyên đề 2. Ứng dụng toán học để giải quyết một số bài toán tối ưu',
          `<p>Bài toán quy hoạch tuyến tính hai biến: miền nghiệm đa giác; hàm mục tiêu đạt cực trị tại đỉnh.</p>`,
          [
            '\\max/\\min F=ax+by\\ \\text{ trên miền } D'
          ],
          ['Vẽ miền $D$, tính $F$ tại các đỉnh, chọn giá trị tối ưu.']
        ),
        L(
          '12-cd2-2',
          'Bài 4. Vận dụng đạo hàm để giải quyết một số bài toán tối ưu',
          12,
          9,
          'Chuyên đề 2. Ứng dụng toán học để giải quyết một số bài toán tối ưu',
          `<p>Thiết lập hàm một biến từ điều kiện thực tế; dùng đạo hàm tìm GTLN/GTNN.</p>`,
          [],
          ['Xác định đúng tập xác định thực tế của biến.']
        ),
        L(
          '12-cd2-bt',
          'Bài tập cuối chuyên đề 2',
          12,
          9,
          'Chuyên đề 2. Ứng dụng toán học để giải quyết một số bài toán tối ưu',
          `<p>Ôn tập quy hoạch tuyến tính và tối ưu bằng đạo hàm.</p>`,
          [],
          []
        )
      ]
    },
    {
      title: 'Chuyên đề 3. Ứng dụng toán học trong một số vấn đề liên quan đến tài chính',
      grade: 12,
      lessons: [
        L(
          '12-cd3-1',
          'Bài 5. Tiền tệ. Lãi suất',
          12,
          10,
          'Chuyên đề 3. Ứng dụng toán học trong một số vấn đề liên quan đến tài chính',
          `<p>Lãi đơn, lãi kép; giá trị tương lai và hiện tại của tiền.</p>`,
          [
            'A = P(1+r)^n\\ (\\text{lãi kép})',
            'PV = \\frac{FV}{(1+r)^n}'
          ],
          ['Phân biệt lãi suất danh nghĩa và lãi suất thực.']
        ),
        L(
          '12-cd3-2',
          'Bài 6. Tín dụng. Vay nợ',
          12,
          10,
          'Chuyên đề 3. Ứng dụng toán học trong một số vấn đề liên quan đến tài chính',
          `<p>Khoản vay trả góp đều; công thức tính số tiền trả mỗi kỳ.</p>`,
          [
            'A = P\\cdot\\frac{r(1+r)^n}{(1+r)^n-1}'
          ],
          ['$A$: trả mỗi kỳ; $P$: số vay; $r$: lãi suất kỳ; $n$: số kỳ.']
        ),
        L(
          '12-cd3-3',
          'Bài 7. Đầu tư tài chính. Lập kế hoạch tài chính cá nhân',
          12,
          10,
          'Chuyên đề 3. Ứng dụng toán học trong một số vấn đề liên quan đến tài chính',
          `<p>Đầu tư định kỳ, quỹ hưu trí đơn giản; lập kế hoạch thu–chi cá nhân.</p>`,
          [
            'S = P\\frac{(1+r)^n-1}{r}\\ (\\text{gửi đều mỗi kỳ})'
          ],
          ['Cân đối mục tiêu dài hạn với khả năng tiết kiệm hiện tại.']
        ),
        L(
          '12-cd3-bt',
          'Bài tập cuối chuyên đề 3',
          12,
          10,
          'Chuyên đề 3. Ứng dụng toán học trong một số vấn đề liên quan đến tài chính',
          `<p>Ôn tập lãi suất, tín dụng và kế hoạch tài chính.</p>`,
          [],
          []
        )
      ]
    }
  ]
};
