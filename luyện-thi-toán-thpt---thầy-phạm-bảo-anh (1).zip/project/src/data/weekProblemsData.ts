import { WeekProblem, WeekSubmission } from '../types/math';

export const INITIAL_WEEK_PROBLEMS: WeekProblem[] = [
  {
    id: 'wk-28',
    weekNumber: 28,
    title: 'Thử thách Tuần 28: Cực trị hàm số chứa giá trị tuyệt đối liên quan đến hình học',
    grade: 12,
    type: 'short',
    content: 'Cho hàm số $f(x) = x^4 - 2mx^2 + m - 1$. Tìm số giá trị nguyên của tham số $m \\in [-10; 10]$ để đồ thị hàm số $y = |f(x)|$ có đúng $7$ điểm cực trị.',
    deadline: '23:59 Chủ Nhật tuần này',
    status: 'active',
    correctAnswer: '9',
    reward: 'Huy hiệu Thủ Khoa Tuần + Trọn bộ sách chuyên đề Toán 12 Thầy PBA',
    solution: `
      Đồ thị hàm số $y = |f(x)|$ có 7 điểm cực trị khi và chỉ khi:
      1. Đồ thị hàm số ban đầu $y = f(x)$ có 3 điểm cực trị.
      2. Đồ thị $y = f(x)$ cắt trục hoành tại 4 điểm phân biệt, tức là giá trị cực tiểu $y_{CT} < 0$ và giá trị cực đại $y_{CD} > 0$.
      - $f'(x) = 4x^3 - 4mx = 4x(x^2 - m) = 0$.
      - Hàm số có 3 cực trị $\\Leftrightarrow m > 0$.
      - Ba cực trị là $x = 0$ và $x = \\pm \\sqrt{m}$.
      - $y_{CD} = f(0) = m - 1 > 0 \\Leftrightarrow m > 1$.
      - $y_{CT} = f(\\pm \\sqrt{m}) = -m^2 + m - 1 < 0$ (luôn đúng với mọi $m$ vì $\\Delta < 0, a = -1 < 0$).
      - Do đó, điều kiện là $m > 1$.
      Vì $m \\in [-10; 10]$ và $m \\in \\mathbb{Z}$ nên $m \\in \\{2, 3, 4, 5, 6, 7, 8, 9, 10\\}$.
      Có đúng $9$ giá trị nguyên của $m$ thỏa mãn.
    `
  },
  {
    id: 'wk-27',
    weekNumber: 27,
    title: 'Thử thách Tuần 27: Xác suất chọn vé số may mắn và dãy số liên tiếp',
    grade: 11,
    type: 'short',
    content: 'Một hộp đựng $20$ tấm thẻ được đánh số từ $1$ đến $20$. Rút ngẫu nhiên đồng thời $3$ tấm thẻ. Tính xác suất để tổng ba số ghi trên $3$ thẻ rút được là một số chia hết cho $3$. Nhập kết quả dưới dạng phân số tối giản $a/b$ hoặc làm tròn 4 chữ số thập phân.',
    deadline: 'Đã kết thúc',
    status: 'ended',
    correctAnswer: '68/285',
    reward: 'Huy hiệu Á Khoa Tuần',
    solution: `
      Chia 20 số thành 3 nhóm theo số dư khi chia cho 3:
      - Nhóm dư 0 ($A_0$): {3, 6, 9, 12, 15, 18} gồm 6 số.
      - Nhóm dư 1 ($A_1$): {1, 4, 7, 10, 13, 16, 19} gồm 7 số.
      - Nhóm dư 2 ($A_2$): {2, 5, 8, 11, 14, 17, 20} gồm 7 số.
      Tổng 3 số chia hết cho 3 khi:
      - TH1: 3 số cùng thuộc $A_0$: $C_6^3 = 20$.
      - TH2: 3 số cùng thuộc $A_1$: $C_7^3 = 35$.
      - TH3: 3 số cùng thuộc $A_2$: $C_7^3 = 35$.
      - TH4: Mỗi nhóm chọn 1 số: $6 \\times 7 \\times 7 = 294$.
      Tổng số cách thuận lợi: $20 + 35 + 35 + 294 = 384$.
      Không gian mẫu: $C_{20}^3 = 1140$.
      Xác suất: $P = \\frac{384}{1140} = \\frac{68}{285} \\approx 0{,}2386$.
    `
  }
];

export const INITIAL_LEADERBOARD: WeekSubmission[] = [
  {
    id: 'sub-1',
    problemId: 'wk-28',
    studentName: 'Nguyễn Trần Minh Đức',
    studentSchool: 'THPT Chuyên Lê Hồng Phong',
    studentClass: '12 Toán 1',
    submittedAnswer: '9',
    isCorrect: true,
    score: 10,
    feedback: 'Lời giải xuất sắc! Lập luận chặt chẽ điều kiện cực trị và giao điểm.',
    submittedAt: 'Hôm qua lúc 19:42'
  },
  {
    id: 'sub-2',
    problemId: 'wk-28',
    studentName: 'Trần Hoàng Yến Vy',
    studentSchool: 'THPT Chuyên Hà Nội - Amsterdam',
    studentClass: '12A1',
    submittedAnswer: '9',
    isCorrect: true,
    score: 10,
    feedback: 'Chính xác! Trình bày rất khoa học và sạch đẹp.',
    submittedAt: 'Hôm qua lúc 20:15'
  },
  {
    id: 'sub-3',
    problemId: 'wk-28',
    studentName: 'Lê Gia Bảo',
    studentSchool: 'THPT Bùi Thị Xuân',
    studentClass: '12A3',
    submittedAnswer: '9',
    isCorrect: true,
    score: 9.5,
    feedback: 'Đúng đáp số, chú ý vẽ thêm bảng biến thiên minh họa sẽ hoàn hảo hơn.',
    submittedAt: 'Hôm nay lúc 08:30'
  }
];
