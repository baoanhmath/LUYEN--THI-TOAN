import { Grade, QuestionGenerated, TrueFalseStatement } from '../types/math';
import { normalizeQuestionContent, normalizeMathContent } from '../utils/mathNormalize';

function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randNonZero(min: number, max: number): number {
  let val = 0;
  while (val === 0) {
    val = randInt(min, max);
  }
  return val;
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function shuffle<T>(arr: T[]): T[] {
  const result = [...arr];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

// -------------------------------------------------------------
// QUESTION GENERATORS BY TOPIC
// -------------------------------------------------------------

export interface GeneratorDef {
  id: string;
  topicTitle: string;
  grade: Grade;
  generate: () => QuestionGenerated;
}

export const TOPIC_GENERATORS: Record<string, GeneratorDef> = {
  // 10-1: Mệnh đề phủ định
  '10-1': {
    id: '10-1',
    topicTitle: 'Phủ định mệnh đề chứa $\\forall, \\exists$',
    grade: 10,
    generate: () => {
      const a = randNonZero(-5, 5);
      const isForall = Math.random() > 0.5;
      const op = pick(['>', '<', '\\ge', '\\le']);
      const signStr = a > 0 ? `+ ${a}` : `- ${Math.abs(a)}`;

      const negOpMap: Record<string, string> = {
        '>': '\\le',
        '<': '\\ge',
        '\\ge': '<',
        '\\le': '>'
      };
      const negOp = negOpMap[op];

      const quant = isForall ? '\\forall' : '\\exists';
      const negQuant = isForall ? '\\exists' : '\\forall';

      const originalProp = `${quant} x \\in \\mathbb{R}, \\ x^2 ${signStr} ${op} 0`;
      const correctNeg = `${negQuant} x \\in \\mathbb{R}, \\ x^2 ${signStr} ${negOp} 0`;

      const w1 = `${quant} x \\in \\mathbb{R}, \\ x^2 ${signStr} ${negOp} 0`;
      const w2 = `${negQuant} x \\in \\mathbb{R}, \\ x^2 ${signStr} ${op} 0`;
      const w3 = `${negQuant} x \\in \\mathbb{R}, \\ x^2 ${signStr} = 0`;

      const tf: TrueFalseStatement[] = [
        {
          text: `Mệnh đề phủ định của $P$ chứa lượng từ "${negQuant === '\\exists' ? '\\exists' : '\\forall'}".`,
          isTrue: true,
          explanation: `Phủ định của lượng từ $\\${quant}$ là lượng từ $\\${negQuant}$.`
        },
        {
          text: `Mệnh đề phủ định của $P$ là $${quant} x \\in \\mathbb{R}, x^2 ${signStr} ${negOp} 0$.`,
          isTrue: false,
          explanation: `Sai vì chưa phủ định lượng từ $\\${quant}$ thành $\\${negQuant}$.`
        },
        {
          text: `Với $x = 0$, biểu thức $x^2 ${signStr}$ nhận giá trị bằng $${a}$.`,
          isTrue: true,
          explanation: `Thay $x = 0$ ta được $0^2 ${signStr} = ${a}$.`
        },
        {
          text: `Nếu $P$ là mệnh đề đúng thì phủ định $\\overline{P}$ cũng luôn là mệnh đề đúng.`,
          isTrue: false,
          explanation: `Theo định nghĩa, hai mệnh đề $P$ và $\\overline{P}$ có giá trị chân lí trái ngược nhau.`
        }
      ];

      return {
        id: `gen-10-1-${Date.now()}-${Math.random()}`,
        topicTitle: 'Phủ định mệnh đề chứa $\\forall, \\exists$',
        grade: 10,
        context: `Cho mệnh đề $P: "${originalProp}"$.`,
        ask: 'Tìm mệnh đề phủ định $\\overline{P}$ của mệnh đề $P$.',
        correctOption: `$${correctNeg}$`,
        distractors: [`$${w1}$`, `$${w2}$`, `$${w3}$`],
        tfStatements: tf,
        shortAnswer: `${a}`,
        shortAnswerPrompt: `Tính giá trị của biểu thức $x^2 ${signStr}$ tại $x = 0$.`,
        solution: `Phủ định của lượng từ $\\${quant}$ là $\\${negQuant}$; phủ định của quan hệ so sánh $${op}$ là $${negOp}$. Do đó mệnh đề phủ định là $\\overline{P}: "${correctNeg}"$.`
      };
    }
  },

  // 10-2: Tập hợp & Phép toán khoảng đoạn
  '10-2': {
    id: '10-2',
    topicTitle: 'Giao, hợp và hiệu các khoảng, đoạn',
    grade: 10,
    generate: () => {
      // Guarantee a < c < b < d strictly:
      const a = randInt(-6, -3);
      const c = randInt(-2, 1);
      const b = randInt(2, 5);
      const d = randInt(6, 9);

      // A = [a, b], B = (c, d)
      // Since a < c < b < d, intersection is strictly (c, b]
      const intersection = `(${c}; ${b}]`;
      const union = `[${a}; ${d})`;
      const diff = `[${a}; ${c}]`;

      const tf: TrueFalseStatement[] = [
        {
          text: `Tập hợp $A \\cap B = (${c}; ${b}]$.`,
          isTrue: true,
          explanation: `Vì $x \\in A \\cap B \\Leftrightarrow a \\le x \\le b$ và $c < x < d$, suy ra $c < x \\le b$.`
        },
        {
          text: `Số phần tử nguyên thuộc $A \\cap B$ là hữu hạn.`,
          isTrue: true,
          explanation: `Trong nửa khoảng $(c; b]$, số phần tử nguyên luôn là hữu hạn.`
        },
        {
          text: `Số $${d}$ thuộc tập hợp $B$.`,
          isTrue: false,
          explanation: `Khoảng $B = (${c}; ${d})$ là khoảng mở tại đầu mút $${d}$, nên $${d} \\notin B$.`
        },
        {
          text: `Tập hợp $A \\cup B = [${a}; ${d})$.`,
          isTrue: true,
          explanation: `Hợp của hai tập hợp là phần từ nhỏ nhất $${a}$ đến lớn nhất $${d}$.`
        }
      ];

      return normalizeQuestionContent({
        id: `gen-10-2-${Date.now()}`,
        topicTitle: 'Giao và hợp của khoảng, đoạn',
        grade: 10,
        context: `Cho hai tập hợp $A = [${a}; ${b}]$ và $B = (${c}; ${d})$.`,
        ask: 'Tìm tập hợp $A \\cap B$.',
        correctOption: `$(${c}; ${b}]$`,
        distractors: [`$[${a}; ${d})$`, `$[${a}; ${c}]$`, `$(${c}; ${d})$`],
        tfStatements: tf,
        shortAnswer: `${b - c}`,
        shortAnswerPrompt: `Tính độ dài khoảng giao $A \\cap B$ (lấy đầu mút phải trừ đầu mút trái: $b - c$):`,
        solution: `Biểu diễn trên trục số:\n- $A = [${a}; ${b}]$\n- $B = (${c}; ${d})$\nPhần chung của cả hai tập hợp là khoảng giao: $A \\cap B = (${c}; ${b}]$.`,
        diagram: { type: 'numberLine' }
      });
    }
  },

  // 10-5: Hệ thức lượng trong tam giác
  '10-5': {
    id: '10-5',
    topicTitle: 'Định lí côsin và diện tích tam giác',
    grade: 10,
    generate: () => {
      const b = randInt(4, 8);
      const c = randInt(5, 9);
      const angle = 60; // cos 60 = 0.5
      // a^2 = b^2 + c^2 - 2bc * cos 60 = b^2 + c^2 - bc
      const a2 = b * b + c * c - b * c;
      const S = (0.5 * b * c * Math.sqrt(3)) / 2;

      return {
        id: `gen-10-5-${Date.now()}`,
        topicTitle: 'Định lí côsin trong tam giác',
        grade: 10,
        context: `Tam giác $ABC$ có cạnh $b = AC = ${b}$, cạnh $c = AB = ${c}$ và góc $\\widehat{A} = 60^\\circ$.`,
        ask: 'Tính bình phương độ dài cạnh $a = BC$ ($a^2$).',
        correctOption: `$${a2}$`,
        distractors: [`$${a2 + 2 * b * c}$`, `$${b * b + c * c}$`, `$${a2 - 12}$`],
        tfStatements: [
          {
            text: `Theo định lí côsin, $a^2 = b^2 + c^2 - 2bc\\cos A$.`,
            isTrue: true,
            explanation: `Đây là công thức định lí côsin chuẩn trong tam giác.`
          },
          {
            text: `Giá trị $\\cos 60^\\circ = \\frac{\\sqrt{3}}{2}$.`,
            isTrue: false,
            explanation: `Sai, vì $\\cos 60^\\circ = \\frac{1}{2}$.`
          },
          {
            text: `Bình phương cạnh $BC$ là $a^2 = ${a2}$.`,
            isTrue: true,
            explanation: `Thay số: $a^2 = ${b}^2 + ${c}^2 - 2 \\cdot ${b} \\cdot ${c} \\cdot \\frac{1}{2} = ${a2}$.`
          },
          {
            text: `Diện tích tam giác $ABC$ tính theo công thức $S = \\frac{1}{2}bc\\sin A$.`,
            isTrue: true,
            explanation: `Đúng, $S = \\frac{1}{2} \\cdot ${b} \\cdot ${c} \\cdot \\sin 60^\\circ$.`
          }
        ],
        shortAnswer: `${a2}`,
        shortAnswerPrompt: `Nhập giá trị $BC^2$:`,
        solution: `Áp dụng định lí côsin:\n$$BC^2 = AB^2 + AC^2 - 2 \\cdot AB \\cdot AC \\cdot \\cos A$$\n$$BC^2 = ${c}^2 + ${b}^2 - 2 \\cdot ${c} \\cdot ${b} \\cdot \\cos 60^\\circ = ${c * c} + ${b * b} - ${b * c} = ${a2}.$$`
      };
    }
  },

  // 11-1: Giá trị lượng giác
  '11-1': {
    id: '11-1',
    topicTitle: 'Giá trị lượng giác của góc và công thức cộng',
    grade: 11,
    generate: () => {
      // sin x = 3/5 with x in (0, pi/2)
      const isFirstQuadrant = true;
      const sinVal = '3/5';
      const cosVal = '4/5';
      const sin2Val = '24/25';
      const cos2Val = '7/25';

      return {
        id: `gen-11-1-${Date.now()}`,
        topicTitle: 'Công thức góc nhân đôi lượng giác',
        grade: 11,
        context: `Cho góc $\\alpha$ thỏa mãn $\\sin \\alpha = \\frac{3}{5}$ với $0 < \\alpha < \\frac{\\pi}{2}$.`,
        ask: 'Tính giá trị của biểu thức $\\sin 2\\alpha$.',
        correctOption: `$\\frac{24}{25}$`,
        distractors: [`$\\frac{6}{5}$`, `$\\frac{7}{25}$`, `$\\frac{12}{25}$`],
        tfStatements: [
          {
            text: `Vì $0 < \\alpha < \\frac{\\pi}{2}$ nên $\\cos \\alpha > 0$.`,
            isTrue: true,
            explanation: `Góc phần tư thứ nhất có $\\cos > 0$ và $\\sin > 0$.`
          },
          {
            text: `Giá trị của $\\cos \\alpha = \\frac{4}{5}$.`,
            isTrue: true,
            explanation: `$\\cos \\alpha = \\sqrt{1 - \\sin^2 \\alpha} = \\sqrt{1 - (3/5)^2} = 4/5$.`
          },
          {
            text: `Công thức nhân đôi là $\\sin 2\\alpha = 2\\sin\\alpha\\cos\\alpha$.`,
            isTrue: true,
            explanation: `Đúng, công thức nhân đôi của sin.`
          },
          {
            text: `Giá trị của $\\cos 2\\alpha = -\\frac{7}{25}$.`,
            isTrue: false,
            explanation: `Sai vì $\\cos 2\\alpha = 1 - 2\\sin^2\\alpha = 1 - 2(9/25) = 7/25 > 0$.`
          }
        ],
        shortAnswer: '0.96',
        shortAnswerPrompt: `Nhập giá trị $\\sin 2\\alpha$ dưới dạng số thập phân:`,
        solution: `Vì $0 < \\alpha < \\frac{\\pi}{2}$ nên $\\cos \\alpha = \\sqrt{1 - \\sin^2 \\alpha} = \\sqrt{1 - \\frac{9}{25}} = \\frac{4}{5}$.\nTa có $\\sin 2\\alpha = 2\\sin\\alpha\\cos\\alpha = 2 \\cdot \\frac{3}{5} \\cdot \\frac{4}{5} = \\frac{24}{25} = 0{,}96$.`,
        diagram: { type: 'trig' }
      };
    }
  },

  // 11-6: Cấp số cộng
  '11-6': {
    id: '11-6',
    topicTitle: 'Cấp số cộng và tổng n số hạng đầu',
    grade: 11,
    generate: () => {
      const u1 = randInt(1, 5);
      const d = randInt(2, 5);
      const n = randInt(8, 12);
      const un = u1 + (n - 1) * d;
      const Sn = (n * (2 * u1 + (n - 1) * d)) / 2;

      return {
        id: `gen-11-6-${Date.now()}`,
        topicTitle: 'Cấp số cộng',
        grade: 11,
        context: `Cho cấp số cộng $(u_n)$ có số hạng đầu $u_1 = ${u1}$ và công sai $d = ${d}$.`,
        ask: `Tính số hạng thứ $${n}$ ($u_{${n}}$) của cấp số cộng.`,
        correctOption: `$${un}$`,
        distractors: [`$${un + d}$`, `$${un - 2 * d}$`, `$${u1 * n * d}$`],
        tfStatements: [
          {
            text: `Công sai của cấp số cộng là $d = ${d}$.`,
            isTrue: true,
            explanation: `Theo đề bài, $d = ${d}$.`
          },
          {
            text: `Số hạng tổng quát là $u_n = u_1 + nd$.`,
            isTrue: false,
            explanation: `Sai, công thức đúng là $u_n = u_1 + (n - 1)d$.`
          },
          {
            text: `Số hạng thứ ba là $u_3 = ${u1 + 2 * d}$.`,
            isTrue: true,
            explanation: `$u_3 = ${u1} + 2 \\cdot ${d} = ${u1 + 2 * d}$.`
          },
          {
            text: `Tổng của $${n}$ số hạng đầu là $S_{${n}} = ${Sn}$.`,
            isTrue: true,
            explanation: `$S_{${n}} = \\frac{${n}(${u1} + ${un})}{2} = ${Sn}$.`
          }
        ],
        shortAnswer: `${un}`,
        shortAnswerPrompt: `Nhập giá trị của $u_{${n}}$:`,
        solution: `Áp dụng công thức số hạng tổng quát của cấp số cộng:\n$$u_n = u_1 + (n - 1)d$$\nVới $n = ${n}$, ta có:\n$$u_{${n}} = ${u1} + (${n} - 1) \\cdot ${d} = ${u1} + ${n - 1} \\cdot ${d} = ${un}.$$`
      };
    }
  },

  // 12-1: Tính đơn điệu & Đạo hàm
  '12-1': {
    id: '12-1',
    topicTitle: 'Tính đơn điệu của hàm số bậc ba',
    grade: 12,
    generate: () => {
      // y = x^3 - 3*m*x + 2, y' = 3x^2 - 3m
      const m = pick([1, 4, 9]);
      const sqrtM = Math.sqrt(m);
      const coeff = 3 * m;

      return normalizeQuestionContent({
        id: `gen-12-1-${Date.now()}`,
        topicTitle: 'Khoảng nghịch biến của hàm số bậc ba',
        grade: 12,
        context: `Cho hàm số $y = x^3 - ${coeff}x + 2$.`,
        ask: 'Tìm khoảng nghịch biến của hàm số đã cho.',
        correctOption: `$(-${sqrtM}; ${sqrtM})$`,
        distractors: [
          `$(-\\infty; -${sqrtM})$`,
          `$(${sqrtM}; +\\infty)$`,
          `$(-${coeff}; ${coeff})$`
        ],
        tfStatements: [
          {
            text: `Tập xác định của hàm số là $D = \\mathbb{R}$.`,
            isTrue: true,
            explanation: `Hàm đa thức xác định trên toàn bộ $\\mathbb{R}$.`
          },
          {
            text: `Đạo hàm của hàm số là $y' = 3x^2 - ${coeff}$.`,
            isTrue: true,
            explanation: `Đạo hàm $(x^3)' = 3x^2$, $(${coeff}x)' = ${coeff}$.`
          },
          {
            text: `Hàm số đồng biến trên khoảng $(-${sqrtM}; ${sqrtM})$.`,
            isTrue: false,
            explanation: `Sai, vì với mọi $x \\in (-${sqrtM}; ${sqrtM})$ thì $y' < 0$ nên hàm số nghịch biến trên khoảng này.`
          },
          {
            text: `Đồ thị hàm số có hai điểm cực trị nằm về hai phía của trục tung.`,
            isTrue: true,
            explanation: `Hai nghiệm của đạo hàm là $x_1 = -${sqrtM} < 0$ và $x_2 = ${sqrtM} > 0$ trái dấu nhau.`
          }
        ],
        shortAnswer: `${sqrtM}`,
        shortAnswerPrompt: `Nhập điểm cực tiểu $x_{CT}$ của hàm số:`,
        solution: `Ta có $y' = 3x^2 - ${coeff} = 3(x^2 - ${m})$.\nCho $y' = 0 \\Leftrightarrow x^2 = ${m} \\Leftrightarrow x = \\pm ${sqrtM}$.\nBảng xét dấu $y'$:\n- $y' > 0$ khi $x \\in (-\\infty; -${sqrtM}) \\cup (${sqrtM}; +\\infty)$ (hàm số đồng biến).\n- $y' < 0$ khi $x \\in (-${sqrtM}; ${sqrtM})$ (hàm số nghịch biến).\nVậy hàm số nghịch biến trên khoảng $(-${sqrtM}; ${sqrtM})$ và đồng biến trên các khoảng $(-\\infty; -${sqrtM})$, $(${sqrtM}; +\\infty)$.`,
        diagram: {
          type: 'cubic',
          params: {
            a: 1,
            b: 0,
            c: -coeff,
            d: 2,
            label: `y = x³ - ${coeff}x + 2`
          }
        }
      });
    }
  },

  // 12-2: Cực trị hàm phân thức
  '12-2': {
    id: '12-2',
    topicTitle: 'Tiệm cận và cực trị hàm phân thức $y = \\frac{ax+b}{cx+d}$',
    grade: 12,
    generate: () => {
      const a = randInt(1, 3);
      const b = randInt(1, 5);
      const x0 = randInt(1, 3);
      // y = (a*x + b)/(x - x0)
      // Vertical asymptote: x = x0
      // Horizontal asymptote: y = a

      return normalizeQuestionContent({
        id: `gen-12-2-${Date.now()}`,
        topicTitle: 'Đường tiệm cận của đồ thị hàm phân thức',
        grade: 12,
        context: `Cho hàm số $y = \\frac{${a === 1 ? '' : a}x + ${b}}{x - ${x0}}$.`,
        ask: 'Tìm phương trình đường tiệm cận ngang của đồ thị hàm số.',
        correctOption: `$y = ${a}$`,
        distractors: [`$x = ${x0}$`, `$y = ${x0}$`, `$x = -${x0}$`],
        tfStatements: [
          {
            text: `Tập xác định của hàm số là $D = \\mathbb{R} \\setminus \\{${x0}\\}$.`,
            isTrue: true,
            explanation: `Mẫu số $x - ${x0} \\ne 0 \\Leftrightarrow x \\ne ${x0}$.`
          },
          {
            text: `Đường tiệm cận đứng của đồ thị hàm số là $x = ${x0}$.`,
            isTrue: true,
            explanation: `Vì $\\lim_{x \\to ${x0}^+} y = +\\infty$, suy ra $x = ${x0}$ là TCĐ.`
          },
          {
            text: `Đường tiệm cận ngang của đồ thị hàm số là $y = ${a}$.`,
            isTrue: true,
            explanation: `Vì $\\lim_{x \\to \\pm\\infty} y = \\frac{${a}}{1} = ${a}$.`
          },
          {
            text: `Tâm đối xứng của đồ thị có tọa độ là $I(${a}; ${x0})$.`,
            isTrue: false,
            explanation: `Sai, giao điểm hai tiệm cận có tọa độ là $I(${x0}; ${a})$ (hoành độ là TCĐ, tung độ là TCN).`
          }
        ],
        shortAnswer: `${x0}`,
        shortAnswerPrompt: `Nhập hoành độ giao điểm của hai đường tiệm cận:`,
        solution: `Ta có:\n- $\\lim_{x \\to \\pm\\infty} \\frac{${a === 1 ? '' : a}x + ${b}}{x - ${x0}} = ${a} \\Rightarrow$ Tiệm cận ngang $y = ${a}$.\n- $\\lim_{x \\to ${x0}^+} y = +\\infty \\Rightarrow$ Tiệm cận đứng $x = ${x0}$.\nTâm đối xứng của đồ thị là $I(${x0}; ${a})$.`,
        diagram: {
          type: 'rational',
          params: {
            a,
            b,
            c: 1,
            d: -x0,
            x0,
            label: `y = (${a === 1 ? '' : a}x + ${b})/(x - ${x0})`
          }
        }
      });
    }
  },

  // 12-6: Vectơ và Hệ tọa độ Oxyz
  '12-6': {
    id: '12-6',
    topicTitle: 'Tọa độ điểm và khoảng cách trong không gian Oxyz',
    grade: 12,
    generate: () => {
      const xA = randInt(-3, 3);
      const yA = randInt(-3, 3);
      const zA = randInt(1, 4);

      const xB = xA + 3;
      const yB = yA + 4;
      const zB = zA; // distance = sqrt(3^2 + 4^2) = 5

      const AB = 5;

      return {
        id: `gen-12-6-${Date.now()}`,
        topicTitle: 'Khoảng cách giữa hai điểm trong Oxyz',
        grade: 12,
        context: `Trong không gian $Oxyz$, cho hai điểm $A(${xA}; ${yA}; ${zA})$ và $B(${xB}; ${yB}; ${zB})$.`,
        ask: 'Tính độ dài đoạn thẳng $AB$.',
        correctOption: `$${AB}$`,
        distractors: [`$${AB + 2}$`, `$${AB * 2}$`, `$\\sqrt{${AB + 10}}$`],
        tfStatements: [
          {
            text: `Tọa độ vectơ $\\vec{AB} = (3; 4; 0)$.`,
            isTrue: true,
            explanation: `$\\vec{AB} = (${xB}-${xA}; ${yB}-${yA}; ${zB}-${zA}) = (3; 4; 0)$.`
          },
          {
            text: `Trung điểm $M$ của đoạn thẳng $AB$ có cao độ $z_M = ${zA}$.`,
            isTrue: true,
            explanation: `$z_M = \\frac{${zA} + ${zB}}{2} = ${zA}$.`
          },
          {
            text: `Độ dài đoạn thẳng $AB$ bằng $5$.`,
            isTrue: true,
            explanation: `$AB = \\sqrt{3^2 + 4^2 + 0^2} = \\sqrt{25} = 5$.`
          },
          {
            text: `Vectơ $\\vec{AB}$ cùng phương với vectơ $\\vec{k} = (0; 0; 1)$.`,
            isTrue: false,
            explanation: `Sai vì thành phần $z$ của $\\vec{AB}$ bằng $0$, vectơ $\\vec{AB}$ song song với mặt phẳng $(Oxy)$.`
          }
        ],
        shortAnswer: `${AB}`,
        shortAnswerPrompt: `Nhập độ dài đoạn thẳng $AB$:`,
        solution: `Ta có vectơ $\\vec{AB} = (${xB} - ${xA}; ${yB} - ${yA}; ${zB} - ${zA}) = (3; 4; 0)$.\nĐộ dài đoạn thẳng $AB$ là:\n$$AB = |\\vec{AB}| = \\sqrt{3^2 + 4^2 + 0^2} = \\sqrt{9 + 16} = 5.$$`,
        diagram: { type: 'box' }
      };
    }
  },

  // 12-11: Tích phân & Diện tích hình phẳng
  '12-11': {
    id: '12-11',
    topicTitle: 'Tích phân xác định',
    grade: 12,
    generate: () => {
      const a = randInt(1, 3);
      // \int_0^1 (2ax + 3) dx = [a*x^2 + 3x]_0^1 = a + 3
      const result = a + 3;

      return {
        id: `gen-12-11-${Date.now()}`,
        topicTitle: 'Tính tích phân của hàm đa thức',
        grade: 12,
        context: `Cho tích phân $I = \\int_0^1 (${2 * a}x + 3) \\, dx$.`,
        ask: 'Tính giá trị của tích phân $I$.',
        correctOption: `$${result}$`,
        distractors: [`$${result + 2}$`, `$${2 * a + 3}$`, `$${result - 1}$`],
        tfStatements: [
          {
            text: `Một nguyên hàm của hàm số $f(x) = ${2 * a}x + 3$ là $F(x) = ${a}x^2 + 3x$.`,
            isTrue: true,
            explanation: `Vì $F'(x) = 2 \\cdot ${a}x + 3 = ${2 * a}x + 3$.`
          },
          {
            text: `Giá trị của $F(1) = ${a + 3}$.`,
            isTrue: true,
            explanation: `$F(1) = ${a}(1)^2 + 3(1) = ${a + 3}$.`
          },
          {
            text: `Giá trị của $F(0) = 0$.`,
            isTrue: true,
            explanation: `$F(0) = ${a}(0)^2 + 3(0) = 0$.`
          },
          {
            text: `Tích phân $I$ nhận giá trị âm.`,
            isTrue: false,
            explanation: `Sai, vì $f(x) > 0$ với mọi $x \\in [0; 1]$ nên $I > 0$.`
          }
        ],
        shortAnswer: `${result}`,
        shortAnswerPrompt: `Nhập giá trị của tích phân $I$:`,
        solution: `Ta có:\n$$I = \\int_0^1 (${2 * a}x + 3) \\, dx = \\left[ ${a}x^2 + 3x \\right]_0^1 = (${a} \\cdot 1^2 + 3 \\cdot 1) - 0 = ${result}.$$`,
        diagram: { type: 'integral' }
      };
    }
  },

  // 12-14: Phương trình mặt phẳng và mặt cầu Oxyz
  '12-14': {
    id: '12-14',
    topicTitle: 'Phương trình mặt cầu trong không gian Oxyz',
    grade: 12,
    generate: () => {
      const a = randInt(1, 3);
      const b = randInt(-3, -1);
      const c = randInt(2, 4);
      const R = randInt(2, 5);
      const R2 = R * R;

      return {
        id: `gen-12-14-${Date.now()}`,
        topicTitle: 'Tọa độ tâm và bán kính mặt cầu',
        grade: 12,
        context: `Trong không gian $Oxyz$, cho mặt cầu $(S): (x - ${a})^2 + (y + ${Math.abs(b)})^2 + (z - ${c})^2 = ${R2}$.`,
        ask: 'Tìm tọa độ tâm $I$ và bán kính $R$ của mặt cầu $(S)$.',
        correctOption: `$I(${a}; ${b}; ${c}), \\ R = ${R}$`,
        distractors: [
          `$I(-${a}; ${Math.abs(b)}; -${c}), \\ R = ${R}$`,
          `$I(${a}; ${b}; ${c}), \\ R = ${R2}$`,
          `$I(${a}; ${Math.abs(b)}; ${c}), \\ R = ${R}$`
        ],
        tfStatements: [
          {
            text: `Mặt cầu có tâm $I(${a}; ${b}; ${c})$.`,
            isTrue: true,
            explanation: `Theo dạng chuẩn $(x-a)^2 + (y-b)^2 + (z-c)^2 = R^2$, tâm $I$ có tọa độ $(${a}; ${b}; ${c})$.`
          },
          {
            text: `Bán kính của mặt cầu là $R = ${R2}$.`,
            isTrue: false,
            explanation: `Sai, $R^2 = ${R2} \\Rightarrow R = \\sqrt{${R2}} = ${R}$.`
          },
          {
            text: `Điểm $A(${a}; ${b}; ${c + R})$ nằm trên mặt cầu $(S)$.`,
            isTrue: true,
            explanation: `Khoảng cách $IA = \\sqrt{0^2 + 0^2 + ${R}^2} = ${R} = R$ nên $A$ thuộc $(S)$.`
          },
          {
            text: `Mặt phẳng $(Oxy)$ có phương trình là $z = 0$.`,
            isTrue: true,
            explanation: `Mọi điểm trên mặt phẳng $(Oxy)$ đều có cao độ $z = 0$.`
          }
        ],
        shortAnswer: `${R}`,
        shortAnswerPrompt: `Nhập bán kính $R$ của mặt cầu:`,
        solution: `Phương trình mặt cầu có dạng chuẩn $(x - a)^2 + (y - b)^2 + (z - c)^2 = R^2$.\nTừ đề bài:\n- Tọa độ tâm: $I(${a}; ${b}; ${c})$\n- Bán kính: $R = \\sqrt{${R2}} = ${R}$.`,
        diagram: { type: 'box' }
      };
    }
  },

  // 12-18: Xác suất Bayes
  '12-18': {
    id: '12-18',
    topicTitle: 'Xác suất toàn phần và công thức Bayes trong y tế',
    grade: 12,
    generate: () => {
      // Disease rate 2%, Test accuracy 95%, false positive 5%
      // P(D) = 0.02, P(T|D) = 0.95, P(T|not D) = 0.05
      // P(T) = 0.02 * 0.95 + 0.98 * 0.05 = 0.019 + 0.049 = 0.068
      // P(D|T) = 0.019 / 0.068 approx 0.2794
      return {
        id: `gen-12-18-${Date.now()}`,
        topicTitle: 'Công thức xác suất toàn phần & Bayes',
        grade: 12,
        context: `Một tỉ lệ mắc một căn bệnh trong cộng đồng là $2\\%$. Một bộ kit xét nghiệm cho kết quả dương tính đối với $95\\%$ người mắc bệnh, và cho kết quả dương tính giả đối với $5\\%$ người khỏe mạnh.`,
        ask: 'Tính xác suất để một người được chọn ngẫu nhiên có kết quả xét nghiệm dương tính.',
        correctOption: `$0{,}068$ (hay $6{,}8\\%$)`,
        distractors: [`$0{,}95$`, `$0{,}02$`, `$0{,}05$`],
        tfStatements: [
          {
            text: `Gọi $B$ là biến cố người đó mắc bệnh, thì $P(B) = 0{,}02$ và $P(\\overline{B}) = 0{,}98$.`,
            isTrue: true,
            explanation: `Xác suất người mắc bệnh là 2% = 0.02, người không mắc bệnh là 98% = 0.98.`
          },
          {
            text: `Xác suất dương tính khi có bệnh là $P(T \\mid B) = 0{,}95$.`,
            isTrue: true,
            explanation: `Độ nhạy của xét nghiệm là 95%.`
          },
          {
            text: `Theo công thức xác suất toàn phần, $P(T) = P(B)P(T \\mid B) + P(\\overline{B})P(T \\mid \\overline{B})$.`,
            isTrue: true,
            explanation: `Đây là công thức xác suất toàn phần chính xác.`
          },
          {
            text: `Nếu một người nhận kết quả dương tính, xác suất họ thực sự mắc bệnh lớn hơn $90\\%$.`,
            isTrue: false,
            explanation: `Sai vì theo công thức Bayes, $P(B \\mid T) = \\frac{0{,}019}{0{,}068} \\approx 27{,}94\\% < 90\\%$ do tỉ lệ bệnh trong cộng đồng thấp.`
          }
        ],
        shortAnswer: '0.068',
        shortAnswerPrompt: `Nhập giá trị xác suất xét nghiệm dương tính (lấy 3 chữ số thập phân):`,
        solution: `Gọi $B$ là biến cố người được xét nghiệm mắc bệnh $\\Rightarrow P(B) = 0{,}02$, $P(\\overline{B}) = 0{,}98$.\nGọi $T$ là biến cố xét nghiệm cho kết quả dương tính.\n- $P(T \\mid B) = 0{,}95$\n- $P(T \\mid \\overline{B}) = 0{,}05$\nÁp dụng công thức xác suất toàn phần:\n$$P(T) = P(B) \\cdot P(T \\mid B) + P(\\overline{B}) \\cdot P(T \\mid \\overline{B})$$\n$$P(T) = 0{,}02 \\cdot 0{,}95 + 0{,}98 \\cdot 0{,}05 = 0{,}019 + 0{,}049 = 0{,}068.$$\nVậy xác suất để người xét nghiệm có kết quả dương tính là $0{,}068$ (tức $6{,}8\\%$).`
      };
    }
  }
};

// Guarantee all generators automatically pass through single-pass normalization:
Object.keys(TOPIC_GENERATORS).forEach((key) => {
  const origGenerate = TOPIC_GENERATORS[key].generate;
  TOPIC_GENERATORS[key].generate = () => normalizeQuestionContent(origGenerate());
});

/**
 * Procedural generator for a complete 2025 THPT Exam conforming strictly to Ministry of Education guidelines:
 * - Part I: 12 MCQ (3.0 pts)
 * - Part II: 4 True/False (4.0 pts)
 * - Part III: 6 Short Answer (3.0 pts)
 */
export function generateFullExam2025(schoolName = 'TRƯỜNG THPT CHUYÊN TOÁN - THẦY PHẠM BẢO ANH') {
  const code = `${randInt(101, 899)}`;
  const allKeys = Object.keys(TOPIC_GENERATORS);

  // 1. Part I: 12 MCQ
  const part1Questions: any[] = [];
  for (let i = 0; i < 12; i++) {
    const key = pick(allKeys);
    const qData = TOPIC_GENERATORS[key].generate();

    const optionsRaw = [
      { label: 'A' as const, content: qData.correctOption },
      { label: 'B' as const, content: qData.distractors[0] || '1' },
      { label: 'C' as const, content: qData.distractors[1] || '2' },
      { label: 'D' as const, content: qData.distractors[2] || '3' }
    ];

    const shuffled = shuffle(optionsRaw);
    const correctLabel = (shuffled.findIndex(o => o.content === qData.correctOption) === 0 ? 'A' :
      shuffled.findIndex(o => o.content === qData.correctOption) === 1 ? 'B' :
      shuffled.findIndex(o => o.content === qData.correctOption) === 2 ? 'C' : 'D') as 'A' | 'B' | 'C' | 'D';

    const labeledOptions = shuffled.map((o, idx) => ({
      label: (['A', 'B', 'C', 'D'][idx]) as 'A' | 'B' | 'C' | 'D',
      content: o.content
    }));

    part1Questions.push({
      id: `p1-q${i + 1}`,
      number: i + 1,
      stem: normalizeMathContent(`${qData.context} ${qData.ask}`),
      options: labeledOptions,
      correctAnswer: correctLabel,
      solution: qData.solution,
      diagram: qData.diagram
    });
  }

  // 2. Part II: 4 True / False
  const part2Questions: any[] = [];
  const tfKeys = ['12-1', '12-2', '12-6', '12-14'];
  for (let i = 0; i < 4; i++) {
    const key = tfKeys[i] || pick(allKeys);
    const qData = TOPIC_GENERATORS[key].generate();

    const subQuestions = qData.tfStatements.map((tf, sIdx) => ({
      id: `p2-q${i + 1}-${['a', 'b', 'c', 'd'][sIdx]}`,
      label: (['a', 'b', 'c', 'd'][sIdx]) as 'a' | 'b' | 'c' | 'd',
      text: normalizeMathContent(tf.text),
      isCorrect: tf.isTrue,
      explanation: tf.explanation
    }));

    part2Questions.push({
      id: `p2-q${i + 1}`,
      number: i + 1,
      stem: normalizeMathContent(qData.context),
      subQuestions,
      solution: qData.solution,
      diagram: qData.diagram
    });
  }

  // 3. Part III: 6 Short Answer
  const part3Questions: any[] = [];
  const saKeys = ['12-1', '12-6', '12-11', '12-14', '11-6', '12-18'];
  for (let i = 0; i < 6; i++) {
    const key = saKeys[i] || pick(allKeys);
    const qData = TOPIC_GENERATORS[key].generate();

    part3Questions.push({
      id: `p3-q${i + 1}`,
      number: i + 1,
      stem: normalizeMathContent(`${qData.context} ${qData.shortAnswerPrompt || qData.ask}`),
      correctAnswer: qData.shortAnswer,
      solution: qData.solution,
      diagram: qData.diagram
    });
  }

  return {
    id: `exam-${Date.now()}`,
    code,
    config: {
      grade: 12 as const,
      type: 'tn' as const,
      format: 'full' as const,
      schoolName,
      studentName: '',
      studentCode: ''
    },
    title: 'ĐỀ THI TỐT NGHIỆP THPT QUỐC GIA NĂM 2025 - MÔN TOÁN',
    durationMinutes: 90,
    createdAt: new Date().toLocaleDateString('vi-VN'),
    part1: part1Questions,
    part2: part2Questions,
    part3: part3Questions
  };
}
