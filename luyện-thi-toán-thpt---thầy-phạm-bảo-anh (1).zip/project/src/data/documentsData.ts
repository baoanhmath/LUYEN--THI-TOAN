import { MathDocument } from '../types/math';

export const MATH_DOCUMENTS: MathDocument[] = [
  {
    id: 'doc-1',
    title: 'Bộ 20 Đề thi thử Tốt nghiệp THPT 2025 môn Toán - Chuẩn ma trận Bộ GD&ĐT (Có giải chi tiết)',
    category: 'exam',
    grade: 12,
    pages: 184,
    fileSize: '12.4 MB',
    downloadCount: 3840,
    description: 'Tuyển tập 20 đề thi chuẩn cấu trúc mới nhất: 12 trắc nghiệm 4 lựa chọn, 4 câu Đúng/Sai và 6 câu trả lời ngắn kèm barem điểm chi tiết của Thầy Phạm Bảo Anh.',
    tags: ['Đề thi 2025', 'Toán 12', 'Có lời giải chi tiết', 'Tốt nghiệp THPT']
  },
  {
    id: 'doc-2',
    title: 'Sổ tay bỏ túi: Toàn bộ công thức Giải nhanh Toán 10 - 11 - 12 (Bản cập nhật GDPT 2018)',
    category: 'theory',
    grade: 'all',
    pages: 48,
    fileSize: '4.8 MB',
    downloadCount: 6120,
    description: 'Tóm lược cô đọng toàn bộ công thức Đại số, Giải tích, Hình học không gian, Tọa độ Oxyz và Xác suất Thống kê cho cả 3 khối lớp, thiết kế trực quan dễ nhớ.',
    tags: ['Sổ tay công thức', 'Ôn thi cấp tốc', 'Toán 10-11-12']
  },
  {
    id: 'doc-3',
    title: 'Chuyên đề 200 câu hỏi Trắc nghiệm Đúng / Sai môn Toán (Phần II cấu trúc đề 2025)',
    category: 'tf_bank',
    grade: 12,
    pages: 96,
    fileSize: '7.2 MB',
    downloadCount: 2950,
    description: 'Rèn luyện kĩ năng phân tích và phản xạ với định dạng câu hỏi Đúng/Sai mới, chống bẫy và tối ưu điểm số phần 4.0 điểm trong bài thi tốt nghiệp.',
    tags: ['Đúng Sai', 'Chống bẫy', 'Toán 12', 'Ma trận mới']
  },
  {
    id: 'doc-4',
    title: 'Tuyển tập Toán thực tế & Ứng dụng đời sống trong đề thi THPT Quốc Gia môn Toán',
    category: 'applied',
    grade: 12,
    pages: 64,
    fileSize: '5.6 MB',
    downloadCount: 2180,
    description: 'Tổng hợp các bài toán tối ưu chi phí, mô hình Parabol đường hầm, tăng trưởng lãi suất, khoảng cách vệ tinh và xác suất kiểm định y khoa Bayes.',
    tags: ['Toán thực tiễn', 'Ứng dụng đời sống', 'Tối ưu hóa', 'Bayes']
  },
  {
    id: 'doc-5',
    title: 'Bí kíp bấm máy tính Casio FX-580VN X & FX-880BTG giải nhanh trắc nghiệm môn Toán',
    category: 'casio',
    grade: 'all',
    pages: 52,
    fileSize: '6.1 MB',
    downloadCount: 5410,
    description: 'Kĩ thuật dò bảng Table, đạo hàm tại điểm d/dx, tích phân, tính góc vectơ Oxyz, giải hệ phương trình và thống kê phương sai trong 15 giây.',
    tags: ['Thủ thuật Casio', 'FX-580VNX', 'FX-880BTG', 'Bấm máy nhanh']
  },
  {
    id: 'doc-6',
    title: 'Chuyên đề Vectơ và Tọa độ trong không gian Oxyz - Đầy đủ các dạng từ cơ bản đến 9+',
    category: 'theory',
    grade: 12,
    pages: 82,
    fileSize: '8.3 MB',
    downloadCount: 1940,
    description: 'Hệ thống hóa lý thuyết mặt phẳng, đường thẳng, mặt cầu, góc và khoảng cách kèm các phương pháp giải hình học không gian Oxyz thực tế.',
    tags: ['Oxyz', 'Hình học không gian', 'Vectơ', 'Toán 12']
  }
];
