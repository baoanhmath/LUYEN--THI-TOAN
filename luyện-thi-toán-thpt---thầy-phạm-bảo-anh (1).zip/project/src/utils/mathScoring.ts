/**
 * Central Mathematical Scoring & Answer Validation Engine.
 * Single Source of Truth for:
 * - Student answer normalization (spacing, commas, dots, signs, fractions)
 * - Mathematical equivalence checking (numeric float tolerance, exact string, symbolic intervals)
 * - Isolated scoring logic for Part 1 (MCQ), Part 2 (True/False - MOET 2025 standard), and Part 3 (Short Answer)
 * - Guarantees: TOTAL SCORE = SUM OF INDIVIDUAL QUESTION SCORES.
 */

import {
  ExamQuestionMCQ,
  ExamQuestionTF,
  ExamQuestionShort,
  GeneratedExam,
  StudentExamAnswers,
  ExamResult
} from '../types/math';

/**
 * Normalizes raw student string answer:
 * - Trims whitespace
 * - Replaces decimal commas with dots (e.g. "0,068" -> "0.068")
 * - Cleans redundant plus signs (e.g. "+3" -> "3")
 * - Cleans spaces inside intervals e.g. "( -1 ; 1 )" -> "(-1; 1)"
 */
export function normalizeStudentAnswer(raw: string | null | undefined): string {
  if (!raw) return '';
  let str = String(raw).trim();

  // Replace decimal commas in numbers (e.g. 2,5 -> 2.5)
  str = str.replace(/(\d+),(\d+)/g, '$1.$2');

  // Remove leading plus if followed by number
  str = str.replace(/^\+(\d+)/, '$1');

  // Normalize interval/set spacing
  str = str.replace(/\s*([(\[{}\])])\s*/g, '$1');
  str = str.replace(/\s*;\s*/g, '; ');

  return str.trim();
}

/**
 * Evaluates mathematical equivalence between student short answer and expected answer.
 * Supports:
 * - Exact string match after normalization
 * - Numeric float comparison with small epsilon (1e-4)
 * - Fraction equivalents: e.g. "24/25" vs "0.96", "1/2" vs "0.5"
 */
export function isShortAnswerEquivalent(
  studentAnswer: string | null | undefined,
  expectedAnswer: string | null | undefined
): boolean {
  const user = normalizeStudentAnswer(studentAnswer);
  const target = normalizeStudentAnswer(expectedAnswer);

  if (!user || !target) return false;

  // 1. Direct normalized string match
  if (user.toLowerCase() === target.toLowerCase()) {
    return true;
  }

  // Helper to parse potential fraction or float
  const parseVal = (s: string): number => {
    if (s.includes('/')) {
      const parts = s.split('/');
      if (parts.length === 2) {
        const num = parseFloat(parts[0]);
        const den = parseFloat(parts[1]);
        if (!isNaN(num) && !isNaN(den) && den !== 0) {
          return num / den;
        }
      }
    }
    return parseFloat(s);
  };

  const userNum = parseVal(user);
  const targetNum = parseVal(target);

  // 2. Numeric equivalence
  if (!isNaN(userNum) && !isNaN(targetNum)) {
    return Math.abs(userNum - targetNum) < 1e-4;
  }

  return false;
}

/**
 * Scores Part 1 (Multiple Choice): 0.25 points per correct question.
 */
export function scorePart1(
  questions: ExamQuestionMCQ[],
  answers: Record<string, 'A' | 'B' | 'C' | 'D'>
) {
  let correctCount = 0;
  let unansweredCount = 0;
  const details: Record<string, { isCorrect: boolean; points: number; selected: string | null }> = {};

  questions.forEach((q) => {
    const selected = answers[q.id] || null;
    if (!selected) {
      unansweredCount++;
      details[q.id] = { isCorrect: false, points: 0, selected: null };
    } else if (selected === q.correctAnswer) {
      correctCount++;
      details[q.id] = { isCorrect: true, points: 0.25, selected };
    } else {
      details[q.id] = { isCorrect: false, points: 0, selected };
    }
  });

  const score = Math.round(correctCount * 0.25 * 100) / 100;

  return {
    correctCount,
    unansweredCount,
    totalQuestions: questions.length,
    score,
    maxScore: questions.length * 0.25,
    details
  };
}

/**
 * Scores Part 2 (True / False): Official MOET 2025 Barem:
 * - 1 correct sub-question = 0.10 pt
 * - 2 correct sub-questions = 0.25 pt
 * - 3 correct sub-questions = 0.50 pt
 * - 4 correct sub-questions = 1.00 pt
 * - 0 correct = 0.00 pt
 */
export function scorePart2(
  questions: ExamQuestionTF[],
  answers: Record<string, Record<'a' | 'b' | 'c' | 'd', boolean | null>>
) {
  let totalScore = 0;
  let totalCorrectSub = 0;
  let totalUnansweredSub = 0;
  const breakdown: { qId: string; correctCount: number; points: number }[] = [];

  questions.forEach((q) => {
    const userChoices = answers[q.id] || { a: null, b: null, c: null, d: null };
    let correctInQ = 0;

    q.subQuestions.forEach((sq) => {
      const choice = userChoices[sq.label];
      if (choice === null || choice === undefined) {
        totalUnansweredSub++;
      } else if (choice === sq.isCorrect) {
        correctInQ++;
        totalCorrectSub++;
      }
    });

    let pts = 0;
    if (correctInQ === 1) pts = 0.1;
    else if (correctInQ === 2) pts = 0.25;
    else if (correctInQ === 3) pts = 0.5;
    else if (correctInQ === 4) pts = 1.0;

    totalScore += pts;
    breakdown.push({ qId: q.id, correctCount: correctInQ, points: pts });
  });

  totalScore = Math.round(totalScore * 100) / 100;

  return {
    totalPoints: totalScore,
    maxPoints: questions.length * 1.0,
    breakdown,
    totalCorrectSub,
    totalUnansweredSub,
    totalSubQuestions: questions.length * 4
  };
}

/**
 * Scores Part 3 (Short Answer): 0.50 points per correct question.
 */
export function scorePart3(
  questions: ExamQuestionShort[],
  answers: Record<string, string>
) {
  let correctCount = 0;
  let unansweredCount = 0;
  const details: Record<string, { isCorrect: boolean; points: number; userVal: string; targetVal: string }> = {};

  questions.forEach((q) => {
    const userVal = answers[q.id] || '';
    if (!userVal.trim()) {
      unansweredCount++;
      details[q.id] = { isCorrect: false, points: 0, userVal: '', targetVal: q.correctAnswer };
    } else if (isShortAnswerEquivalent(userVal, q.correctAnswer)) {
      correctCount++;
      details[q.id] = { isCorrect: true, points: 0.5, userVal, targetVal: q.correctAnswer };
    } else {
      details[q.id] = { isCorrect: false, points: 0, userVal, targetVal: q.correctAnswer };
    }
  });

  const score = Math.round(correctCount * 0.5 * 100) / 100;

  return {
    correctCount,
    unansweredCount,
    totalQuestions: questions.length,
    score,
    maxScore: questions.length * 0.5,
    details
  };
}

/**
 * Comprehensive Exam Evaluator:
 * Strictly ensures TOTAL SCORE = SUM OF PART 1 + PART 2 + PART 3.
 */
export function evaluateExam(
  exam: GeneratedExam,
  answers: StudentExamAnswers,
  timeSpentSeconds: number
): ExamResult {
  const p1 = scorePart1(exam.part1, answers.part1);
  const p2 = scorePart2(exam.part2, answers.part2);
  const p3 = scorePart3(exam.part3, answers.part3);

  const rawSum = p1.score + p2.totalPoints + p3.score;
  const finalScore = Math.round(rawSum * 100) / 100;

  return {
    score: finalScore,
    maxScore: 10.0,
    timeSpentSeconds,
    part1Score: p1.score,
    part2Score: p2.totalPoints,
    part3Score: p3.score,
    part1CorrectCount: p1.correctCount,
    part2ScoreBreakdown: p2.breakdown,
    part3CorrectCount: p3.correctCount,
    submittedAt: new Date().toLocaleTimeString('vi-VN')
  };
}
