/**
 * Comprehensive utility for normalizing mathematical formulas and question content.
 * Single Source of Truth to prevent formula duplication, adjacent repeating strings,
 * broken delimiters, or MathML / HTML double rendering.
 */

/**
 * Normalizes a mathematical formula or text containing formulas:
 * 1. Converts LaTeX delimiters \( ... \) -> $ ... $, \[ ... \] -> $$ ... $$
 * 2. Deduplicates identical adjacent formulas: "$f(x)$$f(x)$" -> "$f(x)$"
 * 3. Deduplicates identical adjacent parenthesized intervals: "(-1; 1)(-1; 1)" -> "(-1; 1)"
 * 4. Deduplicates accidental doubled equation phrases:
 *    "y = x³ - 3x + 2y = x³ - 3x + 2" -> "y = x³ - 3x + 2"
 *    "y = x^3 - 3x + 2y = x^3 - 3x + 2" -> "y = x^3 - 3x + 2"
 * 5. Cleans excess whitespace inside delimiters.
 */
export function normalizeMathContent(input: string | undefined | null): string {
  if (!input) return '';

  let text = String(input);

  // 1. Convert standard LaTeX delimiters to $ and $$
  text = text.replace(/\\\[([\s\S]+?)\\\]/g, '$$$$1$$$');
  text = text.replace(/\\\(([\s\S]+?)\\\)/g, '$$$1$$');

  // 2. Remove duplicate adjacent formulas: e.g. "$formula$$formula$" or "$formula$ $formula$"
  text = text.replace(/(\$\$[\s\S]+?\$\$)\s*\1+/g, '$1');
  text = text.replace(/(\$[^$]+\$)\s*\1+/g, '$1');

  // 3. Remove duplicate identical parenthetical intervals: e.g. "(-1; 1)(-1; 1)"
  text = text.replace(/(\([^\)]+\))\s*\1+/g, '$1');

  // 4. Specific fix for accidental equation duplication like:
  // "y = x³ - 3x + 2y = x³ - 3x + 2" or "f(x) = ...f(x) = ..."
  text = text.replace(/((?:y|f\(x\))\s*=\s*[a-zA-Z0-9\^_\+\-\*/\s\u00B2\u00B3]{4,})\s*\1+/g, '$1');
  text = text.replace(/((?:y|f\(x\))\s*=\s*[^,;.\n]+?)\s*(?:y|f\(x\))\s*=\s*\1/g, '$1');

  // 5. General adjacent duplication of long phrases (>= 7 chars)
  text = text.replace(/([a-zA-Z\u00C0-\u024F\u1EA0-\u1EF90-9\^_\+\-\*/=(),;.\s\u00B2\u00B3]{7,}?)\1+/g, '$1');

  // 6. Normalize spacing inside $ delimiters
  text = text.replace(/\$\s+/g, '$').replace(/\s+\$/g, '$');

  return text.trim();
}

/**
 * Normalizes question stem, context, options, and solution strings
 * to eliminate duplicate text or duplicate math tags before rendering.
 */
export function normalizeQuestionContent<T extends {
  context?: string;
  ask?: string;
  stem?: string;
  correctOption?: string;
  distractors?: string[];
  solution?: string;
  shortAnswer?: string;
  shortAnswerPrompt?: string;
}>(question: T): T {
  const context = question.context ? normalizeMathContent(question.context) : question.context;
  const ask = question.ask ? normalizeMathContent(question.ask) : question.ask;
  const stem = question.stem ? normalizeMathContent(question.stem) : question.stem;

  return {
    ...question,
    context,
    ask,
    stem,
    correctOption: question.correctOption ? normalizeMathContent(question.correctOption) : question.correctOption,
    distractors: question.distractors ? question.distractors.map(normalizeMathContent) : question.distractors,
    solution: question.solution ? normalizeMathContent(question.solution) : question.solution,
    shortAnswer: question.shortAnswer ? normalizeMathContent(question.shortAnswer) : question.shortAnswer,
    shortAnswerPrompt: question.shortAnswerPrompt ? normalizeMathContent(question.shortAnswerPrompt) : question.shortAnswerPrompt,
  };
}
