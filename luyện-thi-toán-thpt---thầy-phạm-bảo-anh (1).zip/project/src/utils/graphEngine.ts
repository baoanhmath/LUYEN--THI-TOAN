/**
 * High-Precision Mathematical Graphing Engine
 * Tailored for High School Calculus (THPT 10-11-12)
 *
 * Core capabilities:
 * 1. Adaptive Viewport Determination based on intrinsic calculus landmarks (extrema, inflection points, asymptotes)
 * 2. Automatic "Nice Numbers" Tick Generation for Ox and Oy
 * 3. Discontinuity-Safe Adaptive Sampling for Rational Functions (hyperbolas) with zero asymptote bridge lines
 * 4. Ultra-smooth geometric-precision SVG path generators for Cubic, Rational, and Quadratic functions
 */

export interface AxisTick {
  value: number;
  formatted: string;
}

/**
 * Eliminates -0 in JavaScript floating point operations
 */
export function cleanZero(val: number): number {
  return Math.abs(val) < 1e-9 ? 0 : val;
}

/**
 * Standard Nice Numbers Algorithm for Axis Ticks (Wilkinson / Heckbert style)
 */
export function generateNiceTicks(min: number, max: number, targetTicks = 6): AxisTick[] {
  if (min >= max) {
    return [{ value: min, formatted: String(cleanZero(min)) }];
  }

  const range = max - min;
  const rawStep = range / targetTicks;
  const magnitude = Math.pow(10, Math.floor(Math.log10(rawStep)));
  const normalized = rawStep / magnitude;

  let stepFraction: number;
  if (normalized < 1.5) {
    stepFraction = 1;
  } else if (normalized < 3) {
    stepFraction = 2;
  } else if (normalized < 7) {
    stepFraction = 5;
  } else {
    stepFraction = 10;
  }

  const step = stepFraction * magnitude;
  const firstTick = Math.ceil(min / step) * step;
  const lastTick = Math.floor(max / step) * step;

  const ticks: AxisTick[] = [];
  for (let val = firstTick; val <= lastTick + step * 0.001; val += step) {
    const cleanVal = cleanZero(Math.round(val * 1e6) / 1e6);
    ticks.push({
      value: cleanVal,
      formatted: Number.isInteger(cleanVal) ? cleanVal.toString() : cleanVal.toFixed(1)
    });
  }

  return ticks;
}

// ============================================================================
// PART 1: CUBIC FUNCTION ENGINE (f(x) = ax³ + bx² + cx + d)
// ============================================================================

export interface CubicAnalysis {
  a: number;
  b: number;
  c: number;
  d: number;
  deltaPrime: number;
  hasExtrema: boolean;
  cd: { x: number; y: number } | null; // Cực đại
  ct: { x: number; y: number } | null; // Cực tiểu
  inflection: { x: number; y: number }; // Điểm uốn U
  viewport: {
    xMin: number;
    xMax: number;
    yMin: number;
    yMax: number;
  };
  xTicks: AxisTick[];
  yTicks: AxisTick[];
}

export function formatCubicFormula(a: number, b: number, c: number, d: number): string {
  if (b === 0 && d === 2 && c === -27) return 'y = x³ - 27x + 2';
  if (b === 0 && d === 2 && c === -3) return 'y = x³ - 3x + 2';
  if (b === 0 && d === 0 && c === -3) return 'y = x³ - 3x';

  const aStr = a === 1 ? '' : a === -1 ? '-' : `${a}`;
  const bStr = b !== 0 ? (b > 0 ? ` + ${b === 1 ? '' : b}x²` : ` - ${Math.abs(b) === 1 ? '' : Math.abs(b)}x²`) : '';
  const cStr = c !== 0 ? (c > 0 ? ` + ${c === 1 ? '' : c}x` : ` - ${Math.abs(c) === 1 ? '' : Math.abs(c)}x`) : '';
  const dStr = d !== 0 ? (d > 0 ? ` + ${d}` : ` - ${Math.abs(d)}`) : '';
  return `y = ${aStr}x³${bStr}${cStr}${dStr}`;
}

export function analyzeCubicFunction(a: number, b: number, c: number, d: number): CubicAnalysis {
  const f = (x: number) => a * x * x * x + b * x * x + c * x + d;

  // Điểm uốn: xU = -b / (3a)
  const rawXU = -b / (3 * a);
  const xU = cleanZero(rawXU);
  const yU = cleanZero(f(xU));
  const inflection = { x: xU, y: yU };

  // Đạo hàm f'(x) = 3ax² + 2bx + c = 0
  // delta' = b² - 3ac
  const deltaPrime = b * b - 3 * a * c;

  let cd: { x: number; y: number } | null = null;
  let ct: { x: number; y: number } | null = null;
  const hasExtrema = deltaPrime > 1e-7;

  let xMin: number;
  let xMax: number;
  let yMin: number;
  let yMax: number;

  if (hasExtrema) {
    const sqrtD = Math.sqrt(deltaPrime);
    const r1 = (-b - sqrtD) / (3 * a);
    const r2 = (-b + sqrtD) / (3 * a);
    const xLeft = cleanZero(Math.min(r1, r2));
    const xRight = cleanZero(Math.max(r1, r2));

    const yLeft = cleanZero(f(xLeft));
    const yRight = cleanZero(f(xRight));

    if (a > 0) {
      cd = { x: xLeft, y: yLeft };
      ct = { x: xRight, y: yRight };
    } else {
      ct = { x: xLeft, y: yLeft };
      cd = { x: xRight, y: yRight };
    }

    // Khoảng cách giữa 2 cực trị
    const dxExtrema = Math.max(0.5, xRight - xLeft);
    const yMinExtrema = Math.min(yLeft, yRight, yU, 0);
    const yMaxExtrema = Math.max(yLeft, yRight, yU, 0);
    const dyExtrema = Math.max(1, yMaxExtrema - yMinExtrema);

    // Padding sư phạm:
    // Trục Ox: cực trị cách mép 25-30% để nhìn rõ nhánh tăng/giảm bên ngoài
    const xMargin = Math.max(1.5, dxExtrema * 0.55);
    xMin = cleanZero(xLeft - xMargin);
    xMax = cleanZero(xRight + xMargin);

    // Trục Oy: thêm margin 18-25%
    const yMargin = Math.max(2, dyExtrema * 0.22);
    yMin = cleanZero(yMinExtrema - yMargin);
    yMax = cleanZero(yMaxExtrema + yMargin);
  } else {
    // Không có cực trị (đơn điệu trên R)
    xMin = cleanZero(xU - 4);
    xMax = cleanZero(xU + 4);
    const yLeft = f(xMin);
    const yRight = f(xMax);
    const yLow = Math.min(yLeft, yRight, yU);
    const yHigh = Math.max(yLeft, yRight, yU);
    const dy = Math.max(4, yHigh - yLow);
    yMin = cleanZero(yLow - dy * 0.15);
    yMax = cleanZero(yHigh + dy * 0.15);
  }

  // Đảm bảo bao trùm trục tọa độ (x=0 và y=0) một cách tự nhiên nếu nằm gần
  if (xMin > -0.8 && xMin < 0) xMin = -1;
  if (xMax < 0.8 && xMax > 0) xMax = 1;
  if (yMin > -1 && yMin < 0) yMin = -2;
  if (yMax < 1 && yMax > 0) yMax = 2;

  // Sinh Nice Ticks
  const xTicks = generateNiceTicks(xMin, xMax, 6);
  const yTicks = generateNiceTicks(yMin, yMax, 6);

  return {
    a,
    b,
    c,
    d,
    deltaPrime,
    hasExtrema,
    cd,
    ct,
    inflection,
    viewport: { xMin, xMax, yMin, yMax },
    xTicks,
    yTicks
  };
}

/**
 * Dense Smooth Sampling for Cubic Function (600 points for zero polygon stepping)
 */
export function sampleCubicCurve(
  a: number,
  b: number,
  c: number,
  d: number,
  xMin: number,
  xMax: number,
  yMin: number,
  yMax: number,
  mapX: (x: number) => number,
  mapY: (y: number) => number,
  steps = 600
): string {
  const f = (x: number) => a * x * x * x + b * x * x + c * x + d;
  const dx = (xMax - xMin) / steps;
  const points: string[] = [];

  const yBuffer = (yMax - yMin) * 0.2;
  const minYBound = yMin - yBuffer;
  const maxYBound = yMax + yBuffer;

  for (let i = 0; i <= steps; i++) {
    const x = xMin + i * dx;
    const rawY = f(x);
    const clampedY = Math.max(minYBound, Math.min(maxYBound, rawY));
    const px = mapX(x).toFixed(2);
    const py = mapY(clampedY).toFixed(2);
    points.push(`${i === 0 ? 'M' : 'L'} ${px} ${py}`);
  }

  return points.join(' ');
}

// ============================================================================
// PART 2: RATIONAL FUNCTION ENGINE (f(x) = (ax + b) / (cx + d))
// ============================================================================

export interface RationalAnalysis {
  a: number;
  b: number;
  c: number;
  d: number;
  hasVerticalAsymptote: boolean;
  hasHorizontalAsymptote: boolean;
  xAsymptote: number; // TCĐ: x = -d / c
  yAsymptote: number; // TCN: y = a / c
  centerI: { x: number; y: number }; // Tâm đối xứng I
  derivativeSign: number; // ad - bc
  viewport: {
    xMin: number;
    xMax: number;
    yMin: number;
    yMax: number;
  };
  xTicks: AxisTick[];
  yTicks: AxisTick[];
}

export function formatRationalFormula(a: number, b: number, c: number, d: number): string {
  // Numerator: ax + b
  let numStr = '';
  if (a !== 0) {
    const aCoeff = a === 1 ? 'x' : a === -1 ? '-x' : `${a}x`;
    if (b === 0) {
      numStr = aCoeff;
    } else {
      numStr = `${aCoeff} ${b > 0 ? `+ ${b}` : `- ${Math.abs(b)}`}`;
    }
  } else {
    numStr = `${b}`;
  }

  // Denominator: cx + d (c > 0)
  let denStr = '';
  const cCoeff = c === 1 ? 'x' : c === -1 ? '-x' : `${c}x`;
  if (d === 0) {
    denStr = cCoeff;
  } else {
    denStr = `${cCoeff} ${d > 0 ? `+ ${d}` : `- ${Math.abs(d)}`}`;
  }

  if (a === 0 && d === 0) {
    return `y = ${b}/${denStr}`;
  }
  if (a === 0) {
    return `y = ${b}/(${denStr})`;
  }
  return `y = (${numStr})/(${denStr})`;
}

export function analyzeRationalFunction(a: number, b: number, c: number, d: number): RationalAnalysis {
  // Chuẩn hóa c > 0 nếu có thể
  let na = a;
  let nb = b;
  let nc = c;
  let nd = d;
  if (nc < 0) {
    na = -a;
    nb = -b;
    nc = -c;
    nd = -d;
  }
  if (nc === 0) {
    nc = 1;
  }

  const rawXAsymptote = -nd / nc;
  const rawYAsymptote = na / nc;
  const xAsymptote = cleanZero(rawXAsymptote);
  const yAsymptote = cleanZero(rawYAsymptote);
  const centerI = { x: xAsymptote, y: yAsymptote };
  const derivativeSign = na * nd - nb * nc;

  // Viewport định hình quanh tâm đối xứng I
  const xSpan = Math.max(4.5, Math.abs(xAsymptote) + 2.5);
  const ySpan = Math.max(4.5, Math.abs(yAsymptote) + 2.5);

  const xMin = cleanZero(xAsymptote - xSpan);
  const xMax = cleanZero(xAsymptote + xSpan);
  const yMin = cleanZero(yAsymptote - ySpan);
  const yMax = cleanZero(yAsymptote + ySpan);

  const xTicks = generateNiceTicks(xMin, xMax, 6);
  const yTicks = generateNiceTicks(yMin, yMax, 6);

  return {
    a: na,
    b: nb,
    c: nc,
    d: nd,
    hasVerticalAsymptote: true,
    hasHorizontalAsymptote: true,
    xAsymptote,
    yAsymptote,
    centerI,
    derivativeSign,
    viewport: { xMin, xMax, yMin, yMax },
    xTicks,
    yTicks
  };
}

/**
 * Adaptive Boundary-Accurate Sampling for Rational Function
 * Generates TWO independent SVG path strings (left branch & right branch)
 * Strictly zero connection across the vertical asymptote!
 * Computes exact boundary intersections so curves terminate directly on viewport edges.
 */
export function sampleRationalBranches(
  a: number,
  b: number,
  c: number,
  d: number,
  xMin: number,
  xMax: number,
  yMin: number,
  yMax: number,
  mapX: (x: number) => number,
  mapY: (y: number) => number
): { leftPath: string; rightPath: string } {
  const xAsymptote = -d / c;
  const det = a * d - b * c; // ad - bc
  const f = (x: number) => (a * x + b) / (c * x + d);

  // Exact inverse mapping: solve f(x) = Y => x = (b - d*Y) / (c*Y - a)
  const getXForY = (Y: number): number | null => {
    const denom = c * Y - a;
    if (Math.abs(denom) < 1e-9) return null;
    return (b - d * Y) / denom;
  };

  // Determine branch domain boundaries based on viewport [xMin, xMax] x [yMin, yMax]
  let leftXStart = xMin;
  let leftXEnd = xAsymptote - 0.01;
  let rightXStart = xAsymptote + 0.01;
  let rightXEnd = xMax;

  if (det < 0) {
    // Left branch decreases to -inf => hits yMin
    const xBottom = getXForY(yMin);
    if (xBottom !== null && xBottom < xAsymptote) {
      leftXEnd = Math.max(leftXStart, Math.min(xAsymptote - 0.001, xBottom));
    }
    // Right branch decreases from +inf => hits yMax
    const xTop = getXForY(yMax);
    if (xTop !== null && xTop > xAsymptote) {
      rightXStart = Math.min(rightXEnd, Math.max(xAsymptote + 0.001, xTop));
    }
  } else if (det > 0) {
    // Left branch increases to +inf => hits yMax
    const xTop = getXForY(yMax);
    if (xTop !== null && xTop < xAsymptote) {
      leftXEnd = Math.max(leftXStart, Math.min(xAsymptote - 0.001, xTop));
    }
    // Right branch increases from -inf => hits yMin
    const xBottom = getXForY(yMin);
    if (xBottom !== null && xBottom > xAsymptote) {
      rightXStart = Math.min(rightXEnd, Math.max(xAsymptote + 0.001, xBottom));
    }
  }

  // Smooth dense sampling (300 points per branch)
  const sampleBranch = (xStart: number, xEnd: number, isRightBranch: boolean): string => {
    if (xStart >= xEnd) return '';
    const points: string[] = [];
    const count = 300;

    for (let i = 0; i <= count; i++) {
      const t = i / count;
      let x: number;

      if (!isRightBranch) {
        // Left branch: cluster points near xEnd (asymptote side)
        const warpedT = 1 - Math.pow(1 - t, 2.2);
        x = xStart + warpedT * (xEnd - xStart);
      } else {
        // Right branch: cluster points near xStart (asymptote side)
        const warpedT = Math.pow(t, 2.2);
        x = xStart + warpedT * (xEnd - xStart);
      }

      const y = f(x);
      if (Number.isFinite(y)) {
        const px = mapX(x).toFixed(2);
        const py = mapY(y).toFixed(2);
        points.push(`${i === 0 ? 'M' : 'L'} ${px} ${py}`);
      }
    }

    return points.join(' ');
  };

  const leftPath = sampleBranch(leftXStart, leftXEnd, false);
  const rightPath = sampleBranch(rightXStart, rightXEnd, true);

  return { leftPath, rightPath };
}

// ============================================================================
// PART 3: QUADRATIC FUNCTION ENGINE (PARABOLA: f(x) = ax² + bx + c)
// ============================================================================

export interface QuadraticAnalysis {
  a: number;
  b: number;
  c: number;
  vertex: { x: number; y: number }; // Đỉnh I(xV; yV)
  axisOfSymmetry: number; // Trục đối xứng x = -b / (2a)
  viewport: {
    xMin: number;
    xMax: number;
    yMin: number;
    yMax: number;
  };
  xTicks: AxisTick[];
  yTicks: AxisTick[];
}

export function formatQuadraticFormula(a: number, b: number, c: number): string {
  if (a === 1 && b === 0 && c === 0) return 'y = x²';
  const aStr = a === 1 ? '' : a === -1 ? '-' : `${a}`;
  const bStr = b !== 0 ? (b > 0 ? ` + ${b === 1 ? '' : b}x` : ` - ${Math.abs(b) === 1 ? '' : Math.abs(b)}x`) : '';
  const cStr = c !== 0 ? (c > 0 ? ` + ${c}` : ` - ${Math.abs(c)}`) : '';
  return `y = ${aStr}x²${bStr}${cStr}`;
}

export function analyzeQuadraticFunction(a: number, b: number, c: number): QuadraticAnalysis {
  const safeA = a === 0 ? 1 : a;
  const f = (x: number) => safeA * x * x + b * x + c;

  const rawXV = -b / (2 * safeA);
  const xV = cleanZero(rawXV);
  const yV = cleanZero(f(xV));
  const vertex = { x: xV, y: yV };
  const axisOfSymmetry = xV;

  let xMin: number;
  let xMax: number;
  let yMin: number;
  let yMax: number;

  const xSpan = 3.5;
  xMin = cleanZero(xV - xSpan);
  xMax = cleanZero(xV + xSpan);

  if (safeA > 0) {
    // Parabola quay bề lõm lên trên, đỉnh I là điểm thấp nhất
    yMin = cleanZero(yV - 1.2);
    yMax = cleanZero(yV + 8.5);
  } else {
    // Parabola quay bề lõm xuống dưới, đỉnh I là điểm cao nhất
    yMax = cleanZero(yV + 1.2);
    yMin = cleanZero(yV - 8.5);
  }

  // Đảm bảo bao trùm trục tọa độ nếu gần
  if (xMin > -0.8 && xMin < 0) xMin = -1;
  if (xMax < 0.8 && xMax > 0) xMax = 1;
  if (yMin > -1 && yMin < 0) yMin = -2;
  if (yMax < 1 && yMax > 0) yMax = 2;

  const xTicks = generateNiceTicks(xMin, xMax, 6);
  const yTicks = generateNiceTicks(yMin, yMax, 6);

  return {
    a: safeA,
    b,
    c,
    vertex,
    axisOfSymmetry,
    viewport: { xMin, xMax, yMin, yMax },
    xTicks,
    yTicks
  };
}

/**
 * Dense Smooth Sampling for Quadratic Function (Parabola)
 */
export function sampleQuadraticCurve(
  a: number,
  b: number,
  c: number,
  xMin: number,
  xMax: number,
  yMin: number,
  yMax: number,
  mapX: (x: number) => number,
  mapY: (y: number) => number,
  steps = 400
): string {
  const safeA = a === 0 ? 1 : a;
  const f = (x: number) => safeA * x * x + b * x + c;

  // Exact entry/exit calculation: f(x) = yBorder => safeA*(x - xV)^2 + yV = yBorder
  const xV = -b / (2 * safeA);
  const yV = f(xV);

  let activeXMin = xMin;
  let activeXMax = xMax;

  if (safeA > 0) {
    const deltaY = yMax - yV;
    if (deltaY > 0) {
      const halfW = Math.sqrt(deltaY / safeA);
      activeXMin = Math.max(xMin, xV - halfW);
      activeXMax = Math.min(xMax, xV + halfW);
    }
  } else {
    const deltaY = yV - yMin;
    if (deltaY > 0) {
      const halfW = Math.sqrt(deltaY / Math.abs(safeA));
      activeXMin = Math.max(xMin, xV - halfW);
      activeXMax = Math.min(xMax, xV + halfW);
    }
  }

  const dx = (activeXMax - activeXMin) / steps;
  const points: string[] = [];

  for (let i = 0; i <= steps; i++) {
    const x = activeXMin + i * dx;
    const y = f(x);
    const px = mapX(x).toFixed(2);
    const py = mapY(y).toFixed(2);
    points.push(`${i === 0 ? 'M' : 'L'} ${px} ${py}`);
  }

  return points.join(' ');
}
